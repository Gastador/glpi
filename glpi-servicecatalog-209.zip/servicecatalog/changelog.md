# Changelog

##GLPI 9.1
### [1.0.0]
* Création du plugin
### [1.0.1]
##### Added
* Ajout de liaison avec la base de connaissances.
* Ajout de détails dans l’interface d’affichage des catégories
##GLPI 9.2
### [1.3.0] 
##### Changed
* Mise à jour du plugin
### [1.3.1]
##### Added
* Ajout de thème avec différentes palettes de couleur pour l’interface du plugin (blue, red, grey)
### [1.3.2]
##### Added
* Ajout de deux modes de vue de l’interface principale (Classique ou vertical)
### [1.3.3]
##### Added
* Ajout d’une configuration pour le choix des titres dans la barre de recherche
### [1.3.4]
##### Added
* Ajout de la fonctionnalité d’un dashboard avec la possibilité de choisir l’interface d’accueil avec une liste de widgets (Widgets d’affichage des contacts, Vos incidents en cours, Vos demandes en cours, Vos tickets à clore, Vos tickets en cour par statut, Information, Supervision du réseau, Maintenances planifiées prévues, Statistiques globales, Message d’accueil).
* Ajout d’un widget de réservation
* Ajout d’une configuration pour afficher le logo dans les détails des catégories
### [1.3.5]
##### Added
* Ajout d’une configuration dans le gabarit de ticket pour ajouter des champs (Impact, Temps de résolution, Demande de validation) dans le formulaire de création de ticket du plugin en interface standard.
### [1.3.6]
##### Added
* Changement de l’interface de sélection de l’entité 
* Ajout d’une nouvelle palette « DarkBlue »
### [1.3.7]
##### Changed
* Cacher le lien « Autres informations » si le contenu est vide
##GLPI 9.3
### [1.4.0]
##### Changed
* Mise à jour du plugin
### [1.4.1]
##### Changed
* Ajout d’un compteur de ticket dans le titre du widget
### [1.4.2]
##### Added
* Ajout de la liaison avec le plugin Formcreator
* Masquage des widgets du plugin MyDashboard si le contenu est vide.
### [1.4.4]
##### Added
* Ajout de la liaison avec le plugin metademand avec l'ajout des champs application et environnement
### [1.4.5]
##### Added
* Ajout de la configuration de l'ordonnancement des sous catégories
* Ajout de la configuration de l'ordonnancement des champs du formulaire de ticket
* Ajout de configurations pour personnaliser l’interface de servicecatalog : <br />
    - Taille des catégories<br />
    - configuration d'images<br />
    - Activer / Désactiver les mots clés<br />
    - Personnaliser les colonnes à afficher et l'ordre des colonnes pour les tableaux de bord
    - Interface simplifié pour la lecture des tickets 
    - Customisations des couleurs des boutons des urgences et des impacts
##### Changed
* Changement pour le moteur de recherche, utilisation du mot clé "+" pour affiner la recherche
### [1.4.6]
##### Added
* Ajout configurations lié à l'affichage de l'interface simplifié
* Masquer les différents boutons : langue, Profil, Aide, Recherches sauvegardés, deconnexion.
* Masquer le suivi par mail
##### Changed
* Mises a jour interfaces
* Modification du comportement de la configuration "Supprimer le bouton accueil pour l'utilisateur final" :
Ne supprime plus le lien mais défini comme lien l'url de l'accueil de servicecatalog.
### [1.4.7]
##### Changed
* Correction problème de chargement des champs supplémentaires
