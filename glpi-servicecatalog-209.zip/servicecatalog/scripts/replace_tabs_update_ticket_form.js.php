<?php
include("../../../inc/includes.php");
//change mimetype
header("Content-type: application/javascript");

if (Plugin::isPluginActive("servicecatalog")) {
    if (isset($_SERVER['HTTP_REFERER'])
        && strpos($_SERVER['HTTP_REFERER'], 'ticket.form.php') > 0) {
        $ongs = ['tab-Ticket_4',
                 'tab-KnowbaseItem_Item',
                 'tab-Item_Ticket_1',
                 'tab-Ticket_Contract_1',
                 'tab-Itil_Project_1',
                 'tab-Problem_Ticket_1',
                 'tab-ProjectTask_Ticket_1',
                 'tab-Change_Ticket_1',
                 'tab-PluginTasklistsTicket_1',
                 'tab-Impact_1',
                 'tab-Log_1',
                 'tab--1'];
        echo "$(function() {";
        foreach ($ongs as $ong) {
            $tab = PluginServicecatalogTicket::escapeTabName($ong);
            echo "$('a[data-bs-target^=\'#$tab\']').hide();";
        }

        echo "});";
    }
}
