<?php
use Glpi\Event;
include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>
var root_servicecatalog_doc = "<?php echo PLUGIN_SERVICECATALOG_WEBDIR; ?>";
(function ($) {
   $.fn.servicecatalog_replace_links = function () {

      init();
      var object = this;

      // Start the plugin
      function init() {
         $(document).ready(function () {
            var hrefs = $("a[href$='/front/helpdesk.public.php']");
            hrefs.each(function (href, value) {
               if (value['pathname'].indexOf('plugins') < 0) {
                  $("a[href$='" + value['pathname'] + "']").attr('href', root_servicecatalog_doc + '/front/main.form.php');
               }
            });
            var hrefs = $("a[href$='/front/helpdesk.public.php?create_ticket=1']");
            hrefs.each(function (href, value) {
               if (value['pathname'].indexOf('plugins') < 0) {
                  $("a[href$='" + value['pathname'] + "?create_ticket=1']").attr('href', root_servicecatalog_doc + '/front/main.form.php');
               }
            });
            var hrefs = $("a[href$='/front/ticket.form.php']");
            hrefs.each(function (href, value) {
               if (value['pathname'].indexOf('plugins') < 0) {
                  $("a[href$='" + value['pathname'] + "']").attr('href', root_servicecatalog_doc + '/front/main.form.php');
               }
            });
            var hrefs = $("a[href$='/front/helpdesk.faq.php']");

            hrefs.each(function (href, value) {
               if (value['pathname'].indexOf('plugins') < 0) {
                  $("a[href$='" + value['pathname'] + "']").attr('href', root_servicecatalog_doc + '/front/faq.php');
               }
            });
         });
      }

      return this;
   };
}(jQuery));

$(document).servicecatalog_replace_links();

$(document).ready(function () {
   $(".flip").click(function () {
      $(".panel").toggle();
   });
});
