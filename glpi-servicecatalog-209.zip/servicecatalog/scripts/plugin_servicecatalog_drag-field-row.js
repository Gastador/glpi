/* enable strict mode */
"use strict";

var plugin_servicecatalog_redipsInit;   // function sets dropMode parameter
var plugin_servicecatalog_redipsFields;   // function sets dropMode parameter
var plugin_servicecatalog_favoriteFields;
var plugin_servicecatalog_redipsWidgetbuttons;   // function sets dropMode parameter

// redips initialization
plugin_servicecatalog_redipsInit = function () {
    // reference to the REDIPS.drag lib
    var rd = REDIPS.drag;
    // initialization
    rd.init();

    rd.event.rowDroppedBefore = function (sourceTable, sourceRowIndex) {
        var pos = rd.getPosition();
        var old_index = sourceRowIndex;
        var new_index = pos[1];
        var container = document.getElementById('type').value;
        var entity = document.getElementById('entity').value;
        var parent = document.getElementById('parent_id').value;

        jQuery.ajax({
            type: "POST",
            url: "../ajax/reorder.php",
            data: {
                old_order: old_index,
                new_order: new_index,
                container_id: container,
                entities_id: entity,
                parent_id: parent
            }
         })
            .fail(function () {
                return false;
            });
    }
};

plugin_servicecatalog_redipsFields = function () {
    // reference to the REDIPS.drag lib
    var rd = REDIPS.drag;
    // initialization
    rd.init();

    rd.event.rowDroppedBefore = function (sourceTable, sourceRowIndex) {
        var pos = rd.getPosition();
        var old_index = sourceRowIndex;
        var new_index = pos[1];

        jQuery.ajax({
            type: "POST",
            url: "../ajax/reorderFields.php",
            data: {
                old_order: old_index,
                new_order: new_index
            }
         })
            .fail(function () {
                return false;
            });
    }
};

plugin_servicecatalog_redipsWidgetbuttons = function () {
    // reference to the REDIPS.drag lib
    var rd = REDIPS.drag;
    // initialization
    rd.init();

    rd.event.rowDroppedBefore = function (sourceTable, sourceRowIndex) {
        var pos = rd.getPosition();
        var old_index = sourceRowIndex;
        var new_index = pos[1];

        jQuery.ajax({
            type: "POST",
            url: "../ajax/reorderWidgetbuttons.php",
            data: {
                old_order: old_index,
                new_order: new_index
            }
        })
           .fail(function () {
               return false;
           });
    }
};


plugin_servicecatalog_favoriteFields = function ($group) {

    var rd = REDIPS.drag;
    // initialization
    rd.init('redips-drag-' + $group);
    var fav_id = '';
    var itil_categories_id = '';
    var type_favorites = '';


    $(".redips-rowhandler").on("mouseover",".id",function () {
        let selectedRow = this.id.split('-');
        fav_id= selectedRow[0];
        itil_categories_id= selectedRow[1];
        type_favorites = selectedRow[2];
    });


    rd.event.rowDroppedBefore = function (sourceTable, sourceRowIndex) {
        var pos = rd.getPosition();
        var old_index = sourceRowIndex;
        var new_index = pos[1];
        var users_id = $('.users_id').val();

        jQuery.ajax({
            type: "POST",
            url: "../ajax/reorderFields.php",
            data: {
                old_order: old_index,
                new_order: new_index,
                users_id: users_id,
                favorites_users_id: fav_id,
                itil_categories_id: itil_categories_id,
                type_favorites: type_favorites
            }
        })
            .fail(function () {
                return false;
            });
    }
};


