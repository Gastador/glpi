<?php
use Glpi\Event;

include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>

var display = "<?php
if (Session::getCurrentInterface() == "central") {
    $config = new PluginServicecatalogConfig();
    if ($config->showIndicators() == 1) {
        PluginServicecatalogIndicator::displayIndicator("PluginServicecatalogIndicator3", [], false);
    }
} else {
    echo false;
}
?>";

$('.ms-md-4').before(display);


function pluginServiceCatalogAdd(toupdate, url, itil_categories_id) {

    var index = $('#plugin_servicecatalog_keywords tr').length;
    $.ajax({
        type: "POST",
        url: url,
        data: {
            "itil_categories_id": itil_categories_id,
            "index": index,
            "action": "plugin_servicecatalog_add_keywords"
        },
        success: function (json) {
            $('#' + toupdate).before(json);
        }
    });
}


function pluginServiceCatalogKnowbaseItemAdd(toupdate, url, itil_categories_id) {

    var index = $('#plugin_servicecatalog_keywords tr').length;
    $.ajax({
        type: "POST",
        url: url,
        data: {
            "itil_categories_id": itil_categories_id,
            "index": index,
            "action": "plugin_servicecatalog_add_keywords"
        },
        success: function (json) {
            $('#' + toupdate).before(json);
        }
    });
}

function pluginServiceCatalogAddGroup(toupdate, url, itil_categories_id) {

    var index = $('#plugin_servicecatalog_groups tr').length;
    $.ajax({
        type: "POST",
        url: url,
        data: {
            "itil_categories_id": itil_categories_id,
            "index": index,
            "action": "plugin_servicecatalog_add_groups"
        },
        success: function (json) {
            $('#' + toupdate).before(json);
        }
    });
}

function pluginServiceCatalogDelete(toupdate) {

    $('#' + toupdate).parent().remove();

}
