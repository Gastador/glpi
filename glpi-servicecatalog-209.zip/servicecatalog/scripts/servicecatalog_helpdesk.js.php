<?php
use Glpi\Event;

include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>


function remove_notif() {
    var notifs = $("[id^='notif_']");
    for (var key = 0; key < notifs.length; key++) {
        notifs[key].style.display = 'none';
    }
}
