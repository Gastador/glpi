<?php
//use Glpi\Event;
//include('../../../inc/includes.php');
//header('Content-Type: text/javascript');
//
////$display = ;
//?>
//
//var root_servicecatalog_doc = "<?php //echo PLUGIN_SERVICECATALOG_WEBDIR; ?>//";
////var layout = "<?php ////echo $_SESSION['page_layout']; ?>////";
//var title_search = "<?php //echo __('My search', 'servicecatalog') ?>//";
//
//jQuery(document).ready(function ($) {
//    //CSS
//    //if (layout == 'vsplit') {
//    //    $('#footer').css({'position': 'fixed'});
//    //}
//
//// Initialize search bar
//    searchInput = $('#plugin_servicecatalog_searchBar input:first');
//    currentType = $('#plugin_servicecatalog_searchBar input:eq(1)');
//    sclayout = $('#plugin_servicecatalog_searchBar input:eq(2)');
//    new_page = $('#plugin_servicecatalog_searchBar input:eq(3)');
//    currentType_id = currentType.val();
//    sclayout_id = sclayout.val();
//    new_page_id = new_page.val();
//
//    $('input[type=search]').on('search', function () {
//
//        updateFormsView(currentType_id);
//    });
//    if (searchInput.length == 1) {
//        // Dynamically update forms and faq items while the user types in the search bar
//        var timer;
//        searchInput.change(
//            function (event) {
//                if (typeof timer != "undefined") {
//                    clearTimeout(timer);
//                }
//                keywords = searchInput.val();
//
//                if (event.which == 13) {
//                    updateFormsView(currentType_id);
//                } else {
//                    timer = setTimeout(function () {
//                        updateFormsView(currentType_id);
//                        //console.log(keywords);
//                    }, 300);
//                }
//
//            }
//        );
//        searchInput.keyup(
//            function (event) {
//                if (typeof timer != "undefined") {
//                    clearTimeout(timer);
//                }
//                keywords = searchInput.val();
//
//                if (event.which == 13) {
//                    updateFormsView(currentType_id);
//                } else {
//                    timer = setTimeout(function () {
//                        updateFormsView(currentType_id);
//                        //console.log(keywords);
//                    }, 300);
//                }
//
//            }
//        );
//        // Clear the search bar if it gains focus
//        $('#plugin_servicecatalog_searchBar input').focus(function (event) {
//            if (searchInput.val() && searchInput.val().length > 0) {
//                searchInput.val('');
//
//                updateFormsView(currentType_id);
////                $.when(getFormItems(0)).then(
////                    function (response) {
////                        titles = response;
//////                  console.log(titles);
////                        showTitles(titles.forms, currentType_id);
////                    }
////                );
//            }
//        });
//    }
//
//});
//
//
//function getFormItems(typeId) {
//    currentType = typeId;
//    keywords = $('#plugin_servicecatalog_searchBar input:first').val();
//    deferred = jQuery.Deferred();
//    $.ajax({
//        url: root_servicecatalog_doc + '/ajax/homepage_search.php',
//        data: {search: 'categories', typesId: typeId, keywords: keywords},
//        type: "GET",
//        dataType: "json"
//    }).done(function (response) {
//        deferred.resolve(response);
//    }).fail(function () {
//        deferred.reject();
//    });
//    return deferred.promise();
//}
//
//function updateFormsView(typeId) {
//    $.when(getFormItems(typeId)).done(
//        function (response) {
//            titles = response.forms;
//            //console.log('result');
//            //console.log(titles);
//            showTitles(titles, response.default, typeId);
//        }
//    ).fail(
//        function () {
//            html = '<div class="alert alert-danger" role="alert"><?php //echo __('An error occured while querying categories', 'servicecatalog')?>//</div>';
//            $('#plugin_servicecatalog_results').empty();
//            $('#plugin_servicecatalog_results').prepend(html);
//
//        }
//    );
//}
//
//function showTitles(titles, defaultForms, typeId) {
//    //tiles = sortFormAndFaqItems(tiles, sortByName);
//    html = '';
//    if (defaultForms) {
//        html += '<div class="alert alert-warning" role="alert"><?php //echo __('No category found. Please choose a category below instead', 'servicecatalog')?>//</div>';
//    }
//    html += buildTitles(titles, typeId);
//
//    //Display titles
//    $('#plugin_servicecatalog_results').empty();
//    $('#plugin_servicecatalog_results').prepend(html);
//}
//
//function buildTitles(list, typeId) {
//
//    if (list.length == 0) {
//        //html = '<p><?php ////echo __('No category found. Please choose a category below instead', 'servicecatalog')?>////</p>';
//    } else {
//        var items = [];
//        $.each(list, function (key, cat) {
//            // Build a HTML tile
//            var parent = "";
//            if (cat.itilcategories_id > 0) {
//                parent = '&choose_category=' + cat.parent;
//            }
//            url_details = '';
//            if ((typeId == 1 && cat.is_incident == 1) || (typeId == 2 && cat.is_request == 1)) {
//                if ((sclayout_id == 3 || sclayout_id == 4) && new_page_id == 0) {
//                    url = root_servicecatalog_doc + '/ajax/newticket.form.php?create_ticket&type=' + typeId + '&category_id=' + cat.id;
//                    url_details = root_servicecatalog_doc + '/ajax/showdetails.php?showalerts&category_id=' + cat.id;
//                } else {
//                    url = root_servicecatalog_doc + '/front/newticket.form.php?type=' + typeId + '&category_id=' + cat.id;
//                }
//            } else {
//                url = root_servicecatalog_doc + '/front/choosecategory.form.php?type=' + typeId + '&level=' + 1 + '&category_id=' + cat.id;
//            }
//            var title;
//            if (cat.title == "") {
//                title = "N/A";
//            } else {
//                title = cat.name;
//                var length = 50;
//                if (title.length > length) {
//                   title = title.substring(0, length);
//                   title = title + ' (...)';
//                }
//
//            }
//            var completename;
//            if (cat.completename == "") {
//                completename = "N/A";
//            } else {
//                completename = cat.completename;
//            }
//           var simplified_name_incident;
//           if (cat.simplified_name_incident != null && cat.simplified_name_incident != "" && typeId == 1) {
//              title = cat.simplified_name_incident;
//           }
//           var simplified_name_request;
//           if (cat.simplified_name_request != null && cat.simplified_name_request != "" && typeId == 2) {
//              title = cat.simplified_name_request;
//           }
//
//
//            comment = "";
//            if (cat.comment) {
//                if (cat.comment.length >= 255) {
//                    comment = cat.comment.substr(0, 255) + ' (...)';
//                } else {
//                    comment = cat.comment;
//                }
//            }
//           sclayout = $('#plugin_servicecatalog_searchBar input:eq(2)');
//           sclayout_id = sclayout.val();
//            if (sclayout_id == 0) {
//                items.push(
//                    '<div class="plugin_servicecatalog_formTitle_0"><ul style="list-style-type: none;">'
//                    + '<li><a class="title_search" href="' + url + '"><div class="favsc-normal child-nav card">')
//                if (cat.picture.length > 0) {
//                    items.push('<img class="sly-btn-img" src= "' + root_servicecatalog_doc + '/front/document.send.php?file=_plugins/' + cat.picture + '">')
//                } else {
//                    items.push('<i class="sc-fa-color sly-btn-i sc-fa-color fas '
//                        + cat.icon
//                        + ' fa-4x" '
//                        + 'style="background-color: '
//                        + cat.background_color
//                        + '!important;"'
//                        + ' title="' + cat.completename + '"></i>')
//                }
//                items.push(
//                    '<span class="label_title bottom_title" style="color: '
//                    + cat.background_color
//                    + '!important;font-size: 12px;">'
//                   + '<i class="fas fa-caret-right sc-fa-color fa-2x" '
//                   + 'style="color: '
//                   + cat.background_color
//                   + '!important;'
//                   + '"></i>'
//                   + '&nbsp;'
//                    + title
//                    + '</span>'
//                    + '</li></ul></div></a>'
//                );
//            } else if (sclayout_id == 1) {
//                items.push(
//                    '<div class="plugin_servicecatalog_formTitle_1">'
//                    + '<a class="subcat" href="' + url + '" id="launchcat'
//                    + cat.id
//                    + '" title="' + title + '">'
//                    + '<div class="favsc-normal " id="launchcat'
//                    + cat.id
//                    + '" style="background: '
//                    + cat.background_color
//                    + ';border: none !important;"   title="' + cat.completename + '">')
//                if (cat.picture.length > 0) {
//                    items.push('<img class="bt-img-responsive" src= "' + root_servicecatalog_doc + '/front/document.send.php?file=_plugins/' + cat.picture + '">')
//                } else {
//                    items.push('<i class="fas-sc fav-small sc-fa-color '
//                        + cat.icon
//                        + ' fa-4x" '
//                        //+ 'style="color: '
//                        //+ cat.background_color
//                        //+ '!important;'
//                        + ' title="' + cat.completename + '"></i>')
//                }
//                items.push(
//                    '<br><br>'
//                    + '<span class="label_firsttitle bottom_title" '
//                    + 'style="color: '
//                    //+ cat.background_color
//                    //+ '!important;'
//                    + '"   title="' + cat.completename + '">'
//                    + '<i class="fas fa-caret-right sc-fa-color fa-2x" '
//                    + 'style="color: '
//                    //+ cat.background_color
//                    //+ '!important;'
//                    + '"></i>'
//                    + '&nbsp;'
//                    + title
//                    + '</span>'
//                    //+ '<span class="label bottom"><br><br>'
//                    //+ comment
//                    //+ '<span>'
//                    + '</div>'
//                    + '</a>'
//                    + '</div>'
//                );
//            } else if (sclayout_id == 2) {
//
//                items.push(
//                    '<div class="plugin_servicecatalog_formTitle_1">'
//                    + '<a class="subcat" href="' + url + '" id="launchcat'
//                    + cat.id
//                    + '" title="' + title + '">'
//                    + '<div class="favsc-normal child-nav " id="cat'
//                    + cat.id
//                    + '"   title="' + cat.completename + '">')
//                if (cat.picture.length > 0) {
//                    items.push('<img class="bt-img-responsive" src= "' + root_servicecatalog_doc + '/front/document.send.php?file=_plugins/' + cat.picture + '">')
//                } else {
//                    items.push('<i class="fas-sc sc-fa-color fas '
//                        + cat.icon
//                        + ' fa-4x" '
//                        + 'style="color: '
//                        + cat.background_color
//                        + '!important;'
//                        + '"'
//                        + ' title="' + cat.completename + '"></i>')
//                }
//                items.push(
//                     '<br><br>'
//                    + '<span class="label_title bottom_title" '
//                    + 'style="color: '
//                    + cat.background_color
//                    + '!important;'
//                    + '"  title="' + cat.completename + '">'
//                    + '<i class="fas fa-caret-right sc-fa-color fa-2x" '
//                    + 'style="color: '
//                    + cat.background_color
//                    + '!important;'
//                    + '"></i>'
//                    + '&nbsp;'
//                    + title
//                    + '</span>'
//                    //+ '<span class="label bottom"><br><br>'
//                    //+ comment
//                    //+ '<span>'
//                    + '</div>'
//                    + '</a>'
//                    + '</div>'
//                );
//            } else if (sclayout_id == 3) {
//
//                items.push(
//                    '<div class="plugin_servicecatalog_formTitle_3">'
//                    + '<a class="subcat" href="#" id="launchcat'
//                    + cat.id
//                    + '" title="' + title + '">'
//                    + '<div class="searchsc-normal child-nav " id="cat'
//                    + cat.id
//                    + '"   title="' + cat.completename + '">')
//                if (cat.picture.length > 0) {
//                    items.push('<img class="bt-img-responsive" src= "' + root_servicecatalog_doc + '/front/document.send.php?file=_plugins/' + cat.picture + '">')
//                } else {
//                    items.push('<i class="fas-sc sc-fa-color fas '
//                        + cat.icon
//                        + ' fa-3x thumbnail" '
//                        + 'style="color: '
//                        + cat.background_color
//                        + '!important;'
//                        + '"'
//                        + ' title="' + cat.completename + '"></i>')
//                }
//                items.push('<br><br>'
//                    + '<span class="label_title bottom_title" '
//                    + 'style="color: '
//                    + cat.background_color
//                    + '!important;'
//                    + '"  title="' + cat.completename + '">'
//                    + '<i class="fas fa-caret-right sc-fa-color fa-2x" '
//                    + 'style="color: '
//                    + cat.background_color
//                    + '!important;'
//                    + '"></i>'
//                    + '&nbsp;'
//                    + title
//                    + '</span>'
//                    //+ '<span class="label bottom"><br><br>'
//                    //+ comment
//                    //+ '<span>'
//                    + '</div>'
//                    + '</a>'
//                    + '</div>'
//                    + '<script>'
//                    + '$("#launchcat'
//                    + cat.id
//                    + '").click(function() {'
//                    //+ 'console.log("js1");'
//                    + 'if ('
//                    + sclayout_id
//                    + '== 3 ) {'
//                    + 'if ('
//                    + new_page_id
//                    + '== 0 ) {'
//                    + '$(\'li[id^=\"launchcat\"]\').removeClass(\'first-btnsc-normal\').addClass(\'btnsc-normal\');'
//                    + '$(\'div[id^=\"cats\"]\').removeClass(\'cats_firstlist\').addClass(\'cats_list\');'
//                    + '$(\'.visitedbg\').removeClass(\'visitedbg\');'
//                    + '$(".favorites_list").hide();'
//                    + '$(".events_list").hide();'
//                    + '$(".faq_articles").hide();'
//                    + '$("#launch_details").hide();'
//                    + '$("#launchcat'
//                    + cat.id
//                    + '").addClass(\'visitedbg\');'
//                    + '$("#css_ticket").show();'
//                    + '$("#launch_ticket").show();'
//                    + '$("#launch_ticket").load("'
//                    + url
//                    + '");'
//                    + '} else {'
//                    + ' window.location.href = "'
//                    + url
//                    + '";'
//                    + '}'
//                    + '}'
//                    + '})'
//                    + '</script>'
//                );
//            } else if (sclayout_id == 4) {
//
//               items.push(
//                  '<div class="plugin_servicecatalog_formTitle_3">'
//                  + '<a class="subcat" href="#" id="launchcat'
//                  + cat.id
//                  + '" title="' + title + '">'
//                  + '<div class="searchsc-normal child-nav"'
//                  + 'style="background-color: '
//                  + cat.background_color
//                  + '!important;'
//                  + '"'
//                  + 'id="cat'
//                  + cat.id
//                  + '"   title="' + cat.completename + '">')
//               if (cat.picture.length > 0) {
//                  items.push('<img class="bt-img-responsive" src= "' + root_servicecatalog_doc + '/front/document.send.php?file=_plugins/' + cat.picture + '">')
//               } else {
//                  items.push('<i class="fas-sc sc-fa-color fas '
//                     + cat.icon
//                     + ' fa-3x thumbnail" '
//                     + 'style="color: '//cat.background_color
//                     + '#FFF'
//                     + '!important;'
//                     + '"'
//                     + ' title="' + cat.completename + '"></i>')
//               }
//               items.push('<br><br>'
//                  + '<span class="label_title bottom_title" '
//                  + 'style="color: '
//                  + '#FFF'
//                  + '!important;'
//                  + '"  title="' + cat.completename + '">'
//                  + '<i class="fas fa-caret-right sc-fa-color fa-2x" '
//                  + 'style="color: '
//                  + '#FFF'
//                  + '!important;'
//                  + '"></i>'
//                  + '&nbsp;'
//                  + title
//                  + '</span>'
//                  //+ '<span class="label bottom"><br><br>'
//                  //+ comment
//                  //+ '<span>'
//                  + '</div>'
//                  + '</a>'
//                  + '</div>'
//                  + '<script>'
//                  + '$("#launchcat'
//                  + cat.id
//                  + '").click(function() {'
//                  //+ 'console.log("js1");'
//                  + 'if ('
//                  + sclayout_id
//                  + '== 4 ) {'
//                  + 'if ('
//                  + new_page_id
//                  + '== 0 ) {'
//                  + '$(\'li[id^=\"launchcat\"]\').removeClass(\'first-btnsc-normal\').addClass(\'btnsc-big\');'
//                  + '$(\'div[id^=\"cats\"]\').removeClass(\'cats_firstlist\').addClass(\'cats_list\');'
//                  + '$(\'.visitedbg\').removeClass(\'visitedbg\');'
//                  + '$(".favorites_list").hide();'
//                  + '$(".events_list").hide();'
//                  + '$(".faq_articles").hide();'
//                  + '$("#launch_details").hide();'
//                  + '$("#launchcat'
//                  + cat.id
//                  + '").addClass(\'visitedbg\');'
//                  + '$("#css_ticket").show();'
//                  + '$("#launch_ticket").show();'
//                  + '$("#launch_ticket").load("'
//                  + url
//                  + '");'
//                  + '} else {'
//                  + ' window.location.href = "'
//                  + url
//                  + '";'
//                  + '}'
//                  + '})'
//                  + '</script>'
//               );
//            } else if (sclayout_id == 5) {
//
//               items.push(
//                  '<div class="plugin_servicecatalog_formTitle_5">'
//                  + '<a class="subcat" href="#" id="launchcat'
//                  + cat.id
//                  + '" title="' + title + '">'
//                  + '<div class="searchsc-normal child-nav center" id="cat'
//                  + cat.id
//                  + '" style="min-height: 190px;box-sizing: initial;"  title="' + cat.completename + '">')
//               if (cat.picture.length > 0) {
//                  items.push('<img class="bt-img-responsive" src= "' + root_servicecatalog_doc + '/front/document.send.php?file=_plugins/' + cat.picture + '">')
//               } else {
//                  items.push('<i class="fas-sc sc-fa-color fas '
//                     + cat.icon
//                     + ' fa-5x" '
//                     //+ 'style="color: '
//                     //+ cat.background_color
//                     //+ '!important;'
//                     + '"'
//                     + ' title="' + cat.completename + '"></i>')
//               }
//               items.push('<br><br>'
//                  + '<span class="label_title bottom_title" '
//                  //+ 'style="color: '
//                  //+ cat.background_color
//                  //+ '!important;'
//                  + '"  title="' + cat.completename + '">'
//                  + '<i class="fas fa-caret-right sc-fa-color fa-2x" '
//                  //+ 'style="color: '
//                  //+ cat.background_color
//                  //+ '!important;'
//                  + '"></i>'
//                  + '&nbsp;'
//                  + title
//                  + '</span>'
//                  //+ '<span class="label bottom"><br><br>'
//                  //+ comment
//                  //+ '<span>'
//                  + '</div>'
//                  + '</a>'
//                  + '</div>'
//                  + '<script>'
//                  + '$("#launchcat'
//                  + cat.id
//                  + '").click(function() {'
//                  //+ 'console.log("js1");'
//                  //+ 'if ('
//                  //+ sclayout_id
//                  //+ '== 3 ) {'
//                  //+ 'if ('
//                  //+ new_page_id
//                  //+ '== 0 ) {'
//                  //+ '$(\'li[id^=\"launchcat\"]\').removeClass(\'first-btnsc-normal\').addClass(\'btnsc-normal\');'
//                  //+ '$(\'div[id^=\"cats\"]\').removeClass(\'cats_firstlist\').addClass(\'cats_list\');'
//                  //+ '$(\'.visitedbg\').removeClass(\'visitedbg\');'
//                  //+ '$(".favorites_list").hide();'
//                  //+ '$(".events_list").hide();'
//                  //+ '$(".faq_articles").hide();'
//                  //+ '$("#launch_details").hide();'
//                  //+ '$("#launchcat'
//                  //+ cat.id
//                  //+ '").addClass(\'visitedbg\');'
//                  //+ '$("#css_ticket").show();'
//                  //+ '$("#launch_ticket").show();'
//                  //+ '$("#launch_ticket").load("'
//                  //+ url
//                  //+ '");'
//                  //+ '} else {'
//                  + ' window.location.href = "'
//                  + url
//                  + '";'
//                  //+ '}'
//                  //+ '}'
//                  + '})'
//                  + '</script>'
//               );
//            } else if (sclayout_id == 6) {
//
//               items.push(
//                  '<div class="plugin_servicecatalog_formTitle_5">'
//                  + '<a class="subcat" href="#" id="launchcat'
//                  + cat.id
//                  + '" title="' + title + '">'
//                  + '<div class="searchsc-normal child-nav center" id="cat'
//                  + cat.id
//                  + '" style="min-height: 190px;box-sizing: initial;"  title="' + cat.completename + '">')
//               if (cat.picture.length > 0) {
//                  items.push('<img class="bt-img-responsive" src= "' + root_servicecatalog_doc + '/front/document.send.php?file=_plugins/' + cat.picture + '">')
//               } else {
//                  items.push('<i class="fas-sc sc-fa-color fas '
//                     + cat.icon
//                     + ' fa-5x" '
//                     + 'style="color: '
//                     + cat.background_color
//                     + '!important;'
//                     + '"'
//                     + ' title="' + cat.completename + '"></i>')
//               }
//               items.push('<br><br>'
//                  + '<span class="label_title bottom_title" '
//                  //BOOTSTRAPPED_COLOR
//                  + 'style="color: '
//                  + cat.background_color
//                  + '!important;'
//                  + '"  title="' + cat.completename + '">'
//                  + '<i class="fas fa-caret-right sc-fa-color fa-2x" '
//                  + 'style="color: '
//                  + cat.background_color
//                  + '!important;'
//                  + '"></i>'
//                  + '&nbsp;'
//                  + title
//                  + '</span>'
//                  //+ '<span class="label bottom"><br><br>'
//                  //+ comment
//                  //+ '<span>'
//                  + '</div>'
//                  + '</a>'
//                  + '</div>'
//                  + '<script>'
//                  + '$("#launchcat'
//                  + cat.id
//                  + '").click(function() {'
//                  //+ 'console.log("js1");'
//                  //+ 'if ('
//                  //+ sclayout_id
//                  //+ '== 3 ) {'
//                  //+ 'if ('
//                  //+ new_page_id
//                  //+ '== 0 ) {'
//                  //+ '$(\'li[id^=\"launchcat\"]\').removeClass(\'first-btnsc-normal\').addClass(\'btnsc-normal\');'
//                  //+ '$(\'div[id^=\"cats\"]\').removeClass(\'cats_firstlist\').addClass(\'cats_list\');'
//                  //+ '$(\'.visitedbg\').removeClass(\'visitedbg\');'
//                  //+ '$(".favorites_list").hide();'
//                  //+ '$(".events_list").hide();'
//                  //+ '$(".faq_articles").hide();'
//                  //+ '$("#launch_details").hide();'
//                  //+ '$("#launchcat'
//                  //+ cat.id
//                  //+ '").addClass(\'visitedbg\');'
//                  //+ '$("#css_ticket").show();'
//                  //+ '$("#launch_ticket").show();'
//                  //+ '$("#launch_ticket").load("'
//                  //+ url
//                  //+ '");'
//                  //+ '} else {'
//                  + ' window.location.href = "'
//                  + url
//                  + '";'
//                  //+ '}'
//                  //+ '}'
//                  + '})'
//                  + '</script>'
//               );
//            }
//
//        });
//
//        // concatenate all HTML parts
//        style = "";
//        if (sclayout_id == 3 || sclayout_id == 4) {
//            style = "style='padding-top:5px;'";
//        }
//       if (sclayout_id == 5) {
//          style = "style='padding-top:5px;margin-bottom: 15px;'";
//       }
//
//        html = '<div id="plugin_servicecatalog_formlist" class="bt-block bt-features" style="display=grid;">'
//            + '<h5 ' + style + '><span id="search_title"><div class="alert alert-secondary" role="alert">' + title_search + '</div></span></h5>'
//            + '<div class="container_thumbnail" style="padding-bottom: 5px;">'
//            + items.join("")
//            + '</div>';
//        +'</div>';
//    }
//
//    return html;
//}
