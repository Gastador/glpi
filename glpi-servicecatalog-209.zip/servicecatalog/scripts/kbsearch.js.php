<?php
use Glpi\Event;
include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>

var root_servicecatalog_doc = "<?php echo PLUGIN_SERVICECATALOG_WEBDIR; ?>";
jQuery(document).ready(function ($) {

    ////Initialize search bar
    searchInput = $('#plugin_servicecatalog_search_kb_Bar input:first');
    word = $('#plugin_servicecatalog_search_kb_Bar input:eq(0)');
    sclayout = $('#plugin_servicecatalog_search_kb_Bar input:eq(1)');
    sclayout_id = sclayout.val();
    currentword = word.val();
    updateFormsViewKb(currentword);

    if (searchInput.length == 1) {
        ////Dynamically update forms and faq items while the user types in the search bar
        var timer;
        searchInput.keyup(
            function (event) {
                if (typeof timer != "undefined") {
                    clearTimeout(timer);
                }
                keywords = searchInput.val();

                if (event.which == 13) {
                    updateFormsViewKb(currentword);
                } else {
                    timer = setTimeout(function () {
                        updateFormsViewKb(currentword);
                        console.log(keywords);
                    }, 300);
                }

            }
        );
        ////Clear the search bar if it gains focus
        $('#plugin_servicecatalog_search_kb_Bar input').focus(function (event) {
            if (searchInput.val() && searchInput.val().length > 0) {
                searchInput.val('');

                updateFormsViewKb(currentword);
                $.when(getFormKbItems(0)).then(
                    function (response) {
                        titles = response;
                        showTitlesKb(titles.forms, currentword);
                    }
                );
            }
        });
    }

});

function getFormKbItems(word) {
    currentword = word;
    keywords = $('#plugin_servicecatalog_search_kb_Bar input:first').val();
    deferred = jQuery.Deferred();
    $.ajax({
        url: root_servicecatalog_doc + '/ajax/kb_search.php',
        data: {search: 'kbitems', keywords: keywords},
        type: "GET",
        dataType: "json"
    }).done(function (response) {
        deferred.resolve(response);
    }).fail(function () {
        deferred.reject();
    });
    return deferred.promise();
}

function updateFormsViewKb(word) {
    $.when(getFormKbItems(word)).done(
        function (response) {
            titles = response.forms;
            showTitlesKb(titles, response.default, word);
        }
    ).fail(
        function () {
            html = "<p><?php echo __("An error occured while querying knowbase", 'servicecatalog')?></p>";
            $('#plugin_servicecatalog_kb_results').empty();
            $('#plugin_servicecatalog_kb_results').prepend(html);

        }
    );
}

function showTitlesKb(titles, defaultForms, word) {
    html = '';
    if (defaultForms) {
       html += '<p>No knowbase item found</p>';
    }
    if (titles.length == 0) {
        html = "<p><?php echo __('No knowbase item found', 'servicecatalog')?></p>";
        html = '';
    } else {
    html += buildTitlesKb(titles, word);
    }
    ////Display titles
    $('#plugin_servicecatalog_kb_results').empty();
    $('#plugin_servicecatalog_kb_results').prepend(html);
}

function buildTitlesKb(list, word) {

    var items = [];
    $.each(list, function (key, kb) {
       ////Build a HTML tile
       url = root_servicecatalog_doc + '/front/faq.php?id=' + kb.id;
        var title;
        if (kb.name == "") {
            title = "N/A";
        } else {
            title = kb.name
        }
        if (kb.answer.length >= 80) {
            comment = kb.answer.substr(0, 80) + ' (...)';
        } else {
            comment = kb.answer;
        }
        if (sclayout_id == 3) {
            default_class = '';
            items.push(
                '<div class="plugin_servicecatalog_formTitlekb visitedchildbg widgetrow"><ul>'
                + '<li><div class="bt-title"><a class="bt-buttons title_search" href="' + url + '" target="_blank" style="\n' +
                '    font-size: 12px;\n' +
                '">'
                + title
                + '</a></div><span class="plugin_servicecatalog_formTitleComment" title="' + comment + '">'
                + comment
                + '</span></li></ul></div>'
            );
        } else {
            items.push(
                '<div class="plugin_servicecatalog_formTitlekb"><ul>'
                + '<li><div class="bt-title"><a class="bt-buttons title_search" href="' + url + '" target="_blank" style="\n' +
                '    font-size: 12px;\n' +
                '">'
                + title
                + '</a></div><span class="plugin_servicecatalog_formTitleComment" title="' + comment + '">'
                + comment
                + '</span></li></ul></div>'
            );
        }
    });

    ////concatenate all HTML parts
    html = '<div id="plugin_servicecatalog_formlist">'
        + items.join("")
        + '</div>';

    return html;
}
