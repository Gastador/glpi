<?php
use Glpi\Event;
include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>
var root_servicecatalog_doc = "<?php echo PLUGIN_SERVICECATALOG_WEBDIR; ?>";
(function ($) {
    $.fn.servicecatalog_drop_home_button = function () {

        init();
        var object = this;

        // Start the plugin
      function init() {
          $(document).ready(function () {

              // $("a[href$='/front/helpdesk.public.php']").removeAttr('href').css("cursor", "default").attr('title', '');
              var hrefs = $("a[href$='/front/helpdesk.public.php']");//, a[href$='/front/helpdesk.public.php']
              hrefs.each(function (href, value) {
                      $("a[href='" + value['pathname'] + "']").attr('href', root_servicecatalog_doc + '/front/main.form.php');
              });
              var hrefs2 = $("a[href$='/front/central.php']");//, a[href$='/front/helpdesk.public.php']
              hrefs2.each(function (href, value) {
                      $("a[href='" + value['pathname'] + "']").attr('href', url + 'front/main.form.php');
              });
              // $("ul[id='menu'] li[id='menu1']").first().remove();
              //if(document.getElementsByClassName('fa fa-plus').length > 0){
              //    document.getElementsByClassName('fa fa-plus').item(0).style.display = 'none';
              //}
          });
      }

        return this;
    }
}(jQuery));

$(document).servicecatalog_drop_home_button();
