<?php
use Glpi\Event;

include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>

var urlBack = "<?php if (isset($_SESSION['servicecatalog']['urlBack'])) {
    echo $_SESSION['servicecatalog']['urlBack'];
}?>";

function back() {
    window.location = urlBack;
}
