$(document).ready(function () {
    if ($(".panel").size() == 0) {
        $("#flip").hide();
    }
    $("#flip").click(function () {
        $(".panel").toggle();
        var toggleButton = $('.flipper-info');
        if (toggleButton.hasClass('fa-caret-right')) {
            toggleButton.removeClass('fa-caret-right');
            toggleButton.addClass('fa-caret-down');
        } else {
            toggleButton.removeClass('fa-caret-down');
            toggleButton.addClass('fa-caret-right');
        }
    });
});