<?php
//use Glpi\Event;
//include('../../../inc/includes.php');
//header('Content-Type: text/javascript');
//
////$display = ;
//?>
//
//var root_servicecatalog_doc = "<?php //echo PLUGIN_SERVICECATALOG_WEBDIR; ?>//";
////var layout = "<?php ////echo $_SESSION['page_layout']; ?>////";
//
//jQuery(document).ready(function ($) {
//    //CSS
//    //if (layout == 'vsplit') {
//    //    $('#footer').css({'position': 'fixed'});
//    //}
//
//// Initialize search bar
////    searchInput = $('#plugin_servicecatalog_search_faq_Bar input:first');
//
//    $('input[type=search]').on('search', function () {
//        updateFAQFormsView();
//    });
//    if ($('#plugin_servicecatalog_search_faq_Bar input:first').length == 1) {
//
//        // Dynamically update forms and faq items while the user types in the search bar
//        var timer;
//   $('#plugin_servicecatalog_search_faq_Bar input:first').change(
//            function (event) {
//                if (typeof timer != "undefined") {
//                    clearTimeout(timer);
//                }
//                keywords = $('#plugin_servicecatalog_search_faq_Bar input:first').val();
//
//                if (event.which == 13) {
//                    updateFAQFormsView();
//                } else {
//                    timer = setTimeout(function () {
//                       updateFAQFormsView();
//                    }, 300);
//                }
//            }
//        );
//   $('#plugin_servicecatalog_search_faq_Bar input:first').keyup(
//            function (event) {
//                if (typeof timer != "undefined") {
//                    clearTimeout(timer);
//                }
//                keywords = $('#plugin_servicecatalog_search_faq_Bar input:first').val();
//                if (event.which == 13) {
//                   updateFAQFormsView();
//                } else {
//                    timer = setTimeout(function () {
//                       updateFAQFormsView();
//                    }, 300);
//                }
//            }
//        );
//        // Clear the search bar if it gains focus
//   $('#plugin_servicecatalog_search_faq_Bar input:first').focus(function (event) {
//            if ($('#plugin_servicecatalog_search_faq_Bar input:first').val()
//               && $('#plugin_servicecatalog_search_faq_Bar input:first').val().length > 0) {
//               $('#plugin_servicecatalog_search_faq_Bar input:first').val('');
//               updateFAQFormsView();
//            }
//        });
//    }
//
//   $('input[type=search]').on('search', function () {
//      console.log('clear');
//         $('#plugin_servicecatalog_faq_results').empty();
//      });
//
//});
//
//function getFAQFormItems() {
//
//    keywords = $('#plugin_servicecatalog_search_faq_Bar input:first').val();
//    deferred = jQuery.Deferred();
//    $.ajax({
//        url: root_servicecatalog_doc + '/ajax/kb_search.php',
//        data: {search: 'faqitems', keywords: keywords},
//        type: "GET",
//        dataType: "json"
//    }).done(function (response) {
//        deferred.resolve(response);
//    }).fail(function () {
//        deferred.reject();
//    });
//    return deferred.promise();
//}
//
//function updateFAQFormsView() {
//    $.when(getFAQFormItems()).done(
//        function (response) {
//            titles = response.forms;
//            //console.log('result');
//            //console.log(titles);
//            showFAQTitles(titles, response.default);
//        }
//    ).fail(
//        function () {
//            html = '<p><?php //echo __('An error occured while querying knowbase', 'servicecatalog')?>//</p>';
//            $('#plugin_servicecatalog_faq_results').empty();
//            $('#plugin_servicecatalog_faq_results').prepend(html);
//
//        }
//    );
//}
//
//function showFAQTitles(titles, defaultForms) {
//    //tiles = sortFormAndFaqItems(tiles, sortByName);
//    html = '';
//    if (defaultForms) {
//        html += '<p>No knowbase item found</p>';
//    }
//    html += buildFAQTitles(titles);
//
//    //Display titles
//    $('#plugin_servicecatalog_faq_results').empty();
//    $('#plugin_servicecatalog_faq_results').prepend(html);
//}
//
//function buildFAQTitles(list) {
//
//    if (list.length == 0) {
//        //html = '<p><?php ////echo __('No KB article founded', 'servicecatalog')?>////</p>';
//    } else {
//        var items = [];
//        $.each(list, function (key, faq) {
//            // Build a HTML tile
//           url = root_servicecatalog_doc + '/front/faq.php?id=' + faq.id;
//           var title;
//           if (faq.name == "") {
//              title = "N/A";
//           } else {
//              title = faq.name
//           }
//           items.push(
//              '<ul class="cd-faq-group">'
//              + '<li><a class="cd-faq-trigger" href="' + url + '"' +
//              '">'
//              + title
//              + '</a></li></ul>'
//           );
//
//        });
//
//
//       html = "<ul class='cd-faq-group'><li class='cd-faq-title'><h2><?php //echo __("Results", 'servicecatalog')?>//</h2></li></ul>";
//       html += ''
//          + items.join("")
//          + '';
//    }
//
//    return html;
//}
