<?php
use Glpi\Event;
include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>
var root_servicecatalog_doc = "<?php echo PLUGIN_SERVICECATALOG_WEBDIR; ?>";
(function ($) {
   $.fn.servicecatalog_replace_ticketformlink = function () {

      init();
      var object = this;

      // Start the plugin
      function init() {
         $(document).ready(function () {
            var hrefs = $("a[href*='/front/ticket.php']");
            hrefs.each(function (href, value) {
               $("a[href*='" + value['pathname'] + "']").attr('href', root_servicecatalog_doc + '/front/ticket.php');
            });
         });
      }

      return this;
   };
}(jQuery));

$(document).servicecatalog_replace_ticketformlink();
