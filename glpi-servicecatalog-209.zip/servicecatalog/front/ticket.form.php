<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

use Glpi\Event;

include('../../../inc/includes.php');

Session::checkLoginUser();
$track = new Ticket();

if (!isset($_GET['id'])) {
    $_GET['id'] = "";
}

if (isset($_GET["id"]) && ($_GET["id"] > 0)) {
    if (Session::getCurrentInterface() == "helpdesk") {
        PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'), true);
    } else {
        Html::header(Ticket::getTypeName(Session::getPluralNumber()), '', "helpdesk", "ticket");
    }

    $available_options = ['load_kb_sol', '_openfollowup'];
    $options = [];
    foreach ($available_options as $key) {
        if (isset($_GET[$key])) {
            $options[$key] = $_GET[$key];
        }
    }
    $track->getFromDB($_GET["id"]);

    echo "<div class='sc-content'>";

//    $title = __('Your ticket', 'servicecatalog')." - ".$track->getName();

//    echo PluginServicecatalogWidget::getWidgetTitle($title, true);

    $options['id'] = $_GET["id"];
    $track->display($options);
    echo "</div>";
//   $js = "$('div#tabspanel').next().tabs().removeClass( 'ui-tabs-vertical' );";
//   echo Html::scriptBlock('$(function() {' . $js . " });");

    $config = new PluginServicecatalogConfig();
    if ((isset($_SESSION["glpiactiveprofile"])
        && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk")) {
        if (isset($_SERVER['HTTP_REFERER'])
          && strpos($_SERVER['HTTP_REFERER'], "/ticket.php") !== false) {
 //         echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/scripts/replace_ticketformlink.js.php");
            echo "<script id='rendered-menu'>
            $('#ticketlist_bar').addClass('active');
            </script>";
        } elseif (isset($_SERVER['HTTP_REFERER'])
                 && strpos($_SERVER['HTTP_REFERER'], "/ticket_validate.php") !== false) {
 //         echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/scripts/replace_validateticketformlink.js.php");
            echo "<script id='rendered-menu'>
            $('#ticketvalidation_bar').addClass('active');
            </script>";
        } elseif (isset($_SERVER['HTTP_REFERER'])
                 && strpos($_SERVER['HTTP_REFERER'], "/resolved_ticket.php") !== false) {
 //         echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/scripts/replace_resolvedticketformlink.js.php");
            echo "<script id='rendered-menu'>
            $('#ticketresolvedlist_bar').addClass('active');
            </script>";
        } elseif (isset($_SERVER['HTTP_REFERER'])
                 && strpos($_SERVER['HTTP_REFERER'], "/closed_ticket.php") !== false) {
 //         echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/scripts/replace_closedticketformlink.js.php");
            echo "<script id='rendered-menu'>
            $('#ticketclosedlist_bar').addClass('active');
            </script>";
        }
    }

    if (isset($_GET['_sol_to_kb'])) {
        Ajax::createIframeModalWindow(
            'savetokb',
            KnowbaseItem::getFormURL() .
            "?_in_modal=1&item_itemtype=Ticket&item_items_id=" .
            $_GET["id"],
            ['title' => __('Save solution to the knowledge base'),
            'reloadonclose' => false]
        );
        echo Html::scriptBlock('$(function() {' . Html::jsGetElementbyID('savetokb') . ".dialog('open'); });");
    }
}

if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "helpdesk") {
    Html::helpFooter();
} else {
    Html::footer();
}
