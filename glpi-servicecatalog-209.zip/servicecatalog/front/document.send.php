<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

Session::checkLoginUser();

$doc = new Document();

if (isset($_GET["file"])) { // for other file
    $splitter = explode("/", $_GET["file"], 2);
    if (count($splitter) == 2) {
        $send = false;

        if ($splitter[0] == "_plugins") {
            $filename = explode(".", $splitter[1]);
           //check extension
            if (in_array(strtolower($filename[1]), ['jpg', 'jpeg', 'png', 'bmp', 'gif'])) {
                $send = true;
            }
        }

        if ($send && file_exists(GLPI_PLUGIN_DOC_DIR . "/" . $splitter[1])) {
            PluginServicecatalogCategory::sendFile(GLPI_PLUGIN_DOC_DIR . "/" . $splitter[1], $splitter[1]);
        } else {
            Html::displayErrorAndDie(__('Unauthorized access to this file'), true);
        }
    } else {
        Html::displayErrorAndDie(__('Invalid filename'), true);
    }
}
