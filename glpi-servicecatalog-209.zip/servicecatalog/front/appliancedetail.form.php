<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

Html::popHeader(Ticket::getTypeName(Session::getPluralNumber()));

if ($_GET['appliance_id']) {
    $appliance_link = new PluginServicecatalogApplianceLink();
    //find category in helpdesk category
    if ($appliance_link->getFromDBByAppliance($_GET['appliance_id'])) {
        echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/sc_bootstrap.scss");
        PluginServicecatalogApplianceLink::getApplianceDetailsText($appliance_link);
    }
}

Html::popFooter();
