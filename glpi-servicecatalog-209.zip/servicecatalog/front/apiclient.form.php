<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

Session::checkRight("plugin_servicecatalog_api", CREATE);

if (empty($_GET["id"])) {
    $_GET["id"] = "";
}

$api = new PluginServicecatalogApiclient();

if (isset($_POST["add"])) {
    $api->check(-1, CREATE);
    $newID = $api->add($_POST);
    Html::redirect(Toolbox::getItemTypeFormURL('PluginServicecatalogApiclient') . "?id=" . $newID);
} elseif (isset($_POST["purge"])) {
    $api->check($_POST["id"], PURGE);
    $api->delete($_POST, 1);
    $api->redirectToList();
} elseif (isset($_POST["update"])) {
    $api->check($_POST["id"], UPDATE);
    $api->update($_POST);
    Html::back();
} else {
    if (Session::getCurrentInterface() == "central") {
        Html::header(PluginServicecatalogApiclient::getTypeName(Session::getPluralNumber()), $_SERVER['PHP_SELF'], "plugins", "PluginServicecatalogApiclient");

        $api->display(['id' => $_GET["id"]]);
    }
}

if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "central") {
    Html::footer();
} else {
    Html::helpFooter();
}
