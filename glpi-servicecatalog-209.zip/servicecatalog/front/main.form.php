<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include("../../../inc/includes.php");

Session::checkSeveralRightsOr(["plugin_servicecatalog_defaultview" => CREATE,
                               "plugin_servicecatalog"             => READ]);

if (!Plugin::isPluginActive("servicecatalog")) {
    Html::displayRightError();
}

if (Session::getCurrentInterface() == 'central') {
    Html::header(Ticket::getTypeName(Session::getPluralNumber()), '', "helpdesk", "ticket");
} else {
    PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'));
}

$config = new PluginServicecatalogConfig();

PluginServicecatalogConfig::loadForLayout();

$seeborder = $config->seeWidgetsBorder();
if ($seeborder == true) {
    echo '<style type="text/css">
        .grid-stack-item-content {
          border: solid #dbdbdb 1px;
        }
    </style>';
}

if ($config->useRadiusBorder()) {
    echo '<style type="text/css">
        .grid-stack-item-content {
          box-shadow: 0px 5px 5px #ccc;
          -webkit-border-radius: 5px;
          -moz-border-radius: 5px;
          border-radius: 5px;
        }
    </style>';
}

echo '<style type="text/css">
        .grid-stack-item-content {
            padding: 5px 5px 5px 5px;
        }
        /*Mydashboard plugin*/
        .weather_block {
            text-align: center;
            margin: 0 auto;
            color: #000;
            font-size: 12px;
            background-color: #FFF;
        }
        .info-ul {
            position: relative !important;
        }
    </style>';

global $DB, $CFG_GLPI;

if (isset($_SERVER['HTTP_REFERER'])
    && strpos($_SERVER['HTTP_REFERER'], "helpdesk.public.php?active_entity") !== false) {
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
}

if (empty($_POST)) {
    $_POST = $_GET;
}

unset($_SESSION["plugin_servicecatalog"]["loadCatAjax"][Session::getLoginUserID()]);

if (!isset($_POST['category_id'])) {
    $_POST['category_id'] = 0;
}

if (!isset($_POST['type'])) {
    $_POST['type'] = 0;
}

if (empty($_POST['manage_favorites'])) {
    $_POST['manage_favorites'] = 0;
}

if (!isset($_POST['level'])) {
    $_POST['level'] = 1;
}

//Prevent direct access to page
$config = new PluginServicecatalogConfig();

if ($config->getEnableGroupRestriction() == 1) {
    $disabled = PluginServicecatalogCategory::getDisabledCategory($_POST['type'], $_POST['category_id']);
    if ($disabled == 1) {
        Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
    }
}

if (count($_SESSION["glpiactiveentities"]) > 1
    && !isset($_POST['active_entity'])
    && !isset($_POST['setup_entity'])) {
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/entity.form.php?listentity=1");
}

if (count($_SESSION["glpiactiveentities"]) > 1
    && isset($_POST['active_entity'])) {
    if (!isset($_POST["is_recursive"])) {
        $_POST["is_recursive"] = 0;
    }
    if (Session::changeActiveEntities($_POST["active_entity"], $_POST["is_recursive"])) {
        if ($_POST["active_entity"] == $_SESSION["glpiactive_entity"]) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            //         Html::redirect(preg_replace("/entities_id.*/", "", $_SERVER['HTTP_REFERER']));
        }
    }
}

if (isset($_POST['add_favorite'])) {
    $favorite                 = new PluginServicecatalogFavorite();
    $itilCategories           = isset($_POST['itilcategories_id']) ? $_POST['itilcategories_id'] : '';
    $favoriteItilCategoriesId = isset($_POST['favorite_itilcategories_id']) ? $_POST['favorite_itilcategories_id'] : '';
    $userId                   = isset($_POST['users_id']) ? $_POST['users_id'] : '';
    $hasFav                   = $favorite->getFromDBByCrit(['itilcategories_id'          => $itilCategories,
                                                            'favorite_itilcategories_id' => $favoriteItilCategoriesId,
                                                            'users_id'                   => $userId]);
    if ($hasFav) {
        //TODO message d'erreur à gérer si doublon.
    } else {
        $cat = new ITILCategory();
        $cat->getFromDB($itilCategories);
        if ($cat->fields['is_request'] == 1 && $cat->fields['is_incident'] == 0) {
            $params['type_favorites'] = PluginServicecatalogFavorite_User::REQUEST_TYPE_FAVORITES;
        } elseif ($cat->fields['is_request'] == 0 && $cat->fields['is_incident'] == 1) {
            $params['type_favorites'] = PluginServicecatalogFavorite_User::INCIDENT_TYPE_FAVORITES;
        } else {
            $params['type_favorites'] = PluginServicecatalogFavorite_User::BOTH_TYPE_FAVORITES;
        }
        $params['pluginservicecatalogfavorites_id'] = $favorite->add(['itilcategories_id'          => $itilCategories,
                                                                      'favorite_itilcategories_id' => $favoriteItilCategoriesId, 'users_id' => $userId]);
        $params['users_id']                         = $userId;
        $params['_type']                            = 'User';
        $params['favorites_id']                     = $favoriteItilCategoriesId;
        $favorite->addFavoriteVisibility($params);
    }
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&level=" . $_POST['level'] . "&manage_favorites=1");
}

if (isset($_POST['delete_favorite'])) {
    if (isset($_POST['item'])) {
        $favoriteUser = new PluginServicecatalogFavorite_User();
        $favorite     = new PluginServicecatalogFavorite();
        $userId       = $_POST['users_id'];
        $postItems    = $_POST['item']['PluginServicecatalogFavorite'];
        foreach ($postItems as $favId => $isChecked) {
            if ($isChecked) {
                $favoriteUser->deleteByCriteria(['favorites_id' => $favId, 'users_id' => $userId]);
                $favorite->deleteByCriteria(['id' => $favId, 'users_id' => $userId]);
            }
        }
        Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&level=" . $_POST['level'] . "&manage_favorites=1");
    }
}

$widget = new PluginServicecatalogWidget();
$widget->getConfig();

if (Session::haveRight('plugin_servicecatalog_incidents', READ)
    && $widget->fields['display_incident'] != 1
    && isset($_POST['type']) && $_POST['type'] == Ticket::INCIDENT_TYPE) {
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
}
if (Session::haveRight('plugin_servicecatalog_requests', READ)
    && $widget->fields['display_request'] != 1
    && isset($_POST['type']) && $_POST['type'] == Ticket::DEMAND_TYPE) {
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
}

if ((isset($_POST['changeactiveentity']))) {
    Session::changeActiveEntities("all");
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/entity.form.php?listentity=1");
} elseif (isset($_POST['choose_category'])) {
    //   if (empty($_POST['choose_category'])) {
    //      $_POST['choose_category'] = 0;
    //   }
    //   PluginServicecatalogMain::showCategories($_POST);
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&choose_category=" . $_POST["choose_category"] . "&level=" . $_POST["level"] . "&manage_favorites=" . $_POST["manage_favorites"] . "&category_id=" . $_POST["category_id"]);
} elseif (isset($_POST['create_ticket'])) {
    //not used with thumbnail* layout if new_page not acitvated
    if (Plugin::isPluginActive("metademands")) {
        $myticket                             = new Ticket();
        $myticket->fields['id']               = 0;
        $myticket->input['type']              = $_POST['type'];
        $myticket->input['itilcategories_id'] = $_POST['category_id'];
        if ($md_exists = PluginMetademandsMetademand::redirectForm($myticket, 'show')) {
            Html::redirect($md_exists);
        } else {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?type=" . $_POST['type'] . "&category_id=" . $_POST["category_id"]);
        }
    } else {
        Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?type=" . $_POST['type'] . "&category_id=" . $_POST["category_id"]);
    }
} else {

    if (Plugin::isPluginActive("metademands")
        && class_exists("PluginMetademandsStepform")
        && Session::haveRight("plugin_metademands", READ)) {
        PluginMetademandsStepform::showWaitingWarning();
    }

    $entity = new Entity();
    if (PluginServicecatalogEntity::isViewOtherEntity()) {
        if ($entity->getFromDB($_SESSION["glpiactive_entity"])) {
            echo "<div class='comment_buttons'>".$entity->fields['name']."</div>";
        }
    }
    $dashboard = new PluginServicecatalogDashboard();
    $dashboard->loadDashboard();
    if (isset($_GET['listentity'])
        && $_GET['listentity'] == 1) {
        echo "<script id='rendered-menu'>
         $('#home_bar').removeClass('active');
         $('#entity_bar').addClass('active');
         </script>";
    } else {
        echo "<script id='rendered-menu'>
         $('#home_bar').addClass('active');
         </script>";
    }
}

if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "central") {
    Html::footer();
} else {
    Html::helpFooter();
}
