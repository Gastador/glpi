<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2020 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

include('../../../inc/includes.php');

// Redirect management
if (isset($_GET["redirect"])) {
    Toolbox::manageRedirect($_GET["redirect"]);
}

Session::checkFaqAccess();

if (Session::getLoginUserID()) {
    if (Session::getCurrentInterface() == "central") {
        Html::header(__('FAQ'), $_SERVER['PHP_SELF'], 'tools');
    } else {
        PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('FAQ'), false, 'PluginServicecatalogKnowbase');
    }
} else {
    $_SESSION["glpilanguage"] = $_SESSION['glpilanguage'] ?? $CFG_GLPI['language'];
   // Anonymous FAQ
    PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('FAQ'), false, 'PluginServicecatalogKnowbase');
}

PluginServicecatalogKnowbase::showFAQ($_GET);

//if (isset($_GET['docbase']) || isset($_GET['id']) || isset($_GET['catid'])) {
//   PluginServicecatalogKnowbase::showFAQ($_GET);
//    } else {
//   PluginServicecatalogKnowbase::showFirstKBCats();
//}

if (isset($_GET['docbase'])
    && $_GET['docbase'] == 1) {
    echo "<script id='rendered-menu'>
   $('#docbase_bar').addClass('active');
   </script>";
} else {
    echo "<script id='rendered-menu'>
   $('#faq_bar').addClass('active');
   </script>";
}


if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "central") {
    Html::footer();
} else {
    Html::helpFooter();
}
