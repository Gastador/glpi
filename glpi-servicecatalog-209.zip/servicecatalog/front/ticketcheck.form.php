<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

if (isset($_POST['update_ticket'])) {
    $ticket = new Ticket();
    $ticket->getFromDB($_POST["tickets_id"]);
    $input["id"]                = $_POST["tickets_id"];
    $input["itilcategories_id"] = $_POST["plugin_servicecatalog_category_id"];
    $input["type"]              = $_POST["plugin_servicecatalog_type"];
    $input["urgency"]           = $_POST["urgency"];
    $input["impact"]            = $_POST["impact"];
    $input["priority"]          = Ticket::computePriority($_POST['urgency'], $_POST['impact']);
    $input["status"]            = $ticket->fields["status"];
    $input["slas_id_ttr"]       = $ticket->fields["slas_id_ttr"];
    $input["slas_id_tto"]       = $ticket->fields["slas_id_tto"];
    $input["time_to_resolve"]   = $ticket->fields["time_to_resolve"];
    $input["time_to_own"]       = $ticket->fields["time_to_own"];

    if (isset($_POST["contracts_id_mandatory"])
        && $_POST["contracts_id_mandatory"] == 1
        && $_POST["contracts_id"] == 0) {
        Html::popHeader(PluginServicecatalogTicketcheck::getTypeName(2));
        echo "<div class='alert alert-danger alert-info d-flex'>";
        echo __('Error : Contract is mandatory', 'servicecatalog');
        echo "</div>";
        echo Html::displayBackLink();
        Html::popFooter();
    } elseif ($_POST["itilcategories_mandatory"] == 1
              && $_POST["plugin_servicecatalog_category_id"] == 0) {
        Html::popHeader(PluginServicecatalogTicketcheck::getTypeName(2));
        echo "<div class='alert alert-danger alert-info d-flex'>";
        echo __('Error : Category is mandatory', 'servicecatalog');
        echo "</div>";
        echo Html::displayBackLink();
        Html::popFooter();
    } else {
        $contracts_id = $_POST["contracts_id"] ?? 0;
        if ($contracts_id) {
            $ticketcontract = new Ticket_Contract();
            $ticketcontract->add([
                                     'contracts_id' => $_POST["contracts_id"],
                                     'tickets_id'   => $_POST["tickets_id"],
                                 ]);
        }

        $ticket->check($input['id'], UPDATE);
        $ticket->update($input);

        $check               = new PluginServicecatalogTicketcheck();
        $datas["tickets_id"] = $_POST["tickets_id"];
        $check->check(-1, CREATE, $datas);
        $check->add($datas);
        Html::popHeader(PluginServicecatalogTicketcheck::getTypeName(2));
        echo "<div class='alert alert-info d-flex'>";
        echo __('The ticket has been requalified', 'servicecatalog');
        echo "</div>";
        Html::popFooter();
    }
} elseif (isset($_POST['validate_ticket'])) {
    if (isset($_POST["contracts_id_mandatory"]) && $_POST["contracts_id_mandatory"] == 1
        && isset($_POST["contracts_id"])
        && $_POST["contracts_id"] == 0) {
        Html::popHeader(PluginServicecatalogTicketcheck::getTypeName(2));
        echo "<div class='alert alert-danger alert-info d-flex'>";
        echo __('Error : Contract is mandatory', 'servicecatalog');
        echo "</div>";
        echo Html::displayBackLink();
        Html::popFooter();
    } else {
        $contracts_id = $_POST["contracts_id"] ?? 0;
        if ($contracts_id) {
            $ticketcontract = new Ticket_Contract();
            $ticketcontract->add([
                                     'contracts_id' => $_POST["contracts_id"],
                                     'tickets_id'   => $_POST["tickets_id"],
                                 ]);
        }

        $check               = new PluginServicecatalogTicketcheck();
        $input["tickets_id"] = $_POST["tickets_id"];
        $check->check(-1, CREATE, $input);
        $check->add($input);
        Html::popHeader(PluginServicecatalogTicketcheck::getTypeName(2));
        echo "<div class='alert alert-info d-flex'>";
        echo __('The ticket has been requalified', 'servicecatalog');
        echo "</div>";
        Html::popFooter();
    }
} else {
    Html::popHeader(PluginServicecatalogTicketcheck::getTypeName(2));

    $params['tickets_id'] = $_GET['tickets_id'];
    PluginServicecatalogTicketcheck::showModalForm($params);

    Html::popFooter();
}
