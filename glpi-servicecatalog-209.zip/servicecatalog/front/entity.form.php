<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');
if (isset($_GET["listentity"])) {
    if (Session::getCurrentInterface() == 'central') {
        Html::header(Ticket::getTypeName(Session::getPluralNumber()), '', "helpdesk", "ticket");
    } else {
        PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'));
    }

    $class = "bt-col-md-12";
    echo PluginServicecatalogEntity::getWidgetEntities("gs1", $class, false);

    echo "<script id='rendered-menu'>
   $('#entity_bar').addClass('active');
    </script>";

    if (Session::getCurrentInterface() != 'central') {
        PluginServicecatalogMain::showNavBarFooter();
    }

    if (Session::getCurrentInterface() == "central") {
        Html::footer();
    } else {
        Html::helpFooter();
    }
} elseif (Plugin::isPluginActive("servicecatalog")
           && Session::haveRight("plugin_servicecatalog_setup", UPDATE)) {
    Html::header(__('Setup'), '', "config", "plugins");

    $entity = new PluginServicecatalogEntity();
    $dashboard = new PluginServicecatalogDashboard();
    if (isset($_POST["delete_entity"])) {
        //TODO if 0 : reinit dashboard
        $dashboard->deleteByCriteria(["entities_id" => $_POST['entities_id'],
            'users_id' => 0], true);
        if ($_POST['entities_id'] == 0) {
            $query = "INSERT INTO `glpi_plugin_servicecatalog_dashboards` (`id`, `entities_id`, `is_recursive`, `users_id`, `grid`)
                VALUES (1, 0, 1, 0, '[{\"id\":\"gs1\",\"x\":0,\"y\":0,\"w\":6,\"h\":6},
            {\"id\":\"gs20\",\"x\":0,\"y\":6,\"w\":6,\"h\":6},
            {\"id\":\"gs12\",\"x\":6,\"y\":6,\"w\":6,\"h\":6},
            {\"id\":\"gs13\",\"x\":6,\"y\":6,\"w\":6,\"h\":6}]');";
            $DB->query($query);
        }

        Html::back();
    } elseif (isset($_POST["update"])) {
        $entity->update($_POST);
        Html::back();
    } elseif (isset($_POST["update_entity"])) {
        $dashboard             = new PluginServicecatalogDashboard();
        $input['id']           = $_POST['id'];
        $input["is_recursive"] = $_POST['is_recursive'];
        $dashboard->update($input);
        Html::back();
    }
} else {
    Html::displayRightError();
}
