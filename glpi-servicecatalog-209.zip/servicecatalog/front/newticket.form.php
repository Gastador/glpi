<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include("../../../inc/includes.php");

Session::checkSeveralRightsOr(["plugin_servicecatalog_defaultview" => CREATE,
                               "plugin_servicecatalog"             => READ]);

if (empty($_POST)) {
    $_POST = $_GET;
}

if (Session::getCurrentInterface() == 'central') {
    Html::header(Ticket::getTypeName(Session::getPluralNumber()), '', "helpdesk", "ticket");
} else {
    PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'), false, 'PluginServicecatalogCategory', $_GET["type"], true);
}

if (isset($_GET['category_id'])) {
    $itilcat = new ITILCategory();
    if ($itilcat->getFromDB($_GET['category_id'])) {
        if (!Session::haveAccessToEntity($itilcat->fields['entities_id'], $itilcat->fields['is_recursive'])) {
            $message = __('This category cannot be used with this entity', 'servicecatalog');
            Session::addMessageAfterRedirect($message, false, ERROR);
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }
    }
}


$config      = new PluginServicecatalogConfig();
$seedetail = $config->getDetailBeforeFormRedirect();

$cat_have_details = false;
$cat = new PluginServicecatalogCategory();
if (isset($_GET['category_id']) && $cat->getFromDBByCategory($_GET['category_id'])) {
    if ($cat->fields['comment'] ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "picture_detail") ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "service_detail") != null ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "service_users") ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "service_ttr") ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "service_use") ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "service_supervision") ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "service_rules") ||
        PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "service_links")) {
        $cat_have_details = true;
    }
}

if ($seedetail != 1
    || (isset($_GET["launch_creation"]) && $_GET["launch_creation"] == 1)
    || $cat_have_details == false) {
    if (isset($_GET["type"]) && isset($_GET["category_id"])) {
        //Metademands / formcreator etc..
        $pluglink = PluginServicecatalogPlugin::showLinkCategory($_GET['type'], $_GET['category_id']);
        if ($pluglink) {
            Html::redirect($pluglink);
        }
    }
}

//PluginServicecatalogConfig::loadForLayout();

if ((Session::haveRight('plugin_servicecatalog_incidents', READ)
     && Ticket::INCIDENT_TYPE == $_GET["type"])
    || (Session::haveRight('plugin_servicecatalog_requests', READ)
        && Ticket::DEMAND_TYPE == $_GET["type"])) {
    if ($seedetail != 1
        || (isset($_GET["launch_creation"]) && $_GET["launch_creation"] == 1)
    || $cat_have_details == false) {
        PluginServicecatalogTicket::launchTicketForm($_POST);
    } else {
        PluginServicecatalogTicket::launchCategoryDetailForm($_POST);
    }
} else {
    Html::displayErrorAndDie(__("You don't have the right to do this", 'servicecatalog'), true);
}

if (Ticket::INCIDENT_TYPE == $_GET["type"]) {
    echo "<script id='rendered-menu'>
   $('#incident_bar').addClass('active');
</script>";
} else {
    echo "<script id='rendered-menu'>
   $('#request_bar').addClass('active');
</script>";
}

if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "central") {
    Html::footer();
} else {
    Html::helpFooter();
}
