<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2020 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

include('../../../inc/includes.php');

Session::checkLoginUser();

if (Session::getCurrentInterface() == "central") {
    Html::header(Ticket::getTypeName(Session::getPluralNumber()), '', "helpdesk", "ticket");
} else {
    PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'));
}
if (Session::getCurrentInterface() == 'central') {
    Search::show('Ticket');
} else {
    echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/datatables.css");
    echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Responsive-2.3.0/css/responsive.dataTables.min.css");
    echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Select-1.4.0/css/select.dataTables.min.css");
    echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/datatables.js");
    echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Responsive-2.3.0/js/dataTables.responsive.min.js");
    echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Select-1.4.0/js/dataTables.select.min.js");

    $type              = (isset($_GET['type']) ? $_GET['type'] : 0);
    $itilcategories_id = (isset($_GET['itilcategories_id']) ? $_GET['itilcategories_id'] : 0);
    $mygroups             = (isset($_GET['mygroups']) ? $_GET['mygroups'] : 0);

    if ($type == Ticket::INCIDENT_TYPE) {
        echo PluginServicecatalogTicket::getYourTickets("gs15", "Incidents", true, $_SESSION['glpiactive_entity'], $type, $mygroups, true, $itilcategories_id);
        echo "<script id='rendered-menu'>
            $('#incidentlist_bar').addClass('active');
            </script>";
    } elseif ($type == Ticket::DEMAND_TYPE) {
        echo PluginServicecatalogTicket::getYourTickets("gs16", "Requests", true, $_SESSION['glpiactive_entity'], $type, $mygroups, true,$itilcategories_id);
        echo "<script id='rendered-menu'>
            $('#requestlist_bar').addClass('active');
            </script>";
    } else {
        echo PluginServicecatalogTicket::getYourTickets("gs12", "YourTickets", true, $_SESSION['glpiactive_entity'], $type, $mygroups, true, $itilcategories_id);
        echo "<script id='rendered-menu'>
            $('#ticketlist_bar').addClass('active');
            </script>";
    }
}

if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "central") {
    Html::footer();
} else {
    Html::helpFooter();
}
