<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

//Session ::checkRight('tickettemplate', UPDATE);

$item = new Ticket_User();
$item_group = new Group_Ticket();

if (isset($_POST["cancelticket"])
    && isset($_POST["tickets_id"])
    && Session::haveRight("plugin_servicecatalog_cancel_ticket", READ)) {
    $ticket = new Ticket();
    $ticket->getFromDB($_POST["tickets_id"]);
    if (!$ticket->canRequesterUpdateItem()) {
        Session::addMessageAfterRedirect(__("You don't have permission to perform this action."), true, ERROR);
        return false;
    }

    $template = new SolutionTemplate();
    $config   = new PluginServicecatalogConfig();
    if ($config->getTicketTemplateAssociatedToCancelTicket() > 0) {
        $solution_template_id = $config->getTicketTemplateAssociatedToCancelTicket();
        $item = New Ticket();
        if ($template->getFromDB($solution_template_id)
            && $_POST["tickets_id"] != null
        && $item->getFromDB($_POST["tickets_id"])) {

            $solution = new ITILSolution();

            if (!$solution->add([
                'itemtype'         => $item::getType(),
                'items_id'         => $item->getID(),
                'solutiontypes_id' => $template->fields['solutiontypes_id'],
                'content'          =>  Glpi\Toolbox\Sanitizer::sanitize($template->getRenderedContent($item))])) {
                Session::addMessageAfterRedirect(__('Failed to cancel your ticket', 'servicecatalog'), true, ERROR);

                Html::popHeader(PluginServicecatalogTicketaction::getTypeName(2));
                echo "<div class='alert alert-danger alert-info d-flex'>";
                echo __("Failed to cancel your ticket", "servicecatalog");
                echo "</div>";
                Html::popFooter();

                return false;
            }
            Html::popHeader(PluginServicecatalogTicketaction::getTypeName(2));
            echo "<div class='alert  alert-info d-flex'>";
            echo __("The ticket is cancelled", "servicecatalog");
            echo "</div>";
            Html::popFooter();
        }
    } else {
        Session::addMessageAfterRedirect(__('Failed to cancel your ticket', 'servicecatalog'), true, ERROR);
        return false;
    }
} elseif (isset($_POST["_itil_requester"]['users_id'])) {
   //   $item->check(-1, UPDATE, $_POST);
    $input['tickets_id'] = $_POST['tickets_id'];
    $input['type']       = CommonITILActor::REQUESTER;
    $input['users_id']   = $_POST["_itil_requester"]['users_id'];
    $item->add($input);
    Html::popHeader(PluginServicecatalogTicketaction::getTypeName(2));
    echo "<div class='alert  alert-info d-flex'>";
    echo __("A new requester has been added on the ticket", "servicecatalog");
    echo "</div>";
    Html::popFooter();
} elseif (isset($_POST["_itil_observer"]['users_id'])) {
   //   $item->check(-1, UPDATE, $_POST);
    $input['tickets_id'] = $_POST['tickets_id'];
    $input['type']       = CommonITILActor::OBSERVER;
    $input['users_id']   = $_POST["_itil_observer"]['users_id'];
    $item->add($input);
    Html::popHeader(PluginServicecatalogTicketaction::getTypeName(2));
    echo "<div class='alert  alert-info d-flex'>";
    echo __("A new observer has been added on the ticket", "servicecatalog");
    echo "</div>";
    Html::popFooter();
} elseif (isset($_POST["_itil_requester"]['groups_id'])) {
   //   $item->check(-1, UPDATE, $_POST);
    $input['tickets_id'] = $_POST['tickets_id'];
    $input['type']       = CommonITILActor::REQUESTER;
    $input['groups_id']   = $_POST["_itil_requester"]['groups_id'];
    $item_group->add($input);
    Html::popHeader(PluginServicecatalogTicketaction::getTypeName(2));
    echo "<div class='alert  alert-info d-flex'>";
    echo __("A new requester group has been added on the ticket", "servicecatalog");
    echo "</div>";
    Html::popFooter();
} elseif (isset($_POST["_itil_observer"]['groups_id'])) {
   //   $item->check(-1, UPDATE, $_POST);
    $input['tickets_id'] = $_POST['tickets_id'];
    $input['type']       = CommonITILActor::OBSERVER;
    $input['groups_id']   = $_POST["_itil_observer"]['groups_id'];
    $item_group->add($input);
    Html::popHeader(PluginServicecatalogTicketaction::getTypeName(2));
    echo "<div class='alert  alert-info d-flex'>";
    echo __("A new observer group has been added on the ticket", "servicecatalog");
    echo "</div>";
    Html::popFooter();
}
