<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

Html::popHeader(Ticket::getTypeName(Session::getPluralNumber()));

if (isset($_GET['add_favorite'])) {
    if ($_GET['category_id']) {
        $favorite                 = new PluginServicecatalogFavorite();
        $itilCategories           = $_GET['category_id'];
        $favoriteItilCategoriesId = 0;
        $userId                   = isset($_GET['users_id']) ? $_GET['users_id'] : Session::getLoginUserID();
        $hasFav                   = $favorite->getFromDBByCrit(['itilcategories_id'          => $itilCategories,
                                                                'favorite_itilcategories_id' => $favoriteItilCategoriesId,
                                                                'users_id'                   => $userId]);
        if ($hasFav) {
            echo "<div class='alert  alert-info d-flex'>";
            echo __('The favorite has been added', 'servicecatalog');
            echo "<br>";
            echo __('It will be displayed at the next page refresh', 'servicecatalog');
            echo "</div>";
        } else {
            $cat = new ITILCategory();
            $cat->getFromDB($itilCategories);
            if ($cat->fields['is_request'] == 1 && $cat->fields['is_incident'] == 0) {
                $params['type_favorites'] = PluginServicecatalogFavorite_User::REQUEST_TYPE_FAVORITES;
            } elseif ($cat->fields['is_request'] == 0 && $cat->fields['is_incident'] == 1) {
                $params['type_favorites'] = PluginServicecatalogFavorite_User::INCIDENT_TYPE_FAVORITES;
            } else {
                $params['type_favorites'] = PluginServicecatalogFavorite_User::BOTH_TYPE_FAVORITES;
            }
            $params['pluginservicecatalogfavorites_id'] = $favorite->add(['itilcategories_id'          => $itilCategories,
                                                                          'favorite_itilcategories_id' => $favoriteItilCategoriesId, 'users_id' => $userId]);
            $params['users_id']                         = $userId;
            $params['_type']                            = 'User';
            $params['favorites_id']                     = $favoriteItilCategoriesId;
            $favorite->addFavoriteVisibility($params);
            echo "<div class='alert  alert-info d-flex'>";
            echo __('The favorite has been added', 'servicecatalog');
            echo "<br>";
            echo __('It will be displayed at the next page refresh', 'servicecatalog');
            echo "</div>";
        }
    }
} else {
    if (isset($_GET['delete_favorite'])) {
        if ($_GET['category_id']) {
            $favoriteUser = new PluginServicecatalogFavorite_User();
            $favorite     = new PluginServicecatalogFavorite();
            $userId       = Session::getLoginUserID();
            if ($favorite->getFromDBByCrit(['itilcategories_id'          => $_GET['category_id'],
                                            'users_id'                   => $userId])) {
                $favoriteUser->deleteByCriteria(['favorites_id' => $favorite->fields['id'],
                                                 'users_id' => $userId]);
                $favorite->deleteByCriteria(['id' => $favorite->fields['id']]);
                echo "<div class='alert  alert-info d-flex'>";
                echo __('The favorite has been deleted', 'servicecatalog');
                echo "<br>";
                echo __('It will be removed at the next page refresh', 'servicecatalog');
                echo "</div>";
            }
        }
    }
}

Html::popFooter();
