<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include("../../../inc/includes.php");

Session::checkSeveralRightsOr(["plugin_servicecatalog_defaultview" => CREATE,
                               "plugin_servicecatalog"             => READ]);

if (empty($_POST)) {
    $_POST = $_GET;
}

if (isset($_GET['choose_category'])) {
    $_POST['choose_category'] = $_GET['choose_category'];
}

if (isset($_GET['category_id'])) {
    $_POST['category_id'] = $_GET['category_id'];
}

if (!isset($_POST['category_id'])) {
    $_POST['category_id'] = 0;
    $_GET['category_id'] = 0;
}

if (isset($_GET['type'])) {
    $_POST['type'] = $_GET['type'];
}

if (!isset($_POST['type'])) {
    $_POST['type'] = 0;
    $_GET['type'] = 0;
}

if (empty($_POST['manage_favorites'])) {
    $_POST['manage_favorites'] = 0;
    $_GET['manage_favorites'] = 0;
}

if (empty($_POST['choose_category'])) {
    $_POST['choose_category'] = 0;
    $_GET['choose_category'] = 0;
}

if (Session::getCurrentInterface() == 'central') {
    Html::header(Ticket::getTypeName(Session::getPluralNumber()), '', "helpdesk", "ticket");
    echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/bootstrap/sc_bootstrap_new.scss");
} else {
    PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'), false, 'PluginServicecatalogCategory', $_GET["type"]);

    echo "<body>";
}

PluginServicecatalogConfig::loadForLayout();

unset($_SESSION["plugin_servicecatalog"]["loadCatAjax"][Session::getLoginUserID()]);

if ((Session::haveRight('plugin_servicecatalog_incidents', READ)
    && Ticket::INCIDENT_TYPE == $_GET["type"])
 || (Session::haveRight('plugin_servicecatalog_requests', READ)
     && Ticket::DEMAND_TYPE == $_GET["type"])
|| (Session::haveRight('plugin_servicecatalog_favorites', READ)
        && 1 == $_GET["manage_favorites"])) {

    $config = new PluginServicecatalogConfig();
    if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
        PluginServicecatalogSly::showCategories($_POST);
    } elseif ($config->getLayout() == PluginServicecatalogConfig::WRAPPER) {
        PluginServicecatalogWrapper::showCategories($_POST);
    } else if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
        PluginServicecatalogWrappersly::showCategories($_POST);
    } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL) {
        PluginServicecatalogThumbnail::showCategories($_POST);
    } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
        PluginServicecatalogThumbnailwrapper::showCategories($_POST);
    } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED) {
        PluginServicecatalogBootstrapped::showCategories($_POST);
    } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
        PluginServicecatalogBootstrappedcolor::showCategories($_POST);
    } else if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
        PluginServicecatalogShoper::showCategories($_POST);
    }


} else {
    Html::displayErrorAndDie(__("You don't have the right to do this", 'servicecatalog'), true);
}

if (Ticket::INCIDENT_TYPE == $_GET["type"]) {
    echo "<script id='rendered-menu'>
   $('#incident_bar').addClass('active');
</script>";
} else {
    echo "<script id='rendered-menu'>
   $('#request_bar').addClass('active');
</script>";
}

if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "central") {
    Html::footer();
} else {
    Html::helpFooter();
}
