<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

Session::checkLoginUser();

if (Session::getCurrentInterface() == "central") {
    Html::header(Ticket::getTypeName(Session::getPluralNumber()), '', "helpdesk", "ticket");
} else {
    PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'));
}

echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/datatables.min.css");
echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Responsive-2.3.0/css/responsive.dataTables.min.css");
echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Select-1.4.0/css/select.dataTables.min.css");
echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/datatables.min.js");
echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Responsive-2.3.0/js/dataTables.responsive.min.js");
echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Select-1.4.0/js/dataTables.select.min.js");

echo PluginServicecatalogTicket::getYourTickets("gs19", "validate", true, $_SESSION['glpiactive_entity'], 3, true, true);

echo "<script id='rendered-menu'>
   $('#ticketvalidation_bar').addClass('active');
</script>";

if (Session::getCurrentInterface() != 'central') {
    PluginServicecatalogMain::showNavBarFooter();
}

if (Session::getCurrentInterface() == "central") {
    Html::footer();
} else {
    Html::helpFooter();
}
