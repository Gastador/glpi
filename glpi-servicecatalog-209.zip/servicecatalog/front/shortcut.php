<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2020 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

include('../../../inc/includes.php');

Session::checkLoginUser();
//Html::header_nocache();
//Session::checkHelpdeskAccess();
global $CFG_GLPI;
//Creating the redirection link
if (count($_GET) > 0) {
    $_SESSION["glpi_plugin_servicecatalog_loaded"] = 1;
    if (isset($_GET['itemtype'])) {
        $item_type = $_GET['itemtype'];
    }
    if (isset($_GET['entities_id'])) {
        $active_entity = $_GET['entities_id'];
        Session::changeActiveEntities($active_entity);
    }
    if (isset($_GET['item_id'])) {
        $item_id = $_GET['item_id'];
    };
    $link = $CFG_GLPI['url_base'] . PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/";
    switch ($item_type) {
        case PluginServicecatalogShortcut::getOjectLinkName(PluginServicecatalogShortcut::OBJECT_SCCATEGORY):
            if (isset($_GET['type'])) {
                $type = $_GET['type'];
            }
            $category = new ITILCategory();
            $category->getFromDB($item_id);
            $choose_category = $category->fields['itilcategories_id'];
            $level = $category->fields['level'];
            $link .= "choosecategory.form.php?type=$type&level=$level&category_id=$item_id&choose_category=$choose_category";
            Html::redirect($link);
            break;
        case PluginServicecatalogShortcut::getOjectLinkName(PluginServicecatalogShortcut::OBJECT_FAQ):

            $link .= "faq.php?id=$item_id";
            Html::redirect($link);
            break;

        case PluginServicecatalogShortcut::getOjectLinkName(PluginServicecatalogShortcut::OBJECT_METADEMAND):
            $link = PLUGIN_METADEMANDS_WEBDIR . "/front/wizard.form.php?metademands_id=$item_id&step=2";
            Html::redirect($link);
            break;
        case PluginServicecatalogShortcut::getOjectLinkName(PluginServicecatalogShortcut::OBJECT_SCPAGE):
            if (isset($_GET['page'])) {
                $page = $_GET['page'];
            }
            Html::redirect($link . $page);
    }

} else {  //Display the generator link page
    $shortcut = new PluginServicecatalogShortcut();
    Html::header(PluginServicecatalogShortcut::getTypeName(), '', 'tools', "plugin_servicecatalog_shortcuts");
    $shortcut->showForm();
    Html::footer();

}

