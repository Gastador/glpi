<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

global $CFG_GLPI;

Session::checkRight("ticket", CREATE);

$track  = new Ticket();
$main   = new PluginServicecatalogMain();
$config = new PluginServicecatalogConfig();
// Security check
if (empty($_POST) || (count($_POST) == 0)) {
    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
}

$itilcat = new ITILCategory();
if ($itilcat->getFromDB($_POST['itilcategories_id'])) {
    if (!Session::haveAccessToEntity($itilcat->fields['entities_id'], $itilcat->fields['is_recursive'])) {
        $message = __('This category cannot be used with this entity', 'servicecatalog');
        Session::addMessageAfterRedirect($message, false, ERROR);
        Html::back();
    }
}

if (isset($_POST["_type"]) && ($_POST["_type"] == "Helpdesk")) {
    Html::nullHeader(Ticket::getTypeName(Session::getPluralNumber()));
} elseif ($_POST["_from_helpdesk"]) {
    PluginServicecatalogMain::showDefaultHeaderHelpdesk(__('Simplified interface'));
} else {
    Html::header(__('Simplified interface'), '', $_SESSION["glpiname"], "helpdesk", "tracking");
}

if (isset($_POST['add'])) {
    $track->check(-1, CREATE, $_POST);

    if (isset($_POST['my_items']) && !empty($_POST['my_items'])) {
        list($_POST['itemtype'], $_POST['items_id']) = explode('_', $_POST['my_items']);
        $_POST['items_id'] = [$_POST['itemtype'] => [$_POST['items_id']]];
    }

    if (!isset($_POST['my_items'])) {
        $_POST['items_id'] = [];
    }

    $mandatory_missing = [];
    if (Plugin::isPluginActive('moreticket')) {
        $configMoreticket = new PluginMoreticketConfig();
        if (Session::haveRight("plugin_moreticket_justification", READ)
          && $configMoreticket->useUrgency() == true) {
            $urgency_ticket = new PluginMoreticketUrgencyTicket();
            $urgency_ids    = $configMoreticket->getUrgency_ids();
            if (in_array($_POST['urgency'], $urgency_ids)) {
                if (empty($_POST['justification'])) {
                    $mandatory_missing['justification'] = __('Justification', 'moreticket');
                }
            }
        }
    }

    if ($config->IsPhoneNumberMandatory() == 1
        && (empty($_POST['phone_number']) && empty($_POST['other_phone_number']))) {
        $mandatory_missing['phonenumber'] = __('Phone number', 'servicecatalog');
    }


    if ($config->getDefaultRequestTemplate() > 0 || $config->getDefaultIncidentTemplate() > 0) {
        if ($_POST['type'] == Ticket::INCIDENT_TYPE && $config->getDefaultIncidentTemplate() > 0) {
            $idt = $config->getDefaultIncidentTemplate();
            $tt = $track->getITILTemplateToUse(
                $idt,
                $_POST['type'],
                $_POST['itilcategories_id'],
                $_POST['entities_id']
            );
        }
        if ($_POST['type'] == Ticket::DEMAND_TYPE && $config->getDefaultRequestTemplate() > 0) {
            $idt = $config->getDefaultRequestTemplate();
            $tt = $track->getITILTemplateToUse(
                $idt,
                $_POST['type'],
                $_POST['itilcategories_id'],
                $_POST['entities_id']
            );
        }
    } else {
        // Load ticket template if available :
        $tt = $track->getITILTemplateToUse(
            0,
            $_POST['type'],
            $_POST['itilcategories_id'],
            $_POST['entities_id']
        );
    }

    if (count($tt->mandatory)) {
        $fieldsname = $tt->getAllowedFieldsNames(true);
        foreach ($tt->mandatory as $key => $val) {
            if ((isset($_POST[$key])
              && (empty($_POST[$key]) || ($_POST[$key] == 'NULL'))
            )) {
                $mandatory_missing[$key] = $fieldsname[$val];
            }
        }
    }

    if (count($mandatory_missing)) {
       //TRANS: %s are the fields concerned
        $message                                             = sprintf(
            __('Mandatory fields are not filled. Please correct: %s'),
            implode(", ", $mandatory_missing)
        );
        $_SESSION['saveInput']['PluginServicecatalogTicket'] = $_POST;
        Session::addMessageAfterRedirect($message, false, ERROR);
        Html::back();
    }
   //phones numbers

    if ($config->getDisplayPhoneNumber() == 1
       || $config->getDisplayBrowserInformations() == 1
    ) {
        $posted_content = "<br><br><table class='tab_cadrehov' width='100%'>";
    }
    if ($config->getDisplayPhoneNumber() == 1) {
        $posted_content .= PluginServicecatalogTicket::formatAdditionalPhonesNumber($_POST, $config);
    }
    if ($config->getDisplayBrowserInformations() == 1) {
        $posted_content .= PluginServicecatalogUsercard::detectBrowser($_POST);
    }
    if ($config->getDisplayPhoneNumber() == 1
       || $config->getDisplayBrowserInformations() == 1
    ) {
        $posted_content .= "</table>";
    }
    if ($config->getDisplayPhoneNumber() == 1
       || $config->getDisplayBrowserInformations() == 1
    ) {
        $posted_content   = addslashes($posted_content);
        $posted_content   = Glpi\Toolbox\Sanitizer::sanitize($posted_content);
        $_POST['content'] .= $posted_content;
    }

    if (!isset($_POST["_users_id_requester"])) {
        $_POST["_users_id_requester"] = Session::getLoginUserID();
    }

    if ($newID = $track->add($_POST)) {
        Session::addMessageAfterRedirect(__('Thank you for using our automatic helpdesk system.'));
        if ($config->getMultiEntityRedirection()) {
            Session::changeActiveEntities("all");
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/entity.form.php?listentity=1");
        }
//        Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&level=1&category_id=" . $_POST['itilcategories_id']);
        $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&level=1&category_id=" . $_POST['itilcategories_id'];
        $itilcat = new ITILCategory();
        $itilcat->getFromDB($_POST['itilcategories_id']);
        $level = $itilcat->fields['level'];
        $id_parent = $itilcat->fields['itilcategories_id'];
        if (count(PluginServicecatalogCategory::getSons($_POST['itilcategories_id'], $_POST['type']))) {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&level=$level&category_id=" . $_POST['itilcategories_id'] . "&choose_category=$id_parent";
        } else {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&level=$level&category_id=" . $id_parent . "&choose_category=0";
        }

        Html::redirect($url);
    } else {
        $_SESSION['saveInput']['PluginServicecatalogTicket'] = $_POST;
        $layout                                              = $config->getLayout();
        if ($layout == PluginServicecatalogConfig::THUMBNAIL
          || $layout == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $_POST['type'] . "&level=1&category_id=" . $_POST['itilcategories_id']);
        } else {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?type=" . $_POST['type'] . "&category_id=" . $_POST['itilcategories_id']);
        }
    }
} else { // reload display form
    $opt['manage_favorites'] = 0;
    $opt['type']             = $_POST['type'];
    $opt['category_id']      = $_POST['itilcategories_id'];

    PluginServicecatalogTicket::launchTicketForm($opt);

    if (Session::getCurrentInterface() != 'central') {
        PluginServicecatalogMain::showNavBarFooter();
    }

    if (Session::getCurrentInterface() == "central") {
        Html::footer();
    } else {
        Html::helpFooter();
    }
}
