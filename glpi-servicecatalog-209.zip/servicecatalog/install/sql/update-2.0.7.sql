ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `search_ticket_color` VARCHAR(10) DEFAULT '#FFFFFF';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `search_kb_color` VARCHAR(10) DEFAULT '#FFFFFF';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `search_api_color` VARCHAR(10) DEFAULT '#FFFFFF';

ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title` `title` VARCHAR(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title` `title` VARCHAR(255) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_contacts` CHANGE `entities_id` `entities_id` int unsigned NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `levelCat` `levelCat` int NOT NULL DEFAULT '2';
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `template_cancel_ticket` `template_cancel_ticket` int DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `template_ticket_assets_user_update` `template_ticket_assets_user_update` int DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `template_ticket_reservation` `template_ticket_reservation` int DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `template_ticket_user_update` `template_ticket_user_update` int DEFAULT '0';

ALTER TABLE `glpi_plugin_servicecatalog_widgets` CHANGE `linked_kbcategory` `linked_kbcategory` int NOT NULL DEFAULT 0;

ALTER TABLE `glpi_plugin_servicecatalog_categoryorders` CHANGE `level` `level` int NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_categoryorders` CHANGE `type` `type` int NOT NULL DEFAULT 0;

ALTER TABLE `glpi_plugin_servicecatalog_tickettemplates` CHANGE `field` `field` int NOT NULL DEFAULT 0;

ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `comment` `comment` TEXT DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title` `title` VARCHAR(255) DEFAULT NULL;