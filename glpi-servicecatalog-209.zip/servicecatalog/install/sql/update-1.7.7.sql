ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `new_page_to_create` tinyint NOT NULL DEFAULT '0';
