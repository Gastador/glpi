ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `header` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_your_tickets_to_validate` varchar(255) DEFAULT NULL;

INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`)
VALUES (11, 'phonenumber', '10');
