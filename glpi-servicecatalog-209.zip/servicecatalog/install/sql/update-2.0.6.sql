CREATE TABLE `glpi_plugin_servicecatalog_apiclients`
(
    `id`          int unsigned NOT NULL auto_increment, -- id
    `is_active`   tinyint NOT NULL DEFAULT '1',
    `name`        varchar(255)     DEFAULT NULL,
    `login`       varchar(255)     DEFAULT NULL,
    `password`    varchar(255)     DEFAULT NULL,
    `url`         varchar(255)     DEFAULT NULL,
    `url_article` varchar(255)     DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

ALTER TABLE `glpi_plugin_servicecatalog_widgets`
    ADD `item_states` TEXT DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_categories`
    ADD `use_website_url` tinyint NOT NULL DEFAULT '0',
    ADD `website_url` varchar(255) DEFAULT NULL,
    ADD `website_target` tinyint DEFAULT 1;

RENAME
TABLE `glpi_plugin_servicecatalog_keywords` TO `glpi_plugin_servicecatalog_itilcategories_keywords`;

CREATE TABLE `glpi_plugin_servicecatalog_knowbaseitems_keywords`
(
    `id`               int unsigned NOT NULL auto_increment, -- id
    `knowbaseitems_id` int unsigned NOT NULL DEFAULT 0,
    `name`             varchar(255) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY                `knowbaseitems_id` (`knowbaseitems_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `phone_mandatory` int DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `helpdesk_form_percent` int DEFAULT '70';
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `force_validation` tinyint NOT NULL DEFAULT '0';

ALTER TABLE `glpi_plugin_servicecatalog_categoryorders` CHANGE `ranking` `ranking` int NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_categories` CHANGE `items_id` `items_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_fieldorders` CHANGE `ranking` `ranking` int NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_widgetbuttonorders` CHANGE `ranking` `ranking` int NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_favorites_users` CHANGE `ranking_incidents` `ranking_incidents` int NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_favorites_users` CHANGE `ranking_requests` `ranking_requests` int NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_favorites_users` CHANGE `type_favorites` `type_favorites` int NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `template_ticket_incident` `template_ticket_incident` int DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `template_ticket_request` `template_ticket_request` int DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `show_linked_tickets_simplifiedform` `show_linked_tickets_simplifiedform` tinyint NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `show_linked_tickets_simplifiedform` `show_linked_tickets_simplifiedform` tinyint NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `add_observers_from_tickets` `add_observers_from_tickets` int DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `add_requesters_from_tickets` `add_requesters_from_tickets` int DEFAULT 0;

ALTER TABLE `glpi_plugin_servicecatalog_categoryorders` CHANGE `itilcategories_id` `itilcategories_id` int unsigned NOT NULL DEFAULT 0;

ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD KEY `knowbaseitems_id` (`knowbaseitems_id`);

ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `new_page_to_create`;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `comment_database` `comment_database` TEXT DEFAULT NULL;