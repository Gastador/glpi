CREATE TABLE `glpi_plugin_servicecatalog_ticketappointments`
(
    `id`                 int unsigned NOT NULL AUTO_INCREMENT,
    `uuid`               varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `tickets_id`         int unsigned NOT NULL DEFAULT '0',
    `date`               timestamp NULL DEFAULT NULL,
    `users_id`           int unsigned NOT NULL DEFAULT '0',
    `content`            longtext COLLATE utf8mb4_unicode_ci,
    `begin`              timestamp NULL DEFAULT NULL,
    `end`                timestamp NULL DEFAULT NULL,
    `users_id_tech`      int unsigned NOT NULL DEFAULT '0',
    `date_mod`           timestamp NULL DEFAULT NULL,
    `date_creation`      timestamp NULL DEFAULT NULL,
    `timeline_position`  tinyint NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uuid` (`uuid`),
    KEY                  `date` (`date`),
    KEY                  `date_mod` (`date_mod`),
    KEY                  `date_creation` (`date_creation`),
    KEY                  `users_id` (`users_id`),
    KEY                  `tickets_id` (`tickets_id`),
    KEY                  `users_id_tech` (`users_id_tech`),
    KEY                  `begin` (`begin`),
    KEY                  `end` (`end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_tickets_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_incidents_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_requests_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `display_browser_infos` tinyint NOT NULL DEFAULT '0';
