--
-- Structure de la table 'glpi_plugin_servicecatalog_configs'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configs`;
CREATE TABLE `glpi_plugin_servicecatalog_configs` (
   `id` int(11) NOT NULL auto_increment, -- id
   `comment` varchar(255) DEFAULT NULL,
   `display_incident` tinyint(1) NOT NULL DEFAULT '1',
   `comment_incident` varchar(255) DEFAULT NULL,
   `display_request` tinyint(1) NOT NULL DEFAULT '1',
   `comment_request` varchar(255) DEFAULT NULL,
   `display_tickets_list` tinyint(1) NOT NULL DEFAULT '1',
   `comment_tickets` varchar(255) DEFAULT NULL,
   `display_incidents_list` tinyint(1) NOT NULL DEFAULT '0',
   `comment_incidents_list` varchar(255) DEFAULT NULL,
   `display_requests_list` tinyint(1) NOT NULL DEFAULT '0',
   `comment_requests_list` varchar(255) DEFAULT NULL,
   `comment_faq` varchar(255) DEFAULT NULL,
   `comment_database` varchar(255) DEFAULT NULL,
   `comment_validation` varchar(255) DEFAULT NULL,
   `comment_links` varchar(255) DEFAULT NULL,
   `comment_reservation` varchar(255) DEFAULT NULL,
   `comment_entity` varchar(255) DEFAULT NULL,
   `replace_ticket_creation_form` tinyint(1) NOT NULL DEFAULT '1',
   `replace_ticket_update_form` tinyint(1) NOT NULL DEFAULT '0',
   `drop_helpdesk_menu` tinyint(1) NOT NULL DEFAULT '0',
   `drop_home_button` tinyint(1) NOT NULL DEFAULT '0',
   `see_more_informations` tinyint(1) NOT NULL DEFAULT '1',
   `see_faq_articles` tinyint(1) NOT NULL DEFAULT '1',
   `linked_kbcategory` int(11) NOT NULL DEFAULT '0',
   `see_category_details` tinyint(1) NOT NULL DEFAULT '1',
   `palette` VARCHAR(255) NOT NULL DEFAULT 'grey',
   `title` varchar(255) DEFAULT NULL,
   `comment_title` TEXT DEFAULT NULL,
   `title_searchbar_request` varchar(255) DEFAULT NULL,
   `title_searchbar_incident` varchar(255) DEFAULT NULL,
   `display_logo_category_detail` tinyint(1) NOT NULL DEFAULT '1',
   `multi_entity_redirection` tinyint(1) NOT NULL DEFAULT '0',
   `display_entity_name` tinyint(1) NOT NULL DEFAULT '0',
   `title_watchers_dropdown` varchar(255) DEFAULT NULL,
   `title_submit_message_button` varchar(255) DEFAULT NULL,
   `title_incidents_list` varchar(255) DEFAULT NULL,
   `title_requests_list` varchar(255) DEFAULT NULL,
   `title_your_open_incidents` varchar(255) DEFAULT NULL,
   `title_your_open_requests` varchar(255) DEFAULT NULL,
   `title_your_and_group_open_incidents` varchar(255) DEFAULT NULL,
   `title_your_and_group_open_requests` varchar(255) DEFAULT NULL,
   `title_incident` varchar(255) DEFAULT NULL,
   `title_request` varchar(255) DEFAULT NULL,
   `img_incident` varchar(255) DEFAULT NULL,
   `img_request` varchar(255) DEFAULT NULL,
   `img_incidents_list` varchar(255) DEFAULT NULL,
   `img_requests_list` varchar(255) DEFAULT NULL,
   `cat_size` varchar(255) DEFAULT NULL,
   `keywords` tinyint(1) NOT NULL DEFAULT '1',
   `categories_detail_child` tinyint(1) NOT NULL DEFAULT '0',
   `impact_1` VARCHAR(200) DEFAULT '#337ab7' NOT NULL,
   `impact_2` VARCHAR(200) DEFAULT '#5cb85c' NOT NULL,
   `impact_3` VARCHAR(200) DEFAULT '#5bc0de' NOT NULL,
   `impact_4` VARCHAR(200) DEFAULT '#f0ad4e' NOT NULL,
   `impact_5` VARCHAR(200) DEFAULT '#d9534f' NOT NULL,
   `urgency_1` VARCHAR(200) DEFAULT '#337ab7' NOT NULL,
   `urgency_2` VARCHAR(200) DEFAULT '#5cb85c' NOT NULL,
   `urgency_3` VARCHAR(200) DEFAULT '#5bc0de' NOT NULL,
   `urgency_4` VARCHAR(200) DEFAULT '#f0ad4e' NOT NULL,
   `urgency_5` VARCHAR(200) DEFAULT '#d9534f' NOT NULL,
   `levelCat` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_servicecatalog_configs`
(`id`, `comment`, `comment_incident`, `comment_request`, `cat_size`)
VALUES (1, '', '', '', 'normal');
--
-- Structure de la table 'glpi_plugin_servicecatalog_configtranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configtranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_configtranslations` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `items_id` int(11) NOT NULL DEFAULT '0',
   `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
   `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `value` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categories'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categories`;
CREATE TABLE `glpi_plugin_servicecatalog_categories` (
   `id` int(11) NOT NULL auto_increment, -- id
   `glpi_itilcategories_id` int(11) NOT NULL DEFAULT 0,
   `picture` varchar(255) DEFAULT NULL,
   `comment` varchar(255) DEFAULT NULL,
   `service_detail` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_users` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_ttr` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_use` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_supervision` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_rules` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_links` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY  (`id`),
   KEY `glpi_itilcategories_id` (`glpi_itilcategories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categorytranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categorytranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_categorytranslations` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `items_id` int(11) NOT NULL DEFAULT '0',
   `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
   `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `value` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categoryorders'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categoryorders`;
CREATE TABLE `glpi_plugin_servicecatalog_categoryorders` (
   `id` int(11) NOT NULL auto_increment, -- id
   `entities_id` int(11) NOT NULL DEFAULT 0,
   `glpi_itilcategories_id` int(11) NOT NULL DEFAULT 0,
   `type` int(11) NOT NULL DEFAULT 0,
   `ranking` int(11) NULL,
   `parent_id` int(11) NOT NULL DEFAULT 0,
   `level` int(11) NOT NULL DEFAULT 0,
   PRIMARY KEY  (`id`),
   KEY `entities_id` (`entities_id`),
   KEY `glpi_itilcategories_id` (`glpi_itilcategories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_keywords'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_keywords`;
CREATE TABLE `glpi_plugin_servicecatalog_keywords` (
   `id` int(11) NOT NULL auto_increment, -- id
   `glpi_plugin_servicecatalog_categoryorders_id` int(11) NOT NULL DEFAULT 0,
   `name` varchar(255) DEFAULT NULL,
   PRIMARY KEY  (`id`),
   KEY `glpi_plugin_servicecatalog_categoryorders_id` (`glpi_plugin_servicecatalog_categoryorders_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_ticketchecks'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_ticketchecks`;
CREATE TABLE `glpi_plugin_servicecatalog_ticketchecks` (
   `id` int(11) NOT NULL auto_increment, -- id
   `tickets_id` int(11) NOT NULL DEFAULT 0,
   PRIMARY KEY  (`id`),
   KEY `tickets_id` (`tickets_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_links`;
CREATE TABLE `glpi_plugin_servicecatalog_links` (
   `id` int(11) NOT NULL auto_increment, -- id
   `entities_id` int(11) NOT NULL DEFAULT 0,
   `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
   `name` varchar(255) DEFAULT NULL,
   `url` varchar(255) DEFAULT NULL,
   `target` tinyint(1) NOT NULL DEFAULT '1',
   `picture` varchar(255) DEFAULT NULL,
   `comment` varchar(255) DEFAULT NULL,
   `display_at_home` tinyint(1) NOT NULL DEFAULT '1',
   PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linkgroups`;
CREATE TABLE `glpi_plugin_servicecatalog_linkgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groups_id` int(11) NOT NULL default '0',
  `plugin_servicecatalog_links_id` int(11) NOT NULL default '0',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`plugin_servicecatalog_links_id`) REFERENCES glpi_plugin_servicecatalog_links(id),
  FOREIGN KEY (`groups_id`) REFERENCES glpi_groups(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_linktranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linktranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_linktranslations` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `items_id` int(11) NOT NULL DEFAULT '0',
   `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
   `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `value` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_dashboards`;
CREATE TABLE `glpi_plugin_servicecatalog_dashboards` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `users_id` int(11) NOT NULL default '0',
   `grid` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
   `grid_statesave` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
   `drag_mode` tinyint(1) NOT NULL DEFAULT '0',
   `profiles_id` int(11) NOT NULL DEFAULT '0',
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;

INSERT INTO `glpi_plugin_servicecatalog_dashboards` (`id`, `users_id`, `grid`) VALUES
   (1, 0, '[{"id":"gs1","x":0,"y":0,"width":6,"height":18},
            {"id":"gs3","x":0,"y":6,"width":6,"height":6},
            {"id":"gs10","x":6,"y":6,"width":6,"height":6},
            {"id":"gs11","x":6,"y":6,"width":6,"height":6}]'
            );

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_contacts`;
CREATE TABLE `glpi_plugin_servicecatalog_contacts` (
   `id` int(11) NOT NULL auto_increment, -- id
   `entities_id` int(11) NOT NULL DEFAULT 0,
   `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
   `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `address` text COLLATE utf8_unicode_ci,
   `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
   `opening_hours` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY  (`id`),
   KEY `entities_id` (`entities_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_tickettemplates`;
CREATE TABLE `glpi_plugin_servicecatalog_tickettemplates` (
   `id` int(11) NOT NULL auto_increment, -- id
   `tickettemplates_id` int(11) NOT NULL DEFAULT 0,
   `field` int(11) NOT NULL DEFAULT '0',
   PRIMARY KEY  (`id`),
   KEY `tickettemplates_id` (`tickettemplates_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_entities`;
CREATE TABLE `glpi_plugin_servicecatalog_entities` (
   `id` int(11) NOT NULL auto_increment, -- id
   `entities_id` int(11) NOT NULL DEFAULT 0,
   `picture` varchar(255) DEFAULT NULL,
   `comment` varchar(255) DEFAULT NULL,
   PRIMARY KEY  (`id`),
   KEY `entities_id` (`entities_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_formcreators`;
CREATE TABLE `glpi_plugin_servicecatalog_formcreators` (
   `id` int(11) NOT NULL auto_increment, -- id
   `plugin_formcreator_forms_id` int(11) NOT NULL DEFAULT 0,
   `itilcategories_id` int(11) NOT NULL DEFAULT '0',
   PRIMARY KEY  (`id`),
   KEY `plugin_formcreator_forms_id` (`plugin_formcreator_forms_id`),
   KEY `itilcategories_id` (`itilcategories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_fieldorders`;
CREATE TABLE `glpi_plugin_servicecatalog_fieldorders` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `name` varchar(255) DEFAULT NULL,
   `ranking` int(11)  NOT NULL DEFAULT '0',
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;

INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`)
VALUES (1, 'urgencies', '0'),
       (2, 'timeToResolve', '1'),
       (3, 'approvalRequest', '2'),
       (4, 'informMe', '3'),
       (5, 'hardwareType', '4'),
       (6, 'location', '5'),
       (7, 'watcher', '6'),
       (8, 'impact', '7'),
       (9, 'title', '8'),
       (10, 'contentAndFile', '9');