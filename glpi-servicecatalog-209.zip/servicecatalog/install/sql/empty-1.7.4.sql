--
-- Structure de la table 'glpi_plugin_servicecatalog_configs'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configs`;
CREATE TABLE `glpi_plugin_servicecatalog_configs`
(
    `id`                                  int(11)      NOT NULL auto_increment, -- id
    `title`                               varchar(255)          DEFAULT NULL,
    `comment`                             TEXT                  DEFAULT NULL,
    `general_color`                       varchar(10)          DEFAULT '#cccccc',
    `general_hover_color`                 varchar(10)          DEFAULT '#8f8e8e',
    `replace_ticket_creation_form`        tinyint(1)   NOT NULL DEFAULT '1',
    `replace_ticket_update_form`          tinyint(1)   NOT NULL DEFAULT '0',
    `drop_helpdesk_menu`                  tinyint(1)   NOT NULL DEFAULT '0',
    `drop_home_button`                    tinyint(1)   NOT NULL DEFAULT '0',
    `drop_languages_button`               tinyint(1)   NOT NULL DEFAULT '0',
    `drop_help_button`                    tinyint(1)   NOT NULL DEFAULT '0',
    `drop_savedsearchs_button`            tinyint(1)   NOT NULL DEFAULT '0',
    `drop_preferences_button`             tinyint(1)   NOT NULL DEFAULT '0',
    `drop_logout_button`                  tinyint(1)   NOT NULL DEFAULT '0',
    `hide_mail_followup`                  tinyint(1)   NOT NULL DEFAULT '0',
    `see_more_informations`               tinyint(1)   NOT NULL DEFAULT '1',
    `see_faq_articles`                    tinyint(1)   NOT NULL DEFAULT '1',
    `see_category_details`                tinyint(1)   NOT NULL DEFAULT '1',
    `palette`                             varchar(255) NOT NULL DEFAULT 'grey',
    `layout`                              tinyint(1)   NOT NULL DEFAULT '0',
    `header`                              tinyint(1) NOT NULL DEFAULT '1',
    `title_searchbar_request`             varchar(255)          DEFAULT NULL,
    `title_searchbar_incident`            varchar(255)          DEFAULT NULL,
    `title_searchbar_kb`                  varchar(255)          DEFAULT NULL,
    `display_logo_category_detail`        tinyint(1)   NOT NULL DEFAULT '1',
    `multi_entity_redirection`            tinyint(1)   NOT NULL DEFAULT '0',
    `title_watchers_dropdown`             varchar(255)          DEFAULT NULL,
    `title_submit_message_button`         varchar(255)          DEFAULT NULL,
    `title_your_open_tickets`             varchar(255)          DEFAULT NULL,
    `title_your_open_incidents`           varchar(255)          DEFAULT NULL,
    `title_your_open_requests`            varchar(255)          DEFAULT NULL,
    `title_your_and_group_open_incidents` varchar(255)          DEFAULT NULL,
    `title_your_and_group_open_requests`  varchar(255)          DEFAULT NULL,
    `title_your_resolved_tickets`         varchar(255)          DEFAULT NULL,
    `title_your_tickets_to_validate`      varchar(255)          DEFAULT NULL,
    `select_title_incident_category`      varchar(255)          DEFAULT NULL,
    `select_title_request_category`       varchar(255)          DEFAULT NULL,
    `title_favorites_category`            varchar(255)          DEFAULT NULL,
    `select_title_faq_article`            varchar(255)          DEFAULT NULL,
    `cat_size`                            varchar(255)          DEFAULT NULL,
    `keywords`                            tinyint(1)   NOT NULL DEFAULT '1',
    `groups_restriction`                  tinyint(1)   NOT NULL DEFAULT '0',
    `groups_restriction_recursive`        tinyint(1)   NOT NULL DEFAULT '0',
    `impact_1`                            varchar(10)          DEFAULT '#337ab7' NOT NULL,
    `impact_2`                            varchar(10)          DEFAULT '#5cb85c' NOT NULL,
    `impact_3`                            varchar(10)          DEFAULT '#5bc0de' NOT NULL,
    `impact_4`                            varchar(10)          DEFAULT '#f0ad4e' NOT NULL,
    `impact_5`                            varchar(10)          DEFAULT '#d9534f' NOT NULL,
    `urgency_1`                           varchar(10)          DEFAULT '#337ab7' NOT NULL,
    `urgency_2`                           varchar(10)          DEFAULT '#5cb85c' NOT NULL,
    `urgency_3`                           varchar(10)          DEFAULT '#5bc0de' NOT NULL,
    `urgency_4`                           varchar(10)          DEFAULT '#f0ad4e' NOT NULL,
    `urgency_5`                           varchar(10)          DEFAULT '#d9534f' NOT NULL,
    `levelCat`                            int(11)      NOT NULL DEFAULT '2',
    `seetop`                              tinyint(1)   NOT NULL DEFAULT '1',
    `use_all_tab_default`                 tinyint(1)   NOT NULL DEFAULT '0',
    `drop_helpdesk_footer`                tinyint(1)   NOT NULL DEFAULT '0',
    `display_phone_number`                tinyint(1)   NOT NULL DEFAULT '0',
    `title_phone_number`                  varchar(255)          DEFAULT NULL,
    `title_ticket`                        varchar(255)          DEFAULT NULL,
    `title_description_ticket`            varchar(255)          DEFAULT NULL,
    `fa_back`                             varchar(100)          DEFAULT NULL,
    `add_requesters_from_tickets`         varchar(255)          DEFAULT NULL,
    `add_observers_from_tickets`          varchar(255)          DEFAULT NULL,
    `default_icon`                        varchar(100) NOT NULL DEFAULT 'fas fa-network-wired',
    `template_ticket_user_update`         int(11)               DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

INSERT INTO `glpi_plugin_servicecatalog_configs`
    (`id`, `cat_size`, `layout`, `general_color`, `general_hover_color`)
VALUES (1, 'normal', '0', '#cccccc', '#8f8e8e');


--
-- Structure de la table 'glpi_plugin_servicecatalog_widgets'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_widgets`;
CREATE TABLE `glpi_plugin_servicecatalog_widgets`
(
    `id`                     int(11)      NOT NULL auto_increment, -- id
    `title_message`          varchar(255)          DEFAULT NULL,
    `comment_message`        TEXT                  DEFAULT NULL,
    `display_incident`       tinyint(1)   NOT NULL DEFAULT '1',
    `incidents_topmenu`      tinyint(1)   NOT NULL DEFAULT '1',
    `title_incident`         varchar(255)          DEFAULT NULL,
    `comment_incident`       TEXT                  DEFAULT NULL,
    `img_incident`           varchar(255)          DEFAULT NULL,
    `fa_incident`            varchar(100) NOT NULL DEFAULT 'fas fa-hands-helping',
    `display_request`        tinyint(1)   NOT NULL DEFAULT '1',
    `requests_topmenu`       tinyint(1)   NOT NULL DEFAULT '1',
    `title_request`          varchar(255)          DEFAULT NULL,
    `comment_request`        TEXT                  DEFAULT NULL,
    `img_request`            varchar(255)          DEFAULT NULL,
    `fa_request`             varchar(100) NOT NULL DEFAULT 'fas fa-question',
    `display_tickets_list`   tinyint(1)   NOT NULL DEFAULT '1',
    `title_tickets_list`     varchar(255)          DEFAULT NULL,
    `comment_tickets`        TEXT                  DEFAULT NULL,
    `img_tickets_list`       varchar(255)          DEFAULT NULL,
    `fa_tickets_list`        varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `display_incidents_list` tinyint(1)   NOT NULL DEFAULT '0',
    `title_incidents_list`   varchar(255)          DEFAULT NULL,
    `comment_incidents_list` TEXT                  DEFAULT NULL,
    `img_incidents_list`     varchar(255)          DEFAULT NULL,
    `fa_incidents_list`      varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `display_requests_list`  tinyint(1)   NOT NULL DEFAULT '0',
    `title_requests_list`    varchar(255)          DEFAULT NULL,
    `comment_requests_list`  TEXT                  DEFAULT NULL,
    `img_requests_list`      varchar(255)          DEFAULT NULL,
    `fa_requests_list`       varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `faq_topmenu`            tinyint(1)   NOT NULL DEFAULT '1',
    `title_faq`              varchar(255)          DEFAULT NULL,
    `comment_faq`            TEXT                  DEFAULT NULL,
    `fa_faq`                 varchar(100) NOT NULL DEFAULT 'fas fa-medkit',
    `img_faq`                varchar(255)          DEFAULT NULL,
    `title_validation`       varchar(255)          DEFAULT NULL,
    `comment_validation`     TEXT                  DEFAULT NULL,
    `img_validation`         varchar(255)          DEFAULT NULL,
    `fa_validation`          VARCHAR(100) NOT NULL DEFAULT 'fas fa-file-signature',
    `title_personalinfo`     varchar(255)          DEFAULT NULL,
    `comment_personalinfo`   TEXT                  DEFAULT NULL,
    `img_personalinfo`       varchar(255)          DEFAULT NULL,
    `fa_personalinfo`        varchar(100) NOT NULL DEFAULT 'fas fa-address-card',
    `links_topmenu`          tinyint(1)   NOT NULL DEFAULT '1',
    `title_links`            varchar(255)          DEFAULT NULL,
    `comment_links`          TEXT                  DEFAULT NULL,
    `img_links`              varchar(255)          DEFAULT NULL,
    `fa_links`               varchar(100) NOT NULL DEFAULT 'fas fa-link',
    `title_reservation`      varchar(255)          DEFAULT NULL,
    `comment_reservation`    TEXT                  DEFAULT NULL,
    `img_reservation`        varchar(255)          DEFAULT NULL,
    `fa_reservation`         varchar(100) NOT NULL DEFAULT 'fas fa-calendar-alt',
    `display_entity_name`    tinyint(1)   NOT NULL DEFAULT '0',
    `title_entity_list`      varchar(255)          DEFAULT NULL,
    `comment_entity_list`    TEXT                  DEFAULT NULL,
    `title_entity`           varchar(255)          DEFAULT NULL,
    `comment_entity`         TEXT                  DEFAULT NULL,
    `fa_entity`              varchar(100) NOT NULL DEFAULT 'fas fa-globe',
    `img_entity`             varchar(255)          DEFAULT NULL,
    `linked_kbcategory`      int(11)      NOT NULL DEFAULT '0',
    `title_database`         varchar(255)          DEFAULT NULL,
    `comment_database`       TEXT                  DEFAULT NULL,
    `fa_database`            varchar(100) NOT NULL DEFAULT 'fas fa-book',
    `img_database`           varchar(255)          DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

INSERT INTO `glpi_plugin_servicecatalog_widgets`
    (`id`)
VALUES (1);

--
-- Structure de la table 'glpi_plugin_servicecatalog_configtranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configtranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_configtranslations`
(
    `id`       int(11) NOT NULL AUTO_INCREMENT,
    `items_id` int(11) NOT NULL                     DEFAULT '0',
    `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
    `language` varchar(5) COLLATE utf8_unicode_ci   DEFAULT NULL,
    `field`    varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
    `value`    text COLLATE utf8_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci
  AUTO_INCREMENT = 1;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categories'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categories`;
CREATE TABLE `glpi_plugin_servicecatalog_categories`
(
    `id`                  int(11)    NOT NULL auto_increment, -- id
    `itilcategories_id`   int(11)    NOT NULL          DEFAULT 0,
    `inherit_picture`     tinyint(1) NOT NULL          DEFAULT '0',
    `picture`             varchar(255)                 DEFAULT NULL,
    `icon`                varchar(255)                 DEFAULT NULL,
    `background_color`    VARCHAR(200)                 DEFAULT NULL,
    `size`                VARCHAR(200)                 DEFAULT NULL,
    `glue`                tinyint(1) NOT NULL          DEFAULT '0',
    `inherit_config`      tinyint(1) NOT NULL          DEFAULT '0',
    `comment`             varchar(255)                 DEFAULT NULL,
    `inherit_detail`      tinyint(1) NOT NULL          DEFAULT '0',
    `inherit_alert`       tinyint(1) NOT NULL          DEFAULT '0',
    `service_detail`      text COLLATE utf8_unicode_ci DEFAULT NULL,
    `service_users`       text COLLATE utf8_unicode_ci DEFAULT NULL,
    `service_ttr`         text COLLATE utf8_unicode_ci DEFAULT NULL,
    `service_use`         text COLLATE utf8_unicode_ci DEFAULT NULL,
    `service_supervision` text COLLATE utf8_unicode_ci DEFAULT NULL,
    `service_rules`       text COLLATE utf8_unicode_ci DEFAULT NULL,
    `service_links`       text COLLATE utf8_unicode_ci DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `itilcategories_unique` (`itilcategories_id`),
    KEY `itilcategories_id` (`itilcategories_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categorytranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categorytranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_categorytranslations`
(
    `id`       int(11) NOT NULL AUTO_INCREMENT,
    `items_id` int(11) NOT NULL                     DEFAULT '0',
    `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
    `language` varchar(5) COLLATE utf8_unicode_ci   DEFAULT NULL,
    `field`    varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
    `value`    text COLLATE utf8_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci
  AUTO_INCREMENT = 1;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categoryorders'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categoryorders`;
CREATE TABLE `glpi_plugin_servicecatalog_categoryorders`
(
    `id`                int(11) NOT NULL auto_increment, -- id
    `entities_id`       int(11) NOT NULL DEFAULT 0,
    `itilcategories_id` int(11) NOT NULL DEFAULT 0,
    `type`              int(11) NOT NULL DEFAULT 0,
    `ranking`           int(11) NULL,
    `parent_id`         int(11) NOT NULL DEFAULT 0,
    `level`             int(11) NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `entities_id` (`entities_id`),
    KEY `itilcategories_id` (`itilcategories_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_keywords'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_keywords`;
CREATE TABLE `glpi_plugin_servicecatalog_keywords`
(
    `id`                                  int(11) NOT NULL auto_increment, -- id
    `plugin_servicecatalog_categories_id` int(11) NOT NULL DEFAULT 0,
    `name`                                varchar(255)     DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `plugin_servicecatalog_categories_id` (`plugin_servicecatalog_categories_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_groups'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_groups`;
CREATE TABLE `glpi_plugin_servicecatalog_groups`
(
    `id`                                  int(11) NOT NULL auto_increment, -- id
    `plugin_servicecatalog_categories_id` int(11) NOT NULL DEFAULT 0,
    `groups_id`                           int(11) NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `plugin_servicecatalog_categories_id` (`plugin_servicecatalog_categories_id`),
    KEY `groups_id` (`groups_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_ticketchecks'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_ticketchecks`;
CREATE TABLE `glpi_plugin_servicecatalog_ticketchecks`
(
    `id`         int(11) NOT NULL auto_increment, -- id
    `tickets_id` int(11) NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `tickets_id` (`tickets_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_links`;
CREATE TABLE `glpi_plugin_servicecatalog_links`
(
    `id`              int(11)    NOT NULL auto_increment, -- id
    `entities_id`     int(11)    NOT NULL DEFAULT 0,
    `is_recursive`    tinyint(1) NOT NULL DEFAULT '0',
    `name`            varchar(255)        DEFAULT NULL,
    `url`             varchar(255)        DEFAULT NULL,
    `target`          tinyint(1) NOT NULL DEFAULT '1',
    `icon`            varchar(255)        DEFAULT NULL,
    `picture`         varchar(255)        DEFAULT NULL,
    `comment`         varchar(255)        DEFAULT NULL,
    `display_at_home` tinyint(1) NOT NULL DEFAULT '1',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linkgroups`;
CREATE TABLE `glpi_plugin_servicecatalog_linkgroups`
(
    `id`                             int(11) NOT NULL AUTO_INCREMENT,
    `groups_id`                      int(11) NOT NULL default '0',
    `plugin_servicecatalog_links_id` int(11) NOT NULL default '0',
    PRIMARY KEY (`id`),
    FOREIGN KEY (`plugin_servicecatalog_links_id`) REFERENCES glpi_plugin_servicecatalog_links (id),
    FOREIGN KEY (`groups_id`) REFERENCES glpi_groups (id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_linktranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linktranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_linktranslations`
(
    `id`       int(11) NOT NULL AUTO_INCREMENT,
    `items_id` int(11) NOT NULL                     DEFAULT '0',
    `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
    `language` varchar(5) COLLATE utf8_unicode_ci   DEFAULT NULL,
    `field`    varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
    `value`    text COLLATE utf8_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci
  AUTO_INCREMENT = 1;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_dashboards`;
CREATE TABLE `glpi_plugin_servicecatalog_dashboards`
(
    `id`             int(11)    NOT NULL AUTO_INCREMENT,
    `entities_id`    int(11)    NOT NULL              DEFAULT 0,
    `is_recursive`   tinyint(1) NOT NULL              DEFAULT '0',
    `users_id`       int(11)    NOT NULL              default '0',
    `grid`           longtext COLLATE utf8_unicode_ci DEFAULT NULL,
    `grid_statesave` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
    `drag_mode`      tinyint(1) NOT NULL              DEFAULT '0',
    `profiles_id`    int(11)    NOT NULL              DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci
  AUTO_INCREMENT = 1;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_contacts`;
CREATE TABLE `glpi_plugin_servicecatalog_contacts`
(
    `id`            int(11)    NOT NULL auto_increment, -- id
    `entities_id`   int(11)    NOT NULL                  DEFAULT 0,
    `is_recursive`  tinyint(1) NOT NULL                  DEFAULT '0',
    `name`          varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `phonenumber`   varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `email`         varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `address`       text COLLATE utf8_unicode_ci,
    `postcode`      varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `town`          varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `state`         varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `country`       varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `opening_hours` text COLLATE utf8_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `entities_id` (`entities_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_tickettemplates`;
CREATE TABLE `glpi_plugin_servicecatalog_tickettemplates`
(
    `id`                 int(11) NOT NULL auto_increment, -- id
    `tickettemplates_id` int(11) NOT NULL DEFAULT 0,
    `field`              int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `tickettemplates_id` (`tickettemplates_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_entities`;
CREATE TABLE `glpi_plugin_servicecatalog_entities`
(
    `id`          int(11) NOT NULL auto_increment, -- id
    `entities_id` int(11) NOT NULL DEFAULT 0,
    `picture`     varchar(255)     DEFAULT NULL,
    `comment`     varchar(255)     DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `entities_id` (`entities_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_formcreators`;
CREATE TABLE `glpi_plugin_servicecatalog_formcreators`
(
    `id`                          int(11) NOT NULL auto_increment, -- id
    `plugin_formcreator_forms_id` int(11) NOT NULL DEFAULT 0,
    `itilcategories_id`           int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `plugin_formcreator_forms_id` (`plugin_formcreator_forms_id`),
    KEY `itilcategories_id` (`itilcategories_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_fieldorders`;
CREATE TABLE `glpi_plugin_servicecatalog_fieldorders`
(
    `id`      int(11) NOT NULL AUTO_INCREMENT,
    `name`    varchar(255)     DEFAULT NULL,
    `ranking` int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci
  AUTO_INCREMENT = 1;

INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`)
VALUES (1, 'urgencies', '0'),
       (2, 'timeToResolve', '1'),
       (3, 'approvalRequest', '2'),
       (4, 'informMe', '3'),
       (5, 'hardwareType', '4'),
       (6, 'location', '5'),
       (7, 'watcher', '6'),
       (8, 'impact', '7'),
       (9, 'title', '8'),
       (10, 'contentAndFile', '9'),
       (11, 'phonenumber', '10');


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_widgetbuttonorders`;
CREATE TABLE `glpi_plugin_servicecatalog_widgetbuttonorders`
(
    `id`            int(11) NOT NULL AUTO_INCREMENT,
    `name`          varchar(255)     DEFAULT NULL,
    `url`           varchar(255)     DEFAULT NULL,
    `internal_name` varchar(255)     DEFAULT NULL,
    `ranking`       int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci
  AUTO_INCREMENT = 1;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites`
(
    `id`                         int(11) NOT NULL AUTO_INCREMENT,
    `itilcategories_id`          int(11) NOT NULL DEFAULT '0',
    `users_id`                   int(11) NOT NULL default '0',
    `favorite_itilcategories_id` int(11) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `itilcategories_id` (`itilcategories_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_entities_favorites`;
CREATE TABLE `glpi_plugin_servicecatalog_entities_favorites`
(
    `id`           int(11)    NOT NULL AUTO_INCREMENT,
    `favorites_id` int(11)    NOT NULL DEFAULT '0',
    `entities_id`  int(11)    NOT NULL DEFAULT '0',
    `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `entities_id` (`entities_id`),
    KEY `is_recursive` (`is_recursive`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites_users`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites_users`
(
    `id`                int(11) NOT NULL AUTO_INCREMENT,
    `favorites_id`      int(11) NOT NULL DEFAULT '0',
    `users_id`          int(11) NOT NULL DEFAULT '0',
    `ranking_requests`  int(11) NOT NULL DEFAULT '0',
    `ranking_incidents` int(11) NOT NULL DEFAULT '0',
    `type_favorites`    int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `users_id` (`users_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites_groups`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites_groups`
(
    `id`           int(11)    NOT NULL AUTO_INCREMENT,
    `favorites_id` int(11)    NOT NULL DEFAULT '0',
    `groups_id`    int(11)    NOT NULL DEFAULT '0',
    `entities_id`  int(11)    NOT NULL DEFAULT '-1',
    `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `groups_id` (`groups_id`),
    KEY `entities_id` (`entities_id`),
    KEY `is_recursive` (`is_recursive`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites_profiles`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites_profiles`
(
    `id`           int(11)    NOT NULL AUTO_INCREMENT,
    `favorites_id` int(11)    NOT NULL DEFAULT '0',
    `profiles_id`  int(11)    NOT NULL DEFAULT '0',
    `entities_id`  int(11)    NOT NULL DEFAULT '-1',
    `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `profiles_id` (`profiles_id`),
    KEY `entities_id` (`entities_id`),
    KEY `is_recursive` (`is_recursive`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;
