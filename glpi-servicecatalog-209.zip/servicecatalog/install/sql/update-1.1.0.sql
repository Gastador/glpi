ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `comment_database` TEXT DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `linked_kbcategory` int(11) NOT NULL DEFAULT '0';

