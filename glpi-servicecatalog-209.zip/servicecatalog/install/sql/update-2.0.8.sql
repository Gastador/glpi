ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `use_detail_before_creation` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD  `picture_detail` VARCHAR(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD  `picture_detail_width` int DEFAULT '100';
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD  `visibility_group` tinyint NOT NULL DEFAULT '0';