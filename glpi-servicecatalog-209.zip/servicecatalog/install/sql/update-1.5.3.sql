--
-- Structure de la table 'glpi_plugin_servicecatalog_groups'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_groups`;
CREATE TABLE `glpi_plugin_servicecatalog_groups` (
   `id` int(11) NOT NULL auto_increment, -- id
   `plugin_servicecatalog_categories_id` int(11) NOT NULL DEFAULT 0,
   `groups_id` int(11) NOT NULL DEFAULT 0,
   PRIMARY KEY  (`id`),
   KEY `plugin_servicecatalog_categories_id` (`plugin_servicecatalog_categories_id`),
   KEY `groups_id` (`groups_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `groups_restriction` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `groups_restriction_recursive` tinyint(1) NOT NULL DEFAULT '0';

ALTER TABLE glpi_plugin_servicecatalog_categories CHANGE glpi_itilcategories_id itilcategories_id int(11);
ALTER TABLE glpi_plugin_servicecatalog_categoryorders CHANGE glpi_itilcategories_id itilcategories_id int(11);
ALTER TABLE glpi_plugin_servicecatalog_keywords CHANGE glpi_plugin_servicecatalog_categoryorders_id plugin_servicecatalog_categories_id int(11);

