SET SESSION innodb_strict_mode=OFF;
ALTER TABLE `glpi_plugin_servicecatalog_categories`
    ADD `inherit_detail` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_categories`
    ADD `inherit_alert` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `select_title_faq_article` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories`
    ADD `inherit_picture` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `img_faq` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `img_database` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `img_entity` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `img_links` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `img_reservation` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `fa_reservations` `fa_reservation` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'fas fa-calendar-alt';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `comment_entity` `title_entity` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `comment_entity` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_database` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `title` `title_message` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `comment_title` `comment_message` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_entity_list` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `comment_entity_list` varchar(50) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_dashboards`
    ADD `entities_id` int(11) NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_dashboards`
    ADD `is_recursive` int(11) NOT NULL DEFAULT 1;