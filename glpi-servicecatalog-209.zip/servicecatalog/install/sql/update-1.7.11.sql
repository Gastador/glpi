ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `display_topmenu` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `see_widgets_border` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `template_cancel_ticket` int unsigned DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_ticketappointments`
    ADD `users_id_requester` int unsigned NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `palette` `navbar-palette` varchar(10) DEFAULT '#cccccc';
UPDATE `glpi_plugin_servicecatalog_configs` SET `navbar-palette` = `general_color` WHERE `glpi_plugin_servicecatalog_configs`.`id` = 1;

ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '#cccccc';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_background_color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '#8f8e8e';
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `knowbaseitems_id` int unsigned NOT NULL DEFAULT 0;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `create_ticket_reservation` tinyint DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `template_ticket_assets_user_update` int unsigned DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `template_ticket_reservation` int unsigned DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `bypass_categories_selection` tinyint(1) NOT NULL DEFAULT '0';
INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`) VALUES (12, 'itilcategories', '11');
