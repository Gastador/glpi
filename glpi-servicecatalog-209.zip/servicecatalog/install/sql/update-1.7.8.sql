ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `leftbar_style` tinyint NOT NULL DEFAULT '0';
