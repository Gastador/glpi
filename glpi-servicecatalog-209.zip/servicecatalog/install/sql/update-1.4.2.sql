CREATE TABLE `glpi_plugin_servicecatalog_formcreators` (
  `id` int(11) NOT NULL auto_increment, -- id
  `plugin_formcreator_forms_id` int(11) NOT NULL DEFAULT 0,
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`),
  KEY `plugin_formcreator_forms_id` (`plugin_formcreator_forms_id`),
  KEY `itilcategories_id` (`itilcategories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
