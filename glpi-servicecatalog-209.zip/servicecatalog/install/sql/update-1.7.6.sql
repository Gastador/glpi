ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `display_closedtickets_menu` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_closedtickets_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `fa_closedtickets_menu` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `force_delegating` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_categories` CHANGE `comment` `comment` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
