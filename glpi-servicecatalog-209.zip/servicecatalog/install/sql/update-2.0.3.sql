ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `force_delegating_restriction` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `actors_restriction` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `comment_urgency` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `comment_impact` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `use_table_lists` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `use_integrated_search` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `favorites_topmenu` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `default_number_rows` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `radius_border` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_links` ADD `display_on_actions_widget` tinyint NOT NULL DEFAULT '1';

ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `incidents_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `requests_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `tickets_list_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `incidents_list_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `requests_list_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `faq_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `links_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `ticketvalidation_list_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `display_personalinfo` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `display_links` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `personalinfo_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `reservation_widgetactions` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgets` ADD `docbase_widgetactions` tinyint NOT NULL DEFAULT '1';

ALTER TABLE `glpi_plugin_servicecatalog_entities` ADD `layout` tinyint NOT NULL DEFAULT '-1';

ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `show_asset_update_button` tinyint NOT NULL DEFAULT '1';
