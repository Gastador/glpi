--
-- Structure de la table 'glpi_plugin_servicecatalog_configs'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configs`;
CREATE TABLE `glpi_plugin_servicecatalog_configs`
(
    `id`                                  int unsigned NOT NULL auto_increment,
    `title`                               varchar(255)                    DEFAULT NULL,
    `comment`                             TEXT                            DEFAULT NULL,
    `use_own_colors`                      tinyint      NOT NULL           DEFAULT '1',
    `general_color`                       varchar(10)                     DEFAULT '#cccccc',
    `general_hover_color`                 varchar(10)                     DEFAULT '#8f8e8e',
    `title_color`                         varchar(10)                     DEFAULT '#cccccc',
    `title_background_color`              varchar(10)                     DEFAULT '#8f8e8e',
    `bypass_categories_selection`         tinyint      NOT NULL           DEFAULT '0',
    `drop_helpdesk_menu`                  tinyint      NOT NULL           DEFAULT '0',
    `drop_home_button`                    tinyint      NOT NULL           DEFAULT '0',
    `drop_languages_button`               tinyint      NOT NULL           DEFAULT '0',
    `drop_help_button`                    tinyint      NOT NULL           DEFAULT '0',
    `drop_savedsearchs_button`            tinyint      NOT NULL           DEFAULT '0',
    `drop_preferences_button`             tinyint      NOT NULL           DEFAULT '0',
    `drop_logout_button`                  tinyint      NOT NULL           DEFAULT '0',
    `hide_mail_followup`                  tinyint      NOT NULL           DEFAULT '0',
    `see_more_informations`               tinyint      NOT NULL           DEFAULT '1',
    `see_faq_articles`                    tinyint      NOT NULL           DEFAULT '1',
    `see_category_details`                tinyint      NOT NULL           DEFAULT '1',
    `navbar-palette`                      varchar(10)                     DEFAULT '#cccccc',
    `layout`                              tinyint      NOT NULL           DEFAULT '0',
    `title_searchbar_request`             TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_searchbar_incident`            TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_searchbar_kb`                  TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `display_logo_category_detail`        tinyint      NOT NULL           DEFAULT '1',
    `multi_entity_redirection`            tinyint      NOT NULL           DEFAULT '0',
    `title_watchers_dropdown`             TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_urgency`                       TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `comment_urgency`                     TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_impact`                        TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `comment_impact`                      TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_time_to_resolve`               TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_add_validation`                TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_preferences`                   TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_inform_me`                     TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_location`                      TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_delegation`                    TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_category`                      TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `use_itemtypes_display`               tinyint      NOT NULL           DEFAULT '0',
    `title_items_dropdown`                TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_others_infos`                  TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_submit_message_button`         TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_your_open_tickets`             TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_your_open_incidents`           TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_your_open_requests`            TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_your_and_group_open_incidents` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_your_and_group_open_requests`  TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_your_resolved_tickets`         TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_your_tickets_to_validate`      TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `select_title_incident_category`      TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `select_title_request_category`       TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_favorites_category`            TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `select_title_faq_article`            TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `cat_size`                            TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `keywords`                            tinyint      NOT NULL           DEFAULT '1',
    `groups_restriction`                  tinyint      NOT NULL           DEFAULT '0',
    `groups_restriction_recursive`        tinyint      NOT NULL           DEFAULT '0',
    `impact_1`                            varchar(10)                     DEFAULT '#337ab7' NOT NULL,
    `impact_2`                            varchar(10)                     DEFAULT '#5cb85c' NOT NULL,
    `impact_3`                            varchar(10)                     DEFAULT '#5bc0de' NOT NULL,
    `impact_4`                            varchar(10)                     DEFAULT '#f0ad4e' NOT NULL,
    `impact_5`                            varchar(10)                     DEFAULT '#d9534f' NOT NULL,
    `urgency_1`                           varchar(10)                     DEFAULT '#337ab7' NOT NULL,
    `urgency_2`                           varchar(10)                     DEFAULT '#5cb85c' NOT NULL,
    `urgency_3`                           varchar(10)                     DEFAULT '#5bc0de' NOT NULL,
    `urgency_4`                           varchar(10)                     DEFAULT '#f0ad4e' NOT NULL,
    `urgency_5`                           varchar(10)                     DEFAULT '#d9534f' NOT NULL,
    `levelCat`                            int unsigned NOT NULL DEFAULT '2',
    `seetop`                              tinyint      NOT NULL           DEFAULT '1',
    `use_all_tab_DEFAULT`                 tinyint      NOT NULL           DEFAULT '0',
    `drop_helpdesk_footer`                tinyint      NOT NULL           DEFAULT '0',
    `display_phone_number`                tinyint      NOT NULL           DEFAULT '0',
    `title_phone_number`                  TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `display_requester_group`             tinyint      NOT NULL           DEFAULT '0',
    `title_requester_group`               TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `display_browser_infos`               tinyint      NOT NULL           DEFAULT '0',
    `title_ticket`                        TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_description_ticket`            TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `placeholder_description_ticket`      longtext,
    `fa_back`                             varchar(100)                    DEFAULT NULL,
    `add_requesters_from_tickets`         int unsigned DEFAULT '0',
    `add_observers_from_tickets`          int unsigned DEFAULT '0',
    `actors_restriction`                  tinyint      NOT NULL           DEFAULT '0',
    `DEFAULT_icon`                        varchar(100) NOT NULL           DEFAULT 'fas fa-network-wired',
    `template_ticket_user_update`         int unsigned DEFAULT '0',
    `display_myelements_menu`             tinyint      NOT NULL           DEFAULT '1',
    `title_myelements_menu`               TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_tickets_menu`                  TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_incidents_menu`                TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_requests_menu`                 TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_help_menu`                     TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `title_others_menu`                   TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `fa_myelements_menu`                  varchar(100)                    DEFAULT NULL,
    `display_closedtickets_menu`          tinyint      NOT NULL           DEFAULT '1',
    `title_closedtickets_menu`            TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `fa_closedtickets_menu`               varchar(100)                    DEFAULT NULL,
    `display_myappliances_menu`           tinyint      NOT NULL           DEFAULT '1',
    `title_myappliances_menu`             TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `fa_myappliances_menu`                TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `force_delegating`                    tinyint      NOT NULL           DEFAULT '0',
    `force_delegating_restriction`        tinyint      NOT NULL           DEFAULT '0',
    `new_page_to_create`                  tinyint      NOT NULL           DEFAULT '0',
    `see_widgets_border`                  tinyint      NOT NULL           DEFAULT '0',
    `radius_border`                       tinyint      NOT NULL           DEFAULT '0',
    `template_cancel_ticket`              int unsigned DEFAULT '0',
    `create_ticket_reservation`           tinyint                         DEFAULT '0',
    `show_asset_update_button`            tinyint      NOT NULL           DEFAULT '1',
    `template_ticket_assets_user_update`  int unsigned DEFAULT '0',
    `template_ticket_reservation`         int unsigned DEFAULT '0',
    `demo_mode`                           tinyint      NOT NULL           DEFAULT '0',
    `switch_prefs`                        tinyint      NOT NULL           DEFAULT '1',
    `show_indicators`                     tinyint      NOT NULL           DEFAULT '1',
    `use_as_step`                         tinyint      NOT NULL           DEFAULT '0',
    `template_ticket_incident`            int unsigned DEFAULT '0',
    `template_ticket_request`             int unsigned DEFAULT '0',
    `fields_more_informations`            text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `show_linked_tickets_simplifiedform`  tinyint      NOT NULL           DEFAULT '0',
    `use_table_lists`                     tinyint      NOT NULL           DEFAULT '1',
    `DEFAULT_number_rows`                 tinyint      NOT NULL           DEFAULT '0',
    `use_integrated_search`               tinyint      NOT NULL           DEFAULT '0',
    `use_strict_search`                   tinyint      NOT NULL           DEFAULT '0',
    `columns_for_table`                   text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_plugin_servicecatalog_configs`
    (`id`, `cat_size`, `layout`, `general_color`, `general_hover_color`)
VALUES (1, 'normal', '6', '#cccccc', '#8f8e8e');


--
-- Structure de la table 'glpi_plugin_servicecatalog_widgets'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_widgets`;
CREATE TABLE `glpi_plugin_servicecatalog_widgets`
(
    `id`                                  int unsigned NOT NULL auto_increment,
    `title_message`                       varchar(255)          DEFAULT NULL,
    `comment_message`                     TEXT                  DEFAULT NULL,
    `display_incident`                    tinyint      NOT NULL DEFAULT '1',
    `incidents_topmenu`                   tinyint      NOT NULL DEFAULT '1',
    `incidents_widgetactions`             tinyint      NOT NULL DEFAULT '1',
    `title_incident`                      varchar(255)          DEFAULT NULL,
    `comment_incident`                    TEXT                  DEFAULT NULL,
    `img_incident`                        varchar(255)          DEFAULT NULL,
    `fa_incident`                         varchar(100) NOT NULL DEFAULT 'fas fa-hands-helping',
    `display_request`                     tinyint      NOT NULL DEFAULT '1',
    `requests_topmenu`                    tinyint      NOT NULL DEFAULT '1',
    `requests_widgetactions`              tinyint      NOT NULL DEFAULT '1',
    `title_request`                       varchar(255)          DEFAULT NULL,
    `comment_request`                     TEXT                  DEFAULT NULL,
    `img_request`                         varchar(255)          DEFAULT NULL,
    `fa_request`                          varchar(100) NOT NULL DEFAULT 'fas fa-question',
    `display_tickets_list`                tinyint      NOT NULL DEFAULT '1',
    `title_tickets_list`                  varchar(255)          DEFAULT NULL,
    `comment_tickets`                     TEXT                  DEFAULT NULL,
    `img_tickets_list`                    varchar(255)          DEFAULT NULL,
    `fa_tickets_list`                     varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `tickets_list_widgetactions`          tinyint      NOT NULL DEFAULT '1',
    `display_incidents_list`              tinyint      NOT NULL DEFAULT '0',
    `title_incidents_list`                varchar(255)          DEFAULT NULL,
    `comment_incidents_list`              TEXT                  DEFAULT NULL,
    `img_incidents_list`                  varchar(255)          DEFAULT NULL,
    `fa_incidents_list`                   varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `incidents_list_widgetactions`        tinyint      NOT NULL DEFAULT '1',
    `display_requests_list`               tinyint      NOT NULL DEFAULT '0',
    `title_requests_list`                 varchar(255)          DEFAULT NULL,
    `comment_requests_list`               TEXT                  DEFAULT NULL,
    `img_requests_list`                   varchar(255)          DEFAULT NULL,
    `fa_requests_list`                    varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `requests_list_widgetactions`         tinyint      NOT NULL DEFAULT '1',
    `faq_topmenu`                         tinyint      NOT NULL DEFAULT '1',
    `faq_widgetactions`                   tinyint      NOT NULL DEFAULT '1',
    `title_faq`                           varchar(255)          DEFAULT NULL,
    `comment_faq`                         TEXT                  DEFAULT NULL,
    `fa_faq`                              varchar(100) NOT NULL DEFAULT 'fas fa-medkit',
    `img_faq`                             varchar(255)          DEFAULT NULL,
    `title_validation`                    varchar(255)          DEFAULT NULL,
    `comment_validation`                  TEXT                  DEFAULT NULL,
    `img_validation`                      varchar(255)          DEFAULT NULL,
    `fa_validation`                       VARCHAR(100) NOT NULL DEFAULT 'fas fa-file-signature',
    `ticketvalidation_list_widgetactions` tinyint      NOT NULL DEFAULT '1',
    `display_personalinfo`                tinyint      NOT NULL DEFAULT '1',
    `title_personalinfo`                  varchar(255)          DEFAULT NULL,
    `comment_personalinfo`                TEXT                  DEFAULT NULL,
    `img_personalinfo`                    varchar(255)          DEFAULT NULL,
    `fa_personalinfo`                     varchar(100) NOT NULL DEFAULT 'fas fa-address-card',
    `personalinfo_widgetactions`          tinyint      NOT NULL DEFAULT '1',
    `display_links`                       tinyint      NOT NULL DEFAULT '1',
    `links_topmenu`                       tinyint      NOT NULL DEFAULT '1',
    `links_widgetactions`                 tinyint      NOT NULL DEFAULT '1',
    `title_links`                         varchar(255)          DEFAULT NULL,
    `comment_links`                       TEXT                  DEFAULT NULL,
    `img_links`                           varchar(255)          DEFAULT NULL,
    `fa_links`                            varchar(100) NOT NULL DEFAULT 'fas fa-link',
    `title_reservation`                   varchar(255)          DEFAULT NULL,
    `comment_reservation`                 TEXT                  DEFAULT NULL,
    `img_reservation`                     varchar(255)          DEFAULT NULL,
    `fa_reservation`                      varchar(100) NOT NULL DEFAULT 'fas fa-calendar-alt',
    `reservation_widgetactions`           tinyint      NOT NULL DEFAULT '1',
    `display_entity_name`                 tinyint      NOT NULL DEFAULT '0',
    `title_entity_list`                   varchar(255)          DEFAULT NULL,
    `comment_entity_list`                 TEXT                  DEFAULT NULL,
    `title_entity`                        varchar(255)          DEFAULT NULL,
    `comment_entity`                      TEXT                  DEFAULT NULL,
    `fa_entity`                           varchar(100) NOT NULL DEFAULT 'fas fa-globe',
    `img_entity`                          varchar(255)          DEFAULT NULL,
    `linked_kbcategory`                   int unsigned NOT NULL DEFAULT '0',
    `title_database`                      varchar(255)          DEFAULT NULL,
    `comment_database`                    TEXT                  DEFAULT NULL,
    `fa_database`                         varchar(100) NOT NULL DEFAULT 'fas fa-book',
    `img_database`                        varchar(255)          DEFAULT NULL,
    `docbase_widgetactions`               tinyint      NOT NULL DEFAULT '1',
    `favorites_topmenu`                   tinyint      NOT NULL DEFAULT '1',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_plugin_servicecatalog_widgets`
    (`id`)
VALUES (1);

--
-- Structure de la table 'glpi_plugin_servicecatalog_configtranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configtranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_configtranslations`
(
    `id`       int unsigned NOT NULL AUTO_INCREMENT,
    `items_id` int unsigned NOT NULL DEFAULT '0',
    `itemtype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `language` varchar(5) COLLATE utf8mb4_unicode_ci   DEFAULT NULL,
    `field`    varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `value`    text COLLATE utf8mb4_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categories'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categories`;
CREATE TABLE `glpi_plugin_servicecatalog_categories`
(
    `id`                       int unsigned NOT NULL auto_increment,
    `itilcategories_id`        int unsigned NOT NULL DEFAULT 0,
    `knowbaseitems_id`         int unsigned NOT NULL DEFAULT 0,
    `inherit_picture`          tinyint NOT NULL                DEFAULT '0',
    `simplified_name_incident` varchar(255)                    DEFAULT NULL,
    `simplified_name_request`  varchar(255)                    DEFAULT NULL,
    `display_warning`          text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `picture`                  varchar(255)                    DEFAULT NULL,
    `icon`                     varchar(255)                    DEFAULT NULL,
    `background_color`         VARCHAR(200)                    DEFAULT NULL,
    `size`                     VARCHAR(200)                    DEFAULT NULL,
    `glue`                     tinyint NOT NULL                DEFAULT '0',
    `inherit_config`           tinyint NOT NULL                DEFAULT '0',
    `comment`                  text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `inherit_detail`           tinyint NOT NULL                DEFAULT '0',
    `inherit_alert`            tinyint NOT NULL                DEFAULT '0',
    `service_detail`           text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `service_users`            text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `service_ttr`              text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `service_use`              text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `service_supervision`      text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `service_rules`            text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `service_links`            text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `inherit_itemtypes`        tinyint NOT NULL                DEFAULT '0',
    `itemtypes`                text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `items_id`                 text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `itilcategories_unique` (`itilcategories_id`),
    KEY                        `itilcategories_id` (`itilcategories_id`),
    KEY                        `knowbaseitems_id` (`knowbaseitems_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categorytranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categorytranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_categorytranslations`
(
    `id`       int unsigned NOT NULL AUTO_INCREMENT,
    `items_id` int unsigned NOT NULL DEFAULT '0',
    `itemtype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `language` varchar(5) COLLATE utf8mb4_unicode_ci   DEFAULT NULL,
    `field`    varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `value`    text COLLATE utf8mb4_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categoryorders'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categoryorders`;
CREATE TABLE `glpi_plugin_servicecatalog_categoryorders`
(
    `id`                int unsigned NOT NULL auto_increment,
    `entities_id`       int unsigned NOT NULL DEFAULT 0,
    `itilcategories_id` int unsigned NOT NULL DEFAULT 0,
    `type`              int unsigned NOT NULL DEFAULT 0,
    `ranking`           int unsigned NULL,
    `parent_id`         int unsigned NOT NULL DEFAULT 0,
    `level`             int unsigned NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY                 `entities_id` (`entities_id`),
    KEY                 `itilcategories_id` (`itilcategories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Structure de la table 'glpi_plugin_servicecatalog_keywords'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_keywords`;
CREATE TABLE `glpi_plugin_servicecatalog_keywords`
(
    `id`                                  int unsigned NOT NULL auto_increment,
    `plugin_servicecatalog_categories_id` int unsigned NOT NULL DEFAULT 0,
    `name`                                varchar(255) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY                                   `plugin_servicecatalog_categories_id` (`plugin_servicecatalog_categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Structure de la table 'glpi_plugin_servicecatalog_groups'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_groups`;
CREATE TABLE `glpi_plugin_servicecatalog_groups`
(
    `id`                                  int unsigned NOT NULL auto_increment,
    `plugin_servicecatalog_categories_id` int unsigned NOT NULL DEFAULT 0,
    `groups_id`                           int unsigned NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY                                   `plugin_servicecatalog_categories_id` (`plugin_servicecatalog_categories_id`),
    KEY                                   `groups_id` (`groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


--
-- Structure de la table 'glpi_plugin_servicecatalog_appliancelinks'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_appliancelinks`;
CREATE TABLE `glpi_plugin_servicecatalog_appliancelinks`
(
    `id`            int unsigned NOT NULL auto_increment,
    `use_with_sc`   tinyint NOT NULL                DEFAULT '0',
    `appliances_id` int unsigned NOT NULL DEFAULT 0,
    `groups`        varchar(255)                    DEFAULT NULL,
    `comment`       text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY             `appliances_id` (`appliances_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Structure de la table 'glpi_plugin_servicecatalog_ticketchecks'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_ticketchecks`;
CREATE TABLE `glpi_plugin_servicecatalog_ticketchecks`
(
    `id`         int unsigned NOT NULL auto_increment,
    `tickets_id` int unsigned NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY          `tickets_id` (`tickets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_links`;
CREATE TABLE `glpi_plugin_servicecatalog_links`
(
    `id`                        int unsigned NOT NULL auto_increment,
    `entities_id`               int unsigned NOT NULL DEFAULT 0,
    `is_recursive`              tinyint NOT NULL DEFAULT '0',
    `name`                      varchar(255)     DEFAULT NULL,
    `url`                       varchar(255)     DEFAULT NULL,
    `target`                    tinyint NOT NULL DEFAULT '1',
    `icon`                      varchar(255)     DEFAULT NULL,
    `picture`                   varchar(255)     DEFAULT NULL,
    `comment`                   varchar(255)     DEFAULT NULL,
    `display_at_home`           tinyint NOT NULL DEFAULT '1',
    `display_on_actions_widget` tinyint NOT NULL DEFAULT '1',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linkgroups`;
CREATE TABLE `glpi_plugin_servicecatalog_linkgroups`
(
    `id`                             int unsigned NOT NULL AUTO_INCREMENT,
    `groups_id`                      int unsigned NOT NULL DEFAULT '0',
    `plugin_servicecatalog_links_id` int unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY                              `groups_id` (`groups_id`),
    KEY                              `plugin_servicecatalog_links_id` (`plugin_servicecatalog_links_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Structure de la table 'glpi_plugin_servicecatalog_linktranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linktranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_linktranslations`
(
    `id`       int unsigned NOT NULL AUTO_INCREMENT,
    `items_id` int unsigned NOT NULL DEFAULT '0',
    `itemtype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `language` varchar(5) COLLATE utf8mb4_unicode_ci   DEFAULT NULL,
    `field`    varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `value`    text COLLATE utf8mb4_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_dashboards`;
CREATE TABLE `glpi_plugin_servicecatalog_dashboards`
(
    `id`             int unsigned NOT NULL AUTO_INCREMENT,
    `entities_id`    int unsigned NOT NULL DEFAULT 0,
    `is_recursive`   tinyint NOT NULL                    DEFAULT '0',
    `users_id`       int unsigned NOT NULL DEFAULT '0',
    `grid`           longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `grid_statesave` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `drag_mode`      tinyint NOT NULL                    DEFAULT '0',
    `profiles_id`    int unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_contacts`;
CREATE TABLE `glpi_plugin_servicecatalog_contacts`
(
    `id`            int unsigned NOT NULL auto_increment,
    `entities_id`   int unsigned NOT NULL DEFAULT 0,
    `is_recursive`  tinyint NOT NULL                        DEFAULT '0',
    `name`          varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `phonenumber`   varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `email`         varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `address`       text COLLATE utf8mb4_unicode_ci,
    `postcode`      varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `town`          varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `state`         varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `country`       varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `opening_hours` text COLLATE utf8mb4_unicode_ci         DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY             `entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_tickettemplates`;
CREATE TABLE `glpi_plugin_servicecatalog_tickettemplates`
(
    `id`                 int unsigned NOT NULL auto_increment,
    `tickettemplates_id` int unsigned NOT NULL DEFAULT 0,
    `field`              int unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY                  `tickettemplates_id` (`tickettemplates_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_entities`;
CREATE TABLE `glpi_plugin_servicecatalog_entities`
(
    `id`          int unsigned NOT NULL auto_increment,
    `entities_id` int unsigned NOT NULL DEFAULT 0,
    `picture`     varchar(255)     DEFAULT NULL,
    `fa_icon`     varchar(100)     DEFAULT NULL,
    `comment`     varchar(255)     DEFAULT NULL,
    `layout`      tinyint NOT NULL DEFAULT '-1',
    PRIMARY KEY (`id`),
    KEY           `entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_formcreators`;
CREATE TABLE `glpi_plugin_servicecatalog_formcreators`
(
    `id`                          int unsigned NOT NULL auto_increment,
    `plugin_formcreator_forms_id` int unsigned NOT NULL DEFAULT 0,
    `itilcategories_id`           int unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY                           `plugin_formcreator_forms_id` (`plugin_formcreator_forms_id`),
    KEY                           `itilcategories_id` (`itilcategories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_fieldorders`;
CREATE TABLE `glpi_plugin_servicecatalog_fieldorders`
(
    `id`      int unsigned NOT NULL AUTO_INCREMENT,
    `name`    varchar(255) DEFAULT NULL,
    `ranking` int unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`)
VALUES (1, 'urgencies', '0'),
       (2, 'timeToResolve', '1'),
       (3, 'approvalRequest', '2'),
       (4, 'informMe', '3'),
       (5, 'hardwareType', '4'),
       (6, 'location', '5'),
       (7, 'watcher', '6'),
       (8, 'impact', '7'),
       (9, 'title', '8'),
       (10, 'contentAndFile', '9'),
       (11, 'phonenumber', '10'),
       (12, 'itilcategories', '11'),
       (13, 'requester_group', '12');


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_widgetbuttonorders`;
CREATE TABLE `glpi_plugin_servicecatalog_widgetbuttonorders`
(
    `id`            int unsigned NOT NULL AUTO_INCREMENT,
    `name`          varchar(255) DEFAULT NULL,
    `url`           TEXT         DEFAULT NULL,
    `internal_name` varchar(255) DEFAULT NULL,
    `ranking`       int unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites`
(
    `id`                         int unsigned NOT NULL AUTO_INCREMENT,
    `itilcategories_id`          int unsigned NOT NULL DEFAULT '0',
    `users_id`                   int unsigned NOT NULL DEFAULT '0',
    `favorite_itilcategories_id` int unsigned NOT NULL,
    PRIMARY KEY (`id`),
    KEY                          `itilcategories_id` (`itilcategories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_entities_favorites`;
CREATE TABLE `glpi_plugin_servicecatalog_entities_favorites`
(
    `id`           int unsigned NOT NULL AUTO_INCREMENT,
    `favorites_id` int unsigned NOT NULL DEFAULT '0',
    `entities_id`  int unsigned NOT NULL DEFAULT '0',
    `is_recursive` tinyint NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY            `favorites_id` (`favorites_id`),
    KEY            `entities_id` (`entities_id`),
    KEY            `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites_users`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites_users`
(
    `id`                int unsigned NOT NULL AUTO_INCREMENT,
    `favorites_id`      int unsigned NOT NULL DEFAULT '0',
    `users_id`          int unsigned NOT NULL DEFAULT '0',
    `ranking_requests`  int unsigned NOT NULL DEFAULT '0',
    `ranking_incidents` int unsigned NOT NULL DEFAULT '0',
    `type_favorites`    int unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY                 `favorites_id` (`favorites_id`),
    KEY                 `users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites_groups`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites_groups`
(
    `id`           int unsigned NOT NULL AUTO_INCREMENT,
    `favorites_id` int unsigned NOT NULL DEFAULT '0',
    `groups_id`    int unsigned NOT NULL DEFAULT '0',
    `entities_id`  int unsigned NOT NULL DEFAULT '0',
    `is_recursive` tinyint NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY            `favorites_id` (`favorites_id`),
    KEY            `groups_id` (`groups_id`),
    KEY            `entities_id` (`entities_id`),
    KEY            `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_favorites_profiles`;
CREATE TABLE `glpi_plugin_servicecatalog_favorites_profiles`
(
    `id`           int unsigned NOT NULL AUTO_INCREMENT,
    `favorites_id` int unsigned NOT NULL DEFAULT '0',
    `profiles_id`  int unsigned NOT NULL DEFAULT '0',
    `entities_id`  int unsigned NOT NULL DEFAULT '0',
    `is_recursive` tinyint NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY            `favorites_id` (`favorites_id`),
    KEY            `profiles_id` (`profiles_id`),
    KEY            `entities_id` (`entities_id`),
    KEY            `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_ticketappointments`;
CREATE TABLE `glpi_plugin_servicecatalog_ticketappointments`
(
    `id`                 int unsigned NOT NULL AUTO_INCREMENT,
    `uuid`               varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `tickets_id`         int unsigned NOT NULL DEFAULT '0',
    `date`               timestamp NULL DEFAULT NULL,
    `users_id`           int unsigned NOT NULL DEFAULT '0',
    `users_id_requester` int unsigned NOT NULL DEFAULT '0',
    `content`            longtext COLLATE utf8mb4_unicode_ci,
    `begin`              timestamp NULL DEFAULT NULL,
    `end`                timestamp NULL DEFAULT NULL,
    `users_id_tech`      int unsigned NOT NULL DEFAULT '0',
    `date_mod`           timestamp NULL DEFAULT NULL,
    `date_creation`      timestamp NULL DEFAULT NULL,
    `timeline_position`  tinyint NOT NULL                        DEFAULT '0',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uuid` (`uuid`),
    KEY                  `date` (`date`),
    KEY                  `date_mod` (`date_mod`),
    KEY                  `date_creation` (`date_creation`),
    KEY                  `users_id` (`users_id`),
    KEY                  `tickets_id` (`tickets_id`),
    KEY                  `users_id_tech` (`users_id_tech`),
    KEY                  `begin` (`begin`),
    KEY                  `end` (`end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
