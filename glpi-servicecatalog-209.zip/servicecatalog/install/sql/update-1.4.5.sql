ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_watchers_dropdown` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_submit_message_button` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_incidents_list` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_requests_list` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_your_open_incidents` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_your_open_requests` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_your_and_group_open_incidents` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_your_and_group_open_requests` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_incident` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_request` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `img_incident` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `img_request` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `img_incidents_list` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `img_requests_list` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `cat_size` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `keywords` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `categories_detail_child` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `impact_1` VARCHAR(200) DEFAULT '#337ab7' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `impact_2` VARCHAR(200) DEFAULT '#5cb85c' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `impact_3` VARCHAR(200) DEFAULT '#5bc0de' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `impact_4` VARCHAR(200) DEFAULT '#f0ad4e' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `impact_5` VARCHAR(200) DEFAULT '#d9534f' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `urgency_1` VARCHAR(200) DEFAULT '#337ab7' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `urgency_2` VARCHAR(200) DEFAULT '#5cb85c' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `urgency_3` VARCHAR(200) DEFAULT '#5bc0de' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `urgency_4` VARCHAR(200) DEFAULT '#f0ad4e' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `urgency_5` VARCHAR(200) DEFAULT '#d9534f' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `replace_ticket_update_form` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `levelCat` int(11) NOT NULL DEFAULT '2';

ALTER TABLE `glpi_plugin_servicecatalog_dashboards` ADD `grid_statesave` longtext COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_dashboards` ADD `drag_mode` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_dashboards` ADD `profiles_id` int(11) NOT NULL DEFAULT '0';

ALTER TABLE `glpi_plugin_servicecatalog_categoryorders` ADD `parent_id` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_categoryorders` ADD `level` int(11) NOT NULL DEFAULT '0';

CREATE TABLE `glpi_plugin_servicecatalog_fieldorders` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `name` varchar(255) DEFAULT NULL,
   `ranking` int(11)  NOT NULL DEFAULT '0',
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;

INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`)
VALUES (1, 'urgencies', '0'),
       (2, 'timeToResolve', '1'),
       (3, 'approvalRequest', '2'),
       (4, 'informMe', '3'),
       (5, 'hardwareType', '4'),
       (6, 'location', '5'),
       (7, 'watcher', '6'),
       (8, 'impact', '7'),
       (9, 'title', '8'),
       (10, 'contentAndFile', '9');