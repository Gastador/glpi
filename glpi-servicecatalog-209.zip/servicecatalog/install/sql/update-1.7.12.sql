ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `fields_more_informations` text COLLATE utf8_unicode_ci DEFAULT NULL;
UPDATE `glpi_plugin_servicecatalog_configs` SET `fields_more_informations` = '[\"4\",\"6\",\"11\"]' WHERE `glpi_plugin_servicecatalog_configs`.`id` = 1;
