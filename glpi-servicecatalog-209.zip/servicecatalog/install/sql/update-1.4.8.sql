ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_validation` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `img_validation` varchar(255) DEFAULT NULL;