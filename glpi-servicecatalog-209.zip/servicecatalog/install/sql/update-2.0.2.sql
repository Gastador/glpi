ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `show_linked_tickets_simplifiedform` tinyint NOT NULL DEFAULT '0';
INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`) VALUES (13, 'requester_group', '12');
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_requester_group` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_requester_group` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
