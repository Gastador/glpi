DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_tickettemplates`;
CREATE TABLE `glpi_plugin_servicecatalog_tickettemplates` (
  `id` int(11) NOT NULL auto_increment, -- id
  `tickettemplates_id` int(11) NOT NULL DEFAULT 0,
  `field` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`),
  KEY `tickettemplates_id` (`tickettemplates_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;