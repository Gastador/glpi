ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `comment_entity` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `multi_entity_redirection` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_entity_name` tinyint(1) NOT NULL DEFAULT '0';

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_entities`;
CREATE TABLE `glpi_plugin_servicecatalog_entities` (
  `id` int(11) NOT NULL auto_increment, -- id
  `entities_id` int(11) NOT NULL DEFAULT 0,
  `picture` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
