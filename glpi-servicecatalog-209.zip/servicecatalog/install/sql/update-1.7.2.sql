DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_widgetbuttonorders`;
CREATE TABLE `glpi_plugin_servicecatalog_widgetbuttonorders`
(
    `id`            int(11) NOT NULL AUTO_INCREMENT,
    `name`          varchar(255)     DEFAULT NULL,
    `url`           TEXT             DEFAULT NULL,
    `internal_name` varchar(255)     DEFAULT NULL,
    `ranking`       int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci
  AUTO_INCREMENT = 1;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `general_color` `general_color` varchar(10) DEFAULT '#cccccc';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `general_hover_color` `general_hover_color` varchar(10) DEFAULT '#8f8e8e';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `impact_1` `impact_1` varchar(10) DEFAULT '#337ab7' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `impact_2` `impact_2` varchar(10) DEFAULT '#5cb85c' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `impact_3` `impact_3` varchar(10) DEFAULT '#5bc0de' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `impact_4` `impact_4` varchar(10) DEFAULT '#f0ad4e' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `impact_5` `impact_5` varchar(10) DEFAULT '#d9534f' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `urgency_1` `urgency_1` varchar(10) DEFAULT '#337ab7' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `urgency_2` `urgency_2` varchar(10) DEFAULT '#5cb85c' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `urgency_3` `urgency_3` varchar(10) DEFAULT '#5bc0de' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `urgency_4` `urgency_4` varchar(10) DEFAULT '#f0ad4e' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `urgency_5` `urgency_5` varchar(10) DEFAULT '#d9534f' NOT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    CHANGE `fa_back` `fa_back` varchar(100) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `template_ticket_user_update` int(11) DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `seetop` tinyint(1)   NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `default_icon` varchar(100) NOT NULL DEFAULT 'fas fa-network-wired';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_your_open_tickets` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_your_resolved_tickets` varchar(255) DEFAULT NULL;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_widgets`;
CREATE TABLE `glpi_plugin_servicecatalog_widgets`
(
    `id`                     int(11)      NOT NULL auto_increment, -- id
    `title_message`          varchar(255)          DEFAULT NULL,
    `comment_message`        TEXT                  DEFAULT NULL,
    `display_incident`       tinyint(1)   NOT NULL DEFAULT '1',
    `incidents_topmenu`      tinyint(1)   NOT NULL DEFAULT '1',
    `title_incident`         varchar(255)          DEFAULT NULL,
    `comment_incident`       TEXT                  DEFAULT NULL,
    `img_incident`           varchar(255)          DEFAULT NULL,
    `fa_incident`            varchar(100) NOT NULL DEFAULT 'fas fa-hands-helping',
    `display_request`        tinyint(1)   NOT NULL DEFAULT '1',
    `requests_topmenu`       tinyint(1)   NOT NULL DEFAULT '1',
    `title_request`          varchar(255)          DEFAULT NULL,
    `comment_request`        TEXT                  DEFAULT NULL,
    `img_request`            varchar(255)          DEFAULT NULL,
    `fa_request`             varchar(100) NOT NULL DEFAULT 'fas fa-question',
    `display_tickets_list`   tinyint(1)   NOT NULL DEFAULT '1',
    `title_tickets_list`     varchar(255)          DEFAULT NULL,
    `comment_tickets`        TEXT                  DEFAULT NULL,
    `img_tickets_list`       varchar(255)          DEFAULT NULL,
    `fa_tickets_list`        varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `display_incidents_list` tinyint(1)   NOT NULL DEFAULT '0',
    `title_incidents_list`   varchar(255)          DEFAULT NULL,
    `comment_incidents_list` TEXT                  DEFAULT NULL,
    `img_incidents_list`     varchar(255)          DEFAULT NULL,
    `fa_incidents_list`      varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `display_requests_list`  tinyint(1)   NOT NULL DEFAULT '0',
    `title_requests_list`    varchar(255)          DEFAULT NULL,
    `comment_requests_list`  TEXT                  DEFAULT NULL,
    `img_requests_list`      varchar(255)          DEFAULT NULL,
    `fa_requests_list`       varchar(100) NOT NULL DEFAULT 'fas fa-list-ul',
    `faq_topmenu`            tinyint(1)   NOT NULL DEFAULT '1',
    `title_faq`              varchar(255)          DEFAULT NULL,
    `comment_faq`            TEXT                  DEFAULT NULL,
    `fa_faq`                 varchar(100) NOT NULL DEFAULT 'fas fa-medkit',
    `img_faq`                varchar(255)          DEFAULT NULL,
    `title_validation`       varchar(255)          DEFAULT NULL,
    `comment_validation`     TEXT                  DEFAULT NULL,
    `img_validation`         varchar(255)          DEFAULT NULL,
    `fa_validation`          VARCHAR(100) NOT NULL DEFAULT 'fas fa-file-signature',
    `title_personalinfo`     varchar(255)          DEFAULT NULL,
    `comment_personalinfo`   TEXT                  DEFAULT NULL,
    `img_personalinfo`       varchar(255)          DEFAULT NULL,
    `fa_personalinfo`        varchar(100) NOT NULL DEFAULT 'fas fa-address-card',
    `links_topmenu`          tinyint(1)   NOT NULL DEFAULT '1',
    `title_links`            varchar(255)          DEFAULT NULL,
    `comment_links`          TEXT                  DEFAULT NULL,
    `img_links`              varchar(255)          DEFAULT NULL,
    `fa_links`               varchar(100) NOT NULL DEFAULT 'fas fa-link',
    `title_reservation`      varchar(255)          DEFAULT NULL,
    `comment_reservation`    TEXT                  DEFAULT NULL,
    `img_reservation`        varchar(255)          DEFAULT NULL,
    `fa_reservation`         varchar(100) NOT NULL DEFAULT 'fas fa-calendar-alt',
    `display_entity_name`    tinyint(1)   NOT NULL DEFAULT '0',
    `title_entity_list`      varchar(255)          DEFAULT NULL,
    `comment_entity_list`    TEXT                  DEFAULT NULL,
    `title_entity`           varchar(255)          DEFAULT NULL,
    `comment_entity`         TEXT                  DEFAULT NULL,
    `fa_entity`              varchar(100) NOT NULL DEFAULT 'fas fa-globe',
    `img_entity`             varchar(255)          DEFAULT NULL,
    `linked_kbcategory`      int(11)      NOT NULL DEFAULT '0',
    `title_database`         varchar(255)          DEFAULT NULL,
    `comment_database`       TEXT                  DEFAULT NULL,
    `fa_database`            varchar(100) NOT NULL DEFAULT 'fas fa-book',
    `img_database`           varchar(255)          DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

INSERT INTO `glpi_plugin_servicecatalog_widgets`
(`id`)
VALUES (1);

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `display_phone_number` tinyint(1)   NOT NULL DEFAULT '1';
    
INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`)
VALUES (11, 'phonenumber', '10');