ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `use_strict_search` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `columns_for_table` text COLLATE utf8mb4_unicode_ci DEFAULT NULL;
