ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `display_myelements_menu` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_myelements_menu` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `fa_myelements_menu` varchar(100) DEFAULT NULL;
