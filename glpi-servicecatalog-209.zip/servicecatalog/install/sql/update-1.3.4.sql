CREATE TABLE `glpi_plugin_servicecatalog_dashboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL default '0',
  `grid` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;

ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `layout`;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `comment_reservation` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_logo_category_detail` tinyint(1) NOT NULL DEFAULT '1';

CREATE TABLE `glpi_plugin_servicecatalog_contacts` (
  `id` int(11) NOT NULL auto_increment, -- id
  `entities_id` int(11) NOT NULL DEFAULT 0,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opening_hours` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;