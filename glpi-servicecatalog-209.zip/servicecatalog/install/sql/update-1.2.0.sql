ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `service_detail` text COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `service_users` text COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `service_ttr` text COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `service_use` text COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `service_supervision` text COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `service_rules` text COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD `service_links` text COLLATE utf8_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `see_category_details` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `comment_links` varchar(255) DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_incident` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_request` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_helpdesk_menu` tinyint(1) NOT NULL DEFAULT '0';

CREATE TABLE `glpi_plugin_servicecatalog_links` (
   `id` int(11) NOT NULL auto_increment, -- id
   `entities_id` int(11) NOT NULL DEFAULT 0,
   `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
   `name` varchar(255) DEFAULT NULL,
   `url` varchar(255) DEFAULT NULL,
   `target` tinyint(1) NOT NULL DEFAULT '1',
   `picture` varchar(255) DEFAULT NULL,
   `comment` varchar(255) DEFAULT NULL,
   `display_at_home` tinyint(1) NOT NULL DEFAULT '1',
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `glpi_plugin_servicecatalog_linkgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groups_id` int(11) NOT NULL default '0',
  `plugin_servicecatalog_links_id` int(11) NOT NULL default '0',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`plugin_servicecatalog_links_id`) REFERENCES glpi_plugin_servicecatalog_links(id),
  FOREIGN KEY (`groups_id`) REFERENCES glpi_groups(id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;