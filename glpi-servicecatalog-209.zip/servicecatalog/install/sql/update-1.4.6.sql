ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_languages_button` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_help_button` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_savedsearchs_button` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_preferences_button` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_logout_button` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `hide_mail_followup` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `use_all_tab_default` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_helpdesk_footer` TINYINT(1) NOT NULL DEFAULT '0';