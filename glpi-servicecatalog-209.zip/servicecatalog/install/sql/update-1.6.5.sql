ALTER TABLE `glpi_plugin_servicecatalog_categories`
    ADD `inherit_alert` tinyint(1) NOT NULL DEFAULT '1';