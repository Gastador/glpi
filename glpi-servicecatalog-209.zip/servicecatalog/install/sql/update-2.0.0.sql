ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `use_own_colors` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `demo_mode` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `switch_prefs` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `show_indicators` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_widgetbuttonorders` CHANGE `url` `url` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
UPDATE `glpi_plugin_servicecatalog_favorites_groups` SET `entities_id` = '0' WHERE `entities_id` = '-1';
UPDATE `glpi_plugin_servicecatalog_favorites_profiles` SET `entities_id` = '0' WHERE `entities_id` = '-1';
UPDATE `glpi_plugin_servicecatalog_ticketchecks` SET `tickets_id` = '0' WHERE `tickets_id` = '-1';

ALTER TABLE `glpi_plugin_servicecatalog_favorites_groups` CHANGE `entities_id` `entities_id` int unsigned NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_favorites_profiles` CHANGE `entities_id` `entities_id` int unsigned NOT NULL DEFAULT '0';

ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_myelements_menu` `title_myelements_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_tickets_menu` `title_tickets_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_incidents_menu` `title_incidents_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_requests_menu` `title_requests_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_closedtickets_menu` `title_closedtickets_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_phone_number` `title_phone_number` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_ticket` `title_ticket` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_description_ticket` `title_description_ticket` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_searchbar_request` `title_searchbar_request` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_searchbar_incident` `title_searchbar_incident` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_searchbar_kb` `title_searchbar_kb` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_watchers_dropdown` `title_watchers_dropdown` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_items_dropdown` `title_items_dropdown` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_others_infos` `title_others_infos` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_submit_message_button` `title_submit_message_button` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_your_open_tickets` `title_your_open_tickets` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_your_open_incidents` `title_your_open_incidents` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_your_open_requests` `title_your_open_requests` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_your_and_group_open_incidents` `title_your_and_group_open_incidents` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_your_and_group_open_requests` `title_your_and_group_open_requests` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_your_resolved_tickets` `title_your_resolved_tickets` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_your_tickets_to_validate` `title_your_tickets_to_validate` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `select_title_incident_category` `select_title_incident_category` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `select_title_request_category` `select_title_request_category` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `title_favorites_category` `title_favorites_category` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `select_title_faq_article` `select_title_faq_article` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `cat_size` `cat_size` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `add_requesters_from_tickets` `add_requesters_from_tickets` int unsigned DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` CHANGE `add_observers_from_tickets` `add_observers_from_tickets` int unsigned DEFAULT '0';

ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_urgency` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_impact` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_time_to_resolve` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_add_validation` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_inform_me` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_location` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_delegation` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_category` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_preferences` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_help_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_others_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `use_as_step` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `placeholder_description_ticket` longtext;

CREATE TABLE `glpi_plugin_servicecatalog_appliancelinks`
(
    `id`            int unsigned NOT NULL auto_increment, -- id
    `use_with_sc`   tinyint NOT NULL DEFAULT '0',
    `appliances_id` int unsigned NOT NULL DEFAULT 0,
    `groups`        varchar(255)     DEFAULT NULL,
    `comment`       text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY             `appliances_id` (`appliances_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_myappliances_menu` tinyint NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `title_myappliances_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `fa_myappliances_menu` TEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `template_ticket_incident` int unsigned DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `template_ticket_request` int unsigned DEFAULT '0';

ALTER TABLE `glpi_plugin_servicecatalog_entities` ADD `fa_icon` varchar(100) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_linkgroups` DROP CONSTRAINT `glpi_plugin_servicecatalog_linkgroups_ibfk_1`;
ALTER TABLE `glpi_plugin_servicecatalog_linkgroups` DROP CONSTRAINT `glpi_plugin_servicecatalog_linkgroups_ibfk_2`;

ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `replace_ticket_creation_form`;
ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `replace_ticket_update_form`;
ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `header`;
ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `leftbar_style`;
ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `display_topmenu`;