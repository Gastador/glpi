ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_incident` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `display_request` tinyint(1) NOT NULL DEFAULT '1';
ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `drop_helpdesk_menu` tinyint(1) NOT NULL DEFAULT '0';

CREATE TABLE `glpi_plugin_servicecatalog_linkgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groups_id` int(11) NOT NULL default '0',
  `plugin_servicecatalog_links_id` int(11) NOT NULL default '0',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`plugin_servicecatalog_links_id`) REFERENCES glpi_plugin_servicecatalog_links(id),
  FOREIGN KEY (`groups_id`) REFERENCES glpi_groups(id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;