--
-- Structure de la table 'glpi_plugin_servicecatalog_configs'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configs`;
CREATE TABLE `glpi_plugin_servicecatalog_configs` (
   `id` int(11) NOT NULL auto_increment, -- id
   `comment` varchar(255) DEFAULT NULL,
   `display_incident` tinyint(1) NOT NULL DEFAULT '1',
   `comment_incident` varchar(255) DEFAULT NULL,
   `display_request` tinyint(1) NOT NULL DEFAULT '1',
   `comment_request` varchar(255) DEFAULT NULL,
   `display_tickets_list` tinyint(1) NOT NULL DEFAULT '1',
   `comment_tickets` varchar(255) DEFAULT NULL,
   `display_incidents_list` tinyint(1) NOT NULL DEFAULT '0',
   `comment_incidents_list` varchar(255) DEFAULT NULL,
   `display_requests_list` tinyint(1) NOT NULL DEFAULT '0',
   `comment_requests_list` varchar(255) DEFAULT NULL,
   `comment_faq` varchar(255) DEFAULT NULL,
   `comment_database` varchar(255) DEFAULT NULL,
   `comment_validation` varchar(255) DEFAULT NULL,
   `comment_links` varchar(255) DEFAULT NULL,
   `replace_ticket_creation_form` tinyint(1) NOT NULL DEFAULT '1',
   `drop_helpdesk_menu` tinyint(1) NOT NULL DEFAULT '0',
   `drop_home_button` tinyint(1) NOT NULL DEFAULT '0',
   `see_more_informations` tinyint(1) NOT NULL DEFAULT '1',
   `see_faq_articles` tinyint(1) NOT NULL DEFAULT '1',
   `linked_kbcategory` int(11) NOT NULL DEFAULT '0',
   `see_category_details` tinyint(1) NOT NULL DEFAULT '1',
   `palette` VARCHAR(255) NOT NULL DEFAULT 'grey',
   `layout` VARCHAR(255) NOT NULL DEFAULT 'classic',
   `title` varchar(255) DEFAULT NULL,
   `comment_title` TEXT DEFAULT NULL,
   `see_stats` tinyint(1) NOT NULL DEFAULT '1',
   `see_title` tinyint(1) NOT NULL DEFAULT '0',
   `title_searchbar_request` varchar(255) DEFAULT NULL,
   `title_searchbar_incident` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_servicecatalog_configs`
(`id`, `comment`, `comment_incident`, `comment_request`)
VALUES (1, '', '', '');
--
-- Structure de la table 'glpi_plugin_servicecatalog_configtranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_configtranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_configtranslations` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `items_id` int(11) NOT NULL DEFAULT '0',
   `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
   `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `value` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categories'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categories`;
CREATE TABLE `glpi_plugin_servicecatalog_categories` (
   `id` int(11) NOT NULL auto_increment, -- id
   `glpi_itilcategories_id` int(11) NOT NULL DEFAULT 0,
   `picture` varchar(255) DEFAULT NULL,
   `comment` varchar(255) DEFAULT NULL,
   `service_detail` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_users` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_ttr` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_use` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_supervision` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_rules` text COLLATE utf8_unicode_ci DEFAULT NULL,
   `service_links` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY  (`id`),
   KEY `glpi_itilcategories_id` (`glpi_itilcategories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categorytranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categorytranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_categorytranslations` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `items_id` int(11) NOT NULL DEFAULT '0',
   `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
   `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `value` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;
--
-- Structure de la table 'glpi_plugin_servicecatalog_categoryorders'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_categoryorders`;
CREATE TABLE `glpi_plugin_servicecatalog_categoryorders` (
   `id` int(11) NOT NULL auto_increment, -- id
   `entities_id` int(11) NOT NULL DEFAULT 0,
   `glpi_itilcategories_id` int(11) NOT NULL DEFAULT 0,
   `type` int(11) NOT NULL DEFAULT 0,
   `ranking` int(11) NULL,
   PRIMARY KEY  (`id`),
   KEY `entities_id` (`entities_id`),
   KEY `glpi_itilcategories_id` (`glpi_itilcategories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_keywords'
--
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_keywords`;
CREATE TABLE `glpi_plugin_servicecatalog_keywords` (
   `id` int(11) NOT NULL auto_increment, -- id
   `glpi_plugin_servicecatalog_categoryorders_id` int(11) NOT NULL DEFAULT 0,
   `name` varchar(255) DEFAULT NULL,
   PRIMARY KEY  (`id`),
   KEY `glpi_plugin_servicecatalog_categoryorders_id` (`glpi_plugin_servicecatalog_categoryorders_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_ticketchecks'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_ticketchecks`;
CREATE TABLE `glpi_plugin_servicecatalog_ticketchecks` (
   `id` int(11) NOT NULL auto_increment, -- id
   `tickets_id` int(11) NOT NULL DEFAULT 0,
   PRIMARY KEY  (`id`),
   KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_links`;
CREATE TABLE `glpi_plugin_servicecatalog_links` (
   `id` int(11) NOT NULL auto_increment, -- id
   `entities_id` int(11) NOT NULL DEFAULT 0,
   `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
   `name` varchar(255) DEFAULT NULL,
   `url` varchar(255) DEFAULT NULL,
   `target` tinyint(1) NOT NULL DEFAULT '1',
   `picture` varchar(255) DEFAULT NULL,
   `comment` varchar(255) DEFAULT NULL,
   `display_at_home` tinyint(1) NOT NULL DEFAULT '1',
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linkgroups`;
CREATE TABLE `glpi_plugin_servicecatalog_linkgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groups_id` int(11) NOT NULL default '0',
  `plugin_servicecatalog_links_id` int(11) NOT NULL default '0',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`plugin_servicecatalog_links_id`) REFERENCES glpi_plugin_servicecatalog_links(id),
  FOREIGN KEY (`groups_id`) REFERENCES glpi_groups(id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Structure de la table 'glpi_plugin_servicecatalog_linktranslations'
-- 
--
DROP TABLE IF EXISTS `glpi_plugin_servicecatalog_linktranslations`;
CREATE TABLE `glpi_plugin_servicecatalog_linktranslations` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `items_id` int(11) NOT NULL DEFAULT '0',
   `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
   `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
   `value` text COLLATE utf8_unicode_ci DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;