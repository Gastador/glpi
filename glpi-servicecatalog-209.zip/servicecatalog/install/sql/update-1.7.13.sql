ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `show_linked_tickets_simplifiedform` tinyint(1) DEFAULT '0';
