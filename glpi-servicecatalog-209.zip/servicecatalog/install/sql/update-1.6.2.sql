SET SESSION innodb_strict_mode=OFF;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `img_tickets_list` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_tickets_list` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_reservation` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `select_title_incident_category` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `select_title_request_category` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_favorites_category` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_phone_number` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_ticket` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_description_ticket` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_links` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `title_faq` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `fa_back` varchar(50) DEFAULT NULL;

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `faq_topmenu` tinyint(1) NOT NULL DEFAULT '1';

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `links_topmenu` tinyint(1) NOT NULL DEFAULT '1';

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `requests_topmenu` tinyint(1) NOT NULL DEFAULT '1';

ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `incidents_topmenu` tinyint(1) NOT NULL DEFAULT '1';

INSERT INTO `glpi_plugin_servicecatalog_fieldorders`(`id`, `name`, `ranking`)
VALUES (11, 'phonenumber', '10');

ALTER TABLE `glpi_plugin_servicecatalog_categories` ADD UNIQUE (`itilcategories_id`);

CREATE TABLE `glpi_plugin_servicecatalog_favorites`
(
    `id`                         int(11) NOT NULL AUTO_INCREMENT,
    `itilcategories_id`          int(11) NOT NULL DEFAULT '0',
    `users_id`                   int(11) NOT NULL default '0',
    `favorite_itilcategories_id` int(11) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `itilcategories_id` (`itilcategories_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

CREATE TABLE `glpi_plugin_servicecatalog_entities_favorites`
(
    `id`           int(11)    NOT NULL AUTO_INCREMENT,
    `favorites_id` int(11)    NOT NULL DEFAULT '0',
    `entities_id`  int(11)    NOT NULL DEFAULT '0',
    `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `entities_id` (`entities_id`),
    KEY `is_recursive` (`is_recursive`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

CREATE TABLE `glpi_plugin_servicecatalog_favorites_users`
(
    `id`                int(11) NOT NULL AUTO_INCREMENT,
    `favorites_id`      int(11) NOT NULL DEFAULT '0',
    `users_id`          int(11) NOT NULL DEFAULT '0',
    `ranking_requests`  int(11) NOT NULL DEFAULT '0',
    `ranking_incidents` int(11) NOT NULL DEFAULT '0',
    `type_favorites`    int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `users_id` (`users_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

CREATE TABLE `glpi_plugin_servicecatalog_favorites_groups`
(
    `id`           int(11)    NOT NULL AUTO_INCREMENT,
    `favorites_id` int(11)    NOT NULL DEFAULT '0',
    `groups_id`    int(11)    NOT NULL DEFAULT '0',
    `entities_id`  int(11)    NOT NULL DEFAULT '-1',
    `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `groups_id` (`groups_id`),
    KEY `entities_id` (`entities_id`),
    KEY `is_recursive` (`is_recursive`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

CREATE TABLE `glpi_plugin_servicecatalog_favorites_profiles`
(
    `id`           int(11)    NOT NULL AUTO_INCREMENT,
    `favorites_id` int(11)    NOT NULL DEFAULT '0',
    `profiles_id`  int(11)    NOT NULL DEFAULT '0',
    `entities_id`  int(11)    NOT NULL DEFAULT '-1',
    `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `favorites_id` (`favorites_id`),
    KEY `profiles_id` (`profiles_id`),
    KEY `entities_id` (`entities_id`),
    KEY `is_recursive` (`is_recursive`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COLLATE = utf8_unicode_ci;

