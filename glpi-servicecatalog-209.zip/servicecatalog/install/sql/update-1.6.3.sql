SET SESSION innodb_strict_mode=OFF;
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `add_requesters_from_tickets` int DEFAULT '0';
ALTER TABLE `glpi_plugin_servicecatalog_configs`
    ADD `add_observers_from_tickets` int DEFAULT '0';