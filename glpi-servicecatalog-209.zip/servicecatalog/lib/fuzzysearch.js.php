<?php
use Glpi\Event;
include('../../../inc/includes.php');
header('Content-Type: text/javascript');

?>
var root_sc_doc = "<?php echo PLUGIN_SERVICECATALOG_WEBDIR; ?>";

$(function() {
   var list = [];

   // prepapre options for fuzzy lib
   var fuzzy_options = {
      pre: "<b>",
      post: "</b>",
      extract: function(el) {
         if ( el.keywords && el.keywords.length > 0) {
            return el.title + ' ('+ el.keywords + ')';
         } else {
            return el.title;
         }
      }
   };

   // when the shortcut for fuzzy is called
   // $(document).on('keyup', null, 'alt+ctrl+g', function() {
   //    trigger_fuzzy();
   // });

   // when a key is pressed in fuzzy input, launch match
   $(document).on('click', ".sc-home-trigger-fuzzy", function(key) {
      trigger_homesearch_fuzzy();
   });
//whet diplay for a category
    $(document).on('click', ".sc-trigger-fuzzy", function(key) {
        trigger_catsearch_fuzzy();
    });

   // when the button is clicked
    //modal case
   $(document).on('click', '.sc-cat-trigger-fuzzy', function() {
      trigger_sc_fuzzy();
   });

   $(document).on('click', '.sc-link-trigger-fuzzy', function() {
      trigger_link_fuzzy();
   });

   $(document).on('click', '.sc-appliancelink-trigger-fuzzy', function() {
      trigger_appliancelink_fuzzy();
   });

   $(document).on('click', '.sc-faq-trigger-fuzzy', function() {
      trigger_faq_fuzzy();
   });

   var fuzzy_started = false;
    var trigger_homesearch_fuzzy = function() {
        // remove old fuzzy modal
        //removeFuzzy();
        currentType = $('#type').val();
        currentCat = 0;

        // retrieve current menu data
        $.getJSON(root_sc_doc+'/ajax/fuzzysearch.php', {
            'action': 'getList',
            'type': currentType,
            'category': currentCat
        }, function(data) {
            list = data;

            // start fuzzy after some time
            setTimeout(function() {
                if ($("#fuzzysearch .results li").length == 0) {
                    startFuzzy();
                }
            }, 100);
        });

        // focus input element
        $("#fuzzysearch input").trigger("focus");

        // don't bind key events twice
        if (fuzzy_started) {
            return;
        }
        fuzzy_started = true;

        // general key matches
        $(document).on('keyup', function(key) {
            switch (key.key) {
                case "Escape":
                    $("#fuzzysearch .results").empty();
                    $(".sc-home-trigger-fuzzy").val('');
                    break;

                case "ArrowUp":
                    selectPrev();
                    break;

                case "ArrowDown":
                    selectNext();
                    break;

                case "Enter":
                    // find url, if one selected, go for it, else try to find first element
                    var url = $("#fuzzysearch .results .active a").attr('href');
                    if (url == undefined) {
                        url = $("#fuzzysearch .results li:first a").attr('href');
                    }
                    if (url != undefined) {
                        document.location = url;
                    }
                    break;
            }
        });

        // when a key is pressed in fuzzy input, launch match
        $(document).on('keyup', "#fuzzysearch input", function(key) {
            if (key.key != "Escape"
                && key.key != "ArrowUp"
                && key.key != "ArrowDown"
                && key.key != "Enter") {
                startFuzzy();
            }
        });
    };
   var trigger_catsearch_fuzzy = function() {
      // remove old fuzzy modal
      //removeFuzzy();
      currentType = $('#type').val();
      currentCat = sessionStorage.categoryload;
      // retrieve html of fuzzy input
       // retrieve current menu data
       $.getJSON(root_sc_doc+'/ajax/fuzzysearch.php', {
           'action': 'getList',
           'type': currentType,
           'category': currentCat
       }, function(data) {
           list = data;

           // start fuzzy after some time
           setTimeout(function() {
               if ($("#fuzzysearch .results li").length == 0) {
                   startFuzzy();
               }
           }, 100);
       });

       // focus input element
       $("#fuzzysearch input").trigger("focus");

       // don't bind key events twice
       if (fuzzy_started) {
           return;
       }
       fuzzy_started = true;

       // general key matches
       $(document).on('keyup', function(key) {
           switch (key.key) {
               case "Escape":
                   $("#fuzzysearch .results").empty();
                   $(".sc-trigger-fuzzy").val('');
                   break;

               case "ArrowUp":
                   selectPrev();
                   break;

               case "ArrowDown":
                   selectNext();
                   break;

               case "Enter":
                   // find url, if one selected, go for it, else try to find first element
                   var url = $("#fuzzysearch .results .active a").attr('href');
                   if (url == undefined) {
                       url = $("#fuzzysearch .results li:first a").attr('href');
                   }
                   if (url != undefined) {
                       document.location = url;
                   }
                   break;
           }
       });

       // when a key is pressed in fuzzy input, launch match
       $(document).on('keyup', "#fuzzysearch input", function(key) {
           if (key.key != "Escape"
               && key.key != "ArrowUp"
               && key.key != "ArrowDown"
               && key.key != "Enter") {
               startFuzzy();
           }
       });
   };
   var trigger_sc_fuzzy = function() {
      // remove old fuzzy modal
      removeFuzzy();
      currentType = $('#type').val();
      // retrieve html of fuzzy input
      $.get(root_sc_doc+'/ajax/fuzzysearch.php', {
         'action': 'getModalHtml',
         'type': currentType
      }, function(html) {
         // add modal to body and show it
         $(document.body).append(html);
         $('#fuzzysearch').modal('show');

         // retrieve current menu data
         $.getJSON(root_sc_doc+'/ajax/fuzzysearch.php', {
            'action': 'getList',
            'type': currentType
         }, function(data) {
            list = data;

            // start fuzzy after some time
            setTimeout(function() {
               if ($("#fuzzysearch .results li").length == 0) {
                  startFuzzy();
               }
            }, 100);
         });

         // focus input element
         $("#fuzzysearch input").trigger("focus");

         // don't bind key events twice
         if (fuzzy_started) {
            return;
         }
         fuzzy_started = true;

         // general key matches
         $(document).on('keyup', function(key) {
            switch (key.key) {
               case "Escape":
                   $("#fuzzysearch .results").empty();
                   $(".sc-cat-trigger-fuzzy").val('');
                  break;

               case "ArrowUp":
                  selectPrev();
                  break;

               case "ArrowDown":
                  selectNext();
                  break;

               case "Enter":
                  // find url, if one selected, go for it, else try to find first element
                  var url = $("#fuzzysearch .results .active a").attr('href');
                  if (url == undefined) {
                     url = $("#fuzzysearch .results li:first a").attr('href');
                  }
                  if (url != undefined) {
                     document.location = url;
                  }
                  break;
            }
         });

         // when a key is pressed in fuzzy input, launch match
         $(document).on('keyup', "#fuzzysearch input", function(key) {
            if (key.key != "Escape"
                   && key.key != "ArrowUp"
                   && key.key != "ArrowDown"
                   && key.key != "Enter") {
               startFuzzy();
            }
         });
      });
   };

   var trigger_faq_fuzzy = function() {
      // remove old fuzzy modal
      removeFuzzy();
      currentType = $('#type').val();
      // retrieve html of fuzzy input
      $.get(root_sc_doc+'/ajax/fuzzysearchfaq.php', {
         'action': 'getHtml',
         'type': currentType
      }, function(html) {
         // add modal to body and show it
         $(document.body).append(html);
         $('#fuzzysearch').modal('show');

         // retrieve current menu data
         $.getJSON(root_sc_doc+'/ajax/fuzzysearchfaq.php', {
            'action': 'getList',
            'type': currentType
         }, function(data) {
            list = data;

            // start fuzzy after some time
            setTimeout(function() {
               if ($("#fuzzysearch .results li").length == 0) {
                  startFuzzy();
               }
            }, 100);
         });

         // focus input element
         $("#fuzzysearch input").trigger("focus");

         // don't bind key events twice
         if (fuzzy_started) {
            return;
         }
         fuzzy_started = true;

         // general key matches
         $(document).on('keyup', function(key) {
            switch (key.key) {
               case "Escape":
                   $("#fuzzysearch .results").empty();
                   $(".sc-faq-trigger-fuzzy").val('');
                  break;

               case "ArrowUp":
                  selectPrev();
                  break;

               case "ArrowDown":
                  selectNext();
                  break;

               case "Enter":
                  // find url, if one selected, go for it, else try to find first element
                  var url = $("#fuzzysearch .results .active a").attr('href');
                  if (url == undefined) {
                     url = $("#fuzzysearch .results li:first a").attr('href');
                  }
                  if (url != undefined) {
                     document.location = url;
                  }
                  break;
            }
         });

         // when a key is pressed in fuzzy input, launch match
         $(document).on('keyup', "#fuzzysearch input", function(key) {
            if (key.key != "Escape"
               && key.key != "ArrowUp"
               && key.key != "ArrowDown"
               && key.key != "Enter") {
               startFuzzy();
            }
         });
      });
   };

   var trigger_link_fuzzy = function() {
      // remove old fuzzy modal
      removeFuzzy();
      currentType = $('#type').val();
      // retrieve html of fuzzy input
      $.get(root_sc_doc+'/ajax/fuzzysearchlink.php', {
         'action': 'getHtml',
         'type': currentType
      }, function(html) {
         // add modal to body and show it
         $(document.body).append(html);
         $('#fuzzysearch').modal('show');

         // retrieve current menu data
         $.getJSON(root_sc_doc+'/ajax/fuzzysearchlink.php', {
            'action': 'getList',
            'type': currentType
         }, function(data) {
            list = data;

            // start fuzzy after some time
            setTimeout(function() {
               if ($("#fuzzysearch .results li").length == 0) {
                  startExternalFuzzy();
               }
            }, 100);
         });

         // focus input element
         $("#fuzzysearch input").trigger("focus");

         // don't bind key events twice
         if (fuzzy_started) {
            return;
         }
         fuzzy_started = true;

         // general key matches
         $(document).on('keyup', function(key) {
            switch (key.key) {
               case "Escape":
                   $("#fuzzysearch .results").empty();
                   $(".sc-link-trigger-fuzzy").val('');
                  break;

               case "ArrowUp":
                  selectPrev();
                  break;

               case "ArrowDown":
                  selectNext();
                  break;

               case "Enter":
                  // find url, if one selected, go for it, else try to find first element
                  var url = $("#fuzzysearch .results .active a").attr('href');
                  if (url == undefined) {
                     url = $("#fuzzysearch .results li:first a").attr('href');
                  }
                  if (url != undefined) {
                     document.location = url;
                  }
                  break;
            }
         });

         // when a key is pressed in fuzzy input, launch match
         $(document).on('keyup', "#fuzzysearch input", function(key) {
            if (key.key != "Escape"
               && key.key != "ArrowUp"
               && key.key != "ArrowDown"
               && key.key != "Enter") {
               startExternalFuzzy();
            }
         });
      });
   };

   var trigger_appliancelink_fuzzy = function() {
      // remove old fuzzy modal
      //removeFuzzy();
      //currentType = $('#type').val();
      // retrieve html of fuzzy input
       $.getJSON(root_sc_doc+'/ajax/fuzzysearchappliancelink.php', {
           'action': 'getList'
       }, function(data) {
           list = data;
           // start fuzzy after some time
           setTimeout(function() {
               if ($("#fuzzysearch .results li").length == 0) {
                   startApplianceFuzzy();
               }
           }, 100);
       });

       // focus input element
       $("#fuzzysearch input").trigger("focus");

       // don't bind key events twice
       if (fuzzy_started) {
           return;
       }
       fuzzy_started = true;

       // general key matches
       $(document).on('keyup', function(key) {
           switch (key.key) {
               case "Escape":
                   $("#fuzzysearch .results").empty();
                   $(".sc-appliancelink-trigger-fuzzy").val('');
                   break;

               case "ArrowUp":
                   selectPrev();
                   break;

               case "ArrowDown":
                   selectNext();
                   break;

               case "Enter":
                   // find url, if one selected, go for it, else try to find first element
                   var url = $("#fuzzysearch .results .active a").attr('href');
                   if (url == undefined) {
                       url = $("#fuzzysearch .results li:first a").attr('href');
                   }
                   if (url != undefined) {
                       document.location = url;
                   }
                   break;
           }
       });

       // when a key is pressed in fuzzy input, launch match
       $(document).on('keyup', "#fuzzysearch input", function(key) {
           if (key.key != "Escape"
               && key.key != "ArrowUp"
               && key.key != "ArrowDown"
               && key.key != "Enter") {
               startApplianceFuzzy();
           }
       });
   };

   var startFuzzy = function() {

      // retrieve input
      var input_text = $("#fuzzysearch input").val();
      var input_strict = $("#fuzzy-strict").val();
      if(input_strict == 1){
           input_text = "\'"+input_text;
      }

      //clean old results
      $("#fuzzysearch .results").empty();

      // launch fuzzy search on this list
      //var results = fuzzy.filter(input_text, list, fuzzy_options);
      const options = {
         // isCaseSensitive: false,
         // includeScore: false,
          shouldSort: false,
         // includeMatches: false,
         // findAllMatches: false,
          minMatchCharLength: 2,
         // location: 0,
         // threshold: 0.6,
         // distance: 100,
         includeScore: false,
         ignoreLocation: true,
         useExtendedSearch: true,
         // ignoreFieldNorm: false,
         // fieldNormWeight: 1,
         keys: [
            "title",
            "keywords",
             //"targets",
            "comment",
            //"icon"
         ]
      };
      //console.log(list);
      const fuse = new Fuse(list, options);

      var results = fuse.search(input_text);
      var sorted_results = results.sort((a, b) => a['item'].order.localeCompare(b['item'].order) || a['item'].title.localeCompare(b['item'].title));
       var target = '_blank';
//
////      const searchWrapper = query => {
//         if (!query) return fuse.getIndex().records.map(({ $: item, i: idx }) => ({ idx, item }));
//         results =  fuse.search(query);
//      };
//// Change the pattern
//      console.log(results);



      // append new results
       sorted_results.map(function(el) {
         //console.log(el);
         if ( el.item.keywords && el.item.keywords.length > 0) {
             if ( el.item.targets && el.item.targets.length > 0) {
                 var finaltitle = '(' + el.item.targets + ') ' + el.item.title + ' (' + el.item.keywords + ')'; //el.item.type + " > " +
             } else {
                 var finaltitle = el.item.title + ' (' + el.item.keywords + ')'; //el.item.type + " > " +
             }
         } else {
             if ( el.item.targets && el.item.targets.length > 0) {
                 var finaltitle = '(' + el.item.targets + ') ' + el.item.title; //el.item.type + " > " +
             } else {
                 var finaltitle = el.item.title; //el.item.type + " > " +
             }

         }
         //$("#fuzzysearch .results")
         //   .append("<li class='list-group-item list-group-item-primary'><i class='fa-1x fas "+el.item.icon+"' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i> <a target='"+el.item.target+"' href='"+ el.item.url+"'>"+finaltitle+"</a><div><i style='color: #CCC;'>"+el.item.comment+"</i></div></li>");
           $("#fuzzysearch .results")
               .append("<li style='background-color: "+el.item.background+";'><a target='"+el.item.target+"' href='"+ el.item.url+"' class='list-group-item list-group-item-action flex-column align-items-start'>" +
                   "<div class='d-flex w-100 justify-content-between'>" +
                   "<h5 class='mb-1' style='font-weight: inherit;'><span class='badge badge-primary badge-pill'><i class='fa-1x fas "+el.item.icon+"' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\">" +
                   "</i></span> " + finaltitle +
                   "</h5></div>" +
                   "<p class='mb-1'><i style='color: #9E9C9C;'>"+el.item.comment+"</i></p>" +
                   "</a></li>");
      });

      selectFirst();
   };


    var startApplianceFuzzy = function() {

        // retrieve input
        var input_text = $("#fuzzysearch input").val();
        var input_strict = $("#fuzzy-strict").val();
        if(input_strict == 1){
            input_text = "\'"+input_text;
        }

        //clean old results
        $("#fuzzysearch .results").empty();

        // launch fuzzy search on this list
        //var results = fuzzy.filter(input_text, list, fuzzy_options);
        const options = {
            // isCaseSensitive: false,
            // includeScore: false,
             shouldSort: false,
            // includeMatches: false,
            // findAllMatches: false,
            minMatchCharLength: 2,
            // location: 0,
            // threshold: 0.6,
            // distance: 100,
            includeScore: false,
            ignoreLocation: true,
            useExtendedSearch: true,
            // ignoreFieldNorm: false,
            // fieldNormWeight: 1,
            keys: [
                "title",
                "comment",
                //"icon"
            ]
        };
        //console.log(list);
        const fuse = new Fuse(list, options);

        var results = fuse.search(input_text);
        var target = '_blank';
//
////      const searchWrapper = query => {
//         if (!query) return fuse.getIndex().records.map(({ $: item, i: idx }) => ({ idx, item }));
//         results =  fuse.search(query);
//      };
//// Change the pattern
//      console.log(results);



        // append new results
        results.map(function(el) {
            //console.log(el);
            var finaltitle = el.item.title; //el.item.type + " > " +
            $("#fuzzysearch .results")
                .append("<li class='list-group-item'><i class='fa-1x fas "+el.item.icon+"' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i> <a target='_blank' href='"+el.item.url+"'>"+finaltitle+"</a><div><i style='color: #CCC;'>"+el.item.comment+"</i></div></li>");
        });

        selectFirst();
    };

   var startExternalFuzzy = function() {

      // retrieve input
      var input_text = $("#fuzzysearch input").val();
       var input_strict = $("#fuzzy-strict").val();
       if(input_strict == 1){
           input_text = "\'"+input_text;
       }
      //clean old results
      $("#fuzzysearch .results").empty();

      // launch fuzzy search on this list
      var results = fuzzy.filter(input_text, list, fuzzy_options);

      // append new results
      results.map(function(el) {
         //console.log(el.string);
         $("#fuzzysearch .results")
            .append("<li class='list-group-item'><i class='fa-1x fas "+el.original.icon+"' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i> <a target='_blank' href='"+el.original.url+"'>"+el.string+"</a></li>");
      });

      selectFirst();
   };


   /**
    * Clean generated Html
    */
   var removeFuzzy = function() {
      $("#fuzzysearch").remove();
   };

   /**
    * Select the first element in the results list
    */
   var selectFirst = function() {
      $("#fuzzysearch .results li:first()").addClass('active');
      scrollToSelected();
   };

   /**
    * Select the last element in the results list
    */
   var selectLast = function() {
      $("#fuzzysearch .results li:last()").addClass('active');
      scrollToSelected();
   };

   /**
    * Select the next element in the results list.
    * If no selected, select the first.
    */
   var selectNext = function() {
      if ($("#fuzzysearch .results .active").length == 0) {
         selectFirst();
      } else {
         $("#fuzzysearch .results .active:not(:last-child)")
            .removeClass('active')
            .next()
            .addClass("active");
         scrollToSelected();
      }
   };

   /**
    * Select the previous element in the results list.
    * If no selected, select the last.
    */
   var selectPrev = function() {
      if ($("#fuzzysearch .results .active").length == 0) {
         selectLast();
      } else {
         $("#fuzzysearch .results .active:not(:first-child)")
            .removeClass('active')
            .prev()
            .addClass("active");
         scrollToSelected();
      }
   };

   /**
    * Force scroll to the selected element in the results list
    */
   var scrollToSelected = function() {
      var results = $("#fuzzysearch .results");
      var selected = results.find('.active');

      if (selected.length) {
         results.scrollTop(results.scrollTop() + selected.position().top - results.height()/2 + selected.height()/2 - 25);
      }
   };
});
