<?php


/**
 * Class PluginFormcreatorServicecatalog
 */
class PluginFormcreatorServicecatalog extends CommonGLPI {

    static $rightname = 'ticket';

    var $dohistory = false;

    /**
     * @return bool
     */
    static function canUse() {
        return Session::haveRight(self::$rightname, READ);
    }

    /**
     * //    * @return string
     * //    */
    //   static function getMenuLink() {
    //      global $CFG_GLPI;
    //
    //      return PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=formcreator";
    //   }
    //
    //   /**
    //    * @return string
    //    */
    //   static function getMenuTitle() {
    //      return __('Create a', 'servicecatalog') . " " . __('advanced request', 'servicecatalog');
    //   }
    //
    //   /**
    //    * @return string
    //    */
    //   static function getMenuLogo() {
    //
    //      return "fas fa-file-alt";
    //
    //   }
    //
    //
    //   /**
    //    * @return string|\translated
    //    */
    //   static function getMenuComment() {
    //
    //      return __('Create a request', 'servicecatalog');
    //   }
    //
    //   /**
    //    * @return string
    //    */
    //   static function getLinkList() {
    //      return "";
    //   }
    //
    //   static function getList() {
    //      global $CFG_GLPI;
    //
    //      Html::redirect(FORMCREATOR_ROOTDOC."/front/formlist.php");
    //   }

    /**
     * @param $type
     * @param $category_id
     *
     * @return string
     */
    static function getLinkURL($type, $category_id) {
        global $CFG_GLPI, $DB;

        $dbu = new DbUtils();

        //profile
        $iterator = $DB->request(['SELECT' => 'plugin_formcreator_forms_id',
                                  'FROM'   => $dbu->getTableForItemType('PluginFormcreatorForm_Profile'),
                                  'WHERE'  => ['profiles_id' => $_SESSION['glpiactiveprofile']['id']]
                                 ]);


        foreach ($iterator as $row) {
            $forms_id = $row['plugin_formcreator_forms_id'];

            $form = $DB->request(['SELECT'     => 'glpi_plugin_formcreator_forms.id',
                                  'FROM'       => 'glpi_plugin_servicecatalog_formcreators',
                                  'INNER JOIN' => [
                                      'glpi_plugin_formcreator_forms' => [
                                          'FKEY' => [
                                              'glpi_plugin_servicecatalog_formcreators' => 'plugin_formcreator_forms_id',
                                              'glpi_plugin_formcreator_forms'           => 'id'
                                          ]
                                      ]
                                  ],
                                  'WHERE'      => ['itilcategories_id' => $category_id,
                                                   'is_active'         => 1,
                                                   'is_deleted'        => 0,
                                                   'language'          => [$_SESSION['glpilanguage'], '', null, '0'],
                                                   'OR'                => ['NOT'                              =>
                                                                               ['access_rights' => PluginFormcreatorForm::ACCESS_RESTRICTED],
                                                                           'glpi_plugin_formcreator_forms.id' => $forms_id]]
                                 ]);

            if (count($form) == 1) {
                foreach ($form as $r) {
                    if ($r['id'] != NULL && $r['id'] > 0) {
                        return FORMCREATOR_ROOTDOC . "/front/formdisplay.php?id=" . $r['id'];
                    }
                }
            }
        }

        return false;
    }
}
