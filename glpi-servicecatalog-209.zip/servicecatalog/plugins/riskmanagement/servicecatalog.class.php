<?php
/*
 -------------------------------------------------------------------------
 riskmanagement plugin for GLPI
 Copyright (C) 2009-2016 by the riskmanagement Development Team.

 https://github.com/InfotelGLPI/riskmanagement
 -------------------------------------------------------------------------

 LICENSE

 This file is part of riskmanagement.

 riskmanagement is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 riskmanagement is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with riskmanagement. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
   die("Sorry. You can't access directly to this file");
}


/**
 * Class PluginRiskmanagementServicecatalog
 */
class PluginRiskmanagementServicecatalog extends CommonGLPI {

   static $rightname = 'plugin_riskmanagement_use_form';

   var $dohistory = false;

   static function canUse() {

//      check if user linked to a resource
//      if(Plugin::isPluginActive("resources")) {
//         $dbu = new DbUtils();
//         $count = $dbu->countElementsInTable('glpi_plugin_resources_resources_items',
//                                    ["itemtype" => 'User',
//                                     "items_id" => Session::getLoginUserID()]);
//         if ($count > 0) {
//            $history = new PluginRiskmanagementLink_History();
//            if (!$history->checkLinkCheckedForUser($_SESSION['glpiID'])) {
//            return Plugin::isPluginActive("riskmanagement");// && Session::haveRight(self::$rightname, READ)
//            } else {
//               return false;
//            }
//         } else {
//            return false;
//         }
//      }
      return false;
   }


    /**
    * @return string
    */
   static function getMenuLink() {
      global $CFG_GLPI;

      return PLUGIN_RISKMANAGEMENT_WEBDIR . "/front/securityform.php";
   }
   
   /**
    * @return string
    */
   static function getMenuLogo() {

      return PluginRiskmanagementFamily::getIcon();

   }

   /**
    * @return string|\translated
    */
   static function getAhrefTitle() {

      return __('Security', 'riskmanagement');
   }

   /**
    * @return string
    * @throws \GlpitestSQLError
    */
   static function getMenuLogoCss() {

      $addstyle = "";
      $history = new PluginRiskmanagementLink_History();
//      if (!$history->checkLinkCheckedForUser($_SESSION['glpiID'])) {
         $addstyle = "style='color:firebrick;'";
//      }
      return $addstyle;

   }

   /**
    * @return string
    */
   static function getMenuTitle() {

      return __('Security', 'riskmanagement');
   }

   /**
    * @return string
    */
   static function getMenuComment() {

      $history = new PluginRiskmanagementLink_History();
      $comments = "";
      if (!$history->checkLinkCheckedForUser($_SESSION['glpiID'])) {
         $comments = "<span style='color:firebrick;'>";
         $comments .= __('You have documents to sign', 'riskmanagement');
         $comments .= "</span>";
      }
      
      return $comments;
   }

}
