<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');
header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

//if (!isset($_SESSION['glpiactiveprofile']['id'])) {
//   // Session is not valid then exit
//   exit;
//}

Session::checkFaqAccess();

if ($_REQUEST['search'] == 'kbitems') {
    $keywords = isset($_REQUEST['keywords']) ? $_REQUEST['keywords'] : '';
    plugin_servicecatalog_showKbItems($keywords);
} elseif ($_REQUEST['search'] == 'faqitems') {
    $keywords = isset($_REQUEST['keywords']) ? $_REQUEST['keywords'] : '';
    plugin_servicecatalog_showKbItems($keywords, true);
}

/**
 * @param      $keywords
 *
 * @param bool $fromfaq
 *
 * @throws \GlpitestSQLError
 */
function plugin_servicecatalog_showKbItems($keywords, $fromfaq = false)
{
    $keywords = str_replace("/", "", $keywords);

    $list_keywords = array_filter(explode("+", $keywords));

    $kbitems = PluginServicecatalogKnowbase::getKbItems();

    $kbs = [];

    if (count($list_keywords) > 0) {
        foreach ($kbitems as $k => $v) {
            $val  = $v['name'];
            $val  = html_entity_decode($val);
            $valc = $v['answer'];
            $valc = html_entity_decode($valc);

            $kb_found = true;

            foreach ($list_keywords as $keyword) {
                $recherche = trim($keyword);
                $pattern   = '(' . $recherche . ')';
                $pattern   = regexAccents($pattern);

                if (preg_match("/" . $pattern . "/i", $val) > 0
                || preg_match("/" . $recherche . "/i", $val) > 0
                || preg_match("/" . $pattern . "/i", $valc) > 0
                || preg_match("/" . $recherche . "/i", $valc) > 0) {
                    $kb_found = true;
                } else {
                    $kb_found = false;
                    break;
                }
            }

            if ($kb_found) {
                $kbs[] = $kbitems[$k];
            }
        }
    } else {
        if ($fromfaq == false) {
            foreach ($kbitems as $k => $v) {
                $kbs[] = $kbitems[$k];
            }
        }
    }

    $formList = ['forms' => $kbs];

    echo json_encode($formList, JSON_UNESCAPED_SLASHES);
}

/**
 * @param $chaine
 *
 * @return mixed
 */
function regexAccents($chaine)
{
    $accent = ['a', 'à', 'á', 'â', 'ã', 'ä', 'å', 'c', 'ç', 'e', 'è', 'é', 'ê', 'ë', 'i', 'ì', 'í', 'î', 'ï', 'o', 'ð', 'ò', 'ó', 'ô', 'õ', 'ö', 'u', 'ù', 'ú', 'û', 'ü', 'y', 'ý', 'ý', 'ÿ'];
    $inter  = ['%01', '%02', '%03', '%04', '%05', '%06', '%07', '%08', '%09', '%10', '%11', '%12', '%13', '%14', '%15', '%16', '%17', '%18', '%19', '%20', '%21', '%22', '%23', '%24', '%25', '%26', '%27', '%28', '%29', '%30', '%31', '%32', '%33', '%34', '%35'];
    $regex  = ['(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)',
              '(c|ç)', '(c|ç)',
              '(è|e|é|ê|ë)', '(è|e|é|ê|ë)', '(è|e|é|ê|ë)', '(è|e|é|ê|ë)', '(è|e|é|ê|ë)',
              '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(u|ù|ú|û|ü)', '(u|ù|ú|û|ü)', '(u|ù|ú|û|ü)', '(u|ù|ú|û|ü)',
              '(y|ý|ý|ÿ)', '(y|ý|ý|ÿ)', '(y|ý|ý|ÿ)', '(y|ý|ý|ÿ)'];
    $chaine = str_ireplace($accent, $inter, $chaine);
    $chaine = str_replace($inter, $regex, $chaine);
    return $chaine;
}
