<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');
header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

Session::checkRight("plugin_servicecatalog_setup", UPDATE);

if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'plugin_servicecatalog_add_groups':
            echo "<tr><td id='plugin_servicecatalog_groups" . $_POST['index'] . "'>";
            $rand   = mt_rand();
            $params = [
            'name'      => 'group_' . $rand,
            'value'     => 0,
            'condition' => getEntitiesRestrictCriteria(Group::getTable(), '', '', true)
            ];
            Dropdown::show(Group::class, $params);

            echo " <a class='pointer' onclick=\"pluginServiceCatalogDelete('plugin_servicecatalog_groups" . $_POST['index'] . "');\">";
            echo "&nbsp;<i style='font-size: 2em' class=\"fas fa-minus-circle\"></i></a>";
            echo "</td></tr>";
            break;
    }
}
