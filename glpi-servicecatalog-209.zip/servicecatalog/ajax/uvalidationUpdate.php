<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2020 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

$AJAX_INCLUDE = 1;
if (strpos($_SERVER['PHP_SELF'], "uvalidationUpdate.php")) {
    include('../../../inc/includes.php');
    header("Content-Type: text/html; charset=UTF-8");
    Html::header_nocache();
}

Session::checkLoginUser();

$users_id_supervisor = 0;
if ((isset($_POST['value']) && ($_POST["value"] > 0))) {
    $user = new User();
    if ($user->getFromDB($_POST["value"])) {
        $users_id_supervisor = $user->fields['users_id_supervisor'];
    }
}

if ((isset($_POST['users_id_supervisor']) && ($_POST["users_id_supervisor"] > 0))) {
    $users_id_supervisor = $_POST['users_id_supervisor'];

}
if ($users_id_supervisor) {
    echo "&nbsp;" . __('Your ticket will be validated by', 'servicecatalog') . "&nbsp;";
    echo getUserName($users_id_supervisor);
    echo Html::hidden('users_id_validate[]', ['value' => $users_id_supervisor]);
} else {
    echo "&nbsp;" . __("You haven't supervisor", 'servicecatalog');
}


$_POST['name'] = "responsible_user";
$_POST['rand'] = "";
Ajax::commonDropdownUpdateItem($_POST);
