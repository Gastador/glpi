<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2020 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

$AJAX_INCLUDE = 1;
if (strpos($_SERVER['PHP_SELF'], "ugroupUpdate.php")) {
    include('../../../inc/includes.php');
    header("Content-Type: text/html; charset=UTF-8");
    Html::header_nocache();
}

Session::checkLoginUser();

$groups_id = 0;
$users_id  = $_SESSION['glpiID'];

if ((isset($_POST['value']) && ($_POST["value"] > 0))) {
    $users_id = $_POST["value"];
}

if ((isset($_POST['requester_group']) && ($_POST["requester_group"] > 0))) {
    $groups_id = $_POST['requester_group'];
}

$config      = new PluginServicecatalogConfig();
$use_as_step = $config->getFormDisplayAsStep();
$center      = "";
if ($use_as_step == 1) {
    $center = "w-50 mx-auto";
}

echo "<div class=\"input-group $center\">";
echo "<div class='input-group-prepend'>
    <span class='input-group-text'><i class=\"fas fa-users\"></i></span>
  </div>";

$condition       = getEntitiesRestrictCriteria(Group::getTable(), '', '', true);
$group_user_data = Group_User::getUserGroups($users_id, $condition);

$requester_groups = [];
foreach ($group_user_data as $groups) {
    $requester_groups[] = $groups['id'];
}
$crit = ["id" => $requester_groups, "is_requester" => 1];

$params = [
   'name'      => '_groups_id_requester',
   'value'     => $groups_id,
   'condition' => $crit
];
Dropdown::show(Group::class, $params);

echo "</div>";

$_POST['name'] = "group_requester";
$_POST['rand'] = "";
Ajax::commonDropdownUpdateItem($_POST);
