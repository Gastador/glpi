<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');

header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

Session::checkLoginUser();

if (!isset($_GET['category_id'])) {
    exit();
}

if (isset($_GET['showalerts'])) {
    if (Plugin::isPluginActive('mydashboard')) {

        echo Html::script(PLUGIN_MYDASHBOARD_NOTFULL_DIR . "/lib/jquery-advanced-news-ticker/jquery.newsTicker.min.js");

        $config = new PluginServicecatalogConfig();
        echo '<style type="text/css">
        #gs4 #display-sc #nt_alert-container::before,
        #gs5 #display-sc #nt_maint-container::before,
        #gs6 #display-sc #nt_info-container::before
         {
          margin-left: 25px;!important;
        }
    </style>';
        $class = "col-md-11";
        if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
            || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY
            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $class = "";
        }
        $style = "";
        if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $style = "background-color: #FFF;";
        }

        if (Plugin::isPluginActive('mydashboard')
            && method_exists("PluginMydashboardWidget", "getWidgetMydashboardAlert")) {
            $cat    = [];
            $id     = PluginServicecatalogCategory::getUsedConfig("inherit_alert", $_GET['category_id'], "itilcategories_id");
            $cats[] = $id;
            $cats   = array_filter($cats);
            $cats   = array_diff($cats, [-1]);
            if (count($cats) > 0 && PluginMydashboardAlert::countForAlerts(0, 0, $cats) > 0) {
                echo PluginMydashboardWidget::getWidgetMydashboardAlert($class, true, $cats, $style);
                echo "<br>";
            }
        }
        if (Plugin::isPluginActive('mydashboard')
            && method_exists("PluginMydashboardWidget", "getWidgetMydashboardMaintenance")) {
            $cat    = [];
            $id     = PluginServicecatalogCategory::getUsedConfig("inherit_alert", $_GET['category_id'], "itilcategories_id");
            $cats[] = $id;
            $cats   = array_filter($cats);
            $cats   = array_diff($cats, [-1]);
            if (count($cats) > 0 && PluginMydashboardAlert::countForAlerts(0, 1, $cats) > 0) {
                echo PluginMydashboardWidget::getWidgetMydashboardMaintenance($class, true, $cats, $style);
                echo "<br>";
            }
        }
        if (Plugin::isPluginActive('mydashboard')
            && method_exists("PluginMydashboardWidget", "getWidgetMydashboardInformation")) {
            $cat    = [];
            $id     = PluginServicecatalogCategory::getUsedConfig("inherit_alert", $_GET['category_id'], "itilcategories_id");
            $cats[] = $id;
            $cats   = array_filter($cats);
            $cats   = array_diff($cats, [-1]);
            if (count($cats) > 0 && PluginMydashboardAlert::countForAlerts(0, 2, $cats) > 0) {
                echo PluginMydashboardWidget::getWidgetMydashboardInformation($class, true, $cats, $style);
                echo "<br>";
            }
        }
    }
}
$config = new PluginServicecatalogConfig();
if ($config->seeCategoryDetails()
    && $config->getLayout() != PluginServicecatalogConfig::WRAPPER
    && $config->getLayout() != PluginServicecatalogConfig::WRAPPERSLY) {
    $detail = new PluginServicecatalogCategory();
    if ($detail->getFromDBByCategory($_GET['category_id'])) {
        $id = PluginServicecatalogCategory::getUsedConfig("inherit_detail", $_GET['category_id'], "itilcategories_id");
        echo $detail->showDetails(['category' => $id]);
        if ($config->getLayout() != PluginServicecatalogConfig::SHOPER) {
            echo "<br>";
        }
    }
}
