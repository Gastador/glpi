<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include("../../../inc/includes.php");
header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

Session::checkLoginUser();

global $CFG_GLPI;
$link = $_SERVER['HTTP_REFERER'] . "?ignore_redirect=1&";
$object_type = '';
$type = '';
$entities_id = '';


if (isset($_POST['object'])) {
    if ($_POST['object'] == PluginServicecatalogShortcut::OBJECT_SCPAGE) {
        $item_type = PluginServicecatalogShortcut::getOjectLinkName($_POST['object']);
        $link .= "itemtype=$item_type&";
        if (isset($_POST['entities_id'])) {
            $entities_id = $_POST['entities_id'];
            $link .= "entities_id=$entities_id&";
        }
        if (isset($_POST['item_id'])) {
            $page = $_POST['item_id'];
            $link .= "page=" . PluginServicecatalogShortcut::getPageLinkName($page);
        }
    } else {
        $item_type = PluginServicecatalogShortcut::getOjectLinkName($_POST['object']);
        $link .= "itemtype=$item_type&";


        if (isset($_POST['entities_id'])) {
            $entities_id = $_POST['entities_id'];
            $link .= "entities_id=$entities_id&";
        }
        if ($_POST['object'] == PluginServicecatalogShortcut::OBJECT_SCCATEGORY) {
            if (isset($_POST["item_id"])) {
                $item_id = $_POST["item_id"];
                $link .= "item_id=$item_id&";
            }
            if (isset($_POST['type'])) {
                $type = $_POST['type'];
                $link .= "type=$type";
            }
        } else {
            if (isset($_POST["item_id"])) {
                $item_id = $_POST["item_id"];
                $link .= "item_id=$item_id";
            }
        }
    }
}
echo $link;
