<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include("../../../inc/includes.php");
header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

Session::checkLoginUser();

$dashboard   = new PluginServicecatalogDashboard();
$user_id     = Session::getLoginUserID();
$entities_id = $_SESSION['glpiactive_entity'];
$profile_id  = $_SESSION['glpiactiveprofile']['id'];
//TODO check for default ?
$id = PluginServicecatalogDashboard::checkIfPreferenceExists($user_id, $entities_id, $profile_id);
if ($id) {
    $input['id'] = $id;
    $dashboard->delete($input);
    $msg_clear = __('Grid cleared', 'servicecatalog');
}
