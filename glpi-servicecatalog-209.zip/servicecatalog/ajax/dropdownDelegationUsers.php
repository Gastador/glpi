<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2018 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

// Direct access to file
if (strpos($_SERVER['PHP_SELF'], "dropdownDelegationUsers.php")) {
    $AJAX_INCLUDE = 1;
    include('../../../inc/includes.php');
    header("Content-Type: text/html; charset=UTF-8");
    Html::header_nocache();
} elseif (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

Session::checkLoginUser();

if ($_POST["nodelegate"] == 1) {
    $_POST['_users_id_requester'] = Session::getLoginUserID();
    $_POST['_right']              = "id";
}

if ($_POST['_right'] == "groups") {
    if (Plugin::isPluginActive('vip')) {
        $vip = new PluginVipGroup();
        $vip_groups = [];
        foreach ($vip->find(['isvip' => 1]) as $data) {
            $vip_groups[] = $data['id'];
        }
    }

    $condition  = getEntitiesRestrictCriteria(Group::getTable(), '', '', true);

    $group_user_data = Group_User::getUserGroups($_POST["_users_id_requester"], $condition);

    $requester_groups = [];
    foreach ($group_user_data as $groups) {
        if (Plugin::isPluginActive('vip')) {
            if (in_array($groups['id'], $vip_groups)) {
                continue;
            }
        }
        $requester_groups[] = $groups['id'];
    }

    if (count($requester_groups) > 0) {
        $_POST['_right'] = "groups";
    } else {
        $_POST['_right'] = "helpdesk";
    }
}

echo "<h5>";
$alert = "alert-secondary";
$style = "";
//                if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//                    || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//                    $alert_hide = "alert-light";
//                }
$config = new PluginServicecatalogConfig();
if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
    $style = 'style="border-radius: 1px"';
}
echo "<div class='alert $alert' role='alert' $style>";
$title = "";
if (empty($title)) {
    $title = __('Who is concerned ?', 'servicecatalog');
}
echo $title;
echo "</div>";
echo "</h5>";

$ticket = new PluginServicecatalogTicket();
$ticket->showActorAddFormOnCreate(Ticket_User::REQUESTER, $_POST);
$config = new PluginServicecatalogConfig();
if ($config->hideMailFollowup()) {
    echo Html::scriptBlock("remove_notif();");
}
