<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include("../../../inc/includes.php");
header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

Session::checkLoginUser();

header("Content-Type: application/json; charset=UTF-8", true);

if (isset($_POST['type'])) {
    $datas = [];

    $opt['choose_category'] = $_POST['choose_category'];
    $opt['type']            = $_POST['type'];
    $opt['category_id']     = $_POST['category_id'];
    $opt['level']           = $_POST['level'];

    $opt['display_favorite'] = 0;
    if (isset($_POST['launchFav'])) {
        $catDBTM = new ITILCategory();
        $catDBTM->getFromDB($opt['category_id']);
        $opt['level'] = $catDBTM->fields['level'] + 1;
    }

    if (isset($_SESSION["plugin_servicecatalog"]["loadCatAjax"][Session::getLoginUserID()][$opt['category_id']])) {
        echo json_encode("ok");
    } else {
        $_SESSION["plugin_servicecatalog"]["loadCatAjax"][Session::getLoginUserID()][$opt['category_id']] = 1;

        $config = new PluginServicecatalogConfig();
        if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
            $retour = PluginServicecatalogSly::listCategories($opt, false, $datas);
        } elseif ($config->getLayout() == PluginServicecatalogConfig::WRAPPER) {
            $retour = PluginServicecatalogWrapper::listCategories($opt, false, $datas);
        } else if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
            $retour = PluginServicecatalogWrappersly::listCategories($opt, false, $datas);
        } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL) {
            $retour = PluginServicecatalogThumbnail::listCategories($opt, false, $datas);
        } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
            $retour = PluginServicecatalogThumbnailwrapper::listCategories($opt, false, $datas);
        } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED) {
            $retour = PluginServicecatalogBootstrapped::listCategories($opt, false, $datas);
        } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $retour = PluginServicecatalogBootstrappedcolor::listCategories($opt, false, $datas);
        } else if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
            $retour = PluginServicecatalogShoper::listCategories($opt, false, $datas);
        }

        echo json_encode($retour);
    }
}
