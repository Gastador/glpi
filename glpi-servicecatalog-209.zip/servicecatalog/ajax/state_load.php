<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include('../../../inc/includes.php');
header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

Session::checkLoginUser();

$result      = "";
$type        = "";
$profiles_id = $_SESSION['glpiactiveprofile']['id'];

if (isset($_GET['type'])) {
    $type = $_GET['type'];
    $gsId = "";
    if ($type == Ticket::INCIDENT_TYPE) {
        $gsId = "gs15";
//        if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
//            $gsId = "gs10";
//        }
    } elseif ($type == Ticket::DEMAND_TYPE) {
        $gsId = "gs16";
//        if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
//            $gsId = "gs11";
//        }
    } elseif ($type == 0) {
        $gsId = "gs12";
    } elseif ($type == 3) {
        $gsId = "gs19";
    } elseif ($type == 4) {
        $gsId = "gs13";
    } elseif ($type == 5) {
        $gsId = "gs22";
    } elseif ($type == 6) {
        $gsId = "gs25";
    }
}


$users_id = $_SESSION['glpiID'];

if (isset($_GET['entities_id'])) {
    $entities_id = $_GET['entities_id'];

    $dashboard = new  PluginServicecatalogDashboard();
    $dbu       = new DbUtils();
    $first     = [];
    if ($dashboard->find(["entities_id" => $entities_id])) {
        $restrict = ["users_id"    => $users_id,
                   "profiles_id" => $profiles_id,
                   "entities_id" => $entities_id];
    } else {
        $restrict = ["users_id"    => $users_id,
                   "profiles_id" => $profiles_id] +
                  $dbu->getEntitiesRestrictCriteria($dashboard->getTable(), '', $entities_id, true);
    }

    $data = $dbu->getAllDataFromTable("glpi_plugin_servicecatalog_dashboards", $restrict);
    if (!empty($data)) {
        $first = array_pop($data);
    }

    if (count($first) == 0 || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
        if ($dashboard->find(["entities_id" => $entities_id])) {
            $restrict = ["users_id"    => 0,
                      "profiles_id" => 0,
                      "entities_id" => $entities_id];
        } else {
            $restrict = ["users_id"    => 0,
                      "profiles_id" => 0] +
                     $dbu->getEntitiesRestrictCriteria($dashboard->getTable(), '', $entities_id, true);
        }

        $data = $dbu->getAllDataFromTable("glpi_plugin_servicecatalog_dashboards", $restrict);
        if (!empty($data)) {
            $first = array_pop($data);
        }
    }
    if (isset($first['grid_statesave'])
       && !is_null($first['grid_statesave'])) {
        $grids_saved = json_decode($first['grid_statesave']);
        foreach ($grids_saved as $key => $grid_saved) {
            if ($key == $gsId) {
                $result = $grid_saved;
                $result = json_encode($result, JSON_NUMERIC_CHECK);
                $result = str_replace(['"true"', '"false"'], ['true', 'false'], $result);
            }
        }
    }
}

echo $result;
