<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include("../../../inc/includes.php");
header("Content-Type: text/html; charset=UTF-8");
Html::header_nocache();

Session::checkLoginUser();
global $DB;
$return = '';
$object_type = '';
$type = '';
$entities_id = '';
if (isset($_POST['object'])) {
    $object_type = $_POST['object'];
}
if (isset($_POST['entities_id'])) {
    $entities_id = $_POST['entities_id'];
}
if (isset($_POST['type'])) {
    $type = $_POST['type'];
}

$name = 'item_id';
switch ($object_type) {
    case PluginServicecatalogShortcut::OBJECT_SCCATEGORY:
        $categories = [];
        $sc_categories = [];
        $sc_category = new PluginServicecatalogCategory();
        $category = new ITILCategory();
        $sc_categories = $sc_category->find();
        $sc_id = [];
        foreach ($sc_categories as $sc_cat) {
            $sc_id[] = $sc_cat['itilcategories_id'];
        }
        $param = [
            'is_helpdeskvisible' => 1
        ];
        if ($type == Ticket::INCIDENT_TYPE) {
            $param['is_incident'] = 1;
        } else {
            $param['is_request'] = 1;
        }
        $categories = $category->find($param);
        $used = [];
        foreach ($categories as $cat) {
            if (!in_array($cat['id'], $sc_id)) {
                $used[] = $cat['id'];
            }
        }
        $options = [
            'name' => $name,
            'used' => $used,
            'entity' => $entities_id,
            'display' => false,
        ];
        $return .= "<td>" . __('Category ID', 'servicecatalog') . "</td>";
        $return .= "<td>";
        $return .= ITILCategory::dropdown($options);
        $return .= "</td>";
        break;
    case PluginServicecatalogShortcut::OBJECT_METADEMAND:
        $return .= "<td>" . __('Object ID', 'servicecatalog') . "</td>";
        $options = [
            'name' => $name,
            'entity' => $entities_id,
            'display' => false
        ];
        $return .= "<td>";
        $return .= PluginMetademandsMetademand::dropdown($options);
        $return .= "</td>";
        break;
    case PluginServicecatalogShortcut::OBJECT_FAQ:
        $dbu = new DbUtils();
        $return .= "<td>" . __('Object ID', 'servicecatalog') . "</td>";
        $criteria = [
            'entities_id' => $entities_id
        ];
        $entities_faq = $dbu->getAllDataFromTable('glpi_entities_knowbaseitems', $criteria);
        $knowbaseitem = new KnowbaseItem();
        $ids = [];
        foreach ($entities_faq as $faq) {
            $ids[] = $faq['knowbaseitems_id'];
        }
        $groups_faq = $dbu->getAllDataFromTable('glpi_groups_knowbaseitems', $criteria);
        foreach ($groups_faq as $faq) {
            $ids[] = $faq['knowbaseitems_id'];
        }
        $profils_faq = $dbu->getAllDataFromTable('glpi_knowbaseitems_profiles', $criteria);
        foreach ($profils_faq as $faq) {
            $ids[] = $faq['knowbaseitems_id'];
        }
        $ids = array_unique($ids);
        $faqs = [];
        foreach ($ids as $id) {
            $knowbaseitem->getFromDB($id);
            if ($knowbaseitem->fields['is_faq']) {
                if (empty($knowbaseitem->fields['end_date'])) {
                    if ($_SESSION['glpi_currenttime'] > $knowbaseitem->fields['begin_date']) {
                        $faqs[$id] = $knowbaseitem->fields['name'];
                    }
                } else {
                    if ($_SESSION['glpi_currenttime'] > $knowbaseitem->fields['begin_date'] && $_SESSION['glpi_currenttime'] < $knowbaseitem->fields['end_date']) {
                        $faqs[$id] = $knowbaseitem->fields['name'];
                    }
                }
            }
        }
        $options = [
            'display' => false,
        ];
        $return .= "<td>";
        $return .= Dropdown::showFromArray($name, $faqs, $options);
        $return .= "</td>";
        break;

    case PluginServicecatalogShortcut::OBJECT_SCPAGE :
        $return .= "<td>" . __('Target specific page', 'servicecatalog') . "</td>";
        $options = [
            'display' => false,
        ];
        $return .= "<td>";
        $return .= Dropdown::showFromArray($name, PluginServicecatalogShortcut::getEnumPage(), $options);
        $return .= "</td>";

        break;
}
echo $return;


