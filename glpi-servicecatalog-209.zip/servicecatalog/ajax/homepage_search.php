<?php
//
///*
// -------------------------------------------------------------------------
// Servicecatalog plugin for GLPI
// Copyright (C) 2018-2022 by the Servicecatalog Development Team.
//
// https://github.com/InfotelGLPI/servicecatalog
// -------------------------------------------------------------------------
//
// LICENSE
//
// This file is part of Servicecatalog.
//
// Servicecatalog is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Servicecatalog is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
// --------------------------------------------------------------------------
// */
//
//include('../../../inc/includes.php');
//header("Content-Type: text/html; charset=UTF-8");
//Html::header_nocache();
//
//if (!isset($_SESSION['glpiactiveprofile']['id'])) {
//   // Session is not valid then exit
//   exit;
//}
//
//Session::checkLoginUser();
//
//if ($_REQUEST['search'] == 'categories') {
//   if (isset($_REQUEST['typesId'])) {
//      $typesId = intval($_REQUEST['typesId']);
//   } else {
//      $typesId = 0;
//   }
//   $keywords = isset($_REQUEST['keywords']) ? $_REQUEST['keywords'] : '';
//
//   plugin_servicecatalog_showCategories($keywords, $typesId);
//}
//
//
//function formatTree($tree) {
//   $tree2 = array();
//   foreach ($tree as $i => $item) {
//      $submenu = $item['subcategories'];
//      unset($item['subcategories']);  //clear submenu of parent item
//      $tree2[] = $item;
//      if (!empty($submenu)) {
//         $sub     = formatTree($submenu); //submenu's return as array in array
//         $tree2[] = $sub[0]; // remove outer array
//      }
//   }
//   return $tree2;
//}
//
///**
// * @param     $keywords
// * @param int $typesId
// *
// * @throws \GlpitestSQLError
// * @throws \Psr\SimpleCache\InvalidArgumentException
// */
//function plugin_servicecatalog_showCategories($keywords, $typesId = 0) {
//   $keywords = str_replace("/", "", $keywords);
//
//   $list_keywords = array_filter(explode("+", $keywords));
//
//   $categories = PluginServicecatalogCategory::getCategoriesCache($typesId);
//
//   $forms = [];
//
//   if (count($list_keywords) > 0) {
//
//      //      $cats_founds = formatTree($categories);
//
//      $cats = $categories;
//      while (!empty($categories)) {
//         $temp = [];
//         foreach ($categories as $k => $v) {
//            if (isset($v["subcategories"])) {
//               $temp = array_merge($temp, $v['subcategories']);
//            }
//         }
//         $cats       = array_merge($cats, $temp);
//         $categories = $temp;
//      }
//
//      if ($typesId == 1) {
//         $field = "is_incident";
//      } else if ($typesId == 2) {
//         $field = "is_request";
//      }
//      $cats_founds = [];
//      foreach ($cats as $key => $val) {
//         if ($val['disabled'] != 1 && isset($val[$field]) && $val[$field] == 1) {
//            $cats_founds[] = $val;
//         }
//      }
//
//      foreach ($cats_founds as $k => $v) {
//         $val       = $v['completename'];
//         $val       = html_entity_decode($val);
//         $valc      = $v['comment'];
//         $valc      = html_entity_decode($valc);
//         $valk      = $v['keywords'];
//         $valk      = html_entity_decode($valk);
//         $valsi     = $v['simplified_name_incident'];
//         $valsi     = html_entity_decode($valsi);
//         $valsr     = $v['simplified_name_request'];
//         $valsr     = html_entity_decode($valsr);
//         $cat_found = true;
//
//         foreach ($list_keywords as $keyword) {
//
//            $recherche = trim($keyword);
//            $pattern   = '(' . $recherche . ')';
//            $pattern   = regexAccents($pattern);
//
//            if (preg_match("/" . $pattern . "/i", $val) > 0
//                || preg_match("/" . $recherche . "/i", $val) > 0
//                || preg_match("/" . $pattern . "/i", $valc) > 0
//                || preg_match("/" . $recherche . "/i", $valc) > 0
//                || preg_match("/" . $pattern . "/i", $valk) > 0
//                || preg_match("/" . $recherche . "/i", $valk) > 0
//                || ($typesId == 1 && preg_match("/" . $pattern . "/i", $valsi) > 0)
//                || ($typesId == 1 && preg_match("/" . $recherche . "/i", $valsi) > 0)
//                || ($typesId == 2 && preg_match("/" . $pattern . "/i", $valsr) > 0)
//                || ($typesId == 2 && preg_match("/" . $recherche . "/i", $valsr) > 0)) {
//               $cat_found = true;
//            } else {
//               $cat_found = false;
//               break;
//            }
//
//         }
//
//         if ($cat_found) {
//            $forms[] = $cats_founds[$k];
//         }
//      }
//   }
//
//   $formList = ['forms' => $forms];
//
//   echo json_encode($formList, JSON_UNESCAPED_SLASHES);
//}
//
///**
// * @param $chaine
// *
// * @return mixed
// */
//function regexAccents($chaine) {
//   $accent = ['a', 'à', 'á', 'â', 'ã', 'ä', 'å', 'c', 'ç', 'e', 'è', 'é', 'ê', 'ë', 'i', 'ì', 'í', 'î', 'ï', 'o', 'ð', 'ò', 'ó', 'ô', 'õ', 'ö', 'u', 'ù', 'ú', 'û', 'ü', 'y', 'ý', 'ý', 'ÿ'];
//   $inter  = ['%01', '%02', '%03', '%04', '%05', '%06', '%07', '%08', '%09', '%10', '%11', '%12', '%13', '%14', '%15', '%16', '%17', '%18', '%19', '%20', '%21', '%22', '%23', '%24', '%25', '%26', '%27', '%28', '%29', '%30', '%31', '%32', '%33', '%34', '%35'];
//   $regex  = ['(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)', '(a|à|á|â|ã|ä|å)',
//              '(c|ç)', '(c|ç)',
//              '(è|e|é|ê|ë)', '(è|e|é|ê|ë)', '(è|e|é|ê|ë)', '(è|e|é|ê|ë)', '(è|e|é|ê|ë)',
//              '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(i|ì|í|î|ï)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(o|ð|ò|ó|ô|õ|ö)', '(u|ù|ú|û|ü)', '(u|ù|ú|û|ü)', '(u|ù|ú|û|ü)', '(u|ù|ú|û|ü)',
//              '(y|ý|ý|ÿ)', '(y|ý|ý|ÿ)', '(y|ý|ý|ÿ)', '(y|ý|ý|ÿ)'];
//   $chaine = str_ireplace($accent, $inter, $chaine);
//   $chaine = str_replace($inter, $regex, $chaine);
//   return $chaine;
//}
