<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogFieldorder
 */
class PluginServicecatalogFieldorder extends CommonDBTM
{

    static $rightname = 'plugin_servicecatalog_setup';

   /**
    * functions mandatory
    * getTypeName(), canCreate(), canView()
    *
    * @param int $nb
    *
    * @return string
    */
    static function getTypeName($nb = 0)
    {
        return __('Ticket fields ordering', 'servicecatalog');
    }

   /**
    * @param \CommonGLPI $item
    * @param int         $withtemplate
    *
    * @return string
    * @see CommonGLPI::getTabNameForItem()
    */
    function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {

        if ($item->getType() == 'PluginServicecatalogConfig') {
            return self::getTypeName();
        }
        return '';
    }

   /**
    * @param \CommonGLPI $item
    * @param int         $tabnum
    * @param int         $withtemplate
    *
    * @return bool
    * @see CommonGLPI::displayTabContentForItem()
    */
    static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {

        if ($item->getType() == 'PluginServicecatalogConfig') {
            $self = new self();
            $self->showForm(1);
        }
        return true;
    }

   /**
    * @param int   $ID
    * @param array $options
    *
    * @return bool|void
    */
    public function showForm($ID, $options = [])
    {

        $fields = new self();
        $config = new PluginServicecatalogConfig();
        $config->getFromDB(1);

        $result = $fields->find([1 => 1], "ranking");

        if (count($result) > 0) {
            echo "<table class='tab_cadre_fixehov'>";
            echo "<tr>";
            echo "<th colspan='4'>" . __('Fields ordering', 'servicecatalog') . "</th>";
            echo "</tr>";
            echo '</table>';

            echo "<form name='form' method='post' id='form' 'action='" .
              Toolbox::getItemTypeFormURL('PluginServicecatalogFieldorder') . "'>";

            echo "<div id='drag'>";
            echo "<table class='tab_cadre_fixehov'>";
            foreach ($result as $data) {
                echo "<tr class='tab_bg_2'>";

                echo '<td class="rowhandler control center">';
                echo "<div class=\"drag row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                echo self::getFullNameField($data['name']);
                $morefields = $config->getFieldsMoreInformations();
                if (in_array($data['name'], $morefields)) {
                    echo " (" . __('In more informations block', 'servicecatalog').")";
                }
                echo '</div>';
                echo '</td>';

                echo '<td class="rowhandler control center">';
                echo "<div class=\"drag row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                echo $data['ranking'];
                echo '</div>';
                echo '</td>';

                echo '<td class="rowhandler control center">';
                echo "<div class=\"drag row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                echo "<i class=\"fas fa-grip-horizontal grip-rule\"></i>";
                echo '</div>';
                echo '</td>';

                echo "</tr>\n";
            }
            echo '</table>';
            echo '</div>';
            echo Html::scriptBlock('$(document).ready(function() {plugin_servicecatalog_redipsFields()});'); // a revoir
            Html::closeForm();
        }
    }

    static function getFullNameField($field)
    {

        $fullname = ['urgencies'       => __('Urgency'),
                   'itilcategories'  => __('Category'),
                   'timeToResolve'   => __('Time to resolve'),
                   'approvalRequest' => __('Approval request'),
                   'informMe'        => __('Inform me about the actions taken', 'servicecatalog'),
                   'hardwareType'    => __('Hardware type'),
                   'location'        => __('Location'),
                   'watcher'         => _n('Watcher', 'Watchers', 2),
                   'impact'          => __('Impact'),
                   'title'           => __('Title'),
                   'contentAndFile'  => __('Description and File Import', 'servicecatalog'),
                   'phonenumber'     => __('Phone number', 'servicecatalog'),
                   'requester_group' => __('Requester group'),
        ];

        return $fullname[$field];
    }

   /**
    * @param array $params
    */
    public function reorder(array $params)
    {
        if (isset($params['old_order']) && isset($params['new_order'])) {
            $crit = [
            'ranking' => $params['old_order']
            ];

            $itemMove = new self();
            $itemMove->getFromDBByCrit($crit);

            if (isset($itemMove->fields["id"])) {
               // Reorganization of all fields
                if ($params['old_order'] < $params['new_order']) {
                    $toUpdateList = $this->find([
                                              '`ranking`' => ['>', $params['old_order']],
                                              'ranking'   => ['<=', $params['new_order']]
                                           ]);

                    foreach ($toUpdateList as $toUpdate) {
                          $this->update([
                                   'id'      => $toUpdate['id'],
                                   'ranking' => $toUpdate['ranking'] - 1
                                ]);
                    }
                } else {
                    $toUpdateList = $this->find([
                                              '`ranking`' => ['<', $params['old_order']],
                                              'ranking'   => ['>=', $params['new_order']]
                                           ]);

                    foreach ($toUpdateList as $toUpdate) {
                        $this->update([
                                   'id'      => $toUpdate['id'],
                                   'ranking' => $toUpdate['ranking'] + 1
                                ]);
                    }
                }

                if (isset($itemMove->fields["id"]) && $itemMove->fields['id'] > 0) {
                    $this->update([
                                'id'      => $itemMove->fields['id'],
                                'ranking' => $params['new_order']
                             ]);
                }
            }
        }
    }
}
