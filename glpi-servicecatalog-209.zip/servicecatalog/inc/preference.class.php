<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2020 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

/**
 * Class PluginServicecatalogPreference for the current connected User
 */
class PluginServicecatalogPreference extends CommonGLPI
{


    /**
     * Return the localized name of the current Type
     * Should be overloaded in each new class
     *
     * @param integer $nb Number of items
     *
     * @return string
     **/
    static function getTypeName($nb = 0) {
        // Always plural
        return __('Settings');
    }


    /**
     *
     * @param array $options
     *
     * @return array
     */
    function defineTabs($options = []) {
        $ong = [];

        $this->addDefaultFormTab($ong);
        return $ong;
    }

    /**
     * Get the identifier of the current item
     *
     * @return integer ID
     **/
    function getID() {

        if (isset($this->fields[static::getIndexName()])) {
            return $this->fields[static::getIndexName()];
        }
        return -1;
    }

    /**
     * Get the name of the index field
     *
     * @return string name of the index field
     **/
    static function getIndexName() {
        return "id";
    }

    /**
     * Print the user preference form.
     *
     * @return boolean true if user found, false otherwise
     */
    function showForm() {
        global $DB, $CFG_GLPI;

        $ID              = Session::getLoginUserID();
        $user            = new User();
        $ticket          = new Ticket();
        $ticket_template = false;
        $config          = new PluginServicecatalogConfig();
        $widget          = new PluginServicecatalogWidget();

        // Load ticket template if available :
        if ($config->getTicketTemplateAssociatedToUserInformationUpdate() > 0) {
            $ticket_template = $config->getTicketTemplateAssociatedToUserInformationUpdate();
            $tt              = $ticket->getITILTemplateToUse(
                $ticket_template,
                "",
                "",
                $_SESSION["glpiactive_entity"]
            );
        }


        // Store predefined fields to be able not to take into account on change template
        $predefined_fields = [];

        if (isset($tt->predefined) && count($tt->predefined)) {
            foreach ($tt->predefined as $predeffield => $predefvalue) {
                $predefined_fields[$predeffield] = $predefvalue;
            }
        }


        if ($user->getFromDB($ID)) {
            $rand     = mt_rand();
            $authtype = $user->getAuthMethodsByID();

            $extauth = !(($user->fields["authtype"] == Auth::DB_GLPI)
                         || (($user->fields["authtype"] == Auth::NOT_YET_AUTHENTIFIED)
                             && !empty($user->fields["password"])));

            echo "<form method='post' name='user_manager' enctype='multipart/form-data' action='" . self::getSearchURL() . "' autocomplete='off'>";

            echo "<div class=\"row\">";
            echo "<div class=\"form-group col-md-11\">";

            $title = PluginServicecatalogConfig::displayField($widget, 'title_personalinfo');
            $title .= "&nbsp;-&nbsp;";
            $title .= $user->getFriendlyName();
            echo Html::hidden('name', ['value' => $user->fields["name"]]);
            echo Html::hidden('id', ['value' => $user->fields["id"]]);

            echo PluginServicecatalogWidget::getPageTitle($title);

            echo "</div>";
            echo "</div>";

            foreach ($predefined_fields as $predefined_field_name => $predefined_field_value) {
                $name = "ticket_$predefined_field_name";
                echo Html::hidden($name, ['value' => $predefined_field_value]);
            }


            echo "<div class=\"row\">";

            echo "<div class=\"form-group col-md-7\">";

            $surnamerand = mt_rand();
            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='textfield_realname$surnamerand'>" . __('Surname') . "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";
            //         if ($extauth
            //             && isset($authtype['realname_field'])
            //             && !empty($authtype['realname_field'])) {
            //            echo $user->fields["realname"];
            //         } else {
            echo Html::input(
                'realname',
                [
                    'value' => $user->fields['realname'],
                    'id'    => "textfield_realname$surnamerand",
                ]
            );
            //         }
            echo "</div>";
            echo "</div>";

            $firstnamerand = mt_rand();
            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='textfield_firstname$firstnamerand'>" . __('First name') . "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";
            //         if ($extauth
            //             && isset($authtype['firstname_field'])
            //             && !empty($authtype['firstname_field'])) {
            //
            //            echo $user->fields["firstname"];
            //         } else {
            echo Html::input(
                'firstname',
                [
                    'value' => $user->fields['firstname'],
                    'id'    => "textfield_firstname$firstnamerand",
                ]
            );
            //         }
            echo "</div>";
            echo "</div>";

            $phonerand = mt_rand();
            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='textfield_phone$phonerand'>" . __('Phone') . "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";
            //         if ($extauth
            //             && isset($authtype['phone_field']) && !empty($authtype['phone_field'])) {
            //            echo $user->fields["phone"];
            //         } else {
            echo Html::input(
                'phone',
                [
                    'value' => $user->fields['phone'],
                    'id'    => "textfield_phone$phonerand",
                ]
            );
            //         }
            echo "</div>";
            echo "</div>";

            $mobilerand = mt_rand();
            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='textfield_mobile$mobilerand'>" . __('Mobile phone') . "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";

            //         if ($extauth
            //             && isset($authtype['mobile_field']) && !empty($authtype['mobile_field'])) {
            //            echo $user->fields["mobile"];
            //         } else {
            echo Html::input(
                'mobile',
                [
                    'value' => $user->fields['mobile'],
                    'id'    => "textfield_mobile$mobilerand",
                ]
            );
            //         }
            echo "</div>";
            echo "</div>";

            $phone2rand = mt_rand();
            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='textfield_phone2$phone2rand'>" . __('Phone 2') . "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";

            //         if ($extauth
            //             && isset($authtype['phone2_field']) && !empty($authtype['phone2_field'])) {
            //            echo $user->fields["phone2"];
            //         } else {
            echo Html::input(
                'phone2',
                [
                    'value' => $user->fields['phone2'],
                    'id'    => "textfield_phone2$phone2rand",
                ]
            );
            //         }
            echo "</div>";
            echo "</div>";

            $admnumrand = mt_rand();
            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='textfield_registration_number$admnumrand'>" . _x('user', 'Administrative number') . "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";
            //         if ($extauth
            //             && isset($authtype['registration_number_field']) && !empty($authtype['registration_number_field'])) {
            //            echo $user->fields["registration_number"];
            //         } else {
            echo Html::input(
                'registration_number',
                [
                    'value' => $user->fields['registration_number'],
                    'id'    => "textfield_registration_number$admnumrand",
                ]
            );
            //         }
            echo "</div>";
            echo "</div>";

            $locrand = mt_rand();
            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='dropdown_locations_id$locrand'>" . __('Location') . "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";
            //         if ($extauth
            //             && isset($authtype['location_field']) && !empty($authtype['location_field'])) {
            //            echo Dropdown::getDropdownName("glpi_locations", $user->fields['locations_id']);
            //         } else {
            Location::dropdown(['value'  => $user->fields['locations_id'],
                                'rand'   => $locrand,
                                'entity' => $_SESSION['glpiactive_entity']]);
            //      }
            echo "</div>";
            echo "</div>";

            //            $userrand = mt_rand();
            //            echo "<label class=\"col-md-6 control-label full_glpi_policy\" for='dropdown_users_id_supervisor_$userrand'>" . __('Responsible') . "</label>";
            //            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            //            echo "<div class=\"input-group\">";
            //            User::dropdown(['name'   => 'users_id_supervisor',
            //                         'value'  => $user->fields["users_id_supervisor"],
            //                         'rand'   => $userrand,
            //                         'entity' => $_SESSION["glpiactive_entity"],
            //                         'right'  => 'all']);
            //
            //            echo "</div>";
            //            echo "</div>";

            echo "</div>";

            echo "<div class=\"form-group col-md-4 right\">";
            echo "<label class=\"col-form-label col-form-label-xd\">";
            echo __('Your photo', 'servicecatalog');
            echo "</label>";
            echo "<div class='user_picture_border_small' id='picture$rand'>";
            if (!empty($user->fields['picture'])) {
                echo "<img class='user_picture_small' alt=\"" . __s('Picture') . "\" src='" .
                     User::getThumbnailURLForPicture($user->fields['picture']) . "'>";
            }
            echo "</div>";
            $full_picture = "<div class='user_picture_border'>";
            $full_picture .= "<img class='user_picture' alt=\"" . __s('Picture') . "\" src='" .
                             User::getURLForPicture($user->fields['picture']) . "'>";
            $full_picture .= "</div>";
            Html::showTooltip($full_picture, ['applyto' => "picture$rand"]);
            //         if ($extauth
            //             && isset($authtype['picture_field']) && empty($authtype['picture_field'])) {
            echo Html::file(['name' => 'picture', 'display' => false, 'onlyimages' => true]);
            //            echo "<input class='form-control' type='file' name='picture'>";
            echo "&nbsp;";
            Html::showCheckbox(['name' => '_blank_picture', 'title' => __('Clear')]);
            echo "&nbsp;" . __('Clear');
            //         }
            echo "</div>";
            echo "</div>";

            echo "<div class=\"row\">";
            echo "<div class=\"col-md-12 selectContainer\">";
            Html::requireJs('glpi_dialog');

            $emailrand = mt_rand();
            echo "<label class=\"col-md-5 control-label full_glpi_policy\" for='textfield_email$emailrand'>" . _n('Email', 'Emails', Session::getPluralNumber());
            echo "&nbsp;<button form='' data-bs-toggle='modal' data-bs-target='#newemail' id='add_new_email' class='submit btn btn-success btn-sm' title='" . _sx('button', 'Add a new email', 'servicecatalog') . "'><i class='fas fa-1x fa-plus pointer'></i></a>";
            echo "</button>";
            $srcImg = "fas fa-info-circle";
            $color  = "forestgreen";
            $title  = "<i class='" . $srcImg . " fa-1x' style='color:" . $color . "'></i>&nbsp;" . __("Add a new email and set as preferred email", 'servicecatalog');
            echo Ajax::createIframeModalWindow(
                'newemail',
                PLUGIN_SERVICECATALOG_WEBDIR . "/front/useremail.form.php",
                ['title'         => $title,
                 'display'       => false,
                 'width'         => 100,
                 'height'        => 100,
                 'reloadonclose' => true]
            );

            echo "</label>";
            echo "<div class=\"form-field row col-12 col-sm-6  mb-2\">";
            echo "<div class=\"input-group\">";

            $query      = [
                'FROM'  => UserEmail::getTable(),
                'WHERE' => [
                    'users_id' => $ID
                ],
                'ORDER' => 'is_dynamic DESC'
            ];
            $item       = new User();
            $lower_name = strtolower(get_called_class());
            $div_id     = "add_" . $lower_name . "_to_" . $item->getType() . "_" . $ID;
            echo "<div id='$div_id'>";
            $current_item = new UserEmail();
            $iterator     = $DB->request($query);
            $count        = 0;
            foreach ($iterator as $data) {
                $current_item->fields = $data;
                $count++;
                if ($count) {
                    $disabled = $current_item->fields['is_dynamic'] == 1 ? "disabled" : "";

                    //               $name = "<i class='fas fa-trash'></i>";
                    $name      = $current_item->fields['email'];
                    $name      .= $current_item->fields['is_dynamic'] == 1 ? " (" . __('D') . ")" : "";
                    $emails_id = $current_item->fields['id'];

                    if ($current_item->fields['is_default'] == 1) {
                        echo "<i class='fas fa-1x fa-check' title='" . __('Preferred email', 'servicecatalog') . "'
                           data-hasqtip='0' aria-hidden='true'></i>&nbsp;";
                    }
                    echo "<input type='text' class='form-control' $disabled size='30' name='email$emails_id' id='email$emails_id' value='" . $name . "'>";
                    if ($current_item->fields['is_dynamic'] != 1) {
                        echo "&nbsp;<button form='' class='submit btn btn-info btn-sm' onclick=\"update_emails(" . $emails_id . ")\">";
                        echo "<i class='fas fa-1x fa-save pointer' title='" . _sx('button', 'Update email', 'servicecatalog') . "'
                           data-hasqtip='0' aria-hidden='true'></i>";
                        echo "</button>";
                        echo "&nbsp;<button form='' class='submit btn btn-danger btn-sm' onclick=\"delete_emails(" . $emails_id . ")\">";
                        echo "<i class='fas fa-1x fa-trash pointer' title='" . _sx('button', 'Delete email', 'servicecatalog') . "'
                           data-hasqtip='0' aria-hidden='true'></i>";
                        echo "</button>";
                    }
                    if ($current_item->fields['is_default'] != 1) {
                        echo "&nbsp;<button form='' class='submit btn btn-success btn-sm' onclick=\"set_as_default(" . $emails_id . ")\">";
                        echo "<i class='fas fa-1x fa-check pointer' title='" . _sx('button', 'Set as preferred email', 'servicecatalog') . "'
                           data-hasqtip='0' aria-hidden='true'></i>";
                        echo "</button>";
                    }
                    echo "<br><br>";
                }
            }

            echo "</div>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            echo "</div>";

            echo "<div class=\"row\">";
            echo "<div class=\"col-md-12 selectContainer center\">";
            echo Html::submit(__s('Update your informations and create a ticket', 'servicecatalog'), ['name' => 'update', 'class' => 'btn btn-primary ticket-button']);

            if ($user->fields['authtype'] == Auth::DB_GLPI) {
                $expiration_msg = "";
                if ($user->shouldChangePassword()) {
                    $expiration_msg = sprintf(
                        __('Your password will expire on %s.'),
                        Html::convDateTime(date('Y-m-d H:i:s', $user->getPasswordExpirationTime()))
                    );
                }

                echo $expiration_msg
                    . ' '
                    . '<a class="btn btn-primary" href="' . $CFG_GLPI['root_doc'] . '/front/updatepassword.php">'
                    . __('Update my password')
                    . '</a>';
            }
            echo "</div>";
            echo "</div>";

            Html::closeForm();



            echo "<script>
                      function set_as_default(email_id) {
                          $('#ajax_loader').show();
                          $.ajax({
                             url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/update_emailpreferences.php',
                                type: 'POST',
                                data:
                                  {
                                    action: 'default',
                                    users_id:$ID,
                                    email_id: email_id,
                                  },
                                success: function(response){
                                    $('#ajax_loader').hide();
                                    document.location.reload();
                                 },
                                error: function(xhr, status, error) {
                                   console.log(xhr);
                                   console.log(status);
                                   console.log(error);
                                 } 
                             });
                       };
                     </script>";
            echo "<script>
                      function update_emails(email_id) {
                          $('#ajax_loader').show();
                          var name = 'email' + email_id;
//                          console.log(name);
                          $.ajax({
                             url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/update_emailpreferences.php',
                                type: 'POST',
                                data:
                                  {
                                    action: 'update',
                                    users_id:$ID,
                                    email_id: email_id,
                                    email: $('#' + name).val()
                                  },
                                success: function(response){
                                    $('#ajax_loader').hide();
                                    document.location.reload();
                                 },
                                error: function(xhr, status, error) {
                                   console.log(xhr);
                                   console.log(status);
                                   console.log(error);
                                 } 
                             });
                       };
                     </script>";
            echo "<script>
                      function delete_emails(email_id) {
                          $('#ajax_loader').show();
                          $.ajax({
                             url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/update_emailpreferences.php',
                                type: 'POST',
                                data:
                                  {
                                    action: 'delete',
                                    users_id:$ID,
                                    email_id: email_id,
                                  },
                                success: function(response){
                                    $('#ajax_loader').hide();
                                    document.location.reload();
                                 },
                                error: function(xhr, status, error) {
                                   console.log(xhr);
                                   console.log(status);
                                   console.log(error);
                                 } 
                             });
                       };
                     </script>";

            return true;
        }
        return false;
    }


    static function showNewEmailForm() {

        global $CFG_GLPI;


        echo "<form method='post' name='user_email' action='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/useremail.form.php'>";
        echo "<div id='add-message' class=''>";
        echo __("Email", "servicecatalog");
        echo "&nbsp;";
        echo Html::input('email', ['id' => 'new_email', 'size' => 30]);
        echo Html::hidden('action', ['value' => 'add']);
        echo Html::hidden('users_id', ['value' => Session::getLoginUserID()]);
        echo "&nbsp;";
        echo Html::submit(_sx('button', 'Add'), ['name'    => 'add_user_email',
                                                 'class'   => 'btn btn-primary',
                                                 'onclick' => "$('#newemail').modal('hide');"]);
        echo "</div>";
        Html::closeForm();
    }

    /**
     * @param $input
     */
    static function createTicket($input) {

        $ticket = new Ticket();
        $pref   = new self();

        $input         = $pref->reformatTicketFields($input);
        $ticket_inputs = [];

        if ($input['updates'] > 0) {
            foreach ($input as $input_key => $input_value) {
                if (strpos($input_key, 'ticket_') !== false) {
                    $value                 = str_replace('ticket_', '', $input_key);
                    $ticket_inputs[$value] = $input_value;
                }
            }

            $ticket_inputs                        = array_merge($ticket_inputs, ['name'        => $input['name'],
                                                                                 'content'     => Glpi\Toolbox\Sanitizer::sanitize($input['content']),
                                                                                 'entities_id' => $_SESSION['glpiactive_entity']]);
            $ticket_inputs["_users_id_requester"] = Session::getLoginUserID();
            $new_id                               = $ticket->add($ticket_inputs);

            if (isset($input['_picture']) && is_array($input['_picture'])) {
                $doc      = new Document();
                $filename = $input['_picture'];
                $tag      = $input['_tag_picture'];
                $prefix   = $input['_prefix_picture'];
                if ($newID = $doc->add(['entities_id'      => $_SESSION['glpiactive_entity'],
                                        '_filename'        => $filename,
                                        '_prefix_filename' => $prefix,
                                        '_tag_filename'    => $tag])) {
                    GLPI\Event::log(
                        $newID,
                        "documents",
                        4,
                        "login",
                        sprintf(
                            __('%1$s adds the item %2$s'),
                            $_SESSION["glpiname"],
                            $doc->fields["name"]
                        )
                    );
                }

                if ($newID > 0) {
                    $doc_item = new Document_Item();
                    $doc_item->add(['itemtype'     => 'Ticket',
                                    'items_id'     => $new_id,
                                    'documents_id' => $newID]);
                }
            }
        }
    }


    /**
     * Get all emails for user.
     *
     * @param $users_id user ID
     *
     * @return array of emails
     **/
    static function getAllForUser($users_id) {
        global $DB;

        $emails = [];

        $iterator = $DB->request([
                                     'FROM'  => UserEmail::getTable(),
                                     'WHERE' => [
                                         'users_id' => $users_id,
                                     ]
                                 ]);

        foreach ($iterator as $row) {
            $emails[$row['email']] = $row['email'];
        }

        return $emails;
    }


    /**
     * @param $input
     *
     * @return mixed
     */
    public static function reformatTicketFields($input) {
        $name             = __('Personal informations updated', 'servicecatalog');
        $input['content'] = "";
        $input['updates'] = 0;
        $input['content'] .= "<table style='width: 100%;'>"; // class='mticket'
        $input['content'] .= "<tr><th colspan='2' style='background-color: #ccc;'>" . $name . "</th></tr>";

        $user = new User();
        $user->getFromDB($input["id"]);

        foreach (self::getFieldsToStore($input) as $key => $value) {
            if ($key != "_useremails"
                && $key != "_default_email"
                && $key != "_picture"
                && !empty($value)
                && ($value != $user->fields[$key])) {
                $translation = self::translateFields($key);
                switch ($key) {
                    case 'locations_id':
                        $input['content'] .= "<tr>";
                        $input['content'] .= "<td>" . $translation . "</td>";
                        $input['content'] .= "<td>" . Dropdown::getDropdownName("glpi_locations", $value) . "</td>";
                        $input['content'] .= "</tr>";
                        unset($input[$key]);
                        $input['updates']++;
                        break;
                    case 'users_id_supervisor':
                        $input['content'] .= "<tr>";
                        $input['content'] .= "<td>" . $translation . "</td>";
                        $input['content'] .= "<td>" . getUserName($value) . "</td>";
                        $input['content'] .= "</tr>";
                        unset($input[$key]);
                        $input['updates']++;
                        break;
                    default:
                        $input['content'] .= "<tr>";
                        $input['content'] .= "<td>" . $translation . "</td>";
                        $input['content'] .= "<td>" . $value . "</td>";
                        $input['content'] .= "</tr>";
                        unset($input[$key]);
                        $input['updates']++;
                        break;
                }
            }
            if ($key == "_picture"
                && count($value) > 0) {
                switch ($key) {
                    case '_picture':
                        $input['content'] .= "<tr>";
                        $input['content'] .= "<td>" . __('Picture') . "</td>";
                        $input['content'] .= "<td>" . __('See linked picture', 'servicecatalog') . "</td>";
                        $input['content'] .= "</tr>";
                        $input['updates']++;
                        //                  unset($input[$key]);
                        break;
                }
            }
            if ($key == "_useremails"
                && count($value) > 0) {
                $translation = self::translateFields($key);
                switch ($key) {
                    case '_useremails':
                        foreach ($value as $k => $mail) {
                            if (!empty($mail) && !UserEmail::isEmailForUser($input["id"], $mail)) {
                                $input['content'] .= "<tr>";
                                $input['content'] .= "<td>" . $translation . "</td>";
                                $input['content'] .= "<td>" . $mail . "</td>";
                                $input['content'] .= "</tr>";
                                unset($input[$key]);
                                $input['updates']++;
                            }
                        }
                        break;
                }
            }
            if ($key == "_default_email"
                && $value > 0) {
                $translation = self::translateFields($key);
                switch ($key) {
                    case '_default_email':
                        $emails = self::getAllForUser($input["id"]);
                        foreach ($emails as $k => $mail) {
                            if ($k == $value) {
                                $input['content'] .= "<tr>";
                                $input['content'] .= "<td>" . $translation . "</td>";
                                $input['content'] .= "<td>" . $emails[$value] . "</td>";
                                $input['content'] .= "</tr>";
                                unset($input[$key]);
                                $input['updates']++;
                            }
                        }

                        break;
                }
            }
        }
        $input['content'] .= "</table>";
        $input['name']    = $name;

        return $input;
    }

    /**
     * @param $input
     *
     * @return array
     */
    private static function getFieldsToStore($input) {

        $ticket_content    = [];
        $accepted_contents = ['name',
                              'realname',
                              'firstname',
                              'phone',
                              'mobile',
                              'phone2',
                              '_useremails',
                              'registration_number',
                              '_default_email',
                              'locations_id',
                              '_picture',
                              'users_id_supervisor'];
        foreach ($input as $key => $value) {
            if (in_array($key, $accepted_contents)) {
                $ticket_content[$key] = $value;
            }
        }
        return $ticket_content;
    }

    /**
     * @param $key
     *
     * @return string
     */
    private static function translateFields($key) {
        switch ($key) {
            case 'name':
                return __('Login');
            case 'realname':
                return __('Surname');
            case 'firstname':
                return __('First name');
            case 'phone':
                return __('Phone');
            case 'mobile':
                return __('Mobile phone');
            case 'phone2':
                return __('Phone 2');
            case '_useremails':
                return _n('Email', 'Emails', Session::getPluralNumber());
            case 'registration_number':
                return _x('user', 'Administrative number');
            case 'locations_id':
                return __('Location');
            case 'users_id_supervisor':
                return __('Responsible');
            case '_default_email':
                return __('Default email');
            default:
                return $key;
        }
    }

    /**
     * @param $class
     *
     * @return string
     */
    static function getWidgetPreferences($id, $class, $fromticketform = 0) {

        $widget = new PluginServicecatalogWidget();

        $delclass = "";
        $display  = "<div id='" . $id . "' class=\"bt-row $delclass\">";
        $display  .= "<div class=\"bt-feature $class \">";

        if ($fromticketform == 1) {
            $title   = __('Check your personnal information');
        } else {
            $title   = PluginServicecatalogConfig::displayField($widget, 'title_personalinfo');
        }

        $display .= PluginServicecatalogWidget::getWidgetTitle($title);

        $display .= "<div id='display-sc'>";
        $display .= "<div class='widget-title visitedchildbg widgetrow'>";

        $display .= self::showPreferences();

        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";

        return $display;
    }

    /**
     * @param $widget
     *
     * @return string|void
     */
    static function showPreferences() {

        $config = new PluginServicecatalogConfig();
        $widget = new PluginServicecatalogWidget();

        $display = "";

        $display .= "<div class='d-inline-flex'>";
        $display .= "<div class='card mb-0' id='user-info'>";
        $display .= "<div class='card-body'>";
        $display .= "<div class='p-0 user-info-card'>";
        $display .= "<div class='row'>";

        $display .= "<div class='col-auto ms-2'>";
        $user    = new User();
        $user->getFromDB(Session::getLoginUserID());
        $thumbnail_url = User::getThumbnailURLForPicture($user->fields['picture']);
        $style         = !empty($thumbnail_url) ? "background-image: url('$thumbnail_url')" : ("background-color: " . $user->getUserInitialsBgColor());
        //        $display .= '<a href="' . $user->getLinkURL() . '" class="d-flex align-items-center">';
        $user_name = formatUserName(
            $user->getID(),
            $user->fields['name'],
            $user->fields['realname'],
            $user->fields['firstname']
        );
        $display   .= '<span class="avatar avatar-md rounded" style="' . $style . '" title="' . $user_name . '">';
        if (empty($thumbnail_url)) {
            $display .= $user->getUserInitials();
        }
        $display .= '</span>';
        //        $display .= '</a>';
        if ($config->getDropPreferencesButton() == 0) {
            $url_prefs = PLUGIN_SERVICECATALOG_WEBDIR . "/front/preference.php";
            $display   .= "<div class='col' style='margin-top:5px;'>";
            $display   .= '<a class="btn btn-icon btn-sm btn-outline-secondary"  href="' . $url_prefs . '"  data-bs-toggle="tooltip" data-bs-placement="top">';
            $display   .= "<i class='fas fa-fw fa-user-edit'></i>";
            $display   .= '</a>';
            $display   .= "</div>";
        }
        $display .= "</div>";


        $display .= "<div class='col-auto ms-2'>";
        $display .= "<h4 class='left card-title mb-1'>";
        $display .= $user_name;
        $display .= "</h4>";

        $default_email = $user->getDefaultEmail();
        $emails        = $user->getAllEmails();
        if ((count($emails) == 1)
            && !empty($default_email)
            && NotificationMailing::isUserAddressValid($default_email)
        ) {
            $display .= "<div class='left'>";
            $display .= "<i class='fas fa-fw fa-envelope'></i>&nbsp;";
            $display .= '<a style ="font-weight: normal;" href="mailto:' . $default_email . '">';
            $display .= $default_email;
            $display .= '</a>';
            $display .= "</div>";
        }

        if ($user->fields['phone']) {
            $display .= "<div class='left'>";
            $display .= "<i class='fas fa-fw fa-phone'></i>&nbsp;";
            $display .= '<a style ="font-weight: normal;" href="tel:' . $user->fields['phone'] . '">';
            $display .= $user->fields['phone'];
            $display .= '</a>';
            $display .= "</div>";
        }

        if ($user->fields['mobile']) {
            $display .= "<div class='left'>";
            $display .= "<i class='fas fa-fw fa-mobile-alt'></i>&nbsp;";
            $display .= '<a style ="font-weight: normal;" href="tel:' . $user->fields['mobile'] . '">';
            $display .= $user->fields['mobile'];
            $display .= '</a>';
            $display .= "</div>";
        }

        if ($user->fields['locations_id']) {
            $display .= "<div class='left' data-bs-toggle='tooltip' data-bs-placement='top'>";
            $display .= "<i class='fas fa-fw fa-map-marker-alt'></i>&nbsp;";
            $display .= Dropdown::getDropdownName("glpi_locations", $user->fields['locations_id']);
            $display .= "</div>";
        }

        if ($user->fields['usercategories_id']) {
            $display .= "<div class='left' data-bs-toggle='tooltip' data-bs-placement='top'>";
            $display .= "<i class='fas fa-fw fa-user-tag'></i>&nbsp;";
            $display .= Dropdown::getDropdownName("glpi_usercategories", $user->fields['usercategories_id']);
            $display .= "</div>";
        }
        $display .= "</div>";

        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";

        return $display;
    }
}
