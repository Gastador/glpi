<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogPlugin
 */
class PluginServicecatalogPlugin extends CommonDBTM
{

    static $rightname = 'plugin_servicecatalog';

   /**
    * Interface for the type of ticket
    *
    * @param $plug
    *
    * @return bool
    */
    static function canUse($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];
            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getMenuComment'])) {
                    return ($item->canUse());
                }
            }
        }
        return false;
    }

   /**
    * Interface for the type of ticket
    *
    * @param $plug
    */
    static function showMain($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $form[$pluginclass] = [];
                $item               = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getList'])) {
                    $item->getList();
                }
            }
        }
    }

   /**
    * Displaying the category interface title
    *
    * @param $plug
    *
    * @return mixed
    */
    static function showLinkList($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getLinkList'])) {
                    return ($item->getLinkList());
                }
            }
        }
    }

   /**
    * Display of type comment
    *
    * @param $plug
    *
    * @return mixed
    */
    static function showMenuComment($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];
            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getMenuComment'])) {
                    return ($item->getMenuComment());
                }
            }
        }
    }

   /**
    * Displaying the menu title in the selection of the type
    *
    * @param $plug
    *
    * @return mixed
    */
    static function showMenuTitle($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getMenuTitle'])) {
                    return ($item->getMenuTitle());
                }
            }
        }
    }

   /**
    * Displaying the menu title in the selection of the type
    *
    * @param $plug
    *
    * @return mixed
    */
    static function showAhrefTitle($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getAhrefTitle'])) {
                    return ($item->getAhrefTitle());
                }
            }
        }
    }

   /**
    * Displaying the menu logo in the selection of the type
    *
    * @param $plug
    *
    * @return mixed
    */
    static function showMenuLogo($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getMenuLogo'])) {
                    return ($item->getMenuLogo());
                }
            }
        }
    }

   /**
    * Displaying the menu logo in the selection of the type
    *
    * @param $plug
    *
    * @return mixed
    */
    static function showMenuLogoCss($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getMenuLogoCss'])) {
                    return ($item->getMenuLogoCss());
                }
            }
        }
    }

    static function showLeftMenuLogoCss($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getLeftMenuLogoCss'])) {
                    return ($item->getLeftMenuLogoCss());
                }
            }
        }
    }

   /**
    * Displaying the category link url
    *
    * @param $type
    * @param $category_id
    *
    * @return mixed
    */
    static function showLinkCategory($type, $category_id)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'])) {
            foreach ($PLUGIN_HOOKS['servicecatalog'] as $plugin => $v) {
                $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plugin];

                foreach ($pluginclasses as $pluginclass) {
                    if (!class_exists($pluginclass)) {
                        continue;
                    }
                    $item = $dbu->getItemForItemtype($pluginclass);
                    if ($item && is_callable([$item, 'getLinkURL'])) {
                        if (($link = $item->getLinkURL($type, $category_id)) !== false) {
                             return $link;
                        } else {
                             continue;
                        }
                    }
                }
            }
        }
    }

   /**
    * Displaying the menu url in the selection of the type
    *
    * @param $plug
    *
    * @return mixed
    */
    static function showNavBarLink($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getNavBarLink'])) {
                    return ($item->getNavBarLink());
                }
            }
        }
    }

   /**
    * Displaying the menu url in the selection of the type
    *
    * @param $plug
    *
    * @return mixed
    */
    static function getMenuLink($plug)
    {
        global $PLUGIN_HOOKS;

        $dbu = new DbUtils();
        if (isset($PLUGIN_HOOKS['servicecatalog'][$plug])) {
            $pluginclasses = $PLUGIN_HOOKS['servicecatalog'][$plug];

            foreach ($pluginclasses as $pluginclass) {
                if (!class_exists($pluginclass)) {
                    continue;
                }
                $item = $dbu->getItemForItemtype($pluginclass);
                if ($item && is_callable([$item, 'getMenuLink'])) {
                    return ($item->getMenuLink());
                }
            }
        }
    }

   /**
    * @param $widget
    * @param $plug
    * @param $bloc_class
    *
    * @return string
    */
    static function getWidgetPlugins($widget, $plug, $bloc_class)
    {


        $url = self::getMenuLink($plug);
        return PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img"      => "",
                                                                               "fa"       => self::showMenuLogo($plug),
                                                                               "fa_style" => self::showMenuLogoCss($plug),
                                                                               "title"    => self::showMenuTitle($plug),
                                                                               "comment"  => self::showMenuComment($plug)]);
    }

   /**
    * @param $widget
    *
    * @param $plug
    *
    * @return string
    */
    static function showNavBar($widget, $plug)
    {

        $form  = "";
        $url   = self::getMenuLink($plug);
        $title = self::showMenuTitle($plug);
        $title_ahref = self::showAhrefTitle($plug);
        $id    = $plug . '_bar';
        $form  .= "<div class='nav-item nav-item-sc'>";
        $form  .= "<a id='$id' class='nav-link' href='" . $url . "' title=\"$title_ahref\">";
        $style = "";
        if (!empty(self::showMenuLogo($plug))) {
            $icon  = self::showMenuLogo($plug);
            $css = self::showLeftMenuLogoCss($plug);
            $style = "style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';$css\"";

            $form  .= "<span id='plugin_fa' class='$icon fa-fw mr-3' $style ></span>";
        }
        $form .= '<span class="menu-label">&nbsp;';
        $form .= $title;
        $form .= "</span>
                    </a></div>";
        return $form;
    }
}
