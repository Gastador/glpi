<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogContact
 */
class PluginServicecatalogReservation extends CommonDBTM
{

    static $rightname = "plugin_servicecatalog";

   /**
    * @param $widget
    * @param $bloc_class
    *
    * @return string
    */
    static function getWidgetReservations($widget, $bloc_class)
    {
        $buttons = "";
        if (Session::haveRight("reservation", ReservationItem::RESERVEANITEM)
        && $widget->fields['reservation_widgetactions'] == 1) {
            $url     = PLUGIN_SERVICECATALOG_WEBDIR . "/front/reservationitem.php";
            $title   = PluginServicecatalogConfig::displayField($widget, 'title_reservation');
            $url_img = "picture.send.php";
            $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img"     => $widget->fields['img_reservation'],
                                                                                      "url_img" => $url_img,
                                                                                      "fa"      => $widget->fields['fa_reservation'],
                                                                                      "title"   => $title,
                                                                                      "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_reservation')]);
        }
        return $buttons;
    }


   /**
    * @param $widget
    *
    * @return string
    */
    static function showNavBarMenu($widget)
    {

        $menu = [];
        if (Session::haveRight("reservation", ReservationItem::RESERVEANITEM)) {
            $url   = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/reservationitem.php";
            $title = PluginServicecatalogConfig::displayField($widget, 'title_reservation');
            $menu['title'] = $title;
            $menu['page'] = $url;
  //ti ti-calendar-event
            if (!empty($widget->fields['fa_reservation'])) {
                $icon = $widget->fields['fa_reservation'];
                $menu['icon'] = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "reservation_bar";
        }
        return $menu;
    }


   /**
    * Display for reservation
    *
    * @param $ID              ID of the reservation (empty for create new)
    * @param $options   array of possibles options:
    *     - item  reservation items ID for creation process
    *     - date date for creation process
    **/
    function showForm($ID, $options = [])
    {
        global $CFG_GLPI;

        if (!Session::haveRight("reservation", ReservationItem::RESERVEANITEM)) {
            return false;
        }

        $resa = new Reservation();

        if (!empty($ID)) {
            if (!$resa->getFromDB($ID)) {
                return false;
            }

            if (!$resa->can($ID, UPDATE)) {
                return false;
            }
           // Set item if not set
            if ((!isset($options['item']) || (count($options['item']) == 0))
             && ($itemid = $resa->getField('reservationitems_id'))) {
                $options['item'][$itemid] = $itemid;
            }
        } else {
            $resa->getEmpty();
            $resa->fields["begin"] = $options['begin'];
            if (!isset($options['end'])) {
                $resa->fields["end"] = date(
                    "Y-m-d H:00:00",
                    strtotime($resa->fields["begin"]) + HOUR_TIMESTAMP
                );
            } else {
                $resa->fields["end"] = $options['end'];
            }
        }

       // No item : problem
        if (!isset($options['item']) || (count($options['item']) == 0)) {
            return false;
        }

        echo "<div class='center'><form method='post' name=form action='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/reservation.form.php'>";

        if (!empty($ID)) {
            echo Html::hidden('id', ['value' => $ID]);
        }

        echo "<table class='tab_cadre' width='700px'>";
        echo "<tr><th colspan='2'>" . __('Reserve an item') . "</th></tr>\n";

       // Add Hardware name
        $r = new ReservationItem();

        echo "<tr class='tab_bg_1'><td>" . _n('Item', 'Items', 1) . "</td>";
        echo "<td>";
        foreach ($options['item'] as $itemID) {
            $r->getFromDB($itemID);
            $type = $r->fields["itemtype"];
            $name = NOT_AVAILABLE;
            $item = null;

            if ($item = getItemForItemtype($r->fields["itemtype"])) {
                $type = $item->getTypeName();

                if ($item->getFromDB($r->fields["items_id"])) {
                    $name = $item->getName();
                } else {
                    $item = null;
                }
            }

            echo "<span class='b'>" . sprintf(__('%1$s - %2$s'), $type, $name) . "</span><br>";
            $name = "items[$itemID]";
            echo Html::hidden($name, ['value' => $itemID]);
        }

        echo "</td></tr>\n";

        $uid = (empty($ID) ? Session::getLoginUserID() : $resa->fields['users_id']);
        echo "<tr class='tab_bg_2'><td>" . __('By') . "</td>";
        echo "<td>";
        if (!Session::haveRight("reservation", UPDATE)
          || is_null($item)
          || !Session::haveAccessToEntity($item->fields["entities_id"])) {
            echo Html::hidden('users_id', ['value' => $uid]);
            echo Dropdown::getDropdownName(
                User::getTable(),
                $uid
            );
        } else {
            User::dropdown([
                           'value'       => $uid,
                           'entity'      => $item->getEntityID(),
                           'entity_sons' => $item->isRecursive(),
                           'right'       => 'all'
                        ]);
        }
        echo "</td></tr>\n";
        echo "<tr class='tab_bg_2'><td>" . __('Start date') . "</td><td>";
        $rand_begin = Html::showDateTimeField(
            "resa[begin]",
            ['value'      => $resa->fields["begin"],
            'maybeempty' => false]
        );
        echo "</td></tr>\n";
        $default_delay = floor((strtotime($resa->fields["end"]) - strtotime($resa->fields["begin"]))
                             / $CFG_GLPI['time_step'] / MINUTE_TIMESTAMP)
                       * $CFG_GLPI['time_step'] * MINUTE_TIMESTAMP;
        echo "<tr class='tab_bg_2'><td>" . __('Duration') . "</td><td>";
        $rand = Dropdown::showTimeStamp(
            "resa[_duration]",
            ['min'        => 0,
                                       'max'        => 24 * HOUR_TIMESTAMP,
                                       'value'      => $default_delay,
            'emptylabel' => __('Specify an end date')]
        );
        echo "<br><div id='date_end$rand'></div>";
        $params = ['duration' => '__VALUE__',
                 'end'      => $resa->fields["end"],
                 'name'     => "resa[end]"];

        Ajax::updateItemOnSelectEvent(
            "dropdown_resa[_duration]$rand",
            "date_end$rand",
            $CFG_GLPI["root_doc"] . "/ajax/planningend.php",
            $params
        );

        if ($default_delay == 0) {
            $params['duration'] = 0;
            Ajax::updateItem("date_end$rand", $CFG_GLPI["root_doc"] . "/ajax/planningend.php", $params);
        }
        Alert::displayLastAlert('Reservation', $ID);
        echo "</td></tr>\n";

        if (empty($ID)) {
            echo "<tr class='tab_bg_2'><td>" . __('Repetition') . "</td>";
            echo "<td>";
            $values   = [''      => _x('periodicity', 'None'),
                      'day'   => _x('periodicity', 'Daily'),
                      'week'  => _x('periodicity', 'Weekly'),
                      'month' => _x('periodicity', 'Monthly')];
            $rand     = Dropdown::showFromArray('periodicity[type]', $values);
            $field_id = Html::cleanId("dropdown_periodicity[type]$rand");

            $params = ['type' => '__VALUE__',
                    'end'  => $resa->fields["end"]];

            Ajax::updateItemOnSelectEvent(
                $field_id,
                "resaperiodcontent$rand",
                $CFG_GLPI["root_doc"] . "/ajax/resaperiod.php",
                $params
            );
            echo "<br><div id='resaperiodcontent$rand'></div>";

            echo "</td></tr>\n";
        }

        echo "<tr class='tab_bg_2'><td>" . __('Comments') . "</td>";
        echo "<td>";
        Html::textarea(['name'            => 'comment',
                      'value'           => $resa->fields['comment'],
                      'cols'       => 60,
                      'rows'       => 8,
                      'enable_richtext' => false]);
        echo "</td></tr>\n";

        if (empty($ID)) {
            echo "<tr class='tab_bg_2'>";
            echo "<td colspan='2' class='top center'>";
            echo Html::submit(_sx('button', 'Add'), ['name' => 'add', 'class' => 'btn btn-primary']);
            echo "</td></tr>\n";
        } else {
            if (($resa->fields["users_id"] == Session::getLoginUserID())
             || Session::haveRightsOr(static::$rightname, [PURGE, UPDATE])) {
                echo "<tr class='tab_bg_2'>";
                if (($resa->fields["users_id"] == Session::getLoginUserID())
                || Session::haveRight(static::$rightname, PURGE)) {
                    echo "<td class='top center'>";
                    echo Html::submit(_sx('button', 'Delete permanently'), ['name' => 'purge', 'class' => 'btn btn-primary']);
                    if ($resa->fields["group"] > 0) {
                         echo "<br><input type='checkbox' name='_delete_group'>&nbsp;" .
                         __s('Delete all repetition');
                    }
                    echo "</td>";
                }
                if (($resa->fields["users_id"] == Session::getLoginUserID())
                || Session::haveRight(static::$rightname, UPDATE)) {
                    echo "<td class='top center'>";
                    echo Html::submit(_sx('button', 'Save'), ['name' => 'update', 'class' => 'btn btn-primary']);
                    echo "</td>";
                }
                echo "</tr>\n";
            }
        }
        echo "</table>";
        Html::closeForm();
        echo "</div>\n";
    }

    static function showListSimple()
    {
        global $DB, $CFG_GLPI;

        if (!Session::haveRight('reservation', ReservationItem::RESERVEANITEM)) {
            return false;
        }
        echo "<div class='sc-content'>";
        $widget = new PluginServicecatalogWidget();
        $title  = PluginServicecatalogConfig::displayField($widget, 'title_reservation');

        echo PluginServicecatalogWidget::getPageTitle($title);

        $ok         = false;
        $showentity = Session::isMultiEntitiesMode();
        $values     = [];

        if (isset($_SESSION['glpi_saved']['ReservationItem'])) {
            $_POST = $_SESSION['glpi_saved']['ReservationItem'];
        }

        if (isset($_POST['reserve'])) {
            echo "<div id='viewresasearch'  class='center'>";
            Toolbox::manageBeginAndEndPlanDates($_POST['reserve']);
            echo "<div id='nosearch' class='center firstbloc'>" .
              "<a href=\"" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/reservationitem.php\">";
            echo __('See all reservable items') . "</a></div>\n";
        } else {
            echo "<div id='makesearch' class='center firstbloc'>" .
              "<a class='btn btn-secondary' href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/reservation.php?reservationitems_id=0'>
                  <i class='far fa-calendar'></i>&nbsp;
                  " . __("View calendar for all items") . "
               </a>
               <a class='btn btn-secondary mw-100 d-inline-block text-truncate' onClick=\"javascript:showHideDiv('viewresasearch','','','');" .
              "showHideDiv('makesearch','','','')\">
               <i class='fas fa-search'></i>&nbsp;";
            echo __('Find a free item in a specific period') . "</a></div>";

            echo "<div id='viewresasearch' style=\"display:none;\" class='center'>";
            $begin_time                 = time();
            $begin_time                -= ($begin_time % HOUR_TIMESTAMP);
            $_POST['reserve']["begin"]  = date("Y-m-d H:i:s", $begin_time);
            $_POST['reserve']["end"]    = date("Y-m-d H:i:s", $begin_time + HOUR_TIMESTAMP);
            $_POST['reservation_types'] = '';
        }
        echo "<form method='post' name='form' action='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/reservationitem.php'>";
        echo "<table class='tab_cadre_fixe full_glpi_policy'><tr class='tab_bg_2'>";
        echo "<th colspan='3'>" . __('Find a free item in a specific period') . "</th></tr>";

        echo "<tr class='tab_bg_2'><td>" . __('Start date') . "</td><td class='d-flex'>";
        Html::showDateTimeField("reserve[begin]", ['value'      =>  $_POST['reserve']["begin"],
                                                 'maybeempty' => false
        ]);
        echo "</td><td rowspan='3'>";
        echo "<input type='submit' class='btn btn-primary' name='submit' value=\"" . _sx('button', 'Search') . "\">";
        echo "</td></tr>";

        echo "<tr class='tab_bg_2'><td>" . __('Duration') . "</td><td>";
        $default_delay = floor((strtotime($_POST['reserve']["end"]) - strtotime($_POST['reserve']["begin"]))
                             / $CFG_GLPI['time_step'] / MINUTE_TIMESTAMP)
                       * $CFG_GLPI['time_step'] * MINUTE_TIMESTAMP;
        $rand = Dropdown::showTimeStamp("reserve[_duration]", [
         'min'        => 0,
         'max'        => 48 * HOUR_TIMESTAMP,
         'value'      => $default_delay,
         'emptylabel' => __('Specify an end date')
        ]);
        echo "<br><div id='date_end$rand'></div>";
        $params = ['duration'     => '__VALUE__',
                 'end'          => $_POST['reserve']["end"],
                 'name'         => "reserve[end]"
        ];

        Ajax::updateItemOnSelectEvent(
            "dropdown_reserve[_duration]$rand",
            "date_end$rand",
            $CFG_GLPI["root_doc"] . "/ajax/planningend.php",
            $params
        );
        echo "</td></tr>";

        echo "<tr class='tab_bg_2'><td>" . __('Item type') . "</td><td>";

        $iterator = $DB->request([
                                  'SELECT'          => 'itemtype',
                                  'DISTINCT'        => true,
                                  'FROM'            => 'glpi_reservationitems',
                                  'WHERE'           => [
                                                          'is_active' => 1
                                                       ] + getEntitiesRestrictCriteria('glpi_reservationitems', 'entities_id', $_SESSION['glpiactiveentities'])
                               ]);

        foreach ($iterator as $data) {
            $values[$data['itemtype']] = $data['itemtype']::getTypeName();
        }

        $iterator = $DB->request([
                                  'SELECT'    => [
                                     'glpi_peripheraltypes.name',
                                     'glpi_peripheraltypes.id'
                                  ],
                                  'FROM'      => 'glpi_peripheraltypes',
                                  'LEFT JOIN' => [
                                     'glpi_peripherals'      => [
                                        'ON' => [
                                           'glpi_peripheraltypes'  => 'id',
                                           'glpi_peripherals'      => 'peripheraltypes_id'
                                        ]
                                     ],
                                     'glpi_reservationitems' => [
                                        'ON' => [
                                           'glpi_reservationitems' => 'items_id',
                                           'glpi_peripherals'      => 'id'
                                        ]
                                     ]
                                  ],
                                  'WHERE'     => [
                                                    'itemtype'           => 'Peripheral',
                                                    'is_active'          => 1,
                                                    'peripheraltypes_id' => ['>', 0]
                                                 ] + getEntitiesRestrictCriteria('glpi_reservationitems', 'entities_id', $_SESSION['glpiactiveentities']),
                                  'ORDERBY'   => 'glpi_peripheraltypes.name'
                               ]);

        foreach ($iterator as $ptype) {
            $id = $ptype['id'];
            $values["Peripheral#$id"] = $ptype['name'];
        }

        Dropdown::showFromArray("reservation_types", $values, [
         'class'               => "form-select",
         'value'               => $_POST['reservation_types'],
         'display_emptychoice' => true,
        ]);

        echo "</td></tr>";
        echo "</table>";
        Html::closeForm();
        echo "</div>";

       // GET method passed to form creation
        echo "<div id='nosearch' class='card'>";
        echo "<form name='form' method='GET' action='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/reservation.form.php'>";
        echo "<div class='table-responsive'>";
        echo "<table class='card-table table table-hover full_glpi_policy'>";
        echo "<tr>";
        echo "<th style='width: 30px;'>" . Html::getCheckAllAsCheckbox('nosearch') . "</th>";
        echo "<th>" . self::getTypeName(Session::getPluralNumber()) . "</th>";
        echo "<th>" . Location::getTypeName(1) . "</th>";
        echo "<th>" . _n('Comment', 'Comments', 1) . "</th>";
        if ($showentity) {
            echo "<th>" . Entity::getTypeName(1) . "</th>";
        }
        echo "<th style='width: 50px;'>" . __("Booking calendar") . "</th>";
        echo "</tr>";

        foreach ($CFG_GLPI["reservation_types"] as $itemtype) {
            if (!($item = getItemForItemtype($itemtype))) {
                continue;
            }
            $itemtable = getTableForItemType($itemtype);
            $itemname  = $item->getNameField();

            $otherserial = new \QueryExpression($DB->quote('') . ' AS ' . $DB->quoteName('otherserial'));
            if ($item->isField('otherserial')) {
                $otherserial = "$itemtable.otherserial AS otherserial";
            }
            $criteria = [
            'SELECT' => [
               'glpi_reservationitems.id',
               'glpi_reservationitems.comment',
               "$itemtable.$itemname AS name",
               "$itemtable.entities_id AS entities_id",
               $otherserial,
               'glpi_locations.id AS location',
               'glpi_reservationitems.items_id AS items_id'
            ],
            'FROM'   => ReservationItem::getTable(),
            'INNER JOIN'   => [
               $itemtable  => [
                  'ON'  => [
                     'glpi_reservationitems' => 'items_id',
                     $itemtable              => 'id', [
                        'AND' => [
                           'glpi_reservationitems.itemtype' => $itemtype
                        ]
                     ]
                  ]
               ]
            ],
            'LEFT JOIN'    =>  [
               'glpi_locations'  => [
                  'ON'  => [
                     $itemtable        => 'locations_id',
                     'glpi_locations'  => 'id'
                  ]
               ]
            ],
            'WHERE'        => [
                                 'glpi_reservationitems.is_active'   => 1,
                                 "$itemtable.is_deleted"             => 0,
                              ] + getEntitiesRestrictCriteria($itemtable, '', $_SESSION['glpiactiveentities'], $item->maybeRecursive()),
            'ORDERBY'      => [
               "$itemtable.entities_id",
               "$itemtable.$itemname"
            ]
            ];

            $begin = $_POST['reserve']["begin"];
            $end   = $_POST['reserve']["end"];
            if (isset($_POST['submit']) && isset($begin) && isset($end)) {
                $criteria['LEFT JOIN']['glpi_reservations'] = [
                'ON'  => [
                  'glpi_reservationitems' => 'id',
                  'glpi_reservations'     => 'reservationitems_id', [
                     'AND' => [
                        'glpi_reservations.end'    => ['>=', $begin],
                        'glpi_reservations.begin'  => ['<=', $end]
                     ]
                  ]
                ]
                ];
                $criteria['WHERE'][] = ['glpi_reservations.id' => null];
            }
            if (isset($_POST["reservation_types"]) && !empty($_POST["reservation_types"])) {
                $tmp = explode('#', $_POST["reservation_types"]);
                $criteria['WHERE'][] = ['glpi_reservationitems.itemtype' => $tmp[0]];
                if (isset($tmp[1]) && ($tmp[0] == 'Peripheral')
                && ($itemtype == 'Peripheral')
                ) {
                    $criteria['LEFT JOIN']['glpi_peripheraltypes'] = [
                    'ON' => [
                     'glpi_peripherals'      => 'peripheraltypes_id',
                     'glpi_peripheraltypes'  => 'id'
                    ]
                    ];
                    $criteria['WHERE'][] = ["$itemtable.peripheraltypes_id" => $tmp[1]];
                }
            }

            $iterator = $DB->request($criteria);
            foreach ($iterator as $row) {
                echo "<tr><td>";
                echo Html::getCheckbox([
                                      'name'  => "item[" . $row["id"] . "]",
                                      'value' => $row["id"],
                                      'zero_on_empty' => false,
                                   ]);
                echo "</td>";
                $typename = $item->getTypeName();
                if ($itemtype == 'Peripheral') {
                     $item->getFromDB($row['items_id']);
                    if (isset($item->fields["peripheraltypes_id"])
                      && ($item->fields["peripheraltypes_id"] != 0)
                     ) {
                        $typename = Dropdown::getDropdownName(
                            "glpi_peripheraltypes",
                            $item->fields["peripheraltypes_id"]
                        );
                    }
                }
                $item_link = sprintf(__('%1$s - %2$s'), $typename, $row["name"]);
                if ($itemtype::canView()) {
                    $item_link = "<a href='" . $itemtype::getFormURLWithId($row['items_id']) . "&forcetab=Reservation$1'>" .
                            $item_link .
                            "</a>";
                }
                echo "<td>$item_link</td>";
                echo "<td>" . Dropdown::getDropdownName("glpi_locations", $row["location"]) . "</td>";
                echo "<td>" . nl2br(($row["comment"] ?? "")) . "</td>";
                if ($showentity) {
                    echo "<td>" . Dropdown::getDropdownName("glpi_entities", $row["entities_id"]) .
                    "</td>";
                }
                echo "<td class='center'><a href='reservation.php?reservationitems_id=" . $row['id'] . "'>
                     <i class='far fa-calendar-plus fa-2x pointer' title=\"" . __s("Reserve this item") . "\"></i>
                  </a></td>";
                echo "</tr>";
                $ok = true;
            }
        }
        if ($ok) {
            echo "<tr class='tab_bg_1'>";
            echo "<th><i class='fas fa-level-up-alt fa-flip-horizontal fa-lg mx-2'></i></th>";
            echo "<th colspan='" . ($showentity ? "5" : "4") . "'>";
            if (isset($_POST['reserve'])) {
                echo Html::hidden('begin', ['value' => $_POST['reserve']["begin"]]);
                echo Html::hidden('end', ['value'   => $_POST['reserve']["end"]]);
            }
            echo Html::submit("<i class='fas fa-lg fa-calendar-plus'></i>&nbsp;" . _sx('button', 'Book'));
            echo "</th></tr>";
        }
        echo "</table>";
        echo "</div>";
        echo Html::hidden('id', ['value' => '']);
        echo "</form>";// No CSRF token needed
        echo "</div>";
    }


   /**
    * Show reservation calendar
    *
    * @param $ID   ID of the reservation item (if 0 display all) (default '')
    **/
    public static function showCalendar(int $ID = 0)
    {
        global $CFG_GLPI;

        if (!Session::haveRight("reservation", ReservationItem::RESERVEANITEM)) {
            return false;
        }

        $rand = mt_rand();

       // scheduler feature key
       // schedular part of fullcalendar is distributed with opensource licence (GLPv3)
       // but this licence is incompatible with GLPI (GPLv2)
       // see https://fullcalendar.io/license
        $scheduler_key = Plugin::doHookFunction('planning_scheduler_key');

        $is_all = $ID === 0 ? "true" : "false";
        if ($ID > 0) {
            $m = new ReservationItem();
            $m->getFromDB($ID);

            if ((!isset($m->fields['is_active'])) || !$m->fields['is_active']) {
                echo "<div class='center'>";
                echo __('Device temporarily unavailable');
                Html::displayBackLink();
                echo "</div>";
                return false;
            }
            $type = $m->fields["itemtype"];
            $name = NOT_AVAILABLE;
            if ($item = getItemForItemtype($m->fields["itemtype"])) {
                $type = $item->getTypeName();

                if ($item->getFromDB($m->fields["items_id"])) {
                    $name = $item->getName();
                }
                $name = sprintf(__('%1$s - %2$s'), $type, $name);
            }

            $all = "<a class='btn btn-primary ms-2 view-all' href='reservation.php?reservationitems_id=0'>" .
                __('View all items') .
                "&nbsp;<i class='fas fa-eye'></i>" .
                "</a>";
        } else {
            $type = "";
            $name = __('All reservable devices');
            $all  = "";
        }
        echo "<div class='card'>";
        echo "<div class='text-center card-header'>";
        echo "<img src='" . $CFG_GLPI["root_doc"] . "/pics/reservation.png' alt='' class='reservation-icon'>";
        echo "<h3 class='item-name'>" . $name . "</h3>";
        echo "$all";
        echo "</div>"; // .center
        echo "<div id='reservations_planning_$rand' class='card-body reservations-planning'></div>";
        echo "</div>"; // .reservation_panel

        $js = <<<JAVASCRIPT
      $(function() {
         var reservation = new Reservations();
         reservation.init({
            id: $ID,
            is_all: $is_all,
            rand: $rand,
            license_key: '$scheduler_key',
         });
         reservation.displayPlanning();
      });
JAVASCRIPT;
        echo Html::scriptBlock($js);
    }



    static function createTicket($input)
    {
        $config = new PluginServicecatalogConfig();
        $config->getConfig();
        if ($config->createTicketReservation()) {
            $reservation = new ReservationItem();
            $reservation->getFromDB($input['reservationitems_id']);
            $itemType = $reservation->getField('itemtype');
            $ticket   = new Ticket();
            $item     = new $itemType();
            $item->getFromDB($reservation->getField('items_id'));

            $name = Toolbox::addslashes_deep(_n('Reservation', 'Reservations', 1) . " - " .
                                          sprintf(__('%1$s adds the reservation %2$s for item %3$s'), getUserName(Session::getLoginUserID()), "", $item->getField('name')));
           // Load ticket template if available :
            if ($config->getTicketTemplateAssociatedToTicketReservationCreation() > 0) {
                 $ticket_template = $config->getTicketTemplateAssociatedToTicketReservationCreation();
                 $tt              = $ticket->getITILTemplateToUse(
                     $ticket_template,
                     "",
                     "",
                     $_SESSION["glpiactive_entity"]
                 );
            }

            if (isset($tt->predefined) && count($tt->predefined)) {
                foreach ($tt->predefined as $predeffield => $predefvalue) {
                   // Load template data
                    $ticket_inputs[$predeffield] = Toolbox::addslashes_deep($predefvalue);
                }
            }
            $ticket_inputs["_users_id_requester"] = Session::getLoginUserID();
            $ticket_inputs["entities_id"] = $_SESSION['glpiactive_entity'];

            $input['content'] = __("New reservation") . " " .
                             __("from", 'servicecatalog') . " " . date("d/m/Y H:i:s", strtotime($input['begin'])) . " " .
                             __("to", 'servicecatalog') . " " . date("d/m/Y H:i:s", strtotime($input['end'])) . "<br />";
            $input['content'] .= __("Item") . " : " . $item->getField('name') . " <br />";
            if (!empty($input['comment'])) {
                $input['content'] .= __("Comment") . " : " . $input['comment'];
            }
            $ticket_inputs["entities_id"]  = $item->fields["entities_id"];
            $ticket_inputs["locations_id"] = $item->fields["locations_id"];


            $ticket_inputs['items_id'] = [$itemType => [$reservation->getField('items_id')]];
            $ticket_inputs["name"]     = Glpi\Toolbox\Sanitizer::sanitize($name);
            $ticket_inputs["content"]  = Glpi\Toolbox\Sanitizer::sanitize($input['content']);

            $ticket->add($ticket_inputs);
        }
    }
}
