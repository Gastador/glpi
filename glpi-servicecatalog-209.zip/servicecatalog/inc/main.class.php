<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

use Glpi\Application\View\TemplateRenderer;

/**
 * Class PluginServicecatalogMain
 */
class PluginServicecatalogMain extends CommonDBTM
{
    public static $rightname = 'plugin_servicecatalog';

    /**
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        return __('Service catalog', 'servicecatalog');
    }

    /**
     * @return array
     * @throws \GlpitestSQLError
     */
    public static function getNavBarMenu()
    {
        global $CFG_GLPI, $PLUGIN_HOOKS;

        $config = new PluginServicecatalogConfig();
        $widget = new PluginServicecatalogWidget();

        $menu["servicecatalog"] = [
            "title" => __('Main menu', 'servicecatalog'),
            "default" => PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/main.form.php",
            //         "content"    => "",
            "title_css" => "sc-bar-title",
            "icon" => "ti ti-home-2",
        ];

        $menu["servicecatalog"]["content"]["home"] = [
            "title" => __('Home'),
            "page" => PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/main.form.php",
            "icon" => "ti ti-home-2",
            "id" => "home_bar",
        ];

        $menu["servicecatalog"]["content"]["entities"] = PluginServicecatalogEntity::showNavBarMenu($widget);

        $select_entity = 0;
        if (isset($_SERVER['REQUEST_URI'])
            && str_contains($_SERVER['REQUEST_URI'], "entity.form.php?listentity=1")) {
            $select_entity = 1;
        }

        if ($select_entity == 0 && Session::haveRight('plugin_servicecatalog_incidents', READ)) {
            $menu["servicecatalog"]["content"]["incident"] = self::showNavBarIncidentMenu($widget);
        }
        if ($select_entity == 0 && Session::haveRight('plugin_servicecatalog_requests', READ)) {
            $menu["servicecatalog"]["content"]["request"] = self::showNavBarRequestMenu($widget);
        }

        if ($select_entity == 0) {
            $linktitle = _n('Ticket', 'Tickets', 2);

            if (Session::haveRight('plugin_servicecatalog_incidents', READ)
                && $widget->fields['display_incident'] == 1
                && $widget->fields['display_request'] == 0) {
                $title = PluginServicecatalogConfig::displayField($config, 'title_incidents_menu');
                if (!empty(($title))) {
                    $linktitle = $title;
                } else {
                    $linktitle = __('Incidents', 'servicecatalog');
                }
            } elseif (Session::haveRight('plugin_servicecatalog_requests', READ)
                && $widget->fields['display_incident'] == 0
                && $widget->fields['display_request'] == 1) {
                $title = PluginServicecatalogConfig::displayField($config, 'title_requests_menu');
                if (!empty(($title))) {
                    $linktitle = $title;
                } else {
                    $linktitle = __('Requests', 'servicecatalog');
                }
            } else {
                $title = PluginServicecatalogConfig::displayField($config, 'title_tickets_menu');
                if (!empty(($title))) {
                    $linktitle = $title;
                }
            }


            if (Session::haveRight("ticket", CREATE)
                || Session::haveRight("ticket", Ticket::READMY)
                || Session::haveRight("followup", ITILFollowup::SEEPUBLIC)
            ) {
                $menu["tickets"] = [
                    "title" => $linktitle,
                    "default" => PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/main.form.php",
                    "icon" => "fas fa-list-ul",
                    "title_css" => "sc-bar-title",
                ];

                $menu['tickets']['content'] = self::showNavBarMenu($widget);
            }
        }

        if ($select_entity == 0) {
            if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)
                || $CFG_GLPI["use_public_faq"]) {
                $title = PluginServicecatalogConfig::displayField($config, 'title_help_menu');
                if (empty($title)) {
                    $title = __('Help');
                }

                $menu["help"] = [
                    "title" => $title,
                    "default" => PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/main.form.php",
                    "icon" => "ti ti-zoom-question",
                    "title_css" => "sc-bar-title",
                ];

                $menu['help']['content']['faq'] = PluginServicecatalogKnowbase::showNavBarMenuFAQ($widget);
                $menu['help']['content']['docbase'] = PluginServicecatalogKnowbase::showNavBarMenuDocbase($widget);
            }

            $dbu = new DbUtils();
            $catlink = new PluginServicecatalogLink();
            $condition = ['display_at_home' => 1]
                + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', '', true);
            $links = $catlink->find($condition, 'name');

            $plugins = 0;
            if (isset($PLUGIN_HOOKS['servicecatalog'])) {
                foreach ($PLUGIN_HOOKS['servicecatalog'] as $plug => $method) {
                    if (PluginServicecatalogPlugin::canUse($plug)) {
                        $plugins++;
                    }
                }
            }
            $can_reserve = Session::haveRight("reservation", ReservationItem::RESERVEANITEM);
            if (Session::getLoginUserID()
                && ($config->see_myelements_menu()
                    || $config->getDropPreferencesButton() == 0
                    || count($links) > 0 || $can_reserve || $plugins > 0)) {
                $title = PluginServicecatalogConfig::displayField($config, 'title_others_menu');
                if (empty($title)) {
                    $title = __('Others');
                }

                $menu["others"] = [
                    "title" => $title,
                    //            "default" => PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/main.form.php",
                    "title_css" => "sc-bar-title",
                    "icon" => "ti ti-dots-circle-horizontal",
                ];

                if ($widget->fields['display_links'] == 1) {
                    $menu['others']['content'] = PluginServicecatalogLink::showNavBarMenu($widget);
                }
                //         $menu['others']['content']["personalinfo"] = PluginServicecatalogWidget::showNavBarMenuPersonalInformation($widget);
                $menu['others']['content']['reservation'] = PluginServicecatalogReservation::showNavBarMenu($widget);

                $dbu = new DbUtils();
                $catlink = new PluginServicecatalogLink();
                $condition = ['display_at_home' => 1]
                    + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', $_SESSION['glpiactive_entity'], true);
                $links = $catlink->find($condition, 'name');

                if (count($links) > 0) {
                    foreach ($links as $link) {
                        if (PluginServicecatalogLinkgroup::isUserHaveRight($link['id'])) {
                            $id = $link['id'];
                            $menu['others']['content']["others_direct_links$id"] = PluginServicecatalogLink::showNavBarMenuHomeUsefullinks($widget, $link);
                        }
                    }
                }

                $url_infos = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/usercard.php";

                if ($config->see_myelements_menu()
                    && Session::haveRight('plugin_servicecatalog_myelements', READ)) {
                    $title = PluginServicecatalogConfig::displayField($config, 'title_myelements_menu');
                    $infos['title'] = $title;
                    $infos['page'] = $url_infos;
                    if (!empty($config->fields['fa_myelements_menu'])) {
                        $icon = $config->fields['fa_myelements_menu'];
                        $infos['icon'] = "fas $icon fa-fw mr-3";
                        $infos['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                        $infos['id'] = "usercard_bar";
                    }
                    $menu['others']['content']['others_myelements'] = $infos;
                }

                if ($config->see_myappliances_menu()
                    && Session::haveRight('plugin_servicecatalog_appliancelinks', READ)) {
                    $menu['others']['content']['others_appliancelinks'] = PluginServicecatalogApplianceLink::showNavBarMenu($widget, $config);
                }
                $url_prefs = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/preference.php";

                if ($config->getDropPreferencesButton() == 0
                    && $widget->fields['display_personalinfo'] == 1) {
                    $title = PluginServicecatalogConfig::displayField($widget, 'title_personalinfo') ?? __('Your preferences', 'servicecatalog');;
                    $infos['title'] = $title;
                    $infos['page'] = $url_prefs;
                    if (!empty($widget->fields['fa_personalinfo'])) {
                        $iconp = $widget->fields['fa_personalinfo'];
                        $infos['icon'] = "fas $iconp fa-fw mr-3";
                        $infos['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                        $infos['id'] = "personal_bar";
                    }
                    $menu['others']['content']['others_prefs'] = $infos;
                }

                if (isset($PLUGIN_HOOKS['servicecatalog'])) {
                    foreach ($PLUGIN_HOOKS['servicecatalog'] as $plug => $method) {
                        if (PluginServicecatalogPlugin::canUse($plug)) {
                            $infos['title'] = PluginServicecatalogPlugin::showMenuTitle($plug);
                            $infos['page'] = PluginServicecatalogPlugin::showNavBarLink($plug);
                            if (!empty(PluginServicecatalogPlugin::showMenuLogo($plug))) {
                                $icon = PluginServicecatalogPlugin::showMenuLogo($plug);
                                $infos['icon'] = "fas $icon fa-fw mr-3";
                                $infos['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                                $infos['id'] = $plug . '_bar';
                            }
                            $menu['others']['content'][$plug] = $infos;
                        }
                    }
                }
            }
        }

        return $menu;
    }


    /**
     * @param string $title
     */
    public static function showDefaultHeaderHelpdesk($title = "", $ishelpdeskform = false, $class = 'PluginServicecatalogCategory', $type = 0, $isnewhelpdeskform = 0)
    {
        global $HEADER_LOADED;

        // Print a nice HTML-head for help page
        if ($HEADER_LOADED) {
            return;
        }
        $HEADER_LOADED = true;

        Html::includeHeader($title, 'self-service');

        $config = new PluginServicecatalogConfig();
        $widget = new PluginServicecatalogWidget();
        $menu = [];
        $menutop = [];
        if (!$config->getDropHelpdeskMenu()) {
            $menu = self::getNavBarMenu();
        }

        $select_entity = 0;
        if (isset($_SERVER['REQUEST_URI'])
            && str_contains($_SERVER['REQUEST_URI'], "entity.form.php?listentity=1")) {
            $select_entity = 1;
        }
        if ($select_entity == 0) {
            if (Session::haveRight('plugin_servicecatalog_incidents', READ)
                && $widget->fields['display_incident'] == 1
                && $widget->fields["incidents_topmenu"] == 1) {
                if ($config->getBypassCategories() == 1) {
                    $url_i = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/newticket.form.php?type=" . Ticket::INCIDENT_TYPE;
                } else {
                    $url_i = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/choosecategory.form.php?type=" . Ticket::INCIDENT_TYPE . "&level=1";
                }
                $menutop['incident'] = [
                    'page' => $url_i,
                    'title' => PluginServicecatalogConfig::displayField($widget, 'title_incident'),
                    'icon' => $widget->fields['fa_incident'],
                ];
            }

            if (Session::haveRight('plugin_servicecatalog_requests', READ)
                && $widget->fields['display_request'] == 1
                && $widget->fields["requests_topmenu"] == 1) {
                if ($config->getBypassCategories() == 1) {
                    $url_r = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/newticket.form.php?type=" . Ticket::DEMAND_TYPE;
                } else {
                    $url_r = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/choosecategory.form.php?type=" . Ticket::DEMAND_TYPE . "&level=1";
                }
                $menutop['request'] = [
                    'page' => $url_r,
                    'title' => PluginServicecatalogConfig::displayField($widget, 'title_request'),
                    'icon' => $widget->fields['fa_request'],
                ];
            }
            if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)
                && $widget->fields["faq_topmenu"] == 1) {
                $menutop['faq'] = [
                    'page' => PLUGIN_SERVICECATALOG_NOTFULL_DIR . '/front/faq.php',
                    'title' => PluginServicecatalogConfig::displayField($widget, 'title_faq'),
                    'icon' => $widget->fields['fa_faq'],
                ];
            }
            $catlink = new PluginServicecatalogLink();
            $dbu = new DbUtils();
            $condition = ['display_at_home' => 0]
                + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', '', true);
            $links = $catlink->find($condition, 'name');
            if (count($links) > 0 && $widget->fields["links_topmenu"] == 1) {
                $url = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/link.form.php?see_links";
                $menutop['link'] = [
                    'page' => $url,
                    'title' => PluginServicecatalogConfig::displayField($widget, 'title_links'),
                    'icon' => $widget->fields['fa_links'],
                ];
            }

            if (Session::haveRight('plugin_servicecatalog_favorites', UPDATE) && $widget->fields["favorites_topmenu"] == 1) {
                $url_f = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/choosecategory.form.php?manage_favorites=1&level=1";
                $menutop['favorites'] = [
                    'page' => $url_f,
                    'title' => __('Favorites', 'servicecatalog'),
                    'icon' => 'fa-star',
                ];
            }

            if ($class == "PluginResourcesResource") {
                $menutop['PluginResourcesResource'] = [];
            }
        }

        if ($class == "PluginServicecatalogLink") {
            TemplateRenderer::getInstance()->display(
                '@servicecatalog/link_header.html.twig',
                [
                    'menu' => $menu,
                    'menutop' => $menutop,
                    'type' => ' ',
                    'sc_pref_url' => PLUGIN_SERVICECATALOG_WEBDIR . '/front/preference.php',
                ] + self::getPageHeaderTplVars()
            );
        } elseif ($class == "PluginServicecatalogApplianceLink") {
            TemplateRenderer::getInstance()->display(
                '@servicecatalog/appliancelink_header.html.twig',
                [
                    'menu' => $menu,
                    'menutop' => $menutop,
                    'type' => ' ',
                    'sc_pref_url' => PLUGIN_SERVICECATALOG_WEBDIR . '/front/preference.php',
                ] + self::getPageHeaderTplVars()
            );
        } elseif ($class == "PluginServicecatalogCategory"
            || $class == "PluginResourcesResource") {
            $usesearch = $config->useIntegratedSearch();

            $width = '100%';
            $self = new Self();
            if ($isnewhelpdeskform == true
                && $config->fields["helpdesk_form_percent"]
            && !$self->isMobile()) {
                $percent = $config->fields["helpdesk_form_percent"];
                $width = $percent.'%';
            }

            TemplateRenderer::getInstance()->display(
                '@servicecatalog/servicecatalog_header.html.twig',
                [
                    'menu' => $menu,
                    'menutop' => $menutop,
                    'usesearch' => $usesearch ?? 0,
                    'type' => $type ?? ' ',
                    'width' => $width ?? '100%',
                    'sc_pref_url' => PLUGIN_SERVICECATALOG_WEBDIR . '/front/preference.php',
                ] + self::getPageHeaderTplVars()
            );
        } elseif ($class == "PluginServicecatalogKnowbase") {
            TemplateRenderer::getInstance()->display(
                '@servicecatalog/faq_header.html.twig',
                [
                    'menu' => $menu,
                    'menutop' => $menutop,
                    'type' => ' ',
                    'strictsearch' => $config->useStrictSearch(),
                    'sc_pref_url' => PLUGIN_SERVICECATALOG_WEBDIR . '/front/preference.php',
                ] + self::getPageHeaderTplVars()
            );
        }
        //used do hide links from helpdesk (language, help..)
        if ($config->getDropLanguagesButton() == 1
            || $config->getDropPreferencesButton() == 1
            || $config->getDropSavedsearchsButton() == 1
            || $config->getDropLogoutButton() == 1) {
            echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/servicecatalog_interfacebuttons.css.php");
        }

        // call static function callcron() every 5min
        CronTask::callCron();

        $config = new PluginServicecatalogConfig();

        if (!$ishelpdeskform) {
            echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/bootstrap/sc_bootstrap_new.scss");
        }

        if (isset($_SESSION["glpi_plugin_servicecatalog_color"]) && $config->getDemoMode() == 1) {
            if ($_SESSION["glpi_plugin_servicecatalog_color"] == PluginServicecatalogConfig::DEFAULT_COLOR) {
                echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/navbar/navbar-default.css");
            } elseif ($_SESSION["glpi_plugin_servicecatalog_color"] == PluginServicecatalogConfig::BLUE_COLOR) {
                echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/navbar/navbar-blue.css");
            } elseif ($_SESSION["glpi_plugin_servicecatalog_color"] == PluginServicecatalogConfig::MALLOW_COLOR) {
                echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/navbar/navbar-mallow.css");
            } elseif ($_SESSION["glpi_plugin_servicecatalog_color"] == PluginServicecatalogConfig::BLACK_COLOR) {
                echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/navbar/navbar-black.css");
            }
        } else {
            if ($config->getUseOwnColors() == 1) {
                echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/navbar/navbar-color.css.php");
            }
        }
        if ($config->getUseOwnColors() == 1) {
            echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/servicecatalog_interface.css.php");
        }
        //used for TopNav / contact / colorize buttons

        //used by new faq
        if (isset($_SERVER['REQUEST_URI'])
            && str_contains($_SERVER['REQUEST_URI'], "faq.php")) {
            echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/servicecatalog_faq.scss");
        }

        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.js");
    }


    /**
     * @param $widget
     *
     * @return array
     */
    public static function showNavBarIncidentMenu($widget)
    {
        $menu = [];
        $config = new PluginServicecatalogConfig();

        if (Session::haveRight('plugin_servicecatalog_incidents', READ)
            && Session::haveRight("ticket", CREATE)
            && $widget->fields['display_incident'] == 1) {
            if ($config->getBypassCategories() == 1) {
                $url_i = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/newticket.form.php?type=" . Ticket::INCIDENT_TYPE;
            } else {
                $url_i = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/choosecategory.form.php?type=" . Ticket::INCIDENT_TYPE . "&level=1";
            }

            $menu['title'] = PluginServicecatalogConfig::displayField($widget, 'title_incident');
            $menu['page'] = $url_i;
            //         $form['ajaxpage']    = $url_i;
            //         $form['id']      = "ajax_link";
            //         $form['type_id'] = Ticket::INCIDENT_TYPE;
            if (!empty($widget->fields['fa_incident'])) {
                $icon = $widget->fields['fa_incident'];
                $menu['icon'] = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "incident_bar";
        }
        return $menu;
    }

    /**
     * @param $widget
     *
     * @return array
     */
    public static function showNavBarRequestMenu($widget)
    {
        $menu = [];
        $config = new PluginServicecatalogConfig();

        if (Session::haveRight('plugin_servicecatalog_requests', READ)
            && Session::haveRight("ticket", CREATE)
            && $widget->fields['display_request'] == 1) {
            if ($config->getBypassCategories() == 1) {
                $url_r = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/newticket.form.php?type=" . Ticket::DEMAND_TYPE;
            } else {
                $url_r = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/choosecategory.form.php?type=" . Ticket::DEMAND_TYPE . "&level=1";
            }
            $menu['title'] = PluginServicecatalogConfig::displayField($widget, 'title_request');
            $menu['page'] = $url_r;
            //         $form['ajaxpage']    = $url_r;
            //         $form['id']      = "ajax_link";
            //         $form['type_id'] = Ticket::DEMAND_TYPE;
            if (!empty($widget->fields['fa_request'])) {
                $icon = $widget->fields['fa_request'];
                $menu['icon'] = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "request_bar";
        }
        return $menu;
    }

    /**
     * @param $widget
     *
     * @return array
     * @throws \GlpitestSQLError
     * @throws \GlpitestSQLError
     */
    public static function showNavBarMenu($widget)
    {
        $form = [];
        $config = new PluginServicecatalogConfig();

        if (Session::haveRight("ticket", CREATE)
            || Session::haveRight("ticket", Ticket::READMY)
            || Session::haveRight("followup", ITILFollowup::SEEPUBLIC)
        ) {
            $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";
            $left = "LEFT JOIN glpi_entities
                  ON (`glpi_tickets`.`entities_id` = `glpi_entities`.`id`) ";
            $left .= "LEFT JOIN `glpi_tickets_users`
                  ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`) ";
            $search_assign = "1=1";
            $search_assign .= " AND (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                                AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "')";
            $search_assign .= " OR (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::OBSERVER . "')";
            $search_assign .= " OR `glpi_tickets`.`users_id_recipient` = '" . Session::getLoginUserID() . "' ";

            if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP) && count($_SESSION['glpigroups'])) {

                $left .= "LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`) ";

                $groups = implode("','", $_SESSION['glpigroups']);

                if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                    $search_assign .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::REQUESTER . "') ";

                    if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                        $search_assign .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::OBSERVER . "') ";
                    }
                }
            }

            $total_incpro = PluginServicecatalogIndicator::queryIncidentTickets($left, $is_deleted, $search_assign);
            $total_dempro = PluginServicecatalogIndicator::queryRequestTickets($left, $is_deleted, $search_assign);
            $total_validate = PluginServicecatalogIndicator::queryValidateTickets($left, $is_deleted, $search_assign);


            if ($widget->fields['display_tickets_list'] == 1) {
                if (Session::haveRight("ticket", CREATE)
                    || Session::haveRight("ticket", Ticket::READMY)
                    || Session::haveRight("followup", ITILFollowup::SEEPUBLIC)
                ) {
                    $url = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/ticket.php";
                    $config = new PluginServicecatalogConfig();
                    $title = PluginServicecatalogConfig::displayField($config, 'title_your_open_tickets');
                    $form['open_ticket']['title'] = $title;
                    $form['open_ticket']['badge'] = ($total_incpro + $total_dempro);
                    $form['open_ticket']['page'] = $url;
                    if (!empty($widget->fields['fa_tickets_list'])) {
                        $icon = $widget->fields['fa_tickets_list'];
                        $form['open_ticket']['icon'] = "fas $icon fa-fw mr-3";
                        $form['open_ticket']['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                    }
                    $form['open_ticket']['id'] = "ticketlist_bar";
                }
            }

            if ($widget->fields['display_incidents_list'] == 1) {
                $url = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/ticket.php?type=" . Ticket::INCIDENT_TYPE;
                $title = PluginServicecatalogConfig::displayField($widget, 'title_incidents_list');
                $form['incidents_list']['title'] = $title;
                $form['incidents_list']['page'] = $url;
                $form['incidents_list']['badge'] = $total_incpro;
                if (!empty($widget->fields['fa_incidents_list'])) {
                    $icon = $widget->fields['fa_incidents_list'];
                    $form['incidents_list']['icon'] = "fas $icon fa-fw mr-3";
                    $form['incidents_list']['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                }
                $form['incidents_list']['id'] = "incidentlist_bar";
            }

            if ($widget->fields['display_requests_list'] == 1) {
                $url = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/ticket.php?type=" . Ticket::DEMAND_TYPE;
                $title = PluginServicecatalogConfig::displayField($widget, 'title_requests_list');
                $form['requests_list']['title'] = $title;
                $form['requests_list']['page'] = $url;
                $form['requests_list']['badge'] = $total_dempro;
                if (!empty($widget->fields['fa_requests_list'])) {
                    $icon = $widget->fields['fa_requests_list'];
                    $form['requests_list']['icon'] = "fas $icon fa-fw mr-3";
                    $form['requests_list']['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                }
                $form['requests_list']['id'] = "requestlist_bar";
            }

            if (Plugin::isPluginActive("metademands")
                && class_exists("PluginMetademandsStepform")
                && Session::haveRight("plugin_metademands", READ)) {
                $stepforms = PluginMetademandsStepform::getWaitingForms();
                $nb = count($stepforms);
                if ($nb > 0) {
                    $url = PLUGIN_METADEMANDS_DIR_NOFULL . "/front/stepform.php";
                    $title = _n('Your form to complete', 'Your forms to complete', 2, 'metademands');
                    $form['metademands_forms']['title'] = $title;
                    $form['metademands_forms']['page'] = $url;
                    $icon = PluginMetademandsMetademand::getIcon();
                    $form['metademands_forms']['badge'] = $nb;
                    $form['metademands_forms']['icon'] = "$icon fa-fw mr-3";
                    $form['metademands_forms']['style'] = "";
                    $form['metademands_forms']['id'] = "metademands_forms_bar";
                }
            }

            $form['validated_ticket'] = PluginServicecatalogTicket::showNavBarMenuTicketValidation($widget, $total_validate);

            $autoclose_value = Entity::getUsedConfig(
                'autoclose_delay',
                $_SESSION['glpiactive_entity'],
                '',
                Entity::CONFIG_NEVER
            );
            if ($autoclose_value) {
                $total_tickets_resolved = PluginServicecatalogIndicator::queryResolvedTickets($left, $is_deleted, $search_assign);
                $url = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/resolved_ticket.php";
                $title = PluginServicecatalogConfig::displayField($config, 'title_your_resolved_tickets');
                $form['resolved_ticket']['title'] = $title;
                $form['resolved_ticket']['page'] = $url;
                $form['resolved_ticket']['badge'] = $total_tickets_resolved;
                $form['resolved_ticket']['icon'] = "fas fa-tasks fa-fw mr-3";
                $form['resolved_ticket']['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                $form['resolved_ticket']['id'] = "ticketresolvedlist_bar";
            }

            $config = new PluginServicecatalogConfig();
            if ($config->see_closedtickets_menu()) {
                //                        $total_tickets_closed   = PluginServicecatalogIndicator::queryClosedTickets($left, $is_deleted, $search_assign);
                $url = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/closed_ticket.php";
                $config = new PluginServicecatalogConfig();
                $title = PluginServicecatalogConfig::displayField($config, 'title_closedtickets_menu');
                $form['closed_ticket']['title'] = $title;
                $form['closed_ticket']['page'] = $url;
                if (!empty($config->fields['fa_closedtickets_menu'])) {
                    $icon = $config->fields['fa_closedtickets_menu'];
                    $form['closed_ticket']['icon'] = "fas $icon fa-fw mr-3";
                    $form['closed_ticket']['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                }
                $form['closed_ticket']['id'] = "ticketclosedlist_bar";
            }
        }
        return $form;
    }

    /**
     * Returns template variables that can be used for page header in any context.
     *
     * @return array
     */
    private static function getPageHeaderTplVars()
    {
        global $CFG_GLPI;

        $founded_new_version = null;
        if (!empty($CFG_GLPI['founded_new_version'] ?? null)) {
            $current_version = preg_replace('/^((\d+\.?)+).*$/', '$1', GLPI_VERSION);
            $founded_new_version = version_compare($current_version, $CFG_GLPI['founded_new_version'], '<')
                ? $CFG_GLPI['founded_new_version']
                : null;
        }

        $user = Session::getLoginUserID() !== false ? User::getById(Session::getLoginUserID()) : null;

        return [
            'is_debug_active' => $_SESSION['glpi_use_mode'] == Session::DEBUG_MODE,
            'is_impersonate_active' => Session::isImpersonateActive(),
            'founded_new_version' => $founded_new_version,
            'user' => $user instanceof User ? $user : null,
        ];
    }


    /**
     * @param string $plug
     *
     * @return void
     */
    public static function showNavBarFooter(string $plug = '')
    {
        if (!empty($plug)) {
            $id = $plug . '_bar';
            echo "<script id='rendered-menu'>
               $('#$id').addClass('active');
               </script>";
        }
    }


    /**
     * Displaying the category interface title
     *
     * @param $config
     * @param $type
     * @param $category_id
     * @param $manage_favorites
     */
    public static function showTitleCategory($config, $type, $category_id, $manage_favorites)
    {
        $dbu = new DbUtils();

        switch ($type) {
            case Ticket::INCIDENT_TYPE:
            case Ticket::DEMAND_TYPE:

                if ($manage_favorites == 1) {
                    $class = "";
                    if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                        || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                        $class = "alert-bootstrapped";
                    }
                    echo "<h5>";
                    echo "<div class='alert alert-secondary $class' role='alert'>";
                    echo PluginServicecatalogConfig::displayField($config, 'title_favorites_category');
                    echo "</div>";
                    echo "</h5>";
                } else {
                    $allsons = $dbu->getSonsOf("glpi_itilcategories", $category_id);
                    unset($allsons[$category_id]);
                    //               if ($category_id > 0 && count($allsons) > 0) {
                    //                  echo __('Available services', 'servicecatalog');
                    //               } else
                    $title_incident = PluginServicecatalogConfig::displayField($config, 'select_title_incident_category');
                    $title_request = PluginServicecatalogConfig::displayField($config, 'select_title_request_category');

                    if (Ticket::INCIDENT_TYPE == $type && !empty($title_incident)) {
                        echo PluginServicecatalogWidget::getNavigationTitle($title_incident);
                    } elseif (Ticket::DEMAND_TYPE == $type && !empty($title_request)) {
                        echo PluginServicecatalogWidget::getNavigationTitle($title_request);
                    }
                }
                //            echo "</span>";


                break;
            default:
                //            echo "<h3 class=\"bt-title-divider\">
                //                     <span>";
                //            echo PluginServicecatalogPlugin::showLinkList($type);
                //            echo "</span>
                //               </h3>";
                break;
        }
    }



    /**
     * Interface for display favorites categories
     *
     * @param $options
     * @param $datas
     *
     * @throws \GlpitestSQLError
     */
    public static function showHomepageFavoritesCategories($config, $options, $datas)
    {
        global $DB;

        $title = PluginServicecatalogConfig::displayField($config, 'title_favorites_category');
        $widget = new PluginServicecatalogWidget();

        switch ($options['type']) {
            case Ticket::INCIDENT_TYPE:
                $crit = "AND `glpi_itilcategories`.`is_incident` = 1
                     AND `glpi_itilcategories`.`is_helpdeskvisible` = 1
                     AND `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id` = 0 ";
                break;
            case Ticket::DEMAND_TYPE:
                $crit = "AND `glpi_itilcategories`.`is_request` = 1
                     AND `glpi_itilcategories`.`is_helpdeskvisible` = 1
                     AND `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id` = 0 ";
                break;
            default:
                $title = "";
                $crit = "";
                break;
        }

        $query = "SELECT `glpi_itilcategories`.`completename`,
                        `glpi_itilcategories`.`name`,
                        `glpi_itilcategories`.`id`,
                        `glpi_itilcategories`.`level`
                   FROM `glpi_plugin_servicecatalog_favorites`
                   LEFT JOIN `glpi_itilcategories`
                        ON (`glpi_itilcategories`.`id` = `glpi_plugin_servicecatalog_favorites`.`itilcategories_id`)"
            . PluginServicecatalogFavorite::addVisibilityJoins();
        $query .= "WHERE " . PluginServicecatalogFavorite::addVisibilityRestrict() . " $crit ";

        $result = $DB->query($query);
        $nb = $DB->numrows($result);
        if ($nb > 0) {
            $style = "margin-bottom: 10px;";
            $styleh3 = "style='font-size: 12px;'";
            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                //                            $style   = 'border: #E6E6E6 1px solid;padding-bottom: 15px;padding-left: 8px;padding-top: 4px;';
                $styleh3 = 'style="border: 1px solid transparent;border-radius: 1px;margin: 0px;"';
            }

            echo "<div class='widgetfav'>";

//            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
//                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
//                echo "<div class=\"alert alert-light child-nav\" $styleh3>";
//            } else {
//                echo "<div class=\"alert alert-light child-nav card\" $styleh3>";
//            }
//
//            echo $title;
//            echo "</div>";
            // echo  $title . '<br><br>';

            if ($options['type'] == Ticket::INCIDENT_TYPE) {
                echo "<div class='alert alert-secondary' style='margin-right: 5px;margin-bottom: 5px;padding: 15px;font-size: 12px;border-radius: 0;--tblr-alert-color:gray;'  title='" . __('Incidents', 'servicecatalog') . "'>";
                $addstyle = "style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';color:gray;\"";
                echo "<i $addstyle class='fas " . $widget->fields['fa_incident'] . " fa-1x'></i>";
                echo "</div>";
            }
            if ($options['type'] == Ticket::DEMAND_TYPE) {
                echo "<div class='alert alert-secondary' style='margin-right: 5px;margin-bottom: 5px;padding: 15px;font-size: 12px;border-radius: 0;--tblr-alert-color:gray;' title='" . __('Requests', 'servicecatalog') . "'>";
                $addstyle = "style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';color:gray;\"";
                echo "<i $addstyle class='fas " . $widget->fields['fa_request'] . " fa-1x'></i>";
                echo "</div>";
            }

            while ($row = $DB->fetchArray($result)) {
                $opt['type'] = $options['type'];
                $opt['level'] = $row['level'];
                $opt['display_favorite'] = 0;
                $opt['category_id'] = $row['id'];

                $data['id'] = $row['id'];
                $cat = new PluginServicecatalogCategory();
                $datac = $cat->findCategory($row['id'], $datas);
                $completename = "";
                $name = "";
                if ($datac != false) {
                    if (empty($completename = DropdownTranslation::getTranslatedValue(
                        $row['id'],
                        ITILCategory::class,
                        'completename',
                        $_SESSION['glpilanguage']
                    ))) {
                        $completename = $row['completename'];
                    }
                    if (empty($name = DropdownTranslation::getTranslatedValue(
                        $row['id'],
                        ITILCategory::class,
                        'name',
                        $_SESSION['glpilanguage']
                    ))) {
                        $name = $row['name'];
                    }
                }

                $data['name'] = $name;
                $data['completename'] = $completename;
                $cat2 = new PluginServicecatalogCategory();
                if ($cat2->getFromDBByCategory($row['id'])) {
                    $data['use_website_url'] = $cat2->fields['use_website_url'] ?? 0;
                    $data['website_url'] = $cat2->fields['website_url'] ?? '';
                    if ($data['use_website_url'] == 1) {
                        $data['website_target'] = $cat2->fields['website_target'] ?? 1;
                    }
                }
                $data['have_sons'] = 0;

                $opt['category'] = $data;
                $opt['display_favorite'] = 1;
                $have_sons = $data['have_sons'] ?? 0;
                if ($have_sons == 0) {
                    $opt['choose_category'] = 0;
                    $display = true;

                    $config = new PluginServicecatalogConfig();
                    if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                        PluginServicecatalogSly::returnCategoryDetail($opt, $display);
                    } elseif ($config->getLayout() == PluginServicecatalogConfig::WRAPPER) {
                        PluginServicecatalogWrapper::returnCategoryDetail($opt, $display);
                    } else if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
                        PluginServicecatalogWrappersly::returnCategoryDetail($opt, $display);
                    } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL) {
                        PluginServicecatalogThumbnail::returnCategoryDetail($opt, $display);
                    } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                        PluginServicecatalogThumbnailwrapper::returnCategoryDetail($opt, $display);
                    } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED) {
                        PluginServicecatalogBootstrapped::returnCategoryDetail($opt, $display);
                    } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                        PluginServicecatalogBootstrappedcolor::returnCategoryDetail($opt, $display);
                    }  else if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
                        PluginServicecatalogShoper::returnCategoryDetail($opt, $display);
                    }

                }
            }
            echo "</div>";
        }
    }

    /**
     * Interface for display most used categories
     *
     * @param       $options
     * @param array $datas
     *
     * @throws \GlpitestSQLError
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public static function showMostUsedCategories($options, $datas = [])
    {
        global $DB;

        if (is_array($datas) && count($datas) == 0) {
            $datas = PluginServicecatalogCategory::getCategoriesCache($options['type']);
        }

        switch ($options['type']) {
            case Ticket::INCIDENT_TYPE:
                $title = __('Your top Incidents', "servicecatalog");
                $crit = "AND `glpi_tickets`.`type` = '" . $options['type'] . "' 
                     AND `glpi_itilcategories`.`is_incident` = 1 
                     AND `glpi_itilcategories`.`is_helpdeskvisible` = 1 ";
                break;
            case Ticket::DEMAND_TYPE:
                $title = __('Your top Requests', "servicecatalog");
                $crit = "AND `glpi_tickets`.`type` = '" . $options['type'] . "' 
                     AND `glpi_itilcategories`.`is_request` = 1 
                     AND `glpi_itilcategories`.`is_helpdeskvisible` = 1 ";
                break;
            default:
                $title = "";
                $crit = "";
                break;
        }


        $dbu = new DbUtils();

        $query = "SELECT `glpi_itilcategories`.`completename`, 
                        `glpi_itilcategories`.`id`,
                        `glpi_itilcategories`.`level`,
                        `glpi_itilcategories`.`comment`,
                        COUNT(`glpi_tickets`.`id`) as count
                     FROM `glpi_tickets`
                     LEFT JOIN `glpi_itilcategories`
                        ON (`glpi_itilcategories`.`id` = `glpi_tickets`.`itilcategories_id`)
                     LEFT JOIN `glpi_tickets_users`
                        ON (`glpi_tickets_users`.`tickets_id` = `glpi_tickets`.`id` AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "')
                     WHERE `glpi_tickets`.`is_deleted` = 0 $crit 
                          AND `glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                     AND `glpi_itilcategories`.`id` IS NOT NULL ";
        $query .= $dbu->getEntitiesRestrictRequest("AND", Ticket::getTable(), '', $_SESSION["glpiactive_entity"]);
        $query .= "GROUP BY `glpi_itilcategories`.`id`
                     ORDER BY count DESC
                     LIMIT 5";

        $result = $DB->query($query);
        $nb = $DB->numrows($result);
        $config = new PluginServicecatalogConfig();

        if ($nb > 0) {

            $style = "";
            $styleh3 = "";
            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                $style = 'border: #E6E6E6 1px solid;padding-bottom: 15px;padding-left: 8px;padding-top: 4px;';
                $styleh3 = 'style="border-radius: 1px;margin: 0px;"';
            }
            if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL
                || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                $styleh3 = 'style="border-radius: 1px;"';
            }
            $class = "";
            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                $class = "alert-bootstrapped";
            }
            echo "<h3 class=\"alert alert-secondary $class\" $styleh3>
                     <span>";
            echo $title;
            echo "</span>
               </h3>";

            echo "<div style='display: flow-root;$style'>";

            // echo  $title . '<br><br>';
            while ($row = $DB->fetchArray($result)) {
                $opt['type'] = $options['type'];
                $opt['level'] = $row['level'];
                $opt['display_favorite'] = 0;
                $opt['category_id'] = $row['id'];

                //            $data['id'] = $row['id'];
                $cat = new PluginServicecatalogCategory();

                $data = $cat->findCategory($row['id'], $datas);
                if (is_array($data)) {
                    if (empty($completename = DropdownTranslation::getTranslatedValue(
                        $row['id'],
                        ITILCategory::class,
                        'completename',
                        $_SESSION['glpilanguage']
                    ))) {
                        $completename = $row['completename'];
                    }

                    $opt['name'] = $completename;
                    $opt['category'] = is_array($data) ? $data : [];
                    $opt['mostused'] = 1;
                    $have_sons = $data['have_sons'] ?? 0;
                    if ($have_sons == 0) {
                        $opt['choose_category'] = 0;
                        $display = true;

                        $config = new PluginServicecatalogConfig();
                        if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                            PluginServicecatalogSly::returnCategoryDetail($opt, $display);
                        } elseif ($config->getLayout() == PluginServicecatalogConfig::WRAPPER) {
                            PluginServicecatalogWrapper::returnCategoryDetail($opt, $display);
                        } else if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
                            PluginServicecatalogWrappersly::returnCategoryDetail($opt, $display);
                        } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL) {
                            PluginServicecatalogThumbnail::returnCategoryDetail($opt, $display);
                        } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                            PluginServicecatalogThumbnailwrapper::returnCategoryDetail($opt, $display);
                        } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED) {
                            PluginServicecatalogBootstrapped::returnCategoryDetail($opt, $display);
                        } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                            PluginServicecatalogBootstrappedcolor::returnCategoryDetail($opt, $display);
                        } else if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
                            PluginServicecatalogShoper::returnCategoryDetail($opt, $display);
                        }
                    }
                }
            }
            echo "</div>";
        } else {
//            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
//                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
//                echo "<div class='alert alert-info'>";
//                if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)) {
//                    echo __('Please select on the left the category for create your ticket or use this search area to find the category or a solution', 'servicecatalog');
//                } else {
//                    echo __('Please select on the left the category for create your ticket or use this search area to find the category', 'servicecatalog');
//                }
//                echo "</div>";
//                echo "<div id='searchcat'>";
//                echo "</div>";
//                echo PluginServicecatalogCategory::fuzzySearchForm('sc-trigger-fuzzy', $options['type']);
//            }
        }
    }


    /**
     * @param      $helpdesk_category
     * @param      $type
     * @param bool $display
     *
     * @return string
     */
    public static function getServiceDetailsText($helpdesk_category, $type, $display = true)
    {
        $class = "class='tooltip-details' style='margin-left: 10px;margin-right: 10px;'";
        $text = "";
        if (!empty($helpdesk_category->fields['display_warning']) && $display) {
            $text .= "<h5>";
            $text .= "<div class='alert alert-danger' role='alert'>";
            $text .= "<i class='fas fa-exclamation-circle fa-2x'></i>";
            $text .= "&nbsp;" . nl2br(PluginServicecatalogCategory::displayField($helpdesk_category, 'display_warning'));
            $text .= "</div>";
            $text .= "</h5>";
        }

        if (!empty($helpdesk_category->fields['knowbaseitems_id']) && $display == true) {
            $know_id = $helpdesk_category->fields['knowbaseitems_id'];
            $text .= "<h5>";
            $text .= "<div class='alert alert-warning' role='alert'>";
            $text .= "<i class='fas fa-exclamation-triangle fa-2x'></i>";
            $text .= "&nbsp;";
            $text .= __('Did you know that there is an FAQ article that may be able to help you?', 'servicecatalog');
            $text .= "&nbsp;";
            $text .= "<a target='_blank' href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php?from_ticket=1&itilcategories_id=" . $helpdesk_category->fields['itilcategories_id'] . "&type=" . $type . "&id=" . $know_id . "'>";
            $text .= "<button form='' class='submit btn btn-info btn-sm'>
<i class='fas fa-link' data-hasqtip='0' aria-hidden='true'></i>&nbsp;";
            $text .= __('Click here for more informations', 'servicecatalog');
            $text .= "</button>";
            $text .= "</a>";
            $text .= "</div>";
            $text .= "</h5>";
        }
        $config = new PluginServicecatalogConfig();
        if ($config->getEnableKeywords()) {
            $keyword = new PluginServicecatalogItilcategory_Keyword();
            $keywords = $keyword->getKeywords($helpdesk_category->getID());
            $count = count($keywords);
            if ($count > 0) {
                $text .= "<h5>";
                $text .= "<div $class>";
                $class2 = "";
                if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    $class2 = "alert-bootstrapped";
                }
                $text .= "<div class='alert alert-secondary $class2'><b>" . __('Keywords', 'servicecatalog') . "</b></div>";
                $rand = mt_rand();
                $viewId = "tag$rand";
                $style = 'style="display: block;"';
                if ($count > 20) {
                    $text .= "<a href=\"javascript:showHideDiv('$viewId','more$rand','fas fa-search-plus','fas fa-search-minus')\">";
                    $text .= "<i id='more$rand' style='color:black' class='fas fa-search-plus'></i>";
                    $text .= "</a>";
                    $style = 'style="display: none;"';
                }
                $text .= "<div id='" . $viewId . "' $style >";
                $url = PLUGIN_SERVICECATALOG_WEBDIR . "/pics/tag.png";
                foreach ($keywords as $data) {
                    $text .= "<div class='sc-tag' style='background: url($url) no-repeat;'>";
                    $text .= $data['name'];
                    $text .= "</div>";
                    $text .= "&nbsp;";
                }
                $text .= "</div></h5>";
            }
        }
        $comment = "";
        $cat = New ITILCategory();
        if ($cat->getFromDB($helpdesk_category->fields['itilcategories_id'])) {
            $comment = $cat->fields['comment'];
        }

        if ($comment != null || $helpdesk_category->fields['comment'] != null ||
            $helpdesk_category->fields['service_detail'] != null ||
            $helpdesk_category->fields['service_users'] ||
            $helpdesk_category->fields['service_ttr'] ||
            $helpdesk_category->fields['service_use'] ||
            $helpdesk_category->fields['service_supervision'] ||
            $helpdesk_category->fields['service_rules']) {
            //         if (!$display) {
            //            $class = "";
            //         }
            $title = __('Incident details', 'servicecatalog');
            if (Ticket::DEMAND_TYPE == $type) {
                $title = __('Request details', 'servicecatalog');
            }
            $class2 = "";
            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                $class2 = "alert-bootstrapped";
            }
            $text .= "<div $class><div class='alert alert-secondary $class2'><b>" . $title . "</b></div>";
            $text .= (!empty($comment)) ?
                "<div style='margin-bottom: 5px'>" . Glpi\RichText\RichText::getSafeHtml($comment) . "</div>" : "";
            $text .= (!empty($helpdesk_category->fields['comment'])) ?
                "<div style='margin-bottom: 5px'>" . Glpi\RichText\RichText::getSafeHtml($helpdesk_category->fields['comment']) . "</div>" : "";
            $text .= (!empty($helpdesk_category->fields['service_detail'])) ?
                "<div style='margin-bottom: 5px'><b>" . __('How can i use it', 'servicecatalog') . "</b><br><br>" . Glpi\RichText\RichText::getSafeHtml($helpdesk_category->fields['service_detail']) . "</div>" : "";
            $text .= (!empty($helpdesk_category->fields['service_users'])) ?
                "<div style='margin-bottom: 5px'><b>" . __('Who can benefit from this service?', 'servicecatalog') . "</b><br><br>" . Glpi\RichText\RichText::getSafeHtml($helpdesk_category->fields['service_users']) . "</div>" : "";
            $text .= (!empty($helpdesk_category->fields['service_ttr'])) ?
                "<div style='margin-bottom: 5px'><b>" . __('Lead time', 'servicecatalog') . "</b><br><br>" . Glpi\RichText\RichText::getSafeHtml($helpdesk_category->fields['service_ttr']) . "</div>" : "";
            $text .= (!empty($helpdesk_category->fields['service_use'])) ?
                "<div style='margin-bottom: 5px'><b>" . __('How to obtain the software in case of request?', 'servicecatalog') . "</b><br><br>" . Glpi\RichText\RichText::getSafeHtml($helpdesk_category->fields['service_use']) . "</div>" : "";
            $text .= (!empty($helpdesk_category->fields['service_supervision'])) ?
                "<div style='margin-bottom: 5px'><b>" . __('Availability of service', 'servicecatalog') . "</b><br><br>" . Glpi\RichText\RichText::getSafeHtml($helpdesk_category->fields['service_supervision']) . "</div>" : "";
            $text .= (!empty($helpdesk_category->fields['service_rules'])) ?
                "<div style='margin-bottom: 5px'><b>" . __('What are the rules to follow ?', 'servicecatalog') . "</b><br><br>" . Glpi\RichText\RichText::getSafeHtml($helpdesk_category->fields['service_rules']) . "</div>" : "";
            $text .= "</div>";

            if ($display) {
                if ($comment != null || $helpdesk_category->fields['comment'] != null ||
                    $helpdesk_category->fields['service_detail'] != null ||
                    $helpdesk_category->fields['service_users'] ||
                    $helpdesk_category->fields['service_ttr'] ||
                    $helpdesk_category->fields['service_use'] ||
                    $helpdesk_category->fields['service_supervision'] ||
                    $helpdesk_category->fields['service_rules']) {
                    echo $text;
                }
            }
        } else {
            if ($display) {
                if (!empty($helpdesk_category->fields['display_warning'])) {
                    $text = "<h5>";
                    $text .= "<div class='alert alert-danger' role='alert'>";
                    $text .= "<i class='fas fa-exclamation-circle fa-2x'></i>";
                    $text .= "&nbsp;" . nl2br(PluginServicecatalogCategory::displayField($helpdesk_category, 'display_warning'));
                    $text .= "</div>";
                    $text .= "</h5>";
                }
                $class2 = "";
                if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    $class2 = "alert-bootstrapped";
                }
                $text .= "<div class='alert alert-secondary $class2'><b>" . __('Service details', 'servicecatalog') . "</b></div>";
                $text .= __('There is no more informations for this category', 'servicecatalog');
                echo $text;
            }
        }
        $link = "";
        //         $config = new PluginServicecatalogConfig();
        //         TODO add link from category
        //            $link = PLUGIN_SERVICECATALOG_WEBDIR . "/front/category.form.php?category=" . $helpdesk_category->fields['itilcategories_id'] . "&type=" . $type;
        $classlink = "fa-info fa-1x fa-gray";
        if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
            $classlink = "fa-info fa-1x alert-bootstrapped";
        }

        $opt = ['awesome-class' => $classlink,
            'link' => $link,
            'linktarget' => "_blank"];
        if (!$display && !empty($text)) {
            $opt["display"] = false;
            return Html::showToolTip($text, $opt);
        }
    }


    /**
     * @param $keyFav
     * @param $data
     *
     * @return array
     */
    public static function groupByDefaults($keyFav, $data)
    {
        $result = [];

        foreach ($data as $key => $row) {
            if ($row['favorite_users_id'] == 0) {
                if (array_key_exists($keyFav, $row)) {
                    $result[$row[$keyFav]][] = $row;
                } else {
                    $result[""][] = $row;
                }
            }
        }

        return $result;
    }

    /**
     * @param $keyFav
     * @param $data
     * @param $type
     *
     * @return array
     */
    public static function groupByUsers($keyFav, $data, $type)
    {
        $result = [];
        $newResult = [];

        foreach ($data as $key => $row) {
            if ($row['favorite_users_id'] != 0) {
                if (array_key_exists($keyFav, $row)) {
                    $result[$row[$keyFav]][] = $row;
                } else {
                    $result[""][] = $row;
                }
            }
        }
        if ($type == Ticket::INCIDENT_TYPE) {
            foreach ($result as $key => $row) {
                usort($row, function ($a, $b) {
                    return $a['ranking_incidents'] - $b['ranking_incidents'];
                });
                $newResult[$key] = $row;
            }
        } else {
            foreach ($result as $key => $row) {
                usort($row, function ($a, $b) {
                    return $a['ranking_requests'] - $b['ranking_requests'];
                });
                $newResult[$key] = $row;
            }
        }

        return $newResult;
    }

    /**
     * @param $favUsers
     * @param $favDefaults
     *
     * @return array
     */
    public static function groupTotal($favUsers, $favDefaults)
    {
        foreach ($favUsers as $favorite_itilcategories_id => $favs) {
            if (count($favDefaults) > 0) {
                if (array_key_exists($favorite_itilcategories_id, $favDefaults)) {
                    foreach ($favs as $fav) {
                        $favDefaults[$favorite_itilcategories_id][] = $fav;
                    }
                } else {
                    $favDefaults[$favorite_itilcategories_id] = $favs;
                }
            }
        }
        return $favDefaults;
    }


    /**
     * @param $categories
     * @param $level
     * @param $category_id
     * @param $path
     *
     * @return bool
     */
    public static function DFS($categories, $level, $category_id, &$path)
    {
        //      $i    = 1;
        $cats = $categories;

        foreach ($cats as $k => $v) {
            if ($v['id'] == $category_id) {
                return true;
            }
            if (isset($v["subcategories"])) {
                $return = self::DFS($v["subcategories"], $level + 1, $category_id, $path);
                if ($return) {
                    array_unshift($path, $v['id']);
                    return true;
                }
            }
        }
        return false;
    }

    public static function checkBrowser()
    {
        if (preg_match('/(?i)msie [1-9]/', $_SERVER['HTTP_USER_AGENT']) ||
            preg_match('/(?i)Trident\/[0-9]/', $_SERVER['HTTP_USER_AGENT'])) {
            echo "<h5><div class='alert alert-warning' role='alert'>";
            echo __("Please use another browser (not Internet Explorer)", "servicecatalog");
            echo "</div></h5>";
            return false;
        }
        return true;
    }

    public static function isMobile() {
        return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
    }
}
