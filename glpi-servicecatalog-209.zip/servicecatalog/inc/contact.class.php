<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogContact
 */
class PluginServicecatalogContact extends CommonDBTM
{
    public static $rightname         = "plugin_servicecatalog_contacts";
    public $can_be_translated = true;

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        return _n('Contact', 'Contacts', $nb, 'servicecatalog');
    }

    /**
     * get menu content
     *
     * @return array array for menu
     **@since version 0.85
     *
     */
    public static function getMenuContent()
    {
        $menu = [];

        $menu['title']           = PluginServicecatalogContact::getMenuName();
        $menu['page']            = PluginServicecatalogContact::getSearchURL(false);
        $menu['links']['search'] = PluginServicecatalogContact::getSearchURL(false);
        if (self::canCreate()) {
            $menu['links']['add'] = PluginServicecatalogContact::getFormURL(false);
        }
        return $menu;
    }

    /**
     * Get Tab Name used for itemtype
     *
     * NB : Only called for existing object
     *      Must check right on what will be displayed + template
     *
     * @param CommonGLPI $item Item on which the tab need to be displayed
     * @param int        $withtemplate is a template object ? (default 0)
     *
     * @return string tab name
     * @since version 0.83
     *
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if (!$withtemplate) {
            if ($item->getType() == 'Entity' && $this->canUpdate()) {
                if ($_SESSION['glpishow_count_on_tabs']) {
                    $dbu = new DbUtils();
                    return self::createTabEntry(
                        PluginServicecatalogMain::getTypeName(),
                        $dbu->countElementsInTable(
                            "glpi_plugin_servicecatalog_contacts",
                            ["entities_id" => $item->getField('id')]
                        )
                    );
                }
                return self::getTypeName();
            }
        }
        return '';
    }

    /**
     * show Tab content
     *
     * @param CommonGLPI $item Item on which the tab need to be displayed
     * @param integer    $tabnum tab number (default 1)
     * @param int        $withtemplate is a template object ? (default 0)
     *
     * @return boolean
     * @since version 0.83
     *
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case 'Entity':
                $self = new self();
                $self->showContactMenu();
                break;
        }

        return true;
    }

    public static function showContactMenu()
    {
        global $CFG_GLPI;

        echo "<br><div align='center'>";
        echo "<table class='tab_cadre_fixehov'>";
        echo "<tr class='tab_bg_2'>";
        echo "<th class='center' colspan='2'>";
        echo __('Contact setup', 'servicecatalog');
        echo "</th>";
        echo "</tr>";
        echo "<tr class='tab_bg_2'>";
        echo "<td class='center'>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/contact.php'>";
        echo __('Contacts list', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<td class='center'>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/contact.form.php'>";
        echo __('Add contact', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<tr>";
        echo "</table></div>";
    }

    /**
     * @param           $ID
     * @param array     $options
     *
     * @return void
     */
    public function showForm($ID, $options = [])
    {
        $options['colspan'] = '1';
        $this->initForm($ID, $options);
        $this->showFormHeader($options);

        echo "<tr class='tab_bg_1'><td>";
        echo __('Entity');
        echo "</td>";
        echo "<td>";
        if ($ID > 0) {
            $entity = new Entity();
            $entity->getFromDB($this->fields["entities_id"]);
            echo $entity->getLink(['complete' => true]);
        } else {
            Dropdown::show('Entity', ['name' => "entities_id"]);
        }
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Location');
        echo "</td>";
        echo "<td>";
        echo Html::input('name', ['value' => $this->fields['name'], 'size' => 40]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Opening hours', 'servicecatalog');
        echo "</td>";
        echo "<td>";
        Html::textarea(['name'            => 'opening_hours',
                        'value'           => $this->fields["opening_hours"],
                        'enable_richtext' => false,
                        'cols'            => '75',
                        'rows'            => '7']);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Phone') . "</td>";
        echo "<td>";
        echo Html::input('phonenumber', ['value' => $this->fields['phonenumber'], 'size' => 40]);
        echo "</td>";
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Address');
        echo "</td>";
        echo "<td>";
        Html::textarea(['name'            => 'address',
                        'value'           => $this->fields["address"],
                        'enable_richtext' => false,
                        'cols'            => '75',
                        'rows'            => '7']);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . _n('Email', 'Emails', 1) . "</td>";
        echo "<td>";
        echo Html::input('email', ['value' => $this->fields['email'], 'size' => 40]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Postal code') . "</td>";
        echo "<td>";
        echo Html::input('postcode', ['value' => $this->fields['postcode'], 'size' => 7]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('City') . "</td>";
        echo "<td>";
        echo Html::input('town', ['value' => $this->fields['town'], 'size' => 27]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . _x('location', 'State') . "</td>";
        echo "<td>";
        echo Html::input('state', ['value' => $this->fields['state'], 'size' => 40]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Country') . "</td>";
        echo "<td>";
        echo Html::input('country', ['value' => $this->fields['country'], 'size' => 40]);
        echo "</td></tr>";

        $this->showFormButtons($options);

        Html::closeForm();
    }


    /**
     * Get the Search options for the given Type
     *
     * This should be overloaded in Class
     *
     * @return array an *indexed* array of search options
     *
     * @see https://glpi-developer-documentation.rtfd.io/en/master/devapi/search.html
     **/
    public function rawSearchOptions()
    {
        $tab = [];

        $tab[] = [
            'id'   => 'common',
            'name' => __('Characteristics')
        ];

        $tab[] = [
            'id'            => '1',
            'table'         => $this->getTable(),
            'field'         => 'name',
            'name'          => __('Name'),
            'datatype'      => 'itemlink',
            'massiveaction' => false
        ];

        $tab[] = [
            'id'            => '2',
            'table'         => $this->getTable(),
            'field'         => 'id',
            'name'          => __('ID'),
            'massiveaction' => false,
            'datatype'      => 'number'
        ];

        $tab[] = [
            'id'       => '30',
            'table'    => $this->getTable(),
            'field'    => 'id',
            'name'     => __('ID'),
            'datatype' => 'number'
        ];

        $tab[] = [
            'id'       => '80',
            'table'    => 'glpi_entities',
            'field'    => 'completename',
            'name'     => __('Entity'),
            'datatype' => 'dropdown'
        ];

        return $tab;
    }


    /**
     * @param int $contacts_id
     *
     * @return array
     */
    public function getContacts($entities_id = 0)
    {
        $dbu     = new DbUtils();
        $contact = new self();

        $condition = [];
        if ($entities_id > 0) {
            $cond = ['entities_id' => $entities_id];
            $exist = $contact->find($cond, 'name');
            if (count($exist) > 0) {
                $condition = $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_contacts', '', $entities_id, false);
            } else {
                $condition = $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_contacts', '', '', true);
            }
        } else {
            $condition = $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_contacts', '', '', true);
        }
        $contacts = $contact->find($condition, 'name');

        return $contacts;
    }

    /**
     * @param     $id
     * @param     $class
     * @param int $contacts_id
     *
     * @return string
     */
    public static function displayContacts($id, $class, $entities_id = 0)
    {
        $self     = new self();

        $contacts = $self->getContacts($entities_id);

        $delclass = "";
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $delclass = "delclass";
        }

        $display = "<div id='$id' class=\"bt-row $delclass\">";
        $display .= "<div class=\"bt-feature $class\">";

        $title   = __('Contact us', 'servicecatalog');
        $display .= PluginServicecatalogWidget::getWidgetTitle($title);


//        if (count($contacts) > 1) {
//            $formId              = uniqid('form');
//            $display             .= "<form id='" . $formId . "' action='' onsubmit='return false;' >";
//            $params              = ['name'    => 'contacts_id',
//                                    'display' => false,
//                                    'value'   => isset($contacts_id) ? $contacts_id : 0,
//            ];
//            $params['on_change'] = "refreshWidgetByForm('$id', this.value);";
//            $display             .= __('Location');
//            $display             .= "&nbsp;";
//            $display             .= PluginServicecatalogContact::dropdown($params)
//                                    . "</form>";
//        }
        if (count($contacts) > 0) {
            foreach ($contacts as $contact) {
                $display .= "<div id=\"sc-line\" class=\"row\">";
                $display .= "<span class='btn btn-alert' style='margin-bottom: 10px;border: 0;'>";
                $display .= "<i class=\"fas fa-compass sc-contact\" style='font-size: 0.5em;'></i>";
                $display .= "<b>" . $contact['name'] . "</b>";
                $display .= "</span>";

                if (!empty($contact['opening_hours'])) {
                    $display  .= "<div class=\"col center\" style='font-size: 12px;margin-top: 10px;'>";
                    $display  .= "<i class=\"fas fa-clock sc-contact\"></i>";
                    $display  .= "<br><br>" . __('Opening hours', 'servicecatalog');
                    $horaires = $contact['opening_hours'];
                    $display  .= "<br>";
                    $display  .= nl2br($horaires);
                    $display  .= "<br>";
                    $display  .= "</div>";
                }
                if (!empty($contact['phonenumber'])) {
                    $display .= "<div class=\"col center\" style='font-size: 12px;margin-top: 10px;'>";
                    $display .= "<i class=\"fas fa-phone sc-contact\"></i>";
                    $display .= "<br><br><a href='tel:" . $contact['phonenumber'] . "'>" . $contact['phonenumber'];
                    $display .= "</a>";
                    $display .= "</div>";
                }
                if (!empty($contact['email'])) {
                    $display .= "<div class=\"col center\" style='font-size: 12px;margin-top: 10px;'>";
                    $display .= "<i class=\"fas fa-at sc-contact\"></i>";
                    $display .= "<br><br><a href='mailto:" . $contact['email'] . "'>";
                    $display .= $contact['email'];
                    $display .= "</a>";
                    $display .= "</div>";
                }
                if (!empty($contact['address'])) {
                    $display .= "<div class=\"col center\" style='font-size: 12px;margin-top: 10px;'>";
                    $display .= "<i class=\"fas fas fa-map-marker-alt sc-contact sc-contact\"></i>";
                    $display .= "<br><br>" . nl2br($contact['address']);
                    $display .= "<br>";
                    $display .= $contact['postcode'] . "&nbsp;" . $contact['town'];
                    $display .= "<br>";
                    $display .= $contact['state'] . "&nbsp;" . $contact['country'];
                    $display .= "</div>";
                }


                $display .= "</div>";
            }
        } else {
            $display .= __('No data available', 'servicecatalog');
            $display .= "</div>";
            $display .= "</div>";
        }

        return $display;
    }
}
