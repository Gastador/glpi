<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogLink
 */
class PluginServicecatalogLink extends CommonDBTM
{
    public static $rightname         = "plugin_servicecatalog_links";
    public $can_be_translated = true;

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        return _n('Useful link', 'Useful links', $nb, 'servicecatalog');
    }

    /**
     * get menu content
     *
     * @return array array for menu
     **@since version 0.85
     *
     */
    public static function getMenuContent()
    {
        $menu = [];

        $menu['title']           = self::getMenuName();
        $menu['page']            = self::getSearchURL(false);
        $menu['links']['search'] = self::getSearchURL(false);
        if (self::canCreate()) {
            $menu['links']['add'] = self::getFormURL(false);
        }
        $menu['icon'] = self::getIcon();

        return $menu;
    }

    /**
     * @return string
     */
    public static function getIcon()
    {
        return "ti ti-link";
    }

    /**
     * @param array $options
     *
     * @return array
     * @see CommonGLPI::defineTabs()
     */
    public function defineTabs($options = [])
    {
        $ong = [];
        $this->addDefaultFormTab($ong);
        $this->addStandardTab('PluginServicecatalogLinkTranslation', $ong, $options);
        return $ong;
    }

    /**
     * @param \CommonGLPI $item
     * @param int         $withtemplate
     *
     * @return string
     * @see CommonGLPI::getTabNameForItem()
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item->getType() == 'PluginServicecatalogConfig') {
            return self::getTypeName(2);
        }
        return '';
    }

    /**
     * @param \CommonGLPI $item
     * @param int         $tabnum
     * @param int         $withtemplate
     *
     * @return bool
     * @see CommonGLPI::displayTabContentForItem()
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if ($item->getType() == 'PluginServicecatalogConfig') {
            $self = new self();
            $self->showMenu();
        }
        return true;
    }

    /**
     * @since version 0.85
     *
     * @see CommonDBTM::getEmpty()
     **/
    public function getEmpty()
    {
        parent::getEmpty();
        //Keep the same behavior as in previous versions
        $this->fields['target'] = 1;
    }

    /**
     * @param       $ID
     * @param array $options
     */
    public function showForm($ID, $options = [])
    {
        $this->initForm($ID, $options);
        $this->showFormHeader($options);

        echo "<tr class='tab_bg_1'><td>" . __('Name') . "</td>";
        echo "<td colspan='3'>";
        echo Html::input('name', ['value' => $this->fields['name'], 'size' => 40]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Picture') . "</td>";
        echo "<td>";
        $rand = mt_rand();
        echo "<div style='width:190px; border-radius: 6px; border: 2px inset #969595;text-align:center;' id='picture$rand'>";
        echo "<img alt=\"" . __s('Picture') . "\" src='" .
             self::getThumbnailURLForPicture($this->fields['picture']) . "'>";
        echo "</div>";

        echo "</td><td>";
        echo "<input class='form-control'  type='file' name='picture' accept='image/*'>";
        echo "<input type='checkbox' name='_blank_picture'>&nbsp;" . __('Clear');
        echo "<p>" . sprintf(__('%1$s (%2$s)'), __('It is recommended to use a png file of size 140px x 80px', 'servicecatalog'), Document::getMaxUploadSize()) . "</p>";
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('URL') . "</td>";
        echo "<td colspan='3'>";
        echo Html::input('url', ['value' => $this->fields['url'], 'size' => 84]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Open in a new window') . "</td>";
        echo "<td colspan='3'>";
        Dropdown::showYesNo('target', $this->fields['target']);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Icon');
        echo "</td>";
        echo "<td colspan='2'>";
        $icon_selector_id = 'icon_' . mt_rand();
        echo Html::select(
            'icon',
            [$this->fields['icon'] => $this->fields['icon']],
            [
                'id'       => $icon_selector_id,
                'selected' => $this->fields['icon'],
                'style'    => 'width:175px;'
            ]
        );

        echo Html::script('js/Forms/FaIconSelector.js');
        echo Html::scriptBlock(
            <<<JAVASCRIPT
         $(
            function() {
               var icon_selector = new GLPI.Forms.FaIconSelector(document.getElementById('{$icon_selector_id}'));
               icon_selector.init();
            }
         );
JAVASCRIPT
        );
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Display on the navigation bar', 'servicecatalog') . "</td>";
        echo "<td colspan='3'>";
        Dropdown::showYesNo('display_at_home', $this->fields['display_at_home']);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Show on the actions widget', 'servicecatalog') . "</td>";
        echo "<td colspan='3'>";
        Dropdown::showYesNo('display_on_actions_widget', $this->fields['display_on_actions_widget']);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Comments') . "</td>";
        echo "<td colspan='3'>";
        Html::textarea(['name'            => 'comment',
                        'value'           => $this->fields["comment"],
                        'enable_richtext' => false,
                        'cols'            => '80',
                        'rows'            => '3']);
        echo "</td>";
        echo "</tr>";

        $this->showFormButtons($options);

        Html::closeForm();
    }

    /**
     * Get the Search options for the given Type
     *
     * This should be overloaded in Class
     *
     * @return array an *indexed* array of search options
     *
     * @see https://glpi-developer-documentation.rtfd.io/en/master/devapi/search.html
     **/
    public function rawSearchOptions()
    {
        $tab = [];

        $tab[] = [
            'id'   => 'common',
            'name' => __('Characteristics')
        ];

        $tab[] = [
            'id'            => '1',
            'table'         => $this->getTable(),
            'field'         => 'name',
            'name'          => __('Name'),
            'datatype'      => 'itemlink',
            'massiveaction' => false
        ];

        $tab[] = [
            'id'            => '2',
            'table'         => $this->getTable(),
            'field'         => 'id',
            'name'          => __('ID'),
            'massiveaction' => false,
            'datatype'      => 'number'
        ];

        $tab[] = [
            'id'       => '3',
            'table'    => $this->getTable(),
            'field'    => 'url',
            'name'     => __('URL'),
            'datatype' => 'string'
        ];

        $tab[] = [
            'id'       => '4',
            'table'    => $this->getTable(),
            'field'    => 'comment',
            'name'     => __('Comments'),
            'datatype' => 'text'
        ];

        $tab[] = [
            'id'       => '18',
            'table'    => $this->getTable(),
            'field'    => 'is_recursive',
            'name'     => __('Child entities'),
            'datatype' => 'bool'
        ];

        $tab[] = [
            'id'       => '30',
            'table'    => $this->getTable(),
            'field'    => 'id',
            'name'     => __('ID'),
            'datatype' => 'number'
        ];

        $tab[] = [
            'id'       => '80',
            'table'    => 'glpi_entities',
            'field'    => 'completename',
            'name'     => __('Entity'),
            'datatype' => 'dropdown'
        ];

        return $tab;
    }

    /**
     * Get picture URL from picture field
     *
     * @param $picture picture field
     *
     * @return string URL to show picture
     **@since version 0.85
     *
     */
    public static function getThumbnailURLForPicture($picture)
    {
        global $CFG_GLPI;

        if (!empty($picture)) {
            $tmp = explode(".", $picture);

            if (count($tmp) == 2) {
                return PLUGIN_SERVICECATALOG_WEBDIR . "/front/document.send.php?file=_plugins/" . $tmp[0] .
                       "." . $tmp[1];
            }
        }
        return PLUGIN_SERVICECATALOG_WEBDIR . "/pics/picture_links.png";
    }

    /**
     * @return void
     */
    public static function showMenu()
    {

        echo "<div class='display-4 center' style='margin: 15px;'>";
        echo "<h4>";
        $icon = self::getIcon();
        echo "<i class='ti $icon'></i>&nbsp;";
        echo self::getTypeName(2);
        echo "</h4>";
        echo "</div><hr style='margin: 1.2rem 0;'>";

        echo "<div align='center'>";
        echo "<table class='tab_cadre_fixe'>";
        echo "<tr class=''>";
        echo "<td class='center'>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/link.php'>";
        echo __('Useful links list', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<td class='center'>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/link.form.php'>";
        echo __('Add useful link', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<tr>";
        echo "</table></div>";
    }

    public static function getList($widget = false)
    {
        $display = "<script>$(document).ready(function() {
                       $('#click').click(function() {
                            window.location.href = '" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php';
                       });
                  });</script>";

        $dbu       = new DbUtils();
        $catlink   = new self();
        $config    = new PluginServicecatalogConfig();
        $condition = $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', '', true);
        $links     = $catlink->find($condition, 'name');

        if (count($links) > 0) {
            foreach ($links as $link) {
                if (PluginServicecatalogLinkgroup::isUserHaveRight($link['id'])) {
                    $target = "";
                    if ($link['target']) {
                        $target = " target='_blank'";
                    }
                    $display .= "<a class='bt-buttons' href='" . $link['url'] . "' $target >";
                    $display .= '<div class="linksc-normal visitedchildbg" >';

                    $class = "bt-list-links";
                    if (!empty($link['icon'])) {
                        $class = "";
                    }
                    if (empty($link['picture']) && empty($link['icon'])) {
                        $class = "";
                    }
                    if (isset($link['picture']) && !empty($link['picture'])) {
                        $display .= "<span>";
                        $display .= '<img style="margin: 0 auto;display: block;" src="' . PLUGIN_SERVICECATALOG_WEBDIR . '/front/document.send.php?file=_plugins/' . $link['picture'] . '">';
                        $display .= "</span>";
                    } else {
                        //                  $display .= "<a class='bt-buttons $class' href='" . $link['url'] . "' $target >";
                    }

                    if (empty($link['picture']) && !empty($link['icon'])) {
                        $fasize  = "fa-5x";
                        $display .= "<div class='center'>";
                        $display .= "<i class='bt-interface fa-menu-sc fas " . $link['icon'] . " $fasize' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>";//$style
                        $display .= "</div>";
                    } elseif (empty($link['picture']) && empty($link['icon']) && !empty($config->fields['fa_links'])) {
                        $fasize  = "fa-5x";
                        $display .= "<div class='center'>";
                        $display .= "<i class='bt-interface fa-menu-sc fas " . $config->fields['fa_links'] . " $fasize' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>";//$style
                        $display .= "</div>";
                    }

                    $display .= "<span class='bt-buttons' style='display: block;width: 100%; height: 100%;margin-top: 10px;'>";
                    $display .= "<h5 class=\"bt-title\">";
                    $self    = new self();
                    $self->getFromDB($link['id']);
                    $display .= self::displayField($self, 'name');
                    $display .= "</h5></span>";
                    $display .= "<em><span style=\"font-weight: normal;font-size: 11px;\">";
                    if (!empty($link['comment'])) {
                        $display .= self::displayField($self, 'comment');
                    }
                    $display .= "</span></em>";
                    $display .= '</div></a>';
                }
            }
        }

        if (count($links) == 0) {
            $display .= "<h5>";
            $display .= "<div class='alert alert-warning' role='alert'>";
            $display .= "<span>" . __('No link founded', 'servicecatalog') . "</span>";
            $display .= "</div>";
            $display .= "</h5>";
        }

        if ($widget == true) {
            echo $display;
        } else {
            return $display;
        }
    }

    /**
     * @param datas $input
     *
     * @return bool|datas
     */
    public function prepareInputForAdd($input)
    {
        //picture manually uploaded by category
        if (isset($input["_blank_picture"]) && $input["_blank_picture"]) {
            PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
            $input['picture'] = 'NULL';
        } else {
            if (isset($_FILES['picture'])) {
                if (!count($_FILES['picture'])
                    || empty($_FILES['picture']['name'])
                    || !is_file($_FILES['picture']['tmp_name'])) {
                    switch ($_FILES['picture']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            Session::addMessageAfterRedirect(
                                __('File too large to be added.'),
                                false,
                                ERROR
                            );
                            return false;
                            break;

                        case UPLOAD_ERR_NO_FILE:
                            unset($input['picture']);
                            //                     Session::addMessageAfterRedirect(__('No file specified.'), false, ERROR);
                            //                     return false;
                            break;
                    }
                } else {
                    if (Toolbox::getMime($_FILES['picture']['tmp_name'], 'image')) {
                        // Unlink old picture (clean on changing format)
                        PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
                        // Move uploaded file
                        $filename     = uniqid($this->fields['id'] . '_');
                        $tmp          = explode(".", $_FILES['picture']['name']);
                        $extension    = array_pop($tmp);
                        $picture_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";
                        PluginServicecatalogCategory::dropPictureFiles($filename . "." . $extension);

                        if (in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'bmp', 'gif'])
                            && Document::renameForce($_FILES['picture']['tmp_name'], $picture_path)) {
                            Session::addMessageAfterRedirect(__('The file is valid. Upload is successful.'));
                            // For display
                            $input['picture'] = "servicecatalog/{$filename}_min.$extension";

                            //prepare a thumbnail
                            $thumb_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}_min.$extension";

                            $img_infos = getimagesize($picture_path);
                            if ($img_infos[2] == IMAGETYPE_PNG) {
                                PluginServicecatalogCategory::resizePicture($picture_path, $thumb_path, $img_infos, 140, 80);
                            } else {
                                Toolbox::resizePicture($picture_path, $thumb_path, 140, 80);
                            }
                        } else {
                            Session::addMessageAfterRedirect(
                                __('Potential upload attack or file too large. Moving temporary file failed.'),
                                false,
                                ERROR
                            );
                            return false;
                        }
                    } else {
                        Session::addMessageAfterRedirect(
                            __('The file is not an image file.'),
                            false,
                            ERROR
                        );
                        return false;
                    }
                }
            } else {
                unset($input['picture']);
            }
        }

        return $input;
    }

    /**
     * @param datas $input
     *
     * @return bool|datas
     */
    public function prepareInputForUpdate($input)
    {
        //picture manually uploaded by category
        if (isset($input["_blank_picture"])) {
            PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
            $input['picture'] = 'NULL';
        } else {
            if (isset($_FILES['picture'])) {
                if (!count($_FILES['picture'])
                    || empty($_FILES['picture']['name'])
                    || !is_file($_FILES['picture']['tmp_name'])) {
                    switch ($_FILES['picture']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            Session::addMessageAfterRedirect(
                                __('File too large to be added.'),
                                false,
                                ERROR
                            );
                            return false;
                            break;

                        case UPLOAD_ERR_NO_FILE:
                            unset($input['picture']);
                            //                     Session::addMessageAfterRedirect(__('No file specified.'), false, ERROR);
                            //                     return false;
                            break;
                    }
                } else {
                    if (Toolbox::getMime($_FILES['picture']['tmp_name'], 'image')) {
                        // Unlink old picture (clean on changing format)
                        PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
                        // Move uploaded file
                        $filename     = uniqid($this->fields['id'] . '_');
                        $tmp          = explode(".", $_FILES['picture']['name']);
                        $extension    = array_pop($tmp);
                        $picture_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";
                        PluginServicecatalogCategory::dropPictureFiles($filename . "." . $extension);

                        if (in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'bmp', 'gif'])
                            && Document::renameForce($_FILES['picture']['tmp_name'], $picture_path)
                        ) {
                            Session::addMessageAfterRedirect(__('The file is valid. Upload is successful.'));
                            // For display
                            $input['picture'] = "servicecatalog/{$filename}_min.$extension";

                            //prepare a thumbnail
                            $thumb_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}_min.$extension";

                            $img_infos = getimagesize($picture_path);
                            if ($img_infos[2] == IMAGETYPE_PNG) {
                                PluginServicecatalogCategory::resizePicture($picture_path, $thumb_path, $img_infos, 140, 80);
                            } else {
                                Toolbox::resizePicture($picture_path, $thumb_path, 140, 80);
                            }
                        } else {
                            Session::addMessageAfterRedirect(
                                __('Potential upload attack or file too large. Moving temporary file failed.'),
                                false,
                                ERROR
                            );
                            return false;
                        }
                    } else {
                        Session::addMessageAfterRedirect(
                            __('The file is not an image file.'),
                            false,
                            ERROR
                        );
                        return false;
                    }
                }
            } else {
                unset($input['picture']);
            }
        }

        return $input;
    }

    /**
     * Returns the translation of the field
     *
     * @param type  $item
     * @param type  $field
     *
     * @return type
     * @global type $DB
     *
     */
    public static function displayField($item, $field)
    {
        global $DB;

        // Make new database object and fill variables
        $table    = $item->getTable();
        $dbu      = new DbUtils();
        $iterator = $DB->request([
                                     'FROM'  => 'glpi_plugin_servicecatalog_linktranslations',
                                     'WHERE' => [
                                         'itemtype' => $dbu->getItemTypeForTable($table),
                                         'items_id' => $item->getID(),
                                         'field'    => $field,
                                         'language' => $_SESSION['glpilanguage']
                                     ]]);

        if (count($iterator)) {
            foreach ($iterator as $data) {
                return $data['value'];
            }
        }
        return $item->fields[$field];
    }

    /**
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     */
    public static function getWidgetUsefullinks($widget, $bloc_class)
    {
        $buttons = "";

        $link = new self();
        if (!$link->canView()) {
            return $buttons;
        }
        if ($widget->fields['links_widgetactions'] == 1) {
            //Usefullinks
            $dbu         = new DbUtils();
            $catlink     = new self();
            $condition   = ['NOT' => ['display_at_home' => 1]]
                           + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', '', true);
            $links       = $catlink->find($condition, 'name');
            $count_links = 0;
            foreach ($links as $link) {
                if (PluginServicecatalogLinkgroup::isUserHaveRight($link['id'])) {
                    $count_links++;
                }
            }

            if ($count_links > 0) {
                $url     = PLUGIN_SERVICECATALOG_WEBDIR . "/front/link.form.php?see_links";
                $url_img = "picture.send.php";
                $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img"     => $widget->fields['img_links'],
                                                                                             "url_img" => $url_img,
                                                                                             "fa"      => $widget->fields['fa_links'],
                                                                                             "title"   => PluginServicecatalogConfig::displayField($widget, 'title_links'),
                                                                                             "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_links')]);
            }
        }
        return $buttons;
    }


    /**
     * @param $type
     * @param $widget
     *
     * @return string
     */
    //   static function showLinkMenu($type, $widget) {
    //      global $CFG_GLPI;
    //
    //      $form      = "";
    //      $dbu       = new DbUtils();
    //      $catlink   = new PluginServicecatalogLink();
    //      $condition = ['display_at_home' => 0]
    //                   + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', '', true);
    //      $links     = $catlink->find($condition, 'name');
    //      $title     = PluginServicecatalogConfig::displayField($widget, 'title_links');
    //      if (count($links) > 0 && $widget->fields["links_topmenu"] == 1) {
    //
    //         $url  = PLUGIN_SERVICECATALOG_WEBDIR . "/front/link.form.php?see_links";
    //         $form .= "<a class='box' href='" . $url . "'>";
    //         if (!empty($widget->fields['fa_links'])) {
    //            $icon = $widget->fields['fa_links'];
    //            $form .= "<i class='fas $icon fa-2x sc-hover' title='" . $title . " ' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>&nbsp;";
    //         }
    //         $form .= "<span>" . $title . "</span>";
    //         $form .= "</a>";
    //      }
    //
    //      return $form;
    //   }

    /**
     * @param $widget
     *
     * @return string
     */
    public static function showNavBarMenu($widget)
    {
        $menu = [];

        $link = new self();
        if (!$link->canView()) {
            return $menu;
        }
        $dbu       = new DbUtils();
        $catlink   = new self();
        $condition = ['display_at_home' => 0]
                     + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', '', true);
        $links     = $catlink->find($condition, 'name');

        if (count($links) > 0) {
            $url                           = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/link.form.php?see_links";
            $title                         = PluginServicecatalogConfig::displayField($widget, 'title_links');
            $menu['others_links']['title'] = $title;
            $menu['others_links']['page']  = $url;
            if (!empty($widget->fields['fa_links'])) {
                $icon                          = $widget->fields['fa_links'];
                $menu['others_links']['icon']  = "fas $icon fa-fw mr-3";
                $menu['others_links']['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "link_bar";
        }
        return $menu;
    }

    /**
     * @param $widget
     * @param $link
     * @param $bloc_class
     *
     * @return string
     */
    public static function getWidgetHomeUsefullinks($widget, $link, $bloc_class)
    {
        $lnk = new self();
        $lnk->getFromDB($link['id']);
        $url_img = "document.send.php";
        $buttons = PluginServicecatalogWidget::getWidgetTemplate($link['url'], $bloc_class, ["img"     => $link['picture'],
                                                                                             "url_img" => $url_img,
                                                                                             "css_img" => "bt-img-responsive bt-img-link-responsive",
                                                                                             "target"  => "_blank",
                                                                                             "fa"      => $link['icon'],
                                                                                             "title"   => self::displayField($lnk, 'name'),
                                                                                             "comment" => self::displayField($lnk, 'comment')]);

        return $buttons;
    }


    /**
     * @param $widget
     *
     * @param $link
     *
     * @return string
     */
    public static function showNavBarMenuHomeUsefullinks($widget, $link)
    {
        $form = [];
        $lnk  = new self();
        $lnk->getFromDB($link['id']);
        $url   = $link['url'];
        $title = self::displayField($lnk, 'name');

        $target = "";
        if ($link['target']) {
            $target = "_blank";
        }

        $form['title']         = $title;
        $form['page_external'] = $url;
        $form['target']        = $target;
        if (!empty($link['icon'])) {
            $icon          = $link['icon'];
            $form['icon']  = "fas $icon fa-fw mr-3";
            $form['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
        }

        return $form;
    }

    /**
     * @param $widget
     *
     * @return string|void
     */
    public static function showLinks($widget = false)
    {
        $display = "";

        if ($widget == false) {
            $display .= PluginServicecatalogConfig::loadForLayout(false);
        }
        $display .= "<div id='content' class='sc-content'>";
        $display .= "<div class='bt-container'>";
        $display .= "<div class='bt-block bt-features'>";

        $widgetclass = new PluginServicecatalogWidget();
        $title       = PluginServicecatalogConfig::displayField($widgetclass, 'title_links');
        if (!$widget) {
            $display .= PluginServicecatalogWidget::getPageTitle($title);
        } else {
            $display .= PluginServicecatalogWidget::getWidgetTitle($title);
        }

        $display .= self::getList(false);
        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";

        if ($widget == true) {
            return $display;
        } else {
            echo $display;
        }
    }

    /**
     * @param $class
     *
     * @return string
     */
    public static function getWidgetLinks($id, $class)
    {
        $delclass = "";
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $delclass = "delclass";
        }
        //
        $display = "<div id='" . $id . "' class=\"bt-row $delclass\">";
        $display .= self::showLinks(true);
        $display .= "</div>";

        return $display;
    }

    /**
     * Manage events from js/fuzzysearch.js
     *
     * @param string $action action to switch (should be actually 'getHtml' or 'getList')
     *
     * @return string
     * @since 9.2
     *
     */
    public static function fuzzySearch($action = '', $type = 0)
    {
        global $CFG_GLPI;

        switch ($action) {
            case 'getHtml':
                $modal_header = __('Search');
                $placeholder  = __("Start typing to find a link", "servicecatalog");
                $alert        = "";
                //            $alert        = sprintf(
                //               __("Tip: You can call this modal with %s keys combination"),
                //               "<kbd><kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>G</kbd></kbd>"
                //            );

                $html = <<<HTML
               <div class="modal" tabindex="-1" id="fuzzysearch">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">
                              <i class="fas fa-arrow-right me-2"></i>
                              {$modal_header}
                           </h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                           <input type="text" class="form-control" placeholder="{$placeholder}">
                           <ul class="results list-group mt-2"></ul>
                        </div>
                     </div>
                  </div>
               </div>

HTML;
                return $html;
                break;

            default:
            $fuzzy_entries = [];

            $dbu       = new DbUtils();
            $catlink   = new self();
            $config    = new PluginServicecatalogConfig();
            $condition = ['NOT' => ['display_at_home' => 1]]
                         + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_links', '', '', true);
            $links     = $catlink->find($condition, 'name');

            if (count($links) > 0) {
                foreach ($links as $link) {
                    if (PluginServicecatalogLinkgroup::isUserHaveRight($link['id'])) {
                        $target = "";
                        if ($link['target']) {
                            $target = " target='_blank'";
                        }
                        $self = new self();
                        $self->getFromDB($link['id']);
                        $name            = self::displayField($self, 'name');
                        $fasize          = "fa-1x";
                        $fuzzy_entries[] = [
                            'url'   => $link['url'],
                            'title' => $name,
                            'order'     => "1",
                            'icon'  => $link['icon']
                        ];
                    }
                }
            }
            // return the entries to ajax call
            return json_encode($fuzzy_entries);
            break;
        }
    }
}
