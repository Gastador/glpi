<?php


if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

/**
 * Common DataBase visibility for items
 */
class PluginServicecatalogFavorite extends CommonDBTM
{

    static $rightname         = 'plugin_servicecatalog_favorites';
    var    $can_be_translated = true;
    const CONFIG_PARENT = 1;


    // For visibility checks
    protected $users    = [];
    protected $groups   = [];
    protected $profiles = [];
    protected $entities = [];

    /**
     * @return array
     * @throws \GlpitestSQLError
     */
    static function getFavorites() {
        global $DB;

        $favorites = [];

        $query = "SELECT `glpi_plugin_servicecatalog_favorites`.`itilcategories_id`
                   FROM `glpi_plugin_servicecatalog_favorites` "
                 . self::addVisibilityJoins();
        $query .= "WHERE " . self::addVisibilityRestrict() . "";

        $result = $DB->query($query);
        $nb     = $DB->numrows($result);
        if ($nb) {
            while ($fav = $DB->fetchArray($result)) {
                $favorites[$fav['itilcategories_id']] = $fav['itilcategories_id'];
            }
        }

        return $favorites;
    }


    /**
     * @return array
     * @throws \GlpitestSQLError
     */
    static function getFavoritesVisibility() {
        global $DB;
        $parents = [];
        $query   = "SELECT `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id`
                   FROM `glpi_plugin_servicecatalog_favorites` "
                   . self::addVisibilityJoins();
        $query   .= "WHERE " . self::addVisibilityRestrict() . "";

        $result = $DB->query($query);
        $nb     = $DB->numrows($result);
        if ($nb) {
            while ($fav = $DB->fetchArray($result)) {
                $parents[] = $fav['favorite_itilcategories_id'];
            }
        }

        return $parents;
    }

    /**
     * @param $fav
     * @param $type
     *
     * @return array
     */
    function getObjectsRelation($fav, $type) {

        switch ($type) {
            case "User":
                return $this->users = PluginServicecatalogFavorite_User::getUsers($fav);
            case "Entity":
                return $this->entities = PluginServicecatalogEntity_Favorite::getEntities($fav);
            case "Group":
                return $this->groups = PluginServicecatalogFavorite_Group::getGroups($fav);
            case "Profile":
                return $this->profiles = PluginServicecatalogFavorite_Profile::getProfiles($fav);
        }
    }


    function cleanDBonPurge() {

        $this->deleteChildrenAndRelationsFromDb(
            [
                PluginServicecatalogFavorite_Group::class,
                PluginServicecatalogFavorite_Profile::class,
                PluginServicecatalogEntity_Favorite::class,
                PluginServicecatalogFavorite_User::class
            ]
        );
    }

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    static function getTypeName($nb = 0) {

        return __('Favorite', 'servicecatalog');
    }

    /**
     * @return array
     */
    static function getFavoritesUsed() {
        global $DB;

        $favsUsed = [];

        $iterator = $DB->request([
                                     'SELECT' => [self::getTable() . '.' . '`itilcategories_id` AS used'],
                                     'FROM'   => self::getTable()
                                 ]);

        foreach ($iterator as $data) {
            array_push($favsUsed, $data['used']);
        }
        return $favsUsed;
    }


    /**
     * Display image tab for each category
     *
     * @param CommonGLPI $item
     * @param int        $withtemplate
     *
     * @return array|string
     */
    function getTabNameForItem(CommonGLPI $item, $withtemplate = 0) {

        if (!$withtemplate) {
            if ($item->getType() == 'ITILCategory' && $this->canUpdate()) {
                if ($_SESSION['glpishow_count_on_tabs']) {
                    $dbu = new DbUtils();
                    return self::createTabEntry(
                        PluginServicecatalogFavorite::getTypeName(),
                        $dbu->countElementsInTable(
                            "glpi_plugin_servicecatalog_favorites",
                            ["itilcategories_id" => $item->getField('id')]
                        )
                    );
                }
                return PluginServicecatalogFavorite::getTypeName();
            }
        }
        return '';
    }


    /**
     * @param \CommonGLPI $item
     * @param int         $tabnum
     * @param int         $withtemplate
     *
     * @return bool
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0) {

        switch ($item->getType()) {
            case 'ITILCategory':
                $itilcategories_id = $item->getField('id');
                $self              = new self();

                if (!$self->getFromDBByCategory($itilcategories_id)) {
                    $self->createAccess($itilcategories_id);
                }
                $self->showFavoritesForm($itilcategories_id);
                break;
        }

        return true;
    }

    /**
     * Returns if category is present
     *
     * @param type  $itilcategories_id
     *
     * @return boolean
     * @global type $DB
     *
     */
    function getFromDBByCategory($itilcategories_id) {
        global $DB;

        $iterator = $DB->request([
                                     'FROM'  => getTableForItemType(__CLASS__),
                                     'WHERE' => [
                                         'itilcategories_id' => $itilcategories_id,
                                     ],
                                 ]);
        if (count($iterator) != 1) {
            return false;
        }
        foreach ($iterator as $data) {
            $this->fields = $data;
            if (is_array($this->fields) && count($this->fields)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }


    /**
     * Create the first access
     *
     * @param type $ID
     */
    function createAccess($ID) {

        $this->add([
                       'itilcategories_id'          => $ID,
                       'users_id'                   => 0,
                       'groups'                     => "",
                       'entities'                   => "",
                       'favorite_itilcategories_id' => 0,
                       'users'                      => "",
                       'profiles'                   => ""
                   ]);
    }


    /**
     * @return int
     */
    public function countVisibilities() {

        return (count($this->entities)
                + count($this->users)
                + count($this->groups)
                + count($this->profiles));
    }

    /**
     * Show visibility configuration
     *
     * @param $itilcategories_id
     *
     * @return bool *
     **@since 9.2 moved from each class to parent class
     */
    public function showFavoritesForm($itilcategories_id) {
        global $CFG_GLPI;

        $canedit  = true;
        $rand     = mt_rand();
        $str_type = strtolower($this::getType());

        $cat = new ITILCategory();
        $cat->getFromDB($itilcategories_id);

        $self = new self();
        $self->getFromDBByCategory($itilcategories_id);
        $fav_itilcategories_id = $self->getField('favorite_itilcategories_id');
        $ID                    = $self->getField('id');


        if ($cat->getField('level') == 1 && $ID > 0) {
            $self->deleteByCriteria(['id' => $ID]);
            echo "<div class='alert  alert-warning d-flex'>";
            echo __('You cannot define a favorite for a first level category', 'servicecatalog') . "</div>";
            return false;
        }

        if ($canedit) {
            echo "<form action='" . $this->getFormURL() . "' method='post' >";
            echo "<table class='tab_cadre_fixe'>";
            echo "<tr class='tab_bg_1'>";
            echo "<th colspan='2'>";
            echo __("Linked itil category", "servicecatalog");
            echo "</th>";
            echo "</tr>";
            echo "<tr class='tab_bg_1'>";
            echo "<td>";
            $opt = [
                'name'   => 'favorite_itilcategories_id',
                'value'  => $self->fields["favorite_itilcategories_id"],
                'entity' => $_SESSION["glpiactiveentities"]
            ];
            ITILCategory::dropdown($opt);
            echo "</td>";

            if (Session::haveRight(self::$rightname, UPDATE)) {
                echo "<td>";
                echo Html::submit(_sx('button', 'Save'), ['name' => 'update', 'class' => 'btn btn-primary']);
                echo Html::hidden("id", ['value' => $ID]);
                echo "</td>";
            }
            echo "</tr>";
            echo "</table>";
            Html::closeForm();


            echo "<div class='firstbloc'>";
            echo "<form name='{$str_type}visibility_form$rand' id='{$str_type}visibility_form$rand' ";
            echo " method='post' action='" . static::getFormURL() . "'>";
            $name = "{$str_type}s_id";
            echo Html::hidden($name, ['value' => $ID]);
            echo Html::hidden('favorites_id', ['value' => $fav_itilcategories_id]);
            echo "<table class='tab_cadre_fixe'>";
            echo "<tr class='tab_bg_1'><th colspan='4'>" . __('Visibility', 'servicecatalog') . "</tr>";
            echo "<tr class='tab_bg_1'><td class='tab_bg_2' width='100px'>";

            $types = ['Entity', 'Group', 'Profile', 'User'];
            foreach ($types as $type) {
                self::getObjectsRelation($ID, $type);
            }
            $nb = $this->countVisibilities();

            $addrand = Dropdown::showItemTypes('_type', $types);
            $params  = $this->getShowVisibilityDropdownParams();

            Ajax::updateItemOnSelectEvent(
                "dropdown__type" . $addrand,
                "visibility$rand",
                $CFG_GLPI["root_doc"] . "/ajax/visibility.php",
                $params
            );

            echo "</td>";
            echo "<td><span id='visibility$rand'></span>";
            echo "</td></tr>";
            echo "</table>";
            Html::closeForm();
            echo "</div>";
        }
        echo "<div class='spaced'>";
        if ($canedit && $nb) {
            Html::openMassiveActionsForm('mass' . __CLASS__ . $rand);
            $massiveactionparams = ['num_displayed'
                                    => min($_SESSION['glpilist_limit'], $nb),
                                    'container'
                                    => 'mass' . __CLASS__ . $rand,
                                    'specific_actions'
                                    => ['delete' => _x('button', 'Delete permanently')]];

            Html::showMassiveActions($massiveactionparams);
        }
        echo "<table class='tab_cadre_fixehov'>";
        $header_begin  = "<tr>";
        $header_top    = '';
        $header_bottom = '';
        $header_end    = '';
        if ($canedit && $nb) {
            $header_begin  .= "<th width='10'>";
            $header_top    .= Html::getCheckAllAsCheckbox('mass' . __CLASS__ . $rand);
            $header_bottom .= Html::getCheckAllAsCheckbox('mass' . __CLASS__ . $rand);
            $header_end    .= "</th>";
        }
        $header_end .= "<th>" . __('Type') . "</th>";
        $header_end .= "<th>" . _n('Recipient', 'Recipients', Session::getPluralNumber()) . "</th>";
        $header_end .= "</tr>";
        echo $header_begin . $header_top . $header_end;

        // Users
        if (count($this->users)) {
            foreach ($this->users as $val) {
                foreach ($val as $data) {
                    echo "<tr class='tab_bg_1'>";
                    if ($canedit) {
                        echo "<td>";
                        Html::showMassiveActionCheckBox($this::getType() . '_User', $data["id"]);
                        echo "</td>";
                    }
                    echo "<td>" . __('User') . "</td>";
                    echo "<td>" . getUserName($data['users_id']) . "</td>";
                    echo "</tr>";
                }
            }
        }

        // Groups
        if (count($this->groups)) {
            foreach ($this->groups as $val) {
                foreach ($val as $data) {
                    echo "<tr class='tab_bg_1'>";
                    if ($canedit) {
                        echo "<td>";
                        Html::showMassiveActionCheckBox($this::getType() . '_Group', $data["id"]);
                        echo "</td>";
                    }
                    echo "<td>" . __('Group') . "</td>";

                    $names   = Dropdown::getDropdownName('glpi_groups', $data['groups_id'], 1);
                    $entname = sprintf(
                        __('%1$s %2$s'),
                        $names["name"],
                        Html::showToolTip($names["comment"], ['display' => false])
                    );
                    if ($data['entities_id'] >= 0) {
                        $entname = sprintf(
                            __('%1$s / %2$s'),
                            $entname,
                            Dropdown::getDropdownName(
                                'glpi_entities',
                                $data['entities_id']
                            )
                        );
                        if ($data['is_recursive']) {
                            //TRANS: R for Recursive
                            $entname = sprintf(
                                __('%1$s %2$s'),
                                $entname,
                                "<span class='b'>(" . __('R') . ")</span>"
                            );
                        }
                    }
                    echo "<td>" . $entname . "</td>";
                    echo "</tr>";
                }
            }
        }

        // Entity
        if (count($this->entities)) {
            foreach ($this->entities as $val) {
                foreach ($val as $data) {
                    echo "<tr class='tab_bg_1'>";
                    if ($canedit) {
                        echo "<td>";
                        Html::showMassiveActionCheckBox('PluginServicecatalogEntity_Favorite', $data["id"]);
                        echo "</td>";
                    }
                    echo "<td>" . __('Entity') . "</td>";
                    $names   = Dropdown::getDropdownName('glpi_entities', $data['entities_id'], 1);
                    $tooltip = Html::showToolTip($names["comment"], ['display' => false]);
                    $entname = sprintf(__('%1$s %2$s'), $names["name"], $tooltip);
                    if ($data['is_recursive']) {
                        $entname = sprintf(
                            __('%1$s %2$s'),
                            $entname,
                            "<span class='b'>(" . __('R') . ")</span>"
                        );
                    }
                    echo "<td>" . $entname . "</td>";
                    echo "</tr>";
                }
            }
        }

        // Profiles
        if (count($this->profiles)) {
            foreach ($this->profiles as $val) {
                foreach ($val as $data) {
                    echo "<tr class='tab_bg_1'>";
                    if ($canedit) {
                        echo "<td>";
                        Html::showMassiveActionCheckBox($this::getType() . '_Profile', $data["id"]);
                        echo "</td>";
                    }
                    echo "<td>" . _n('Profile', 'Profiles', 1) . "</td>";

                    $names   = Dropdown::getDropdownName('glpi_profiles', $data['profiles_id'], 1);
                    $tooltip = Html::showToolTip($names["comment"], ['display' => false]);
                    $entname = sprintf(__('%1$s %2$s'), $names["name"], $tooltip);
                    if ($data['entities_id'] >= 0) {
                        $entname = sprintf(
                            __('%1$s / %2$s'),
                            $entname,
                            Dropdown::getDropdownName(
                                'glpi_entities',
                                $data['entities_id']
                            )
                        );
                        if ($data['is_recursive']) {
                            $entname = sprintf(
                                __('%1$s %2$s'),
                                $entname,
                                "<span class='b'>(" . __('R') . ")</span>"
                            );
                        }
                    }
                    echo "<td>" . $entname . "</td>";
                    echo "</tr>";
                }
            }
        }

        if ($nb) {
            echo $header_begin . $header_bottom . $header_end;
        }
        echo "</table>";
        if ($canedit && $nb) {
            $massiveactionparams['ontop'] = false;
            Html::showMassiveActions($massiveactionparams);
            Html::closeForm();
        }

        echo "</div>";
        // Add items

        return true;
    }


    /**
     * @param $table
     * @param $favorite_itilcategories_id
     * @param $id
     * @param $typeFavorite
     *
     * @return array|int|mixed|string
     */
    static function getLastFavoriteRankingValue($table, $favorite_itilcategories_id, $id, $typeFavorite) {
        global $DB;

        switch ($typeFavorite) {
            case PluginServicecatalogFavorite_User::INCIDENT_TYPE_FAVORITES:
                $query    = "SELECT MAX(`{$table}`.`ranking_incidents`) AS ranking_user FROM `{$table}` INNER JOIN `glpi_plugin_servicecatalog_favorites`
                  ON `glpi_plugin_servicecatalog_favorites`.`id` = `{$table}`.`favorites_id` 
                    WHERE `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id` = {$favorite_itilcategories_id} 
                       AND `{$table}`.`users_id` = {$id}";
                $result   = $DB->queryOrDie($query);
                $lastRank = $DB->fetchAssoc($result);
                $lastRank = $lastRank['ranking_user'];
                if (isset($lastRank)) {
                    $lastRank += 1;
                } else {
                    $lastRank = 0;
                }
                return $lastRank;

            case PluginServicecatalogFavorite_User::REQUEST_TYPE_FAVORITES:
                $query    = "SELECT MAX(`{$table}`.`ranking_requests`) AS ranking_user FROM `{$table}` 
                              INNER JOIN `glpi_plugin_servicecatalog_favorites`
                  ON `glpi_plugin_servicecatalog_favorites`.`id` = `{$table}`.`favorites_id` 
                    WHERE `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id` = {$favorite_itilcategories_id} 
                       AND `{$table}`.`users_id` = {$id}";
                $result   = $DB->queryOrDie($query);
                $lastRank = $DB->fetchAssoc($result);
                $lastRank = $lastRank['ranking_user'];
                if (isset($lastRank)) {
                    $lastRank += 1;
                } else {
                    $lastRank = 0;
                }
                return $lastRank;

            case PluginServicecatalogFavorite_User::BOTH_TYPE_FAVORITES:
                $lastRank = [];
                $query    = "SELECT MAX(`{$table}`.`ranking_requests`) AS `ranking_requests`, MAX(`{$table}`.`ranking_incidents`) `ranking_incidents`FROM `{$table}` INNER JOIN `glpi_plugin_servicecatalog_favorites`
                  ON `glpi_plugin_servicecatalog_favorites`.`id` = `{$table}`.`favorites_id` 
                    WHERE `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id` = {$favorite_itilcategories_id} 
                       AND `{$table}`.`users_id` = {$id}";
                $result   = $DB->queryOrDie($query);
                while ($data = $DB->fetchAssoc($result)) {
                    if (is_array($data)) {
                        if (isset($data['ranking_requests'])) {
                            $lastRank['ranking_requests'] = $data['ranking_requests'] += 1;
                        } else {
                            $lastRank['ranking_requests'] = 0;
                        }
                        if (isset($data['ranking_incidents'])) {
                            $lastRank['ranking_incidents'] = $data['ranking_incidents'] += 1;
                        } else {
                            $lastRank['ranking_incidents'] = 0;
                        }
                    }
                }

                return $lastRank;
        }
    }


    /**
     * @param $params
     */
    static function addFavoriteVisibility($params) {

        $favId = $params['pluginservicecatalogfavorites_id'];
        $item  = null;

        if ($favId > 0) {
            switch ($params["_type"]) {
                case 'User':
                    if (isset($params['users_id']) && $params['users_id']) {
                        if (isset($favId)) {
                            $item  = new PluginServicecatalogFavorite_User();
                            $table = "glpi_plugin_servicecatalog_favorites_users";
                            $ranks = self::getLastFavoriteRankingValue($table, $params['favorites_id'], $params['users_id'], $params['type_favorites']);
                            if (is_array($ranks)) {
                                $ranking_requests  = $ranks['ranking_requests'];
                                $ranking_incidents = $ranks['ranking_incidents'];

                                $item->add(['favorites_id'      => $favId,
                                            'users_id'          => $params['users_id'],
                                            'ranking_requests'  => $ranking_requests,
                                            'ranking_incidents' => $ranking_incidents,
                                            'type_favorites'    => $params['type_favorites']]);
                            } else {
                                if ($params['type_favorites'] == PluginServicecatalogFavorite_User::REQUEST_TYPE_FAVORITES) {
                                    $item->add(['favorites_id'      => $favId,
                                                'users_id'          => $params['users_id'],
                                                'ranking_requests'  => $ranks,
                                                'ranking_incidents' => -1,
                                                'type_favorites'    => $params['type_favorites']]);
                                } else {
                                    $item->add(['favorites_id'      => $favId,
                                                'users_id'          => $params['users_id'],
                                                'ranking_incidents' => $ranks,
                                                'ranking_requests'  => -1,
                                                'type_favorites'    => $params['type_favorites']]);
                                }
                            }
                        }
                    }
                    break;


                case 'Group':
                    if (isset($params['groups_id']) && $params['groups_id']) {
                        if (isset($favId)) {
                            $item = new PluginServicecatalogFavorite_Group();
                            $item->add(['favorites_id' => $favId,
                                        'groups_id'    => $params['groups_id'],
                                        'entities_id'  => $params['entities_id'],
                                        'is_recursive' => $params['is_recursive']]);
                        }
                    }
                    break;

                case 'Profile':
                    if (isset($_POST['profiles_id']) && $_POST['profiles_id']) {
                        if (isset($favId)) {
                            $item = new PluginServicecatalogFavorite_Profile();
                            $item->add(['favorites_id' => $favId,
                                        'profiles_id'  => $params['profiles_id'],
                                        'entities_id'  => $params['entities_id'],
                                        'is_recursive' => $params['is_recursive']]);
                        }
                    }
                    break;

                case 'Entity':
                    if (isset($favId)) {
                        $item = new PluginServicecatalogEntity_Favorite();
                        $item->add(['favorites_id' => $favId,
                                    'entities_id'  => $params['entities_id'],
                                    'is_recursive' => $params['is_recursive']]);
                    }
                    break;
            }
        }
    }

    /**
     * Return visibility joins to add to SQL
     *
     * @param bool $forceall force all joins (false by default)
     *
     * @return string joins to add
     */
    static function addVisibilityJoins($forceall = false) {

        //      if (!Session::haveRight(self::$rightname, READ)) {
        //         return '';
        //      }
        // Users
        $join = " LEFT JOIN `glpi_plugin_servicecatalog_favorites_users`
                     ON (`glpi_plugin_servicecatalog_favorites_users`.`favorites_id` = `glpi_plugin_servicecatalog_favorites`.`id`) ";

        // Groups
        if ($forceall
            || (isset($_SESSION["glpigroups"]) && count($_SESSION["glpigroups"]))) {
            $join .= " LEFT JOIN `glpi_plugin_servicecatalog_favorites_groups`
                        ON (`glpi_plugin_servicecatalog_favorites_groups`.`favorites_id` = `glpi_plugin_servicecatalog_favorites`.`id`) ";
        }

        // Profiles
        if ($forceall
            || (isset($_SESSION["glpiactiveprofile"])
                && isset($_SESSION["glpiactiveprofile"]['id']))) {
            $join .= " LEFT JOIN `glpi_plugin_servicecatalog_favorites_profiles`
                        ON (`glpi_plugin_servicecatalog_favorites_profiles`.`favorites_id` = `glpi_plugin_servicecatalog_favorites`.`id`) ";
        }

        // Entities
        if ($forceall
            || (isset($_SESSION["glpiactiveentities"]) && count($_SESSION["glpiactiveentities"]))) {
            $join .= " LEFT JOIN `glpi_plugin_servicecatalog_entities_favorites`
                        ON (`glpi_plugin_servicecatalog_entities_favorites`.`favorites_id` = `glpi_plugin_servicecatalog_favorites`.`id`) ";
        }

        return $join;
    }


    /**
     * Return visibility SQL restriction to add
     *
     * @return string restrict to add
     **/
    static function addVisibilityRestrict() {
        //not deprecated because used in Search

        //get and clean criteria
        $criteria = self::getVisibilityCriteria();
        unset($criteria['LEFT JOIN']);
        $criteria['FROM'] = self::getTable();

        $it = new \DBmysqlIterator(null);
        $it->buildQuery($criteria);
        $sql = $it->getSql();
        $sql = preg_replace('/.*WHERE /', '', $sql);

        return $sql;
    }

    /**
     * Return visibility joins to add to DBIterator parameters
     *
     * @param boolean $forceall force all joins (false by default)
     *
     * @return array
     * @since 9.4
     *
     */
    public static function getVisibilityCriteria($forceall = false) {

        if (!Session::haveRight(self::$rightname, READ)) {
            return [
                'WHERE' => ['glpi_plugin_servicecatalog_favorites.users_id' => Session::getLoginUserID()],
            ];
        }

        $join  = [];
        $where = [];

        // Users
        $join['glpi_plugin_servicecatalog_favorites_users'] = [
            'FKEY' => [
                'glpi_plugin_servicecatalog_favorites_users' => 'favorites_id',
                'glpi_plugin_servicecatalog_favorites'       => 'id'
            ]
        ];


        if (Session::getLoginUserID()) {
            $where['OR'] = [
                'glpi_plugin_servicecatalog_favorites.users_id'       => Session::getLoginUserID(),
                'glpi_plugin_servicecatalog_favorites_users.users_id' => Session::getLoginUserID(),
            ];
        } else {
            $where = [
                0
            ];
        }

        // Groups
        if ($forceall
            || (isset($_SESSION["glpigroups"]) && count($_SESSION["glpigroups"]))) {
            $join['glpi_plugin_servicecatalog_favorites_groups'] = [
                'FKEY' => [
                    'glpi_plugin_servicecatalog_favorites_groups' => 'favorites_id',
                    'glpi_plugin_servicecatalog_favorites'        => 'id'
                ]
            ];

            $or       = ['glpi_plugin_servicecatalog_favorites_groups.entities_id' => ['<', 0]];
            $restrict = getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_favorites_groups', '', '', true);
            if (count($restrict)) {
                $or = $or + $restrict;
            }
            $where['OR'][] = [
                'glpi_plugin_servicecatalog_favorites_groups.groups_id' => count($_SESSION["glpigroups"])
                    ? $_SESSION["glpigroups"]
                    : [-1],
                'OR'                                                    => $or
            ];
        }

        // Profiles
        if ($forceall
            || (isset($_SESSION["glpiactiveprofile"])
                && isset($_SESSION["glpiactiveprofile"]['id']))) {
            $join['glpi_plugin_servicecatalog_favorites_profiles'] = [
                'FKEY' => [
                    'glpi_plugin_servicecatalog_favorites_profiles' => 'favorites_id',
                    'glpi_plugin_servicecatalog_favorites'          => 'id'
                ]
            ];

            $or       = ['glpi_plugin_servicecatalog_favorites_profiles.entities_id' => ['<', 0]];
            $restrict = getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_favorites_profiles', '', '', true);
            if (count($restrict)) {
                $or = $or + $restrict;
            }
            $where['OR'][] = [
                'glpi_plugin_servicecatalog_favorites_profiles.profiles_id' => $_SESSION["glpiactiveprofile"]['id'],
                'OR'                                                        => $or
            ];
        }

        // Entities
        if ($forceall
            || (isset($_SESSION["glpiactiveentities"]) && count($_SESSION["glpiactiveentities"]))) {
            $join['glpi_plugin_servicecatalog_entities_favorites'] = [
                'FKEY' => [
                    'glpi_plugin_servicecatalog_entities_favorites' => 'favorites_id',
                    'glpi_plugin_servicecatalog_favorites'          => 'id'
                ]
            ];
        }
        if (isset($_SESSION["glpiactiveentities"]) && count($_SESSION["glpiactiveentities"])) {
            $restrict = getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_entities_favorites', '', '', true, true);
            if (count($restrict)) {
                $where['OR'] = $where['OR'] + $restrict;
            }
        }

        $criteria = [
            'LEFT JOIN' => $join,
            'WHERE'     => $where
        ];

        return $criteria;
    }

    /**
     * Get dropdown parameters from showVisibility method
     *
     * @return array
     */
    protected function getShowVisibilityDropdownParams() {
        return [
            'type'  => '__VALUE__',
            'right' => "itilcategory"
        ];
    }

    /**
     * @param $type
     * @param $config
     *
     * @return string
     */
    //   static function showLinkMenu($type, $config) {
    //      global $CFG_GLPI;
    //
    //      $form = "";
    //      if ((Ticket::INCIDENT_TYPE == $type || Ticket::DEMAND_TYPE == $type)
    //          && Session::haveRight("plugin_servicecatalog_favorites", UPDATE)) {
    //         $form .= "<a class='box' href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=1&manage_favorites=1' >";
    //         $form .= "<i class='fas fa-star fa-2x sc-hover' title='" . PluginServicecatalogConfig::displayField($config, 'title_favorites_category') . " '></i>&nbsp;";
    //         $form .= "<span>" . PluginServicecatalogConfig::displayField($config, 'title_favorites_category') . "</span></a>";
    //      }
    //      return $form;
    //   }

    /**
     * @param $opt
     */
    static function displayFavoriteTemplate($opt) {

        echo '<div class="bt-row">';
        echo '<div class="bt-col-md-12">';
        echo '<div class="bt-feature bt-col-md-6">';
        echo '<div class="bt-col-md-12">';
        self::addFavoriteTemplate($opt);
        echo "</div>";
        echo '<div class="bt-col-md-12">';
        self::deleteFavoriteTemplate($opt);
        echo "</div>";
        echo "</div>";
        echo '<div class="bt-feature bt-col-md-6">';
        echo '<div class="bt-col-md-12">';
        self::manageRankingFavorites($opt);
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
    }

    /**
     * @param $opt
     */
    static function manageRankingFavorites($opt) {

        $favorites              = isset($opt['favorites']) ? $opt['favorites'] : [];
        $catFav                 = new ITILCategory();
        $groupFavoritesRequest  = [];
        $groupFavoritesIncident = [];
        $fav_id                 = [];

        foreach ($favorites as $favorite) {
            if ($favorite['type_favorites'] == PluginServicecatalogFavorite_User::REQUEST_TYPE_FAVORITES
                || $favorite['type_favorites'] == PluginServicecatalogFavorite_User::BOTH_TYPE_FAVORITES) {
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['users_id']                   = $favorite['users_id'];
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['favorites_id']               = $favorite['favorites_id'];
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['itilcategories_id']          = $favorite['itilcategories_id'];
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['completename']               = $favorite['completename'];
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['favorite_itilcategories_id'] = $favorite['favorite_itilcategories_id'];
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['favorites_users_id']         = $favorite['favorites_users_id'];
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['ranking_requests']           = $favorite['ranking_requests'];
                $groupFavoritesRequest[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['type_favorites']             = PluginServicecatalogFavorite_User::REQUEST_TYPE_FAVORITES;
            }

            if ($favorite['type_favorites'] == PluginServicecatalogFavorite_User::INCIDENT_TYPE_FAVORITES
                || $favorite['type_favorites'] == PluginServicecatalogFavorite_User::BOTH_TYPE_FAVORITES) {
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['users_id']                   = $favorite['users_id'];
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['favorites_id']               = $favorite['favorites_id'];
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['itilcategories_id']          = $favorite['itilcategories_id'];
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['completename']               = $favorite['completename'];
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['favorite_itilcategories_id'] = $favorite['favorite_itilcategories_id'];
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['favorites_users_id']         = $favorite['favorites_users_id'];
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['ranking_incidents']          = $favorite['ranking_incidents'];
                $groupFavoritesIncident[$favorite['favorite_itilcategories_id']][$favorite['itilcategories_id']]['type_favorites']             = PluginServicecatalogFavorite_User::INCIDENT_TYPE_FAVORITES;
            }
        }

        $groupFavoritesIncident = PluginServicecatalogFavorite_User::orderIncidentsRanking($groupFavoritesIncident);


        echo "<table class='tab_cadre_fixehov'>";
        echo "<tr>";
        echo "<th colspan='4'>" . __('Favorites ordering', 'servicecatalog') . "</th>";
        echo "</tr>";
        echo '</table>';
        if (count($groupFavoritesRequest) > 0) {
            echo "<table class='tab_cadre_fixehov'>";
            echo "<tr>";
            echo "<th colspan='4'>" . __('Requests', 'servicecatalog') . "</th>";
            echo "</tr>";
            echo '</table>';

            foreach ($groupFavoritesRequest as $group => $groupValue) {
                if (count($groupValue) >= 2) {
                    $catFav->getFromDB($group);
                    echo "<table style='margin-top : 15px;'  id={$group} class='tab_cadre_fixehov'>";
                    echo "<tr>";
                    $name = $catFav->getName();
                    if ($group == 0) {
                        $name = __("Homepage", "servicecatalog");
                    }
                    echo "<th colspan='4'>" . $name . "</th>";
                    echo "</tr>";
                    echo '</table>';

                    echo Html::hidden('users_id', ['value' => $opt['users_id']]);
                    echo "<form name='form' action='" . PluginServicecatalogMain::getFormURL() . "' method='post' >";
                    echo "<div id='redips-drag-$group'>";
                    echo "<table class='tab_cadre_fixehov'>";
                    foreach ($groupValue as $groupId => $details) {
                        $fav_id   = $details['favorites_users_id'];
                        $type_fav = $details['type_favorites'];

                        echo "<tr class='tab_bg_2'>";
                        echo "<td class='redips-rowhandler control center'>";
                        echo "<div id='$fav_id-$group-$type_fav'  class=\"id redips-drag redips-row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                        echo $details['completename'];
                        echo '</div>';
                        echo '</td>';

                        echo '<td class="redips-rowhandler control center">';
                        echo "<div id='$fav_id-$group-$type_fav'  class=\"id redips-drag redips-row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                        echo $details['ranking_requests'];
                        echo '</div>';
                        echo '</td>';

                        echo '<td class="redips-rowhandler control center">';
                        echo "<div id='$fav_id-$group-$type_fav'  class=\"id redips-drag redips-row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";

                        echo "<i class=\"fas fa-grip-horizontal grip-rule\"></i>";
                        echo '</div>';
                        echo '</td>';
                        echo "</tr>\n";
                    }

                    echo "<script>$(document).ready(function() {
                    plugin_servicecatalog_favoriteFields($group);
                       });</script>";
                    echo '</table>';
                    Html::closeForm();
                }
            }
            echo '<br>';
        }

        if (count($groupFavoritesIncident) > 0) {
            echo "<table class='tab_cadre_fixehov'>";
            echo "<tr>";
            echo "<th colspan='4'>" . __('Incidents', 'servicecatalog') . "</th>";
            echo "</tr>";
            echo '</table>';

            foreach ($groupFavoritesIncident as $group => $groupValue) {
                if (count($groupValue) >= 2) {
                    $catFav->getFromDB($group);
                    echo "<table style='margin-top : 15px;'  id={$group} class='tab_cadre_fixehov'>";
                    echo "<tr>";
                    $name = $catFav->getName();
                    if ($group == 0) {
                        $name = __("Homepage", "servicecatalog");
                    }
                    echo "<th colspan='4'>" . $name . "</th>";
                    echo "</tr>";
                    echo '</table>';

                    echo Html::hidden('users_id', ['value' => $opt['users_id']]);
                    echo "<form name='form' action='" . PluginServicecatalogMain::getFormURL() . "' method='post' >";
                    echo "<div id='redips-drag-$group'>";
                    echo "<table class='tab_cadre_fixehov'>";
                    foreach ($groupValue as $groupId => $details) {
                        $fav_id   = $details['favorites_users_id'];
                        $type_fav = $details['type_favorites'];

                        echo "<tr class='tab_bg_2'>";
                        echo "<td class='redips-rowhandler control center'>";
                        echo "<div id='$fav_id-$group-$type_fav'  class=\"id redips-drag redips-row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                        echo $details['completename'];
                        echo '</div>';
                        echo '</td>';

                        echo '<td class="redips-rowhandler control center">';
                        echo "<div id='$fav_id-$group-$type_fav'  class=\"id redips-drag redips-row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                        echo $details['ranking_incidents'];
                        echo '</div>';
                        echo '</td>';

                        echo '<td class="redips-rowhandler control center">';
                        echo "<div id='$fav_id-$group-$type_fav'  class=\"id redips-drag redips-row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";

                        echo "<i class=\"fas fa-grip-horizontal grip-rule\"></i>";
                        echo '</div>';
                        echo '</td>';
                        echo "</tr>\n";
                    }

                    echo "<script>$(document).ready(function() {
                    plugin_servicecatalog_favoriteFields($group);
                       });</script>";
                    echo '</table>';
                    echo '</div>';
                    Html::closeForm();
                }
            }
        }
    }

    /**
     * @param $opt
     */
    static function deleteFavoriteTemplate($opt) {

        $favorites = isset($opt['favorites']) ? $opt['favorites'] : [];
        $catFav    = new ITILCategory();
        $favUsers  = new PluginServicecatalogFavorite_User();

        echo "<form action='" . PluginServicecatalogMain::getFormURL() . "' method='post' >";
        echo "<table class='tab_cadre_fixehov'>";
        echo "<tr class='tab_bg_1'>";
        echo "<th colspan='4'>";
        echo __("Select one or more favorites to delete", "servicecatalog");
        echo "</th>";
        echo "</tr>";
        echo Html::hidden('users_id', ['value' => $opt['users_id']]);
        echo Html::hidden('level', ['value' => $opt['level']]);
        echo Html::hidden('type', ['value' => $opt['type']]);
        if (count($favorites) > 0) {
            foreach ($favorites as $key => $value) {
                $type = $favUsers->getTypesFavorites($value['type_favorites']);
                $catFav->getFromDB($value['favorite_itilcategories_id']);
                $name = $catFav->getName();
                if ($value['favorite_itilcategories_id'] == 0) {
                    $name = __("Homepage", "servicecatalog");
                }
                echo "<tr class='tab_bg_2'>";
                echo "<td>";
                Html::showMassiveActionCheckBox(__CLASS__, $value['favorites_id']);
                echo "</td>";
                echo "<td>" . $type . "</td>";
                echo "<td> {$value['completename']}" . " " . __("stored in category", "servicecatalog") . " " . "<b>{$name}</b></td>";
                echo "</tr>";
                echo "</td>";
            }
            echo "<td class='center' colspan='4'>";
            echo Html::submit(_sx('button', 'Delete permanently'), ['name' => 'delete_favorite', 'class' => 'btn btn-primary']);
        } else {
            echo "<tr class='tab_bg_2'>";
            echo "<td class='center' colspan='4'>" . __('No item to display') . "</td></tr>";
        }
        echo "</table>";
        Html::closeForm();
    }


    /**
     * @param $opt
     */
    static function addFavoriteTemplate($opt) {

        echo "<form action='" . PluginServicecatalogMain::getFormURL() . "' method='post' >";
        echo "<table class='tab_cadre_fixehov'>";
        echo "<tr class='tab_bg_2'>";
        echo "<th colspan='2'>";
        echo __("Add a favorite", "servicecatalog");
        echo "</th>";
        echo "</tr>";
        echo Html::hidden('users_id', ['value' => $opt['users_id']]);
        echo Html::hidden('level', ['value' => $opt['level']]);
        echo Html::hidden('type', ['value' => $opt['type']]);

        echo "<tr class='tab_bg_2'><td colspan='1'>" . __("Select a favorite category", "servicecatalog") . "</td>";
        echo "<td colspan='1'>";
        $used         = self::getFavoritesUsed();
        $cond_visible = ["level != '1'", "is_helpdeskvisible = '1'"];

        ITILCategory::dropdown(['condition' => $cond_visible,
                                'name'      => 'itilcategories_id',
                                'value'     => 'itilcategories_id',
                                'used'      => $used,
                                'entity'    => $_SESSION['glpiactive_entity'],]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_2'><td colspan='1'>" . __("Choose the category where to display the favorite", "servicecatalog") . "</td>";
        echo "<td colspan='1'>";
        $cond_visible = ((isset($_SESSION['glpiactiveprofile']['interface'])
                          && Session::getCurrentInterface() == 'central') ? ["1" => "1"] : ["is_helpdeskvisible" => "1"]);
        ITILCategory::dropdown(['condition' => $cond_visible,
                                'name'      => "favorite_itilcategories_id",
                                'entity'    => $_SESSION['glpiactive_entity']]);

        echo "</td>";
        echo "</tr>";

        echo "<td class='tab_bg_1 center' colspan='4'>";
        echo Html::submit(_sx('button', 'Save'), ['name' => 'add_favorite', 'class' => 'btn btn-primary']);
        echo "<br><br><div class='alert alert-info' role='alert'>";
        echo __("You have to log in again to see your favorites", "servicecatalog");
        echo "</div>";
        echo "</table>";
        Html::closeForm();
    }

    /**
     * @param $class
     *
     * @return string
     */
    static function getWidgetFavorites($id) {

        $delclass = "";
        if (Session::haveRight("plugin_servicecatalog_favorites", READ)) {
            $delclass = "delclass";
        }
        //
        $display = "<div id='" . $id . "' class=\"bt-row $delclass\">";
        $display .= self::showFavorites();
        $display .= "</div>";

        return $display;
    }

    /**
     * @param $widget
     *
     * @return string|void
     */
    static function showFavorites() {

        $display = "";

        $display .= "<div id='content' class='sc-content'>";
        $display .= "<div class='bt-container'>";
        $display .= "<div class='bt-block bt-features'>";

        $config = new PluginServicecatalogConfig();
        $widget = new PluginServicecatalogWidget();

        $title   = PluginServicecatalogConfig::displayField($config, 'title_favorites_category');
        $display .= PluginServicecatalogWidget::getNavigationTitle($title);

        if ($widget->fields['display_incident'] == 1) {
            $params['type'] = Ticket::INCIDENT_TYPE;
            $display        .= "<div class='widgetfav'>";
            $display        .= "<div class='btn btn-alert' style='margin-right: 5px;margin-bottom: 5px;padding: 15px;'  title='" . __('Incidents', 'servicecatalog') . "'>";
            $addstyle       = "style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';color:gray;\"";
            $display        .= "<i $addstyle class='fas " . $widget->fields['fa_incident'] . " fa-1x'></i>";
            $display        .= "</div>";
            $display        .= self::getList($config, $params);
            $display        .= "</div>";
        }
        if ($widget->fields['display_request'] == 1) {
            $params['type'] = Ticket::DEMAND_TYPE;
            $display        .= "<div class='widgetfav'>";
            $display        .= "<div class='btn btn-alert' style='margin-right: 5px;margin-bottom: 5px;padding: 15px;' title='" . __('Requests', 'servicecatalog') . "'>";
            $addstyle       = "style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';color:gray;\"";
            $display        .= "<i $addstyle class='fas " . $widget->fields['fa_request'] . " fa-1x'></i>";
            $display        .= "</div>";

            $display .= self::getList($config, $params);
            $display .= "</div>";
        }
        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";

        return $display;
    }

    /**
     * @param $config
     * @param $params
     *
     * @return string
     */
    static function getList($config, $params) {
        global $DB;

        switch ($params['type']) {
            case Ticket::INCIDENT_TYPE:
                $crit = "AND `glpi_itilcategories`.`is_incident` = 1 
                     AND `glpi_itilcategories`.`is_helpdeskvisible` = 1 
                     AND `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id` = 0 ";
                break;
            case Ticket::DEMAND_TYPE:
                $crit = "AND `glpi_itilcategories`.`is_request` = 1 
                     AND `glpi_itilcategories`.`is_helpdeskvisible` = 1 
                     AND `glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id` = 0 ";
                break;
            default:
                $crit = "";
                break;
        }


        $query = "SELECT `glpi_itilcategories`.`completename`, 
                        `glpi_itilcategories`.`id`,
                        `glpi_itilcategories`.`level`
                   FROM `glpi_plugin_servicecatalog_favorites` 
                   LEFT JOIN `glpi_itilcategories`
                        ON (`glpi_itilcategories`.`id` = `glpi_plugin_servicecatalog_favorites`.`itilcategories_id`)"
                 . PluginServicecatalogFavorite::addVisibilityJoins();
        $query .= "WHERE " . PluginServicecatalogFavorite::addVisibilityRestrict() . " $crit ";

        $result = $DB->query($query);
        $nb     = $DB->numrows($result);

        $output = "";
        if ($nb > 0) {
            while ($row = $DB->fetchArray($result)) {

                $cat = new ITILCategory();
                $cat->getFromDB($row['id']);
                //                $datas['id'] = $row['id'];
                //                $datas       = $cat->findCategory($row['id'], $datas);

                if (empty($completename = DropdownTranslation::getTranslatedValue(
                    $row['id'],
                    ITILCategory::class,
                    'completename',
                    $_SESSION['glpilanguage']
                ))) {
                    $completename = $row['completename'];
                }
                $btn                     = "favsc-";//
                $id_cat                  = $category_id = $row['id'];
                $opt['id_cat']           = $id_cat; //for displaycat
                $opt['display']          = false;
                $opt['first']            = 0;
                $opt['display_favorite'] = 1;
                $opt['display_mostused'] = 0;
                $opt['btn']              = $btn;
                $opt['count']            = 0;
                $catfirsts               = 0;
                $opt['onclick']          = "";
                $onclick                 = 0;
                $type                    = $params['type'];

                $category['comment'] = $cat->fields['comment'];

                $helpdesk_category = new PluginServicecatalogCategory();
                //find category in helpdesk category
                $helpdesk_category->getFromDBByCategory($row['id']);

                $addstyle = "style='margin-right: 5px;'";

                $addclass = "";
                if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                    $addclass = "card";
                }
                //                $addclass .= " child-nav";

                $comment = !empty($category['comment']) ? $category['comment'] : "";

                if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
                    || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                    $color    = PluginServicecatalogCategory::getUsedConfig("inherit_config", $id_cat, "background_color");
                    $addstyle = "style=\"background-color: $color !important;margin-right: 5px;\"";
                    //                    $addclass = "btn ";
                }

                $output .= "<div title=\"$comment\" class='" . $btn . "normal $addclass'  $addstyle id=cat" . $category_id . "  " . $onclick . ">";

                $title = $completename;

                $target = "";
                $use_website_url = $helpdesk_category->fields['use_website_url'] ?? 0;
                $website_url = $helpdesk_category->fields['website_url'] ?? '';
                $itilcat = new ITILCategory();
                $itilcat->getFromDB($category_id);
                $level = $itilcat->fields['level'];
                $id_parent = $itilcat->fields['itilcategories_id'];
                if (count(PluginServicecatalogCategory::getSons($category_id, $type))) {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$category_id&choose_category=$id_parent";
                } else {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . '/front/newticket.form.php?create_ticket&category_id=';
                    $url .= $category_id;
                    $url .= '&type=' . $type;
                }
                if ($use_website_url && !empty($website_url)) {
                    if ($use_website_url && $helpdesk_category->fields['website_target'] == 0) {
                        $target = 'target="_blank"';
                    }
                    $url = $website_url;
                }

                $output .= "<a href='$url' $target title=\"" . $title . "\">";

                $config = new PluginServicecatalogConfig();
                if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                    $output .=PluginServicecatalogSly::showCategoryLogo($helpdesk_category, $opt);
                } elseif ($config->getLayout() == PluginServicecatalogConfig::WRAPPER) {
                    $output .=PluginServicecatalogWrapper::showCategoryLogo($helpdesk_category, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
                    $output .=PluginServicecatalogWrappersly::showCategoryLogo($helpdesk_category, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL) {
                    $output .=PluginServicecatalogThumbnail::showCategoryLogo($helpdesk_category, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                    $output .=PluginServicecatalogThumbnailwrapper::showCategoryLogo($helpdesk_category, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED) {
//                        $output .=PluginServicecatalogBootstrappe::showCategoryLogo($helpdesk_category, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
//                        $output .=PluginServicecatalogBootstrappedcolor::showCategoryLogo($helpdesk_category, $opt);
                }

                //                if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                //                    $output .= '<div class="card-body">';
                //                    $output .= '<h5 class="card-title">';
                //                }
                $style  = "";
                $stylei = "";
                //color first categories
                if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
                    || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                    $color  = PluginServicecatalogCategory::getUsedConfig("inherit_config", $id_cat, "background_color");
                    $stylei = "style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"";
                }

                if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY
                    || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL
                    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    $color  = PluginServicecatalogCategory::getUsedConfig("inherit_config", $id_cat, "background_color");
                    $style  = "style=\"color: $color !important;\"";
                    $stylei = "style=\"color: $color !important;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"";
                }

                if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                    $color = PluginServicecatalogCategory::getUsedConfig("inherit_config", $row['id'], "background_color");
                    $color = ($color == null ? $config->getGeneralColor() : $color);
                    if ($config->getGeneralColor() || $color != null) {
                        $style  = "style=\"color: $color !important;\"";
                        $stylei = "style=\"color: $color !important;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"";
                    } else {
                        $style  = "";
                        $stylei = "style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"";
                    }
                }

                $fa_style = '';
                if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
                    $output .= "<span $style>";
                } else {
                    $output .= "<span class=\"label_favtitle bottom_title\" $style>";
                }
                if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    $fa_style = PluginServicecatalogCategory::getUsedConfig("inherit_config", $id_cat, 'icon');
                    if (empty($fa_style)) {
                        if (!empty($config->fields['default_icon'])) {
                            $fa_style = $config->fields['default_icon'];
                        }
                    }
                }
                $output .= "<i class=\"fas $fa_style sc-fa-color fa-2x\" aria-hidden=\"true\" $stylei></i>&nbsp;";

                if ($type == Ticket::INCIDENT_TYPE) {
                    $field = $helpdesk_category->fields['simplified_name_incident'] ?? "";
                } else {
                    $field = $helpdesk_category->fields['simplified_name_request'] ?? "";
                }
                $r = 35;
                if (isset($field) && $field != "") {
                    $name = Html::resume_text($field, $r);
                } elseif ($cat->fields['name'] != "") {
                    $name = Html::resume_text($cat->fields['name'], $r);
                } else {
                    $name = NOT_AVAILABLE;
                }
                $output .= $name;
                $output .= "</span>";

                //                if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                //                    $output .= "</h5>";
                //                    $output .= "</div>";
                //                }

                $output .= "</a>";
                //                if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                $output .= "</div>";
                //                }
                //                if ($config->getLayout() != PluginServicecatalogConfig::SLY
                //                    && $config->getLayout() != PluginServicecatalogConfig::THUMBNAIL
                //                    && $config->getLayout() != PluginServicecatalogConfig::THUMBNAIL_WRAPPER
                //                    && $config->getLayout() != PluginServicecatalogConfig::BOOTSTRAPPED
                //                    && $config->getLayout() != PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                //                    $output .= "</div>";
                //                } else {
                //                    $output .= "</li>";
                //                }
            }
        } else {
            $output .= "<div class='alert alert-light' role='alert'>";
            $output .= __('No data available', 'servicecatalog');
            $output .= "</div>";
        }
        return $output;
    }
}
