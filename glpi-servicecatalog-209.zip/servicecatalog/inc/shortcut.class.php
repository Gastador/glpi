<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

class PluginServicecatalogShortcut extends CommonDBTM
{
    public static $rightname = "plugin_servicecatalog_shortcuts";
    public static $notable = true;
    const OBJECT_FAQ = 1;
    const OBJECT_SCCATEGORY = 2;
    const OBJECT_METADEMAND = 3;
    const OBJECT_SCPAGE = 4;
    const HOME_PAGE = 1;
    const FAQ_PAGE = 2;
    const FIRSTLVL_CATEGORY_DEMAND_PAGE = 3;
    const FIRSTLVL_CATEGORY_INCIDENT_PAGE = 4;
    const TICKET_PAGE = 5;
    const TICKET_VALIDATE_PAGE = 6;
    const TICKET_RESOLVED_PAGE = 7;

    /**
     * @param int $nb
     *
     * @return translated
     */
    static function getTypeName($nb = 0)
    {
        return _n('Shortcut', 'Shortcuts', $nb, 'servicecatalog');
    }

    /**
     * Get available object
     *
     */
    public static function getEnumObject(): array
    {
        return [
            self::OBJECT_FAQ => __('FAQ'),
            self::OBJECT_SCCATEGORY => __('Service catalog category', 'servicecatalog'),
            self::OBJECT_METADEMAND => __('Meta-demand', 'servicecatalog'),
            self::OBJECT_SCPAGE => __('Service catalog page', 'servicecatalog')
        ];
    }


    public static function getEnumPage(): array
    {
        return [
            self::HOME_PAGE => __('Home page', 'servicecatalog'),
            self::FAQ_PAGE => __('FAQ page', 'servicecatalog'),
            self::FIRSTLVL_CATEGORY_DEMAND_PAGE => __('Top-level categories page for requests', 'servicecatalog'),
            self::FIRSTLVL_CATEGORY_INCIDENT_PAGE => __('Top-level categories page for incidents', 'servicecatalog'),
            self::TICKET_PAGE => __('Ticket page', 'servicecatalog'),
            self::TICKET_RESOLVED_PAGE => __('Resolved ticket page', 'servicecatalog'),
            self::TICKET_VALIDATE_PAGE => __('Validate ticket page', 'servicecatalog')
        ];
    }

    /**
     * Return the name of the object
     * @return string
     */
    public static function getOjectLinkName($object)
    {
        switch ($object) {
            case self::OBJECT_FAQ :
                return "Faq";
            case self::OBJECT_SCCATEGORY:
                return "ServiceCatalogCategory";
            case self::OBJECT_METADEMAND:
                return "Metademand";
            case self::OBJECT_SCPAGE:
                return "ServiceCatalogPage";
        }
    }

    public static function getPageLinkName($page)
    {
        switch ($page) {
            case self::HOME_PAGE:
                return "main.form.php";
            case self::FAQ_PAGE:
                return "faq.php";
            case self::FIRSTLVL_CATEGORY_DEMAND_PAGE:
                return "choosecategory.form.php?type=2&level=1";
            case self::FIRSTLVL_CATEGORY_INCIDENT_PAGE:
                return "choosecategory.form.php?type=1&level=1";
            case self::TICKET_PAGE:
                return "ticket.php";
            case self::TICKET_VALIDATE_PAGE:
                return "ticket_validate.php";
            case self::TICKET_RESOLVED_PAGE:
                return "resolved_ticket.php";
        }
    }


    /**
     * @param array $options
     *
     * @return array
     */
    function defineTabs($options = [])
    {

        $ong = parent::defineTabs($options);
        $this->addDefaultFormTab($ong);
        return $ong;
    }

    /**
     * get menu content
     *
     * @return array array for menu
     **@since version 0.85
     *
     */
    static function getMenuContent()
    {
        $menu = [];

        $menu['title'] = self::getMenuName();
        $menu['page'] = self::getSearchURL(false);
        $menu['links']['search'] = self::getSearchURL(false);
        if (self::canCreate()) {
            $menu['links']['add'] = self::getFormURL(false);
        }
        $menu['icon'] = self::getIcon();
        return $menu;
    }

    static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        return true;
    }

    /**
     * @return string
     */
    static function getIcon()
    {
        return "ti ti-arrow-big-right";
    }

    /**
     * @param string $interface
     *
     * @return array
     */
    public function getRights($interface = 'central')
    {
        $values = parent::getRights();

        unset($values[READ], $values[UPDATE], $values[DELETE], $values[PURGE]);
        return $values;
    }

    /**
     * @param       $ID
     * @param array $options
     *
     * @return bool
     */
    function showForm($ID = -1, $options = [])
    {
        echo "<form id = 'shortcut_form' name='asset_form' method='post' enctype='multipart/form-data' data-submit-once>";
        echo "<table class='tab_cadre_fixe'>";
        echo "<tr><th class='text-center'  colspan='2'><h2>" . __('Creating a shortened link', 'servicecatalog') . "</h2></th></tr>";
        echo "<tr>";
        $rand = mt_rand();
        echo "<td>";
        echo __('Target element type', 'servicecatalog') . "&nbsp;&nbsp;";
        $param = [
            'rand' => $rand,
            'display_emptychoice' => true
        ];
        Dropdown::showFromArray('object', self::getEnumObject(), $param);
        echo "</td>";

        echo "<td>";
        echo __('Entity') . "&nbsp;&nbsp;";
        $param = [
            'name' => 'entities_id'
        ];
        Entity::dropdown($param);
        echo "</td>";
        $param = [
            'objects_id' => '__VALUE__',
            'rand' => $rand
        ];
        Ajax::updateItemOnSelectEvent(
            "dropdown_object$rand",
            "type$rand",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/display_type.php",
            $param
        );
        echo "<tr>";
        echo "<td><span id='item_id'</span></td>";
        echo "<td>";
        echo "<span id='type$rand'></span>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td class='center' colspan='2'>";
        echo "<button type='button' class='btn btn-primary' name='generate'>" . __('Generate shortcut link', 'servicecatalog') . "</button>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td colspan='2' class='text-center'>";
        echo "<span id='generated_link'>";
        echo "</span>";
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        Html::closeForm();
        echo "<script>
                $('select').on('change', function(){
                 formDatas = $('#shortcut_form').serializeArray();
                 console.log(formDatas);
                 $.ajax({
                    url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/display_item_id.php',
                                   type: 'POST',
                                   datatype: 'JSON',
                                   data: formDatas,
                                   success: function (response) {
                                        $('#item_id').html(response);
                                   },
                                   error: function (xhr, status, error) {
                                      console.log(xhr);
                                      console.log(status);
                                      console.log(error);
                                   }
                 });
             });
            
                        
             $('button[name=\'generate\']').click(function(){
                  formDatas = $('#shortcut_form').serializeArray();
                  $.ajax({
                    url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/generate_link.php',
                                   type: 'POST',
                                   datatype: 'JSON',
                                   data: formDatas,
                                   success: function (response) {
                                     $('#generated_link').html(response);
                                   },
                                   error: function (xhr, status, error) {
                                      console.log(xhr);
                                      console.log(status);
                                      console.log(error);
                                   }
                 });
             
             });
            </script>";
        return true;
    }
}