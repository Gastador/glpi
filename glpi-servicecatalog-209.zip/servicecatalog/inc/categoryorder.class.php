<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogCategory
 */
class PluginServicecatalogCategoryorder extends CommonDBTM
{

    static $rightname = 'plugin_servicecatalog_setup';

   /**
    * functions mandatory
    * getTypeName(), canCreate(), canView()
    *
    * @param int $nb
    *
    * @return string
    */
    static function getTypeName($nb = 0)
    {
        return __('Ticket category ordering', 'servicecatalog');
    }

   /**
    * @param \CommonGLPI $item
    * @param int         $withtemplate
    *
    * @return string
    * @see CommonGLPI::getTabNameForItem()
    */
    function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {

        if ($item->getType() == 'PluginServicecatalogConfig') {
            return self::getTypeName();
        }
        return '';
    }

   /**
    * @param \CommonGLPI $item
    * @param int         $tabnum
    * @param int         $withtemplate
    *
    * @return bool
    * @see CommonGLPI::displayTabContentForItem()
    */
    static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {

        if ($item->getType() == 'PluginServicecatalogConfig') {
            self::showLinkOrder();
        }
        return true;
    }

    static function showLinkOrder()
    {
        global $CFG_GLPI;

        echo "<br><div align='center'>";
        echo "<table class='tab_cadre_fixe'>";
        echo "<tr>";
        echo "<th colspan='2'>";
        echo __('Ticket category ordering', 'servicecatalog');
        echo "</th>";
        echo "</tr>";

        echo "<tr class='tab_bg_2'>";
        echo "<td class='center'>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/categoryorder.form.php?type=" . Ticket::INCIDENT_TYPE . "'>";
        echo __('Incident category ordering', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<td class='center'>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/categoryorder.form.php?type=" . Ticket::DEMAND_TYPE . "'>";
        echo __('Request category ordering', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<tr>";

        echo "</table></div>";
    }

   /**
    * @param      $catId
    * @param      $type
    * @param bool $child
    *
    * @return int
    */
    function hasChildType($catId, $type, $child = false)
    {
        $isType     = 0;
        $categories = new ITILCategory();

        if ($child) {
            $catChilds = $categories->find(['itilcategories_id' => $catId]);
            foreach ($catChilds as $catChild) {
                if (!$isType) {
                    $id = $catChild['id'];
                    if ($type == Ticket::DEMAND_TYPE) {
                        $isType = $catChild['is_request'];
                    } elseif ($type == Ticket::INCIDENT_TYPE) {
                        $isType = $catChild['is_incident'];
                    }
                    if (!$isType) {
                        $isType = $this->hasChildType($id, $type, true);
                    }
                }
            }
        } else {
            if ($categories->getFromDB($catId)) {
                $id = $categories->fields['id'];
                if ($type == Ticket::DEMAND_TYPE) {
                    $isType = $categories->fields['is_request'];
                } elseif ($type == Ticket::INCIDENT_TYPE) {
                    $isType = $categories->fields['is_incident'];
                }
                if (!$isType) {
                    $isType = $this->hasChildType($id, $type, true);
                }
            }
        }

        return $isType;
    }

   /**
    * Load categories
    *
    * @param $type
    */
    function loadCategories($type)
    {

        $this->deleteByCriteria(['type' => $type, 'entities_id' => $_SESSION["glpiactive_entity"]]);

        $dbu = new DbUtils();

        $condition  = ['is_helpdeskvisible' => 1]
                    + $dbu->getEntitiesRestrictCriteria('glpi_itilcategories', '', $_SESSION["glpiactiveentities"], true);
        $levelMax   = 0;
        $categories = new ITILCategory();
        $categories = $categories->find($condition, 'completename');

        foreach ($categories as $cat) {
            if ($this->hasChildType($cat['id'], $type)) {
                if (!isset($orderCat[$cat['level']])) {
                    $orderCat[$cat['level']] = [];
                }
                if ($levelMax < $cat['level']) {
                    $levelMax = $cat['level'];
                }

                $orderCat[$cat['level']][$cat['id']] = $cat;
            }
        }

        $ranking = 0;
        $parent  = 0;
        for ($level = 1; $level <= $levelMax; $level++) {
            if (isset($orderCat[$level])) {
                foreach ($orderCat[$level] as $categoryByLevel) {
                    if ($parent != $categoryByLevel['itilcategories_id']) {
                        $ranking = 0;
                    }
                    $input['itilcategories_id'] = $categoryByLevel['id'];
                    $input['entities_id']       = $_SESSION["glpiactive_entity"];
                    $input['type']              = $type;
                    $input['ranking']           = $ranking;
                    $input['parent_id']         = $categoryByLevel['itilcategories_id'];
                    $input['level']             = $level;
                    $this->add($input);
                    $ranking++;
                    $parent = $categoryByLevel['itilcategories_id'];
                }
            }
        }
    }

   /**
    * @param $type
    *
    * @throws \GlpitestSQLError
    */
    function addNewCategories($type)
    {
        global $DB;

        $dbu = new DbUtils();
        $ok  = 0;
       //Get All parents categories
        $typeSql = '';
        if ($type == Ticket::DEMAND_TYPE) {
            $typeSql = ' AND is_request = 1 ';
        } elseif ($type == Ticket::INCIDENT_TYPE) {
            $typeSql = ' AND is_incident =1 ';
        }
        $condition = $dbu->getEntitiesRestrictRequest(" AND ", 'glpi_itilcategories', '', $_SESSION["glpiactive_entity"]);
        $query     = "SELECT id,itilcategories_id FROM `glpi_itilcategories`
                WHERE is_helpdeskvisible = 1" .
                   $condition . $typeSql;
        $result    = $DB->query($query);
        while ($array = $DB->fetchAssoc($result)) {
            $idCat[$array['itilcategories_id']][$array['id']] = ['parent_id'         => $array['itilcategories_id'],
                                                              'itilcategories_id' => $array['id']];
        }
       //Check Max ranking by parent id
        $query       = "SELECT parent_id, MAX(ranking) AS max FROM `glpi_plugin_servicecatalog_categoryorders`
                WHERE `type` = '" . $type . "'
                AND `entities_id` = '" . $_SESSION["glpiactive_entity"] . "'
                GROUP BY parent_id";
        $resultOrder = $DB->query($query);
        if ($DB->numrows($resultOrder)) {
            while ($arrayMax = $DB->fetchAssoc($resultOrder)) {
                $max    = $arrayMax['max'];
                $parent = $arrayMax['parent_id'];
               //Remove from array off all categories parents
                if (isset($idCat[$parent])) {
                    unset($idCat[$parent]);
                }

               //check itil categories not in table for each childs & parents
                $condition = ['type'        => $type,
                          'entities_id' => $_SESSION["glpiactive_entity"],
                          'parent_id'   => $parent];
                $result    = $this->find($condition, "id");
                $catorders = [];
                if (count($result) > 0) {
                    foreach ($result as $data) {
                        $catorders[] = $data["itilcategories_id"];
                    }
                }

                $news = [];

                $condition = ['is_helpdeskvisible' => 1,
                          'itilcategories_id'  => $parent]
                         + $dbu->getEntitiesRestrictCriteria('glpi_itilcategories', '', $_SESSION["glpiactive_entity"]);

                $itil_category = new ITILCategory();
                $categories    = $itil_category->find($condition, "id");

                if (count($categories) > 0) {
                    foreach ($categories as $cat) {
                        if ($this->hasChildType($cat['id'], $type)) {
                            if (!in_array($cat["id"], $catorders)) {
                                $news[] = $cat;
                            }
                        }
                    }
                }
                if (count($news) > 0) {
                    foreach ($news as $data) {
                        $input['itilcategories_id'] = $data['id'];
                        $input['entities_id']       = $_SESSION["glpiactive_entity"];
                        $input['type']              = $type;
                        $input['ranking']           = $max + 1;
                        $input['parent_id']         = $data['itilcategories_id'];
                        $input['level']             = $data['level'];
                        $this->add($input);
                        $max++;
                        $ok = 1;
                    }
                }
            }
           //Foreach categories without child in ordercat
            $i = 0;
            foreach ($idCat as $id) {
                $categorieOrder = new self();
                foreach ($id as $cat) {
                    $categorieOrder->getFromDBByCrit(['itilcategories_id' => $cat['parent_id'],
                                                 'type'              => $type]);
                    if ($categorieOrder) {
                           $input['itilcategories_id'] = $cat['itilcategories_id'];
                           $input['entities_id']       = $_SESSION["glpiactive_entity"];
                           $input['type']              = $type;
                           $input['ranking']           = 0 + $i;
                           $input['parent_id']         = $cat['parent_id'];
                           $input['level']             = intval($categorieOrder->getField('level')) + 1;
                           $this->add($input);
                           $max++;
                           $i++;
                           $ok = 1;
                    }
                }
            }
        } else {
            $this->loadCategories($type);
        }

        if ($ok > 0) {
            $message = __('New categories added', 'servicecatalog');
        } else {
            $message = __('No new categories found', 'servicecatalog');
        }
        Session::addMessageAfterRedirect($message);
    }

   /**
    * Display form
    *
    * @param $type
    */
    function showCategoryOrderForm($type)
    {

        if (count($_SESSION["glpiactiveentities"]) > 1) {
            $message = __('You must choose a entity before ordering categories', 'servicecatalog');
            Html::displayErrorAndDie($message);
        } else {
            $dbu       = new DbUtils();
            $condition = ['type' => $type]
                      + $dbu->getEntitiesRestrictCriteria('glpi_plugin_servicecatalog_categoryorders', '', $_SESSION["glpiactive_entity"]);

            if (isset($_GET['cat_id'])) {
                $condition['parent_id'] = $_GET['cat_id'];
            } else {
                $condition['parent_id'] = 0;
            }

            $order  = new self();
            $result = $order->find($condition, "ranking");

            if (count($result) > 0) {
                echo "<table class='tab_cadre_fixehov'>";
                echo "<tr>";
                echo "<th colspan='4'>";
                if (Ticket::INCIDENT_TYPE == $type) {
                    echo __('Incident category ordering', 'servicecatalog');
                } else {
                    echo __('Request category ordering', 'servicecatalog');
                }

                echo "</th>";
                echo "</tr>";

                echo '</table>';

                echo "<form name='form' method='post' id='form$type 'action='" .
                 Toolbox::getItemTypeFormURL('PluginServicecatalogCategoryorder') . "'>";

                echo "<div id='drag'>";
                echo "<table class='tab_cadre_fixehov'>";

                echo Html::hidden('type', ['id' => 'type', 'value' => $type]);
                echo Html::hidden('entity', ['id' => 'entity','value' => $_SESSION["glpiactive_entity"]]);
                $parent_id = 0;

                foreach ($result as $data) {
                    $itil_category = new ITILCategory();
                    if (!$itil_category->getFromDB($data['itilcategories_id'])) {
                        if ($order->delete($data)) {
                             $condition_del['parent_id'] = $data['parent_id'];
                             $condition_del['ranking']   = ['>', $data['ranking']];
                             $condition_del['type']      = $type;
                             $updateRank                 = $order->find($condition_del, "ranking");
                            if (count($updateRank) > 0) {
                                foreach ($updateRank as $update) {
                                      $order->update(['id'      => $update['id'],
                                           'ranking' => $update['ranking'] - 1]);
                                }
                                echo Html::scriptBlock("location.reload();");
                            }
                        }
                    } else {
                        echo "<tr class='tab_bg_2'>";
                        if ($_SESSION['glpi_use_mode'] == Session::DEBUG_MODE) {
                            echo '<td class="rowhandler control center">';
                            echo "<div class=\"drag row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                            echo $data['itilcategories_id'];
                            echo '</div>';
                            echo '</td>';
                        }
                        echo '<td class="rowhandler control center">';
                        echo "<div class=\"drag row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";

                        $itil_category = new ITILCategory();
                        $itil_category->getFromDB($data['itilcategories_id']);
                        echo Dropdown::getDropdownName("glpi_entities", $data['entities_id']);
                        echo " - ";
                        echo $itil_category->fields['completename'];
                        echo '</div>';
                        echo '</td>';

                        echo '<td class="rowhandler control center">';
                        echo "<div class=\"drag row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                        echo $data['ranking'];
                        echo '</div>';
                        echo '</td>';

                        echo '<td class="rowhandler control center">';
                        echo "<div class=\"drag row\" style=\"cursor: move;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                        echo "<i class=\"fas fa-grip-horizontal grip-rule\"></i>";
                        echo '</div>';
                        echo '</td>';

                        $order  = new self();
                        $childs = $order->find(["parent_id" => $data['itilcategories_id'],
                                          "type"      => $type]);

                        if (count($childs) > 0) {
                            echo '<td class="rowhandler control center">';
                            echo "<div class=\"\" style=\"cursor: pointer;border-width: 0 !important;border-style: none !important; border-color: initial !important;border-image: initial !important;\">";
                            echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/categoryorder.form.php?type=" . $type . "&cat_id=" . $data['itilcategories_id'] . "'>";
                            echo "<i class=\"fas fa-arrow-right\"></i>";
                            echo "</a>";
                            echo '</div>';
                            echo '</td>';
                        } else {
                            echo '<td class="rowhandler control center"></td>';
                        }

                        echo "</tr>\n";
                        $parent_id = $data['parent_id'];
                    }
                }
                echo Html::hidden('parent_id', ['id' => 'parent_id','value' => $parent_id]);

                echo '</table>';
                echo '</div>';
                echo Html::scriptBlock('$(document).ready(function() {plugin_servicecatalog_redipsInit()});');
            }

            Html::closeForm();

            echo "<br><div align='center'>";
            echo "<table class='tab_cadre_fixehov'>";
            echo "<tr class='tab_bg_2'>";
            echo "<td class='center'>";
            echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/categoryorder.form.php?addnew=1&type=" . $type . "'>";
            echo __('Add new categories from GLPI', 'servicecatalog');
            echo "</a>";
            echo "</td>";
            echo "<td class='center'>";
            $msg = __("Are you sure you want to reload the categories, the ordering will be lost", 'servicecatalog');
            echo "<a onclick=\"return confirm('Are you sure you want to reload the categories, the ordering will be lost');\" 
         href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/categoryorder.form.php?reload=1&type=" . $type . "'>";
            echo __('Load categories from GLPI', 'servicecatalog');
            echo "</a>";
            echo "</td>";
            echo "<tr>";
            echo "</table></div>";
        }
        $buttons["config.form.php"] = __('Return to plugin setup', 'servicecatalog');
        if (isset($_GET['cat_id'])) {
            $buttons["categoryorder.form.php?type=" . $type] = __('Return to first category level', 'servicecatalog');
        }
        Html::displayTitle(
            "",
            __('Return to plugin setup', 'servicecatalog'),
            "",
            $buttons
        );
    }

   /**
    * @param array $params
    */
    public function reorder(array $params)
    {
        if (isset($params['old_order']) && isset($params['new_order'])) {
            $crit = [
            'type'        => $params['container_id'],
            'entities_id' => $params['entities_id'],
            'ranking'     => $params['old_order'],
            'parent_id'   => $params['parent_id'],
            ];

            $itemMove = new self();
            $itemMove->getFromDBByCrit($crit);

            if (isset($itemMove->fields["id"])) {
                if ($params['old_order'] < $params['new_order']) {
                    $toUpdateList = $this->find([
                                              'type'        => $params['container_id'],
                                              'entities_id' => $params['entities_id'],
                                              '`ranking`'   => ['>', $params['old_order']],
                                              'ranking'     => ['<=', $params['new_order']],
                                              'parent_id'   => $params['parent_id']
                                           ]);

                    foreach ($toUpdateList as $toUpdate) {
                          $this->update([
                                   'id'      => $toUpdate['id'],
                                   'ranking' => $toUpdate['ranking'] - 1
                                ]);
                    }
                } else {
                    $toUpdateList = $this->find([
                                              'type'        => $params['container_id'],
                                              'entities_id' => $params['entities_id'],
                                              '`ranking`'   => ['<', $params['old_order']],
                                              'ranking'     => ['>=', $params['new_order']],
                                              'parent_id'   => $params['parent_id']
                                           ]);

                    foreach ($toUpdateList as $toUpdate) {
                        $this->update([
                                   'id'      => $toUpdate['id'],
                                   'ranking' => $toUpdate['ranking'] + 1
                                ]);
                    }
                }

                if (isset($itemMove->fields["id"]) && $itemMove->fields['id'] > 0) {
                    $this->update([
                                'id'      => $itemMove->fields['id'],
                                'ranking' => $params['new_order']
                             ]);
                }
            }
        }
    }
}
