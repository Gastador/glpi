<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogDashboard
 */
class PluginServicecatalogDashboard extends CommonDBTM
{
    public static $rightname = 'plugin_servicecatalog_defaultview';

    /**
     * Return the localized name of the current Type
     * Should be overloaded in each new class
     *
     * @param integer $nb Number of items
     *
     * @return string
     **/
    public static function getTypeName($nb = 0)
    {
        return __('Dashboard', 'servicecatalog') . " " . __('Service catalog', 'servicecatalog');
    }

    /**
     * @param $users_id
     *
     * @param $entities_id
     * @param $profiles_id
     *
     * @return int
     */
    public static function checkIfPreferenceExists($users_id, $entities_id, $profiles_id)
    {
        return self::checkPreferenceValue('id', $entities_id, $users_id, $profiles_id);
    }

    /**
     * @param     $field
     * @param int $users_id
     *
     * @param     $entities_id
     * @param int $profiles_id
     *
     * @return int
     */
    public static function checkPreferenceValue($field, $entities_id, $users_id = 0, $profiles_id = 0)
    {
        $dbu  = new DbUtils();
        $self = new self();

        if ($self->find(["entities_id" => $entities_id])) {
            $restrict = ["users_id"    => $users_id,
                         "profiles_id" => $profiles_id,
                         "entities_id" => $entities_id];
        } else {
            $restrict = ["users_id"    => $users_id,
                         "profiles_id" => $profiles_id] +
                        $dbu->getEntitiesRestrictCriteria($self->getTable(), '', $entities_id, true);
        }


        $data = $dbu->getAllDataFromTable($dbu->getTableForItemType(__CLASS__), $restrict);

        if (!empty($data)) {
            $first = array_pop($data);
            return $first[$field];
        } else {
            return 0;
        }
    }

    /**
     * @param string $interface
     *
     * @return array
     */
    public function getRights($interface = 'central')
    {
        $values = parent::getRights();

        unset($values[READ], $values[UPDATE], $values[DELETE], $values[PURGE]);
        return $values;
    }

    /**
     * @param \CommonGLPI $item
     * @param int         $withtemplate
     *
     * @return string
     * @see CommonGLPI::getTabNameForItem()
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item->getType() == 'Entity') {
            return self::getTypeName(2);
        }
        return '';
    }

    /**
     * @param \CommonGLPI $item
     * @param int         $tabnum
     * @param int         $withtemplate
     *
     * @return bool
     * @see CommonGLPI::displayTabContentForItem()
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if ($item->getType() == 'Entity') {
            $self = new self();
            $self->showDisplaySetup($item->getID());
        }
        return true;
    }

    /**
     * @param $ID
     */
    public static function showDisplaySetup($ID)
    {
        global $CFG_GLPI;

        $self = new self();
        echo "<div align='center'>";
        echo "<table class='tab_cadre_fixe'>";
        echo "<tr>";
        echo "<th colspan='2'>";
        echo self::getTypeName();
        echo "</th>";
        echo "</tr>";

        $form = Toolbox::getItemTypeFormURL('PluginServicecatalogEntity');

        if ($self->find(["entities_id" => $ID])) {
            echo "<tr class='center tab_bg_1'>";
            echo "<td colspan='2'> " . __('This entity use her own dashboard display', 'servicecatalog') . "</td>";
            echo "</tr>";
        } else {
            echo "<tr class='center tab_bg_1'>";
            echo "<td colspan='2'> " . __('This entity use parent dashboard display', 'servicecatalog') . "</td>";
            echo "</tr>";
        }
        if ($self->find(["entities_id" => $ID])) {
            echo "<tr class='center tab_bg_2'>";
            echo "<td colspan='2'>";

            echo Html::getSimpleForm(
                $form,
                'delete_entity',
                "",
                ["entities_id" => $ID],
                "fa-times-circle fa-1x",
                "class='submit btn btn-default'",
                __('Are you sure you want to delete this default dashboard ?', 'servicecatalog')
            );
            echo "</td>";
            echo "</tr>";
        }
        echo "</table></div><br>";

        if ($self->getFromDBByCrit(['entities_id' => $ID,
                                    'users_id' => 0])) {
            echo "<form name='form' method='post' action='" .
                $form . "'>";
            echo "<div align='center'>";
            echo "<table class='tab_cadre_fixe'>";
            echo "<th colspan='2'>";
            echo __('Childs use the same dashboard', 'servicecatalog');
            echo "</th>";

            echo "<tr class='center tab_bg_1'>";
            echo "<td colspan='2'>";
            Dropdown::showYesNo("is_recursive", $self->fields["is_recursive"]);
            echo "</td>";
            echo "</tr>";

            echo "<tr class='center tab_bg_2'>";
            echo "<td colspan='2'>";
            echo Html::hidden('id', ['value' => $self->fields['id']]);
            echo Html::submit(_sx('button', 'Update'), ['name' => 'update_entity', 'class' => 'btn btn-primary']);
            echo "</td>";
            echo "</tr>";
            echo "</table></div>";
            Html::closeForm();
        }

        echo "<div align='center'>";
        echo "<table class='tab_cadre_fixe'>";
        echo "<tr class='tab_bg_1'>";
        echo "<th colspan='2'> " . __('You want to setup the dashboard display for this entity (& childs) ?', 'servicecatalog') . "</th>";
        echo "</tr>";
        echo "<tr class='tab_bg_1'>";
        echo "<td colspan='2' class='center'>";
        echo "<a class='submit btn btn-primary' href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php?setup_entity=$ID'>";
        echo __('Custom and save default grid', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "</tr>";
        echo "</table></div>";
    }

    /**
     * @param $entities_id
     *
     * @return int|mixed
     */
    public function checkDragMode($entities_id)
    {
        $drag_mode = 0;
        if (Session::haveRight("plugin_servicecatalog_resize", CREATE)) {
            $profile = $_SESSION['glpiactiveprofile']['id'];
            $id      = self::checkIfPreferenceExists(Session::getLoginUserID(), $entities_id, $profile);
            if ($id) {
                $this->getFromDB($id);
                $drag_mode = $this->fields['drag_mode'];
            } elseif (Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
                $id = self::checkIfPreferenceExists(0, $entities_id, 0);
                if ($id) {
                    $this->getFromDB($id);
                    $drag_mode = $this->fields['drag_mode'];
                }
            }
        }
        return $drag_mode;
    }

    /**
     * @throws \GlpitestSQLError
     */
    public function loadDashboard()
    {
        Html::requireJs('gridstack');
        echo Html::css("/public/lib/gridstack.css");
        echo Html::scss("/css/standalone/gridstack-grids.scss");

        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/circles/circles.min.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/echarts/echarts.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/echarts/theme/blue.js");
        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/datatables.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/datatables.min.js");

        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Responsive-2.3.0/css/responsive.dataTables.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Responsive-2.3.0/js/dataTables.responsive.min.js");
        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Select-1.4.0/css/select.dataTables.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Select-1.4.0/js/dataTables.select.min.js");
        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Buttons-2.2.3/css/buttons.dataTables.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Buttons-2.2.3/js/dataTables.buttons.min.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Buttons-2.2.3/js/buttons.html5.min.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Buttons-2.2.3/js/buttons.print.min.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/Buttons-2.2.3/js/buttons.colVis.min.js");
        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/ColReorder-1.5.6/css/colReorder.dataTables.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/ColReorder-1.5.6/js/dataTables.colReorder.min.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/JSZip-2.5.0/jszip.min.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/pdfmake-0.1.36/pdfmake.min.js");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/datatables/pdfmake-0.1.36/vfs_fonts.js");

        //        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR. "/lib/jquery-ui/jquery-ui.min.css");
        //        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR. "/lib/jquery-ui/jquery-ui.min.js");
        if (Session::getCurrentInterface() == 'central') {
            echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/sc_bootstrap.scss");
        }
        //        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR. "/lib/lodash.min.js");
        //        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR. "/lib/gridstack/src/gridstack.css");
        //        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR. "/lib/gridstack/src/gridstack-extra.css");
        //        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR. "/lib/gridstack/src/gridstack.js");
        //        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR. "/lib/gridstack/src/gridstack.jQueryUI.js");
        //      Html::requireJs('gridstack');


        if (PluginServicecatalogMain::checkBrowser() == false) {
            return false;
        }

        $config = new PluginServicecatalogConfig();
        $config->getConfig();

        $entities_id  = (isset($_GET['setup_entity']) ? $_GET['setup_entity'] : $_SESSION['glpiactive_entity']);
        $setup_entity = (isset($_GET['setup_entity']) ? 1 : 0);

        $drag = $this->checkDragMode($entities_id);

        $dashboard_id = $this->getFromDBByCrit(["entities_id" => $entities_id,
                                                "users_id"    => 0,
                                                "profiles_id" => 0]);

        if ($dashboard_id == 0) {
            if (Session::haveRight("plugin_servicecatalog_view", CREATE)) {
                $drag = 1;
            }
        }

        $grid = "{}";

        $id = self::checkIfPreferenceExists(0, $entities_id, 0);
        if ($this->getFromDB($id)) {
            $grid = stripslashes($this->fields['grid']);
        }
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)) {
            $idu = self::checkIfPreferenceExists(Session::getLoginUserID(), $entities_id, $_SESSION['glpiactiveprofile']['id']);
            if ($this->getFromDB($idu)) {
                $grid = stripslashes($this->fields['grid']);
            }
        }
        $datajson = [];

        if (empty($grid) || $grid == null) {
            $grid = "{}";
        }
        //      if (count($_SESSION["glpiactiveentities"]) > 1) {
        //         $grid = '[{"id":"gs1","x":0,"y":23,"width":12,"height":30}]';
        //      }
        $datagrid = json_decode($grid, true);
        if (is_array($datagrid) && count($datagrid) > 0) {
            foreach ($datagrid as $k => $v) {
                $datajson[$v["id"]] = PluginServicecatalogWidget::getWidget($entities_id, $v["id"]);
            }
        }
        $datajson = json_encode($datajson);
        //FOR ADD NEW WIDGET
        $allwidgetjson = [];
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $widgets = PluginServicecatalogWidget::getWidgetList();
            //TODO DEBUG
//            foreach ($widgets as $k => $val) {
//                $allwidgetjson[$k] = PluginServicecatalogWidget::getWidget($entities_id, $k);
//            }
            foreach ($widgets as $k => $val) {
                $allwidgetjson[$k] = ["<div class='alert alert-success' id='success-alert'>
                <strong>" . __('Success', 'servicecatalog') . "</strong> - 
                " . __('Save grid to see widget', 'servicecatalog') . "
            </div>"];
            }
        }
        $allwidgetjson = json_encode($allwidgetjson);

        //END FOR ADD NEW WIDGET
        $msg_save          = __('Grid saved', 'servicecatalog');
        $msg_default_save  = __('Default grid saved', 'servicecatalog');
        $msg_delete_button = __('Delete widget', 'servicecatalog');
        $msg_delete        = __('Are you sure you wish to delete this widget?', 'servicecatalog');
        $msg_refresh       = __('Refresh widget', 'servicecatalog');
        $disableResize     = 'false';
        $disableDrag       = 'true';
        $delete_button     = 0;
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $disableResize = 'false';
            $disableDrag   = 'false';
            $delete_button = 'true';
        }
        if ($drag > 0) {
            if (Session::haveRight("plugin_servicecatalog_resize", CREATE)) {
                $disableResize = 'false';
                $disableDrag   = 'false';
            }
        } else {
            $disableResize = 'true';
            $disableDrag   = 'true';
        }

        echo "<div id='content' class='sc-content'>";
        echo "<div class='bt-container'>";
        echo "<div class='bt-block bt-features'>";
        $config = new PluginServicecatalogConfig();
        if ($config->getDemoMode() == 1) {
            echo "<div class='alert alert-warning demo alert-dismissible' role='alert'>";
            echo "<a href='#' class='close' data-bs-dismiss='alert' aria-label='close'>&times;</a>";
            $config->showLayoutSelector();
            $config->showColorSelector();
            $config->showDisplayAsTableSelector();
            echo "</div>";
            echo Html::scriptBlock('$(document).ready(function() {
            setTimeout(function() {
                $(".demo").alert("close");
            }, 10000);
            });');
        }

        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            PluginServicecatalogWidget::dropdownWidget($entities_id);
        }
        if (Session::haveRight("plugin_servicecatalog_view", CREATE) ||
            (Session::haveRight("plugin_servicecatalog_resize", CREATE)
             && !Session::haveRight("plugin_servicecatalog_defaultview", CREATE))) {
            echo "&nbsp;";
            echo "<a class='bt-buttons' id='save-grid' href='#' title=\"" . __('Save grid', 'servicecatalog') . "\">";
            echo "<i class='fas fa-save fa-1x'></i>";
            echo "<span class='sr-only'>" . __('Save grid', 'servicecatalog') . "</span>";
            echo "</a>";
        }
        if (Session::haveRight("plugin_servicecatalog_resize", CREATE)) {
            if ($dashboard_id > 0) {
                if ($drag < 1) {
                    echo "&nbsp;";
                    echo "<a class='bt-buttons' id='drag-grid' href='#' title=\"" . __('Permit resize widgets', 'servicecatalog') . "\">";
                    echo "<i class='fas fa-lock'></i>";
                    echo "<span class='sr-only'>" . __('Permit resize widgets', 'servicecatalog') . "</span>";
                    echo "</a>&nbsp;";
                }
                if ($drag > 0) {
                    echo "&nbsp;";
                    echo "<a class='bt-buttons' id='undrag-grid' href='#' title=\"" . __('Block resize widgets', 'servicecatalog') . "\">";
                    echo "<i class='fas fa-unlock-alt'></i>";
                    echo "<span class='sr-only'>" . __('Block resize widgets', 'servicecatalog') . "</span>";
                    echo "</a>&nbsp;";
                }
            }
        }
        if (Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            echo "&nbsp;";
            echo "<a class='bt-buttons' id='save-default-grid' href='#' title=\"" . __('Save default grid', 'servicecatalog') . "\">";
            echo "<i class='fas fa-hdd'></i>";
            echo "<span class='sr-only'>" . __('Save default grid', 'servicecatalog') . "</span>";
            echo "</a>";
            echo "&nbsp;(";
            echo Dropdown::getDropdownName("glpi_entities", $entities_id);
            echo ")&nbsp;";
            if ($_SESSION['glpi_use_mode'] == Session::DEBUG_MODE) {
                echo " - ID : " . $dashboard_id;
            }
            if (count($this->find([
                                      'entities_id' => 0,
                                      'users_id'    => 0,
                                      'profiles_id' => 0
                                  ])) > 1) {
                echo "<div class='alert  alert-danger d-flex'>";
                echo __('Warning ! There is more than one default view - please drop not used views', 'servicecatalog');
                echo "</div>";
            }
        }
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            echo "&nbsp;<a class='bt-buttons' id='clear-grid' href='#' title=\"" . __('Clear grid', 'servicecatalog') . "\">";
            echo "<i class='fas fa-window-restore'></i>";
            echo "<span class='sr-only'>" . __('Clear grid', 'servicecatalog') . "</span>";
            echo "</a>";
        }

        echo Html::hidden('entities_id', ['value' => $entities_id]);

        if (isset($_SESSION['glpiactiveprofile'])
            && $_SESSION['glpiactiveprofile']['interface'] == 'central'
            && isset($_SERVER['HTTP_REFERER'])
            && strpos($_SERVER['HTTP_REFERER'], "plugins/servicecatalog/front/config.form.php") !== false) {
            echo "&nbsp;<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/config.form.php'>";
            echo __('Return to setup', 'servicecatalog');
            echo "</a>";
        }

        echo "<div id='ajax_loader' class='ajax_loader hidden'></div>";
        echo "<div id='scmygrid' class='scmygrid'>";
        echo "<div class='grid-stack'>";
        echo "</div>";

        $seeborder = $config->seeWidgetsBorder();
        $margin    = 5;
        if ($seeborder == true) {
            $margin = 10;
        }
        echo "<script type='text/javascript'>
        $(function () {
            var setup_entity= $setup_entity;  
            var options = {
                 cellHeight: 80,
                 disableResize: $disableResize,
                 disableDrag: $disableDrag,
                 margin: $margin,
                 resizable: {
                    handles: 'e, se, s, sw, w'
                }
            };
            let grid = GridStack.init(options);
            new function () {
                this.loadGrid = function () {
                     grid.removeAll();
                     var items = $grid;
                     if (Array.isArray(items)) {
                         items.forEach(function(node)  {
                             var nodeid = node.id;
                             var widgetArray = $datajson; 
                             var widget = widgetArray['' + nodeid + ''];
                             var delbutton = '';
                             if ($delete_button == 1) {
                                var delbutton = '&nbsp;<button title=\"$msg_delete_button\" class=\"sc-button pull-right\" onclick=\"deleteWidget(\'' + node.id + '\');\"><i class=\"ti ti-x sc-buttons\"></i></button>';
                             } 
//                             else {
//                                var delbutton = ' <span class=\"sc-button pull-right\" style=\"margin:5px\">&nbsp;</span>';
//                             }
                             //No refresh for mydashboard widgets
                             if (node.id == 'gs4' || node.id == 'gs5' || node.id == 'gs6'  || node.id == 'gs19' || node.id == 'gs21') {
                                 if (widget != false) {
                                     var el = '<div class=\"grid-stack-item\" ><div class=\"grid-stack-item-content\" id=\"scgridcontent' + nodeid + '\">' + delbutton + widget + '</div></div>';
    //                                 this.grid.addWidget(el, node.x, node.y, node.width, node.height, true, null, null, null, null, node.id);
                                     grid.addWidget(el,
                                                {
                                                   x: node.x,
                                                   y: node.y,
                                                   w: node.w,
                                                   h: node.h,
                                                   id: node.id,
    //                                               autoPosition: true,
                                                }
                                             );
                                 } else {
                                     widget = $('div[data-gs-id='+ node.id + ']');
                                     if (widget.length != 0) {
                                        this.grid.removeWidget(widget, false);
                                     }
                                 }
                             } else {
                                var el = '<div class=\"grid-stack-item\"><div class=\"grid-stack-item-content\">' + delbutton + widget + '</div></div>';
    //                            this.grid.addWidget(el, node.x, node.y, node.width, node.height, true, null, null, null, null, node.id);
                                  grid.addWidget(el,
                                                {
                                                   x: node.x,
                                                   y: node.y,
                                                   w: node.w,
                                                   h: node.h,
                                                   id: node.id,
    //                                               autoPosition: true,
                                                }
                                             );
                             }
                             refreshWidget(node.id);
                        }, this);
                     }
                    return false;
                }.bind(this);
//                this.saveGrid = function () {
//                    this.serializedData = _.map($('.grid-stack > .grid-stack-item:visible'), function (el) {
//                        el = $(el);
//                        var node = el.data('_gridstack_node');
//                        return {
//                            id: node.id,
//                            x: node.x,
//                            y: node.y,
//                            width: node.width,
//                            height: node.height
//                        };
//                    }, this);
//                    var sData = JSON.stringify(this.serializedData);
//                     $.ajax({
//                       url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/saveGrid.php',
//                       type: 'POST',
//                       data:{data:sData},
//                       success:function(data) {
////                         alert('$msg_save');
//                           window.location.reload();
//                       }
//                       });
//                    return false;
//                }.bind(this);
//                this.saveDefaultGrid = function () {
//                    this.serializedData = _.map($('.grid-stack > .grid-stack-item:visible'), function (el) {
//                        el = $(el);
//                        var node = el.data('_gridstack_node');
//                        return {
//                            id: node.id,
//                            x: node.x,
//                            y: node.y,
//                            width: node.width,
//                            height: node.height
//                        };
//                    }, this);
//                    var sDData = JSON.stringify(this.serializedData);
//                    var users_id = 0;
//                     $.ajax({
//                       url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/saveDefaultGrid.php',
//                       type: 'POST',
//                       data:{data:sDData,users_id:users_id, entities_id:$entities_id,action:'default'},
//                       success:function(data) {
//                         alert('$msg_default_save');
//                       }
//                       });
//                    return false;
//                }.bind(this);
                this.clearGrid = function () {
                  $('#ajax_loader').show();
                  $.ajax({
                    url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/clearGrid.php',
                       type: 'POST',
                       success:function(data) {
                           $('#ajax_loader').hide();
                           window.location.reload();
                          }
                       });
                    return false;
                }.bind(this);
                 this.dragGrid = function () {
                  $('#ajax_loader').show();
                  $.ajax({
                    url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/dragGrid.php',
                       type: 'POST',
                       data:{drag_mode:1, entities_id:$entities_id},
                       success:function(data) {
                            $('#ajax_loader').hide();
                           window.location.reload();
                          }
                       });
                    return false;
                }.bind(this);
                this.undragGrid = function () {
                  $('#ajax_loader').show();
                  $.ajax({
                    url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/dragGrid.php',
                       type: 'POST',
                       data:{drag_mode:0, entities_id:$entities_id},
                       success:function(data) {
                            $('#ajax_loader').hide();
                           window.location.reload();
                          }
                       });
                    return false;
                }.bind(this);
                
                this.resizeGrid = function () {
//                   var items = GridStackUI.Utils.sort(this.serializedData);
                   var grid = $(this).data('gridstack');

                   var nodeid = 0;
                   var items = $grid;
//                     items.forEach(function(node)  {
                        for (var i = 0; i < items.length; i++) {
                         var widgetid = items[i].id;
                            var widget = $('.grid-stack-item-content')[i];
                            if (typeof widget !== 'undefined' && (widgetid == 'gs1' 
                         || widgetid == 'gs2'
                         || widgetid == 'gs3'
                         || widgetid == 'gs7'
                         || widgetid == 'gs14'
                         || widgetid == 'gs17'
                         || widgetid == 'gs18'
                         || widgetid == 'gs20')) {
//                               grid.resize(
//                                   $('.grid-stack-item')[i],
//                                   $($('.grid-stack-item')[i]).attr('data-gs-width'),
//                                  Math.ceil((widget.scrollHeight + grid.opts.verticalMargin) / (grid.cellHeight() + grid.opts.verticalMargin))
//                              );
                             nodeid++;
                            }
                     };
                    return false;
                }.bind(this);
                $('#save-grid').click(function () {
                    launchSaveGrid();
                });
                 $('#save-default-grid').click(function () {
                    launchSaveDefaultGrid();
                });
//                $('#save-grid').click(this.saveGrid);
//                $('#save-default-grid').click(this.saveDefaultGrid);
//                $('#remove-widget').click(this.removewidget);
                $('#clear-grid').click(this.clearGrid);
                $('#drag-grid').click(this.dragGrid);
                $('#undrag-grid').click(this.undragGrid);
                this.loadGrid();
                
                if (setup_entity == 0) {
                   this.resizeGrid();
                }
                deleteWidget = function(value) {
                    widget = 'div[gs-id='+ value + ']';
                    if (confirm('$msg_delete') == true) {
                       grid.removeWidget(widget);
                    }
                }
                addNewWidget = function(value) {
                    if (value != 0){
                            var widgetArray = $allwidgetjson; 
                            widget = widgetArray['' + value + ''];
                            var el = '<div class=\"grid-stack-item\"><div class=\"grid-stack-item-content\">' +
                                     '<button class=\"sc-button pull-right\" onclick=\"deleteWidget(\'' + value + '\');\">' +
                                      '<i class=\"ti ti-x sc-button\"></i></button>' + widget + '</div></div>';
            //                grid = $('.grid-stack').data('gridstack');
                            grid.addWidget(
                                                        el,
                                                        {
                                                           x: 0,
                                                           y: 0,
                                                           w: 6,
                                                           h: 4,
                                                           id: value
                                                        }
                                                     );
                            refreshWidget(value);
                         }
                }
                launchSaveGrid = function() {
                    delete serializedFull;
                    serializedData = grid.save(false);
                    var sDData = JSON.stringify(serializedData);
                    $('#ajax_loader').show();
                    $.ajax({
                       url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/saveGrid.php',
                       type: 'POST',
                       data:{data:sDData},
                       success:function(data) {
//                         alert('$msg_save');
                           window.location.reload();
                       }
                       });
                }
                
                launchSaveDefaultGrid = function() {
                    delete serializedFull;
                    serializedData = grid.save(false);
                    var sDData = JSON.stringify(serializedData);
                    var users_id = 0;
                     $.ajax({
                       url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/saveDefaultGrid.php',
                       type: 'POST',
                       data:{data:sDData,users_id:users_id, entities_id:$entities_id,action:'default'},
                       success:function(data) {
                         alert('$msg_default_save');
                       }
                       });
                }
            };
        });
    </script>";
        echo "<script type='text/javascript'>
//         function addNewWidget(value) {
//             var id = value;
//             if (id != 0){
//                var widgetArray = $allwidgetjson; 
//                widget = widgetArray['' + id + ''];
//                var el = $('<div><div class=\"grid-stack-item-content\">' +
//                         '<button class=\"sc-button pull-right\" onclick=\"deleteWidget(\'' + id + '\');\">' +
//                          '<i class=\"ti ti-x\"></i></button>' + widget + '<div/><div/>');
////                var grid = $('.grid-stack').data('gridstack');
////                grid.addWidget(el, 0, 0, 6, 6, true, null, null, null, null, id);
//                  grid.addWidget(
//                                                    el,
//                                                    {
//                                                       x: 0,
//                                                       y: 0,
//                                                       w: 4,
//                                                       h: 12,
//                                                       id: value
//                                                    }
//                                                 );
//             }
//         };
         function refreshWidget (id, params) {
            var widget = $('div[id='+ id + ']');
            $.ajax({
              url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/refreshWidget.php',
              type: 'POST',
              data:{widget_id:id, params:params},
              success:function(data) {
                  widget.replaceWith(data);
              }
           });
             return false;
           };
         function refreshWidgetByForm (id, params) {
            var widget = $('div[id='+ id + ']');
            $.ajax({
              url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/refreshWidget.php',
              type: 'POST',
              data:{widget_id:id, params:params},
              success:function(data) {
                  widget.replaceWith(data);
              }
           });
             return false;
           };
//         function deleteWidget (id, dom) {
//           this.grid = $('.grid-stack').data('gridstack');
//           widget = $('div[data-gs-id='+ id + ']');
//             if (confirm('$msg_delete') == true)
//             { 
//                 this.grid.removeWidget(widget, dom);
//             }
//             return false;
//           };
    </script>";


        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
    }
}
