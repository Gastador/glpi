<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogThumbnail
 */
class PluginServicecatalogThumbnail extends CommonDBTM
{
    public static $rightname = "plugin_servicecatalog";

    /**
     * @param $params
     *
     * @return false|void
     * @throws \GlpitestSQLError
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public static function showCategories($params)
    {
        if (!PluginServicecatalogMain::checkBrowser()) {
            return false;
        }

        $params['manage_favorites'] = $params['manage_favorites'] ?? 0;
        $params['category_id'] = $params['category_id'] ?? 0;

        $config = new PluginServicecatalogConfig();

        if (Session::getCurrentInterface() != "central") {
            if (Ticket::INCIDENT_TYPE == $params['type']) {
                echo "<script id='rendered-menu'>
            $('#incident_bar').addClass('active');
            </script>";
            } else {
                echo "<script id='rendered-menu'>
            $('#request_bar').addClass('active');
            </script>";
            }
        }

        if (Ticket::INCIDENT_TYPE == $params['type'] || Ticket::DEMAND_TYPE == $params['type']) {
            $stat = new PluginServicecatalogIndicator();
            $stat->displayGroupUserTickets($params['type']);

            $config = new PluginServicecatalogConfig();
            if ($config->getDemoMode() == 1) {
                echo "<div class='alert alert-warning demo alert-dismissible' role='alert'>";
                echo "<a href='#' class='close' data-bs-dismiss='alert' aria-label='close'>&times;</a>";
                $config->showLayoutSelector();
                $config->showColorSelector();
                $config->showSearchEngineSelector();
                echo "</div>";
                echo Html::scriptBlock('$(document).ready(function() {
                    setTimeout(function() {
                        $(".demo").alert("close");
                    }, 10000);
                    });');
            }
        }

        echo "<div id='content' class='sc-content'>";
        $class = "";
        echo "<div class='bt-container $class'>";
        echo "<div class='bt-block bt-features' style='padding-top: 5px;'>";
        $params['from_ticket'] = 0;
        //      PluginServicecatalogTicket::showTopMenuTitle($params, $config);

        $opt['categories'] = null;

        $datas = PluginServicecatalogCategory::getCategoriesCache($params['type']);
        //faorite console
        if (Session::haveRight("plugin_servicecatalog_favorites", UPDATE)) {
            if ($params['manage_favorites'] == 1) {
                $userId = Session::getLoginUserID();
                $favorites_users = PluginServicecatalogFavorite_User::getFavoritesByUser($userId);
                $opt['type'] = $params['type'];
                $opt['level'] = 1;
                $opt['favorites'] = $favorites_users;
                $opt['display_favorite'] = 1;
                $opt['users_id'] = $userId;
                $opt['entity'] = $_SESSION['glpiactive_entity'];
                PluginServicecatalogMain::showTitleCategory($config, $params['type'], $params['category_id'], $params['manage_favorites']);
                PluginServicecatalogFavorite::displayFavoriteTemplate($opt);
            }
        }
        if ($params['manage_favorites'] == 0) {
            echo '<script>
               $(document).ready(function(){
                 $("#hide").click(function(){
                   $(".categories_list").hide();
                 });
                 $("#show").click(function(){
                   $(".categories_list").show();
                 });
               });
            </script>';

            if (!isset($params['category_id'])) {
                $params['category_id'] = 0;
            }
            if (!isset($params['level'])) {
                $params['level'] = 1;
            }

            $opt['choose_category'] = $params['choose_category'];
            $opt['type'] = $params['type'];
            $opt['category_id'] = $params['category_id'];
            $opt['level'] = $params['level'];
            $opt['catfirsts'] = 1;

            if (Session::haveRight("plugin_servicecatalog_favorites", READ)) {
                PluginServicecatalogMain::showHomepageFavoritesCategories($config, $opt, $datas);
            }
            echo "<div class='container_thumbnail'>";

            PluginServicecatalogMain::showTitleCategory($config, $params['type'], $params['category_id'], 0);
            echo "<div id='searchcat'>";
            echo "</div>";
            if ($config->useIntegratedSearch()) {
                //THUMBNAIL
                echo PluginServicecatalogCategory::fuzzySearchForm('sc-home-trigger-fuzzy', $params['type']);
            }

            self::showMainCategories($opt, $datas);

            echo "</div>";

            if ($config->seetop() || $config->useIntegratedSearch()) {
                echo "<div id='mostused' class='mostused'>";
            }

            if ($config->seetop() && $params['choose_category'] == 0) {
                PluginServicecatalogMain::showMostUsedCategories($opt, $datas);
            }
            if ($config->seetop() || $config->useIntegratedSearch()) {
                echo "</div>";
            }
            if (Session::haveRight("plugin_servicecatalog_favorites", READ)) {
                $favorites = PluginServicecatalogFavorite::getFavorites();
                if (count($favorites) > 0) {
                    $opt['choose_category'] = $params['choose_category'];
                    $opt['type'] = $params['type'];
                    $opt['category_id'] = $params['category_id'];
                    $opt['level'] = $params['level'];
                    self::showMainListCategoryFavorites($opt, $config, $datas);
                }
            }
            echo "<div class='events_list'>";
            if (!$config->useIntegratedSearch()) {
                echo "<div id='faq'>";
                PluginServicecatalogKnowbase::createFaqDiv($opt, $datas);
                echo "</div>";
            }
            echo "<div class='subcats_list' style='display: none'>";

            echo "<h5>";
            echo "<span id='categories_title' style='display: none'>";

            $style = 'style="border-radius: 1px;margin: 0px;"';
            $important = "";
            $force  = $config->getforceBackgroundColor();
            if ($force == 1) {
                $important = "alert-important";
            }
            echo "<div class='alert alert-secondary $important' role='alert' $style>";
            echo "<span id='title_cat'>";
            echo "</span>";
            echo "</div>";
            echo "</span>";
            echo "</h5>";


            echo "<ul class='events' id='events'>";

            if (!isset($params['category_id'])) {
                $params['category_id'] = 0;
            }
            if (!isset($params['level'])) {
                $params['level'] = 1;
            }
            $level = ($params['level'] == 1) ? 1 : $params['level'] + 1;
            //all childs
            $opt['choose_category'] = $params['choose_category'];
            $opt['type'] = $params['type'];
            $opt['category_id'] = $params['category_id'];
            $opt['level'] = $level;
            //                                $opt['categories'] = $categories;

            self::showMainListCategoryChilds($opt, $config, $datas);

            echo "</ul>";

            //return to last categories (back of create ticket)
            if (isset($params['category_id'])) {
                $id_cat = $params['category_id'];
                $ancestors = getAncestorsOf("glpi_itilcategories", $id_cat);
                if (count($ancestors) > 0) {
                    $parent = end($ancestors);
                    echo "<script>$(document).ready(function() {
                              $('#displaycat$parent').show();
                              let cat = document.getElementById('cat$id_cat');
                                 if (cat) {
                                    document.getElementById('cat$id_cat').style.opacity = 0.7;
                                 }
                              });</script>";
                } else {
                    echo "<script>$(document).ready(function() {
                                 $('.categories_list').show();
                                 });</script>";
                }
            }

            echo "</div>";
            echo "</div>";

            //Second_opt
            echo "<div id='create_ticket' class='create_ticket'>";

            echo "<div id='faq_articles' class='faq_articles faq'>";
            echo "</div>";

            echo "<div id='css_ticket'>";
            echo "<div id='launch_ticket'>";
            echo "</div>";
            echo "</div>";

            echo "<div id='launch_details' class='launch_details'>";
            echo "</div>";

            echo "</div>";

            echo "</div>";
            echo "</div>";

        }


        echo "</div>";
        echo "</div>";

        echo "<script>$(document).ready(function() {
         $('#launch_ticket').hide();
         $('#css_ticket').hide();
         $('.faq').hide();
         $('#categories_title').hide();
         $('#launch_details').hide();
        });</script>";

        echo "</div>";
    }


    /**
     * Interface for selecting the ticket category
     *
     * @param $options
     * @param $datas
     *
     * @throws \GlpitestSQLError
     */
    public static function showMainCategories($options, $datas)
    {
        switch ($options['type']) {
            case Ticket::INCIDENT_TYPE:
            case Ticket::DEMAND_TYPE:
                $opt['choose_category'] = $options['choose_category'];
                $opt['type'] = $options['type'];
                $opt['category_id'] = $options['category_id'];
                $opt['level'] = $options['level'];
                $opt['catfirsts'] = $options['catfirsts'];
                self::showMainListCategories($opt, $datas);
                break;
            case "formcreator":
                PluginServicecatalogPlugin::showMain($options['type']);
                break;
            default:
                break;
        }
    }

    /**
     * Interface for selecting the first category of the incident ticket or request
     *
     * @param $options
     * @param $datas
     *
     * @throws \GlpitestSQLError
     */
    public static function showMainListCategories($options, $datas)
    {
        $choose_category = $options['choose_category'];
        $type = $options['type'];
        $category_id = $options['category_id'];
        $level = $options['level'];
        $catfirsts = $options['catfirsts'] ?? 0;

        $categories = $datas ?? [];

        $cats_level1 = [];
        foreach ($categories as $id => $value) {
            if (isset($value['level']) && $value['level'] == 1) {
                //            foreach ($value['subcategory'] as $k => $v) {
                unset($value['subcategories']);
                $cats_level1[] = $value;
                //            }
            }
        }

        $categories = $cats_level1;

        //      if (0 != $choose_category) {
        //         if (isset($categories[$choose_category]['subcategories'])) {
        //            $categories = $options['categories'][$choose_category]['subcategories'];
        //         }
        //      }

        $config = new PluginServicecatalogConfig();

        if (is_array($categories) && count($categories) > 0) {
            $hide = "";
            if ($category_id > 0) {
                $hide = "hidden";
            }

            echo '<div id="cats" class="cats_firstlist">';

            usort($categories, function ($a, $b) {
                return $a['ranking'] - $b['ranking'];
            });

            foreach ($categories as $id => $value) {
                if ($value['disabled'] == 0) {
//xaca
//                    $value['level'] == $level &&
                    if (($value['itilcategories_id'] == 0)) {
                        $helpdesk_category = new PluginServicecatalogCategory();
                        if (isset($value['id'])) {
                            //                     if (!$helpdesk_category->getFromDBByCategory($value['id'])) {
                            //                        if (isset($value['subcategories'])) {
                            //                           foreach ($value['subcategories'] as $subcat) {
                            //                              $helpdesk_category->getFromDBByCategory($subcat['itilcategories_id']);
                            //                           }
                            //                        }
                            //                     }
                            //                     $cat = new ITILCategory();
                            //                     $cat->getFromDB($value['id']);

                            $id_cat = $value['id'];
                            if ($value['comment'] != "") {
                                $comments = $value['name'];
                                $comments .= "\n";
                                $comments .= $value['comment'];
                                $comments = Toolbox::stripTags($comments);
                            } else {
                                $comments = Toolbox::stripTags($value['name']);
                            }

                            $count = ((isset($value['have_sons']) && $value['have_sons']) > 0 ? 1 : 0);

                            $opt['id_cat'] = $id_cat; //for displaycat
                            $opt['onclick'] = "";
                            $opt['display'] = true;
                            $opt['level'] = $level;
                            $opt['count'] = $count; //if childs it's a mother category
                            //                     $opt['categories'] = $categories;
                            self::showCategoryColor($value, $opt);

                            $opt['comments'] = $comments;
                            $opt['first'] = 1;
                            $helpdesk_category->getFromDBByCategory($value['id']);

                            self::showCategoryLogo($helpdesk_category, $opt);
                            echo "<br><br>";
                            $style = "";
                            $stylei = "";
                            //color first categories
                            $color = $value['background_color'];
                            $style = "style=\"color: $color !important;\"";
                            $stylei = "style=\"color: $color !important;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"";

                            $class = "label_firsttitle";

                            echo "<span class=\"$class bottom_title\" $style>";
                            if (!$count) {
                                $fa_style = "fas fa-caret-right";
                            } else {
                                $fa_style = "far fa-folder-open";
                            }

                            echo "<i class=\"fas $fa_style sc-fa-color fa-2x\" aria-hidden=\"true\" $stylei></i>&nbsp;";

                            if ($type == Ticket::INCIDENT_TYPE) {
                                $field = $value['simplified_name_incident'];
                            } else {
                                $field = $value['simplified_name_request'];
                            }
                            if (isset($field) && $field != "") {
                                $name = $field;
                            } elseif ($value['name'] != "") {
                                $name = Html::resume_text($value['name'], 50);
                            } else {
                                $name = NOT_AVAILABLE;
                            }
                            echo $name;

                            $config = new PluginServicecatalogConfig();
                            if ($config->seeCategoryDetails()) {
                                if ($helpdesk_category->getFromDBByCategory($value['id'])) {
                                    echo "&nbsp;";
                                    echo PluginServicecatalogMain::getServiceDetailsText($helpdesk_category, $type, false);
                                }
                            }

                            echo "</span>";

                            self::getKeywordsAndComments($value);

                            echo "</li>";
                        }
                    }
                }
            }
        } else {
            echo "<h4>";
            echo "<div class='alert  alert-warning d-flex'>";
            echo __('No category found', 'servicecatalog') . "</div></h4>";
        }
    }

    /**
     * @param $category
     * @param $options
     *
     * @return string
     * @throws \GlpitestSQLError
     */
    public static function showCategoryColor($category, $options)
    {
        //link with other
        $count = $options['count'];
        $config = new PluginServicecatalogConfig();
        $folder = "";

        if ($options['count']) { //if is parent
            $folder = "";
        } elseif ($options['count']) { //if is parent
            $folder = " background_title";
        }
        $onclick = $options['onclick'];

        $type = "li";

        $class = "btnsc-normal";

        if ($options['level'] == 1) {
            $class = "first-btnsc-normal";
        }
        $color = $category["background_color"];
        $color = ($color == null ? $config->getGeneralColor() : $color);

        $url = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/showdetails.php?showalerts&category_id=';
        $url .= $options['id_cat'];

        $style = "";
        //color background first categories

        $comment = !empty($category['comment']) ? $category['comment'] : "";

        $class_ouput = "class='$class $folder' $style";
        $output = "<$type title=\"$comment\" $class_ouput id=launchcat" . $options['id_cat'] . " $onclick>";

        $faq_exist = $options['id_cat'] . '0';
        $cat = new ITILCategory();
        if ($cat->getFromDB($options['id_cat'])) {
            $kbitem = new KnowbaseItem();
            $found_kbitem = $kbitem->find([KnowbaseItem::getTable() . '.id' => KnowbaseItem::getForCategory($cat->fields['knowbaseitemcategories_id']),
                'is_faq' => 1
            ]);
            if (count($found_kbitem)) {
                $faq_exist = $options['id_cat'] . '1';
            }
        }
        $favorites = PluginServicecatalogFavorite::getFavoritesVisibility();
        $favs = json_encode($favorites);

        $layout = $config->getLayout();
        $id_cat = $options['id_cat'];
        $output .= Html::scriptBlock("if ($('#launchcat" . $options['id_cat'] . "').length) {
                           var scrollTrigger = 100, // px
                              backToTop = function () {
                                 var scrollTop = $(window).scrollTop();
                              };
                           backToTop();
                           $(window).on('scroll', function () {
                              backToTop();
                           });
                           
                           $('#launchcat" . $options['id_cat'] . "').on('click', function (e) {
//                              console.log($id_cat);
                              $('#fuzzysearch .results').empty();
                              $('.sc-trigger-fuzzy').val('');
                              sessionStorage.setItem('categoryload', $id_cat);
                              var layout = $layout;
                              var faq = $faq_exist;
                              e.preventDefault();
                              $('html,body').animate({
                                 scrollTop: 0
                              }, 700);
                              //Thumbnail Jquery
                              
                                 $('li[id^=\"launchcat\"]').removeClass('first-btnsc-normal').addClass('btnsc-normal');
                              
                              $('div[id^=\"cats\"]').removeClass('cats_firstlist').addClass('cats_list');
                              $('.visitedbg').removeClass('visitedbg');
                              $('#launchcat" . $options['id_cat'] . "').addClass('visitedbg');
                              $('#launch_ticket').hide();
                              $('#css_ticket').hide();

                              if ($count > 0) {
                                 $('.events_list').show();
                                 $('.subcats_list').show();
                                 $('#launch_details').show();
                                 $('#launch_details').load('$url');
                              } else {
                                 $('.events_list').hide();
                                 $('.subcats_list').hide();
                              }
                              //favs
                              var cats = $favs;
                              $('#favorites_title').hide();
                              $('.favorites_list').hide();
                              $.each(cats, function (i, elem) {
                                  $('#favorites_list'+elem).hide();
                              });
                              if ($('#favorites_list" . $options['id_cat'] . "').length > 0) {
                                  $('#favorites_title').show();
                                  $('.favorites_list').show();
                              }
                              //end favs
                              if (faq == " . $options['id_cat'] . "1) {
                                 $('#faq').show();
                                 $('#faq" . $options['id_cat'] . "').show();
                              } else {
                                 $('#faq').hide();
                                 $('#faq" . $options['id_cat'] . "').hide();
                              }
                              $('.faq_articles').hide();
                           });
                        }");


        if ($options['display']) {
            echo $output;
        } else {
            return $output;
        }
    }

    /**
     * @param $helpdesk_category
     * @param $options
     *
     * @return string
     */
    public static function showCategoryLogo($helpdesk_category, $options)
    {
        $display = ($options['display'] ?? true);
        $withlink = ($options['withlink'] ?? true);
        $id_cat = ($options['id_cat'] ?? 0);
        $comments = ($options['comments'] ?? "");
        $first = ($options['first'] ?? 0);
        $display_favorite = ($options['display_favorite'] ?? 0);
        $display_mostused = ($options['display_mostused'] ?? 0);
        $details = ($options['details'] ?? 0);
        $btn = ($options['btn'] ?? "");
        $output = "";
        $config = new PluginServicecatalogConfig();

        $class = "";
        if ($config->getDisplayLogoCategoryDetail()
            && $display_favorite != 1) {
            $class = "thumbnail";
        }
        if (!$config->getDisplayLogoCategoryDetail()) {
            $class .= " nologo";
        }
        $btresponsive = "bt-img-responsive";
        if ($first == 1 || $details == 1) {
            $btresponsive = "bt-img-responsive bt-img-responsive-details";
        }
        if ($display_favorite == 1) {
            $btresponsive = "bt-img-fav";
        }

        $picture = PluginServicecatalogCategory::getUsedConfig("inherit_picture", $id_cat, "picture");
        $category = new PluginServicecatalogCategory();
        $category->getFromDBByCrit(['itilcategories_id' => $id_cat]);
        $use_website_url = $category->fields['use_website_url'] ?? 0;
        $website_url = $category->fields['website_url'] ?? '';
        if (!empty($picture)) {
            if ($use_website_url && !empty($website_url)) {
                $target = '';
                if ($use_website_url == 1 && $category->fields['website_target'] == 0) {
                    $target = 'target="_blank"';
                }
                $output .= "<a href='$website_url' $target class=\"$class\" title=\"" . $comments . "\">";
            } elseif ($display && $withlink) {
//                $output .= "<a href='#' class='$class' id=launchcat$id_cat title=\"" . $comments . "\">";
            }
            if ($config->getDisplayLogoCategoryDetail()) {
                $output .= "<img class='$btresponsive' src='" . PLUGIN_SERVICECATALOG_WEBDIR . '/front/document.send.php?file=_plugins/' . $picture . "'>";
            }
        } else {
//            if ($use_website_url && !empty($website_url)) {
//                $target = '';
//                if ($category->fields['website_target'] == 0) {
//                    $target = 'target="_blank"';
//                }
////                $output .= "<a href='$website_url' $target class=\"$class\" title=\"" . $comments . "\">";
//            } elseif ($display && $withlink) {
////                $output .= "<a href='#' class='$class' id=launchcat$id_cat title=\"" . $comments . "\">";
//            }

            $fasize = "fa-4x";
            if ($config->getCatSize() == 'verysmall') {
                $fasize = "fa-3x";
            }

            $fasize = "fa-4x";
            if (!$first) {
                $fasize = "fa-3x";
            }


            $margin = "fas-sc";
            if ($config->getCatSize() == 'verysmall' && $display_favorite == 1) {
                $margin = "fas-sc-fav-small";
            } elseif ($config->getCatSize() == 'verysmall') {
                $margin = "fas-sc-small";
            }
            if ($display_favorite == 1) {
                $fasize = "fa-2x";
                $margin = "fas-fav-sc";
            }

            $icon = PluginServicecatalogCategory::getUsedConfig("inherit_config", $id_cat, 'icon');

            $style = "";

            //color logo child categories
            $color = PluginServicecatalogCategory::getUsedConfig("inherit_config", $id_cat, "background_color");
            $color = ($color == null ? $config->getGeneralColor() : $color);

//                if ($display_favorite == 1) {
//                    $style = "style=\"background-color: $color !important;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"";
//                } else {
            $style = "style=\"color: $color !important;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"";

            if ($details == 1) {
                $top = "";
                $color = PluginServicecatalogCategory::getUsedConfig("inherit_config", $id_cat, "background_color");
                $color = ($color == null ? $config->getGeneralColor() : $color);

                $style = "style=\"color: $color !important;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';$top\"";
            }

            if ($first != 1 && $display_favorite != 1) {
                $class = "thumbnail_child";
            }

            if ($config->getDisplayLogoCategoryDetail()) {
                if ($icon != null) {
                    $output .= "<i class='$margin sc-fa-color fas $icon $fasize $class' $style></i>";
                } else {
                    if (!empty($config->fields['default_icon'])) {
                        $icon = $config->fields['default_icon'];
                        $output .= "<i class='$margin sc-fa-color fas $icon $fasize $class' $style ></i>";
                    } else {
                        $output .= "<i class='$margin sc-fa-color fas fa-network-wired $fasize $class' $style ></i>";
                    }
                }
            }
        }
        if ($display && $withlink) {
            $output .= "</a>";
        }
        if (!$first && !$display_favorite) {
            $output .= "<br><br>";
        }

        if ($display) {
            echo $output;
        } else {
            return $output;
        }
    }

    /**
     * @param      $category
     * @param bool $display
     *
     * @return string
     * @throws \GlpitestSQLError
     */
    public static function getKeywordsAndComments($category, $display = true)
    {
        $output = "";

        $config = new PluginServicecatalogConfig();
        $style = "";
        if (isset($category['background_color'])) {
            $color = $category['background_color'];
            $style = "style='color: $color !important;'";
        }

        $output .= "<span class=\"label bottom\" $style>";

        $r = 80;

        if ($config->getCatSize() == 'normal') {
            $output .= "<br>";
        }

        if (!empty($category['comment'])) {
            $output .= "<br>";

            $list_comments = explode("\n", $category['comment']);
            if (count($list_comments) > 0) {
                $output .= "<ul class='ul_comment'>";
                foreach (array_slice($list_comments, 0, 4) as $comment) {
                    $output .= "<li class='li_comment'>";
                    $output .= Html::resume_text($comment, 30);
                    $output .= "</li>";
                }
                $output .= "</ul>";
            }
        }

        $color = '';

        $output .= "</span>";

        if ($config->getEnableKeywords()) {
            if (!empty($category['keywords'])) {
                $output .= "<br>";
                $output .= "<div class='keywords keywords_founded'>";
                $output .= __('Keywords', 'servicecatalog');
                $output .= "&nbsp;";
                $keywords = explode(',', $category['keywords']);
                $tags = "";
                foreach ($keywords as $k => $v) {
                    $tags .= $v . "<br>";
                }
                $opt = ['awesome-class' => 'fa-search-plus fa-1x' . $color];
                $opt["display"] = false;

                $output .= Html::showToolTip($tags, $opt);
                //            $output .= "<i data-title=\"$tags\" class='fas $color fa-search-plus tags' $style></i>";
                $output .= "</div>";
            }
        }

        if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)) {
            $criteria = "IN";
            $knowbasecategories = [];
            if (isset($category['knowbaseitemcategories_id'])
                && $category['knowbaseitemcategories_id'] > 0) {
                $knowbasecategories[] = $category['knowbaseitemcategories_id'];

                $kbitems = PluginServicecatalogKnowbase::getKbItems($criteria, $knowbasecategories);

                if (count($kbitems) > 0) {
                    $output .= "<div class='kb_founded'>";
                    $output .= count($kbitems);
                    $output .= "&nbsp;" . __("solution(s) found", "servicecatalog") . "</div>";
                }
            }
        }
        if ($display) {
            echo $output;
        } else {
            return $output;
        }
    }

    /**
     *  Display of sub-categories
     *
     *
     * @throws \GlpitestSQLError
     */
    public static function showMainListCategoryChilds($options, $config, $datas)
    {
        //      $TIMER = new Timer();
        //      $TIMER->start();

        $choose_category = $options['choose_category'];
        $type = $options['type'];
        $category_id = $options['category_id'];
        $level = $options['level'];

        //      $datas      = PluginServicecatalogCategory::getCategoriesCache($type);

        $categories = $datas ?? [];

        $cats_level1 = [];
        foreach ($categories as $id => $value) {
            if (isset($value['level']) && $value['level'] == 1) {
                $cats_level1[$value["id"]] = $value;
                //            if ($category_id != 0) {
                //               if (isset($value["subcategories"])) {
                //                  if (array_key_exists($category_id, $value["subcategories"])) {
                //                     $catParentToload = $value["id"];
                //                     $catTodisp       = $value["subcategories"][$category_id]["itilcategories_id"];
                //                  }
                //               }
                //            }
            }
        }
        $path = [];
        if ($category_id != 0) {
            $ret = PluginServicecatalogMain::DFS($categories, $level, $category_id, $path);
        }

        if (count($categories) > 0) {
            foreach ($categories as $id => $value) {
                if (($category_id == 0
                        || ($category_id > 0))
                    && isset($value['id']) && $value['id'] != 0
                    && $value['disabled'] == 0
                ) {
                    $id_cat = $value['id'];
                    $class = "";
                    $style = "";
                    $class = "thumbnail_grid";
                    $style = "style='display:grid;'";

                    echo "<li who='first' id='displaycat$id_cat' $style parent='0' level='$level' class='$class'>";

                    $opt['choose_category'] = $choose_category;
                    $opt['type'] = $type;
                    $opt['category_id'] = $id_cat;
                    $opt['level'] = $level + 1;
                    //               $opt['categories']      = $cats_level1;
                    //URL link for first categories
                    self::linkMainCategories($opt, $config, $cats_level1);

                    $opt['display_favorite'] = 0;
                    //               $opt['categories']       = $categories;
                    //print hidden child categories
                    //               self::listCategories($opt, $config);

                    echo "</li>";
                }
            }

            if ($category_id != 0) {
                $favorites = PluginServicecatalogFavorite::getFavoritesVisibility();
                $favs = json_encode($favorites);
                $cat_parent = new ITILCategory();
                $cat_parent->getFromDB($category_id);
                if ($cat_parent->fields['id'] == 0) {
                    echo "<script>$(document).ready(function() {
                  $('ul.events li').hide();
                  $('.categories_list').show();
                  $('#title_cat').hide();
                  $('#categories_title').hide();
                  let cats = $favs;
           
                  $.each(cats, function (i, elem) {
                      $('#favorites_list'+elem).hide();
                  });
                });</script>";
                } else {
                    $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($type, $category_id, 1);
                    $name = $treename['name'];
                    $treescript = json_decode($treename['script']);

                    $layout = $config->getLayout();
                    echo "<script>$(document).ready(function() {
                          let layout = $layout;
                          $('ul.events li').hide();
                          $('.categories_list').hide();
                          if (layout != -1) {
                             $('#title_cat').show();
                             $('#categories_title').show();
                             document.getElementById('title_cat').innerHTML = \"$name\";
                             let newScript = document.createElement('script');
                             newScript.type = 'text/javascript';
                             let scriptContent = document.createTextNode( $treescript ); 
                             newScript.appendChild( scriptContent ); //add the text node to the newly created div. 
                             document.body.appendChild( newScript ); //add the text node to the newly created div. 
                          }
                          $('#displaycat" . $cat_parent->fields['id'] . "').show();
                          let cats = $favs;
                          $.each(cats, function (i, elem) {
                              $('#favorites_list'+elem).hide();
                          });
                          if ($('#favorites_list" . $cat_parent->fields['itilcategories_id'] . "').length > 0) {
                              $('#favorites_title').show();
                          }
                          $('#favorites_list" . $cat_parent->fields['itilcategories_id'] . "').show();
                        });</script>";
                }
            } else {
                echo "<script>$(document).ready(function() {
                  $('.events_list').hide();
                  $('.subcats_list').hide();
                });</script>";
            }

            reset($path);
            //level 1 without choosecategory
            if (!empty($path)) {
                $config = new PluginServicecatalogConfig();

                $favorites = PluginServicecatalogFavorite::getFavoritesVisibility();
                $favs = json_encode($favorites);
                $url = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/showdetails.php?showalerts&category_id=';
                $url .= $category_id;

                $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($type, $category_id, 6);
                $name = $treename['name'];
                $treescript = json_decode($treename['script']);
                //         $name .= "2";

                $path2 = $path;
                foreach ($path as $k => $v) {
//                    $level += 1;
                    if ($level > 1) {
                        $choose_category = $path2[$k - 1] ?? $path2[$k];
                    }
                    $layout = $config->getLayout();
                    $root_doc = PLUGIN_SERVICECATALOG_WEBDIR;
                    echo "<script>$(document).ready(function() {
                          let layout = $layout;
                          $('ul.events li').hide();
                          $('.categories_list').hide();
                          if (layout != -1) {
                             $('#title_cat').show();
                             $('#categories_title').show();
                             document.getElementById('title_cat').innerHTML = \"$name\";
                             let newScript = document.createElement('script');
                             newScript.type = 'text/javascript';
                             let scriptContent = document.createTextNode( $treescript ); 
                             newScript.appendChild( scriptContent ); //add the text node to the newly created div. 
                             document.body.appendChild( newScript ); //add the text node to the newly created div. 
                          }
                          $('#ajax_loader').show();
                          data = {};
                          data.choose_category = $choose_category;
                          data.type            = $type;
                          data.category_id     = $category_id;
                          //xaca
                          data.level           = $level;
                          data.display_favorite = 0;
                               
                          $.ajax({
                                'url': '$root_doc/ajax/addChild.php',
                                'data': data,
                                'dataType': 'json',
                                 'async': true, // Mode synchrone
                                'type': 'POST'
                                            
                            }).done(function (data) {
                                if(data != 'ok'){
                                    console.log('thumbnail-showMainListCategoryChilds-addChilds');
                                    sessionStorage.setItem('categoryload', $category_id);
                                    $('div[id^=\"cats\"]').removeClass('cats_firstlist').addClass('cats_list');
                                   $('#events').append(data.script[0]);
                                   $('#launchcat$category_id').trigger('click');
                                   $.each(data.table, function(i, item) {
                                       $('#events').append(item);
                                   });
                                }
                                let width = (window.innerWidth > 0) ? window.innerWidth : document.documentElement.clientWidth;
                                if(width < 768){
                                     $('.cats_list').hide();
                                 }
                                $('#categories_title').show();
                                $('.subcats_list').show();
//                                $('#displaycat$category_id').show();
                                $('#ajax_loader').hide();
              
                          }).fail(function (jqXHR, textStatus, errorThrown) {
                              $('#ajax_loader').hide();
                              window.console.log(jqXHR);
                              window.console.log(textStatus);
                              window.console.log(errorThrown);
                          });
                          
//                          $('#displaycat$category_id').show();
//                          let cats = $favs;
//                   
//                          $('#favorites_title').hide();
//                          $.each(cats, function (i, elem) {
//                              $('#favorites_list'+elem).hide();
//                          });
//                          if ($('#favorites_list$category_id').length > 0) {
//                              $('#favorites_title').show();
//                          }
//                          $('#favorites_list$category_id').show();
//                          $('#displaycat$category_id').attr(\"selected\",\"selected\");
//                          $('.faq').hide();
//                          $('#faq$category_id').show();
//                          $('#faq$category_id').css(\"margin-bottom\", \"10px\");
//                          $('#launch_details').show();
//                          $('#launch_details').load('$url');
        
                        });</script>";
                }

            } else {
                if ($category_id != 0 && $choose_category == 0) {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/showdetails.php?showalerts&category_id=';
                    $url .= $category_id;
                    $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($type, $category_id, 2);
                    $name = $treename['name'];
                    $treescript = json_decode($treename['script']);
//                echo Html::scriptBlock("$(document).ready(function() {
////                $('#launchcat$category_id').trigger('click');
//                $('#displaycat$category_id').show();
//                });");

                    $layout = $config->getLayout();
                    $root_doc = PLUGIN_SERVICECATALOG_WEBDIR;
                    echo "<script>$(document).ready(function() {
                          let layout = $layout;
                          $('ul.events li').hide();
                          $('.categories_list').hide();
                          if (layout != -1) {
                             $('#title_cat').show();
                             $('#categories_title').show();
                             document.getElementById('title_cat').innerHTML = \"$name\";
                             let newScript = document.createElement('script');
                             newScript.type = 'text/javascript';
                             let scriptContent = document.createTextNode( $treescript );
                             newScript.appendChild( scriptContent ); //add the text node to the newly created div.
                             document.body.appendChild( newScript ); //add the text node to the newly created div.
                          }
                          $('#ajax_loader').show();
                          data = {};
                          data.choose_category = $choose_category;
                          data.type            = $type;
                          data.category_id     = $category_id;
                          //xaca
                          data.level           = $level;
                          data.display_favorite = 0;

                          $.ajax({
                                'url': '$root_doc/ajax/addChild.php',
                                'data': data,
                                'dataType': 'json',
                                 'async': true, // Mode synchrone
                                'type': 'POST'

                            }).done(function (data) {
                                if(data != 'ok'){
                                    console.log('thumbnail-showMainListCategoryChilds-addChilds2');
                                    sessionStorage.setItem('categoryload', $category_id);
                                   $('#events').append(data.script[0]);
                                   $('#launchcat$category_id').trigger('click');
 
                                   $.each(data.table, function(i, item) {
                                       $('#events').append(item);
                                   });
                                }
                                let width = (window.innerWidth > 0) ? window.innerWidth : document.documentElement.clientWidth;
                                if(width < 768){
                                     $('.cats_list').hide();
                                 }
                                $('#categories_title').show();
                                $('.subcats_list').show();
//                                if ($category_id == i && $level > 1) {
//                                    $('ul.events li').hide();
//                                }
//                                $('#displaycat$category_id').show();
                                $('#ajax_loader').hide();

                          }).fail(function (jqXHR, textStatus, errorThrown) {
                              $('#ajax_loader').hide();
                              window.console.log(jqXHR);
                              window.console.log(textStatus);
                              window.console.log(errorThrown);
                          });

                          $('#displaycat$category_id').show();
//                          let cats = $favs;
//
//                          $('#favorites_title').hide();
//                          $.each(cats, function (i, elem) {
//                              $('#favorites_list'+elem).hide();
//                          });
//                          if ($('#favorites_list$category_id').length > 0) {
//                              $('#favorites_title').show();
//                          }
//                          $('#favorites_list$category_id').show();
//                          $('#displaycat$category_id').attr(\"selected\",\"selected\");
//                          $('.faq').hide();
//                          $('#faq$category_id').show();
//                          $('#faq$category_id').css(\"margin-bottom\", \"10px\");
//                          $('#launch_details').show();
//                          $('#launch_details').load('$url');

                        });</script>";
                }
            }
        }
        //      $TIME = $TIMER->getTime();
        //Toolbox::logWarning($TIME);
    }

    /**
     *
     *
     * @param $options
     * @param $config
     * @param $datas
     *
     * @return void
     * @throws \GlpitestSQLError
     */
    public static function linkMainCategories($options, $config, $datas)
    {
        $choose_category = $options['choose_category'];
        $type = $options['type'];
        $category_id = $options['category_id'];
        $level = $options['level'];

        //      $datas      = $options['categories'];
        $categories = $datas ?? [];

        $conf = json_encode($config);

        uasort($categories, function ($a, $b) {
            return $a['ranking'] - $b['ranking'];
        });

        $opt['type'] = $type;
        //        $opt['level'] = $level;

        //      foreach ($categories as $data) {
        //         if ($data['disabled'] == 0) {
        //            $opt['category_id'] = $data['id'];
        //            $opt['category']    = $data;
        //            $have_sons          = $data['have_sons'];
        //
        //            if ($data["itilcategories_id"] != 0) {
        //               //First level
        //               if (($data['level'] == $level) && $data['itilcategories_id'] == $category_id) {
        //
        //                  if ($have_sons > 0) {
        //                     if (0 == $choose_category) {
        //                        $opt['choose_category'] = $category_id;
        //                        self::returnCategoryDetail($opt, true);
        //                     } else {
        //                        $opt['choose_category'] = $choose_category;
        //                        self::returnCategoryDetail($opt, true);
        //                     }
        //                  } else {
        //                     $opt['choose_category'] = 0;
        //                     self::returnCategoryDetail($opt, true);
        //                  }
        //               }
        //            }
        //         }
        //      }

        $favorites = PluginServicecatalogFavorite::getFavoritesVisibility();
        $favs = json_encode($favorites);
        $url = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/showdetails.php?showalerts&category_id=';
        $url .= $category_id;

        $first = false;

        $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($type, $category_id, 3, true, $first);
        $name = $treename['name'];
        $treescript = json_decode($treename['script']);
        //         $name .= "3";

        if (!isset($categories[$category_id]["subcategories"])) {
            if (count(PluginServicecatalogCategory::getSons($category_id, $type))) {
                $itilcat = new ITILCategory();
                $itilcat->getFromDB($category_id);
                $level = $itilcat->fields['level'];
                $id_parent = $itilcat->fields['itilcategories_id'];
                $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$category_id&choose_category=$id_parent";
            } else {
                $url = PLUGIN_SERVICECATALOG_WEBDIR . '/front/newticket.form.php?category_id=';
                $url .= $category_id;
                $url .= '&type=' . $type;
            }
            $use_website_url = $categories[$category_id]['use_website_url'] ?? 0;
            $website_url = $categories[$category_id]['website_url'] ?? '';

            $target = 1;
            if ($use_website_url == 1) {
                $target = $categories[$category_id]['website_target'] ?? 1;
            }

            if ($use_website_url && !empty($website_url)) {
                $url = $website_url;
            }

            $layout = $config->getLayout();
            echo "<script>$(document).ready(function() {
              let layout = $layout;
              let target = $target;
              $('#launchcat$category_id').click(function() {
                  console.log('thumbnail-1');
                  sessionStorage.setItem('categoryload', $category_id);
                  if (target == 0) {
                        window.open('" . $url . "', '_blank');
                     } else {
                        window.location.href = '" . $url . "';
                     }
                });
                });</script>";
        } else {
            $layout = $config->getLayout();
            if ($layout == 0 && count(PluginServicecatalogCategory::getSons($category_id, $type))) {
                $itilcat = new ITILCategory();
                $itilcat->getFromDB($category_id);
                $level = $itilcat->fields['level'];
                $id_parent = $itilcat->fields['itilcategories_id'];
                $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$category_id&choose_category=$id_parent";
            }

            $itilcat = new ITILCategory();
            $itilcat->getFromDB($category_id);
            $level = $itilcat->fields['level'];

            $root_doc = PLUGIN_SERVICECATALOG_WEBDIR;
            echo "<script>$(document).ready(function() {
              //show second level categories
              $('#launchcat$category_id').click(function() {
                  let layout = $layout;
                   sessionStorage.setItem('categoryload', $category_id);
                   
                   if (layout == 0) {
                       window.location.href = '" . $url . "';
                   } else {
                       $('#mostused').remove();

                  $('.categories_list').hide();
                     if (layout != -1) {
                         $('#title_cat').show();
                         $('#categories_title').show();
                         document.getElementById('title_cat').innerHTML = \"$name\";
                         let newScript = document.createElement('script');
                         newScript.type = 'text/javascript';
                         let scriptContent = document.createTextNode( $treescript ); 
                         newScript.appendChild( scriptContent ); //add the text node to the newly created div. 
                         document.body.appendChild( newScript ); //add the text node to the newly created div. 
                      }
                      $('#ajax_loader').show();
                     
                      data = {};
                      data.choose_category = $choose_category;
                      data.type            = $type;
                      data.category_id     = $category_id;
                      //xaca define
                      data.level           = $level;
                      data.display_favorite = 0;
    //                  data.config          = $conf;
                      
                      $.ajax({
                               'url': '$root_doc/ajax/addChild.php',
                               'data': data,
                               'dataType': 'json',
                                'async': true, // Mode synchrone
                               'type': 'POST'
                            
                            }).done(function (data) {
                              
                               if(data != 'ok'){
                                   console.log('thumbnail-linkMainCategories-addChilds');
                                   $('div[id^=\"cats\"]').removeClass('cats_firstlist').addClass('cats_list');
                                   $('li[id^=\"displaycat\"]').hide();
                                  $('#events').append(data.script[0]);
                                  $.each(data.table, function(i, item) {
                                       if ($category_id == i) {
                                           $('#displaycat'+i).append(item);
                                       } else {
                                           $('#events').append(item);
                                       }
                                  });
                               }
                               let width = (window.innerWidth > 0) ? window.innerWidth : document.documentElement.clientWidth;
                                if(width < 768){
                                    $('.cats_list').hide();
                                }
                                $('#categories_title').show();
                                $('.subcats_list').show();
    //                           $('ul.events li').hide();
                               $('#displaycat$category_id').show();
                               $('#ajax_loader').hide();
          
                      }).fail(function (jqXHR, textStatus, errorThrown) {
                           $('#ajax_loader').hide();
                          window.console.log(jqXHR);
                          window.console.log(textStatus);
                          window.console.log(errorThrown);
                      });
                      
                      $('#displaycat$category_id').show();
                      let cats = $favs;
               
                      $('#favorites_title').hide();
                      $.each(cats, function (i, elem) {
                          $('#favorites_list'+elem).hide();
                      });
                      if ($('#favorites_list$category_id').length > 0) {
                          $('#favorites_title').show();
                      }
                      $('#favorites_list$category_id').show();
                      $('#displaycat$category_id').attr(\"selected\",\"selected\");
                      $('.faq').hide();
                      $('#faq$category_id').show();
                      $('#faq$category_id').css(\"margin-bottom\", \"10px\");
                      $('#launch_details').show();
                      $('#launch_details').load('$url');
                       
                   }
                  
                });

                });</script>";
        }
    }

    /**
     *  Display of sub-categories
     *
     *
     * @throws \GlpitestSQLError
     */
    public static function showMainListCategoryFavorites($options, $config, $datas)
    {
        $choose_category = $options['choose_category'];
        $type = $options['type'];
        $category_id = $options['category_id'];
        $level = $options['level'];
        //      $datas           = PluginServicecatalogCategory::getCategoriesCache($type);
        $categories = $datas ?? [];

        $favorites = [];

        $cats = $categories;
        while (!empty($categories)) {
            $temp = [];
            foreach ($categories as $k => $v) {
                if (isset($v["subcategories"])) {
                    $temp = array_merge($temp, $v['subcategories']);
                }
            }
            $cats = array_merge($cats, $temp);
            $categories = $temp;
        }

        foreach ($cats as $id => $cat) {
            if (isset($cat['subcategories'])) {
                foreach ($cat['subcategories'] as $onecat => $value) {
                    if (isset($value['id']) && $value['id'] != 0
                        && $value['disabled'] == 0
                        && $value['favorite'] == 1
                    ) {
                        $favorites[] = $cat['subcategories'][$value['id']];
                    }
                }
            }
        }

        $ParentDefaults = PluginServicecatalogMain::groupByDefaults("favorite_itilcategories_id", $favorites);

        $ParentUsers = PluginServicecatalogMain::groupByUsers("favorite_itilcategories_id", $favorites, $type);

        $Parent = PluginServicecatalogMain::groupTotal($ParentUsers, $ParentDefaults);

        echo "<div class='favorites_list' style='display: none;'>";
        $style = "";

        echo "<h5>";
        echo "<span id='favorites_title'>";
        echo "<div class='alert alert-secondary' role='alert' $style>";
        echo __('Global favorites', 'servicecatalog');
        echo "</div>";
        echo "</span>";
        echo "</h5>";

        $display = "<div class='container_thumbnail' style='display: flex;'>";
        $display = "<div id='favorites_grid'>";//thumbnail_grid
        echo $display;

        foreach ($Parent as $key => $favs) {
            echo "<ul id='favorites_list$key' style='display: none;' class='favorites'>";
            echo "<li who='first' id='displayfav' parent='0' level='$level'>";
            $opt['choose_category'] = $choose_category;
            $opt['type'] = $type;
            $opt['category_id'] = 1;
            $opt['level'] = $level + 1;
            $opt['favs'] = $favs;
            $opt['display_favorite'] = 1;

            if (is_array($categories)) {
                self::listCategories($opt, true, $categories);
            } else {
                echo __('There is a problem with loading categories', 'servicecatalog');
            }

            echo "</li>";
            echo "</ul>";
        }
        echo "</div>";
        echo "</div>";
    }

    /**
     * @param       $options
     *
     * @param bool $display
     * @param array $datas
     *
     * @return array
     * @throws \GlpitestSQLError
     */
    public static function listCategories($options, $display = true, $datas = [])
    {
        $ret = [];
//        $TIMER = new Timer();
//        $TIMER->start();
        if (count($datas) == 0) {
            $datas = PluginServicecatalogCategory::getCategoriesCache($options['type']);
        }

        $config = new PluginServicecatalogConfig();
        $config->getConfig();

        $choose_category = $options['choose_category'];
        $type = $options['type'];
        $category_id = $options['category_id'];
        $level = $options['level'];
        $favs = $options['favs'] ?? [];
        $categories = [];

        if (count($favs) == 0) {
            //                  $datas      = PluginServicecatalogCategory::getCategoriesCache($type);
            //         $datas      = $options['categories'];
            $categories = $datas ?? [];
        } else {
            $categories = $favs;
        }
        $display_favorite = $options['display_favorite'];

        if (count($favs) == 0) {
            $cats_found = [];
            if (0 == $choose_category) {
                //level 2
                foreach ($categories as $k => $v) {
                    if ($k == $category_id) {
                        if (isset($v['subcategories'])) {
                            $cats_found = $v['subcategories'];
                        }
                    }
                }
            } else {
                $i = 1;
                $cats = $categories;
                while ($i < $level - 1) {
                    $temp = [];
                    foreach ($cats as $k => $v) {
                        if (isset($v["subcategories"])) {
                            $temp = array_merge($temp, $v['subcategories']);
                        }
                    }
                    $cats = $temp;
                    $i++;
                }
                foreach ($cats as $key => $val) {
                    if ($val['id'] == $category_id) {
                        if (isset($val["subcategories"])) {
                            $cats_found = $val['subcategories'];
                        }
                        break;
                    }
                }
            }
            $categories = $cats_found;
        }

        //      $helpdesk_category = new PluginServicecatalogCategory();

        //find category in helpdesk category
        //      $helpdesk_category->getFromDBByCategory($category_id);

        $i = 0;
        if ($display_favorite == 0) {
            uasort($categories, function ($a, $b) {
                return $a['ranking'] - $b['ranking'];
            });
        }
        $tableLi = [];
        $opt['type'] = $type;
        $opt['level'] = $level;
        $opt['display_favorite'] = $display_favorite;
        foreach ($categories as $data) {
            if ($data['disabled'] == 0) {
                $opt['category_id'] = $data['id'];
                $opt['category'] = $data;
                $have_sons = $data['have_sons'];

                if ($data["itilcategories_id"] != 0) {
                    //Have childs
                    if (($data['level'] == $level) && $data['itilcategories_id'] == $category_id) {
                        if ($have_sons > 0) {
                            if (0 == $choose_category) {
                                $opt['choose_category'] = $category_id;
                                $output = self::returnCategoryDetail($opt, $display);
                            } else {
                                $opt['choose_category'] = $choose_category;
                                $output = self::returnCategoryDetail($opt, $display);
                            }
                        } else {
                            $opt['choose_category'] = 0;
                            $output = self::returnCategoryDetail($opt, $display);
                        }
                        if (!$display) {
                            $cat_parent = new ITILCategory();
                            $cat_parent->getFromDB($data['itilcategories_id']);
                            $parent = 0;

                            if (isset($cat_parent->fields["itilcategories_id"])) {
                                $parent = $cat_parent->fields["itilcategories_id"];
                            }

                            $class = "";
                            $style = "";
                            $class = "thumbnail_grid";
                            $style = "style='display:grid;'";
                            //TODO enlever le li si cat = cat parent
                            if (!isset($tableLi[$data['itilcategories_id']]) && ($data['itilcategories_id'] != $category_id || $level >= 3)) {
                                $tableLi[$data['itilcategories_id']] = "<li id='displaycat" . $data['itilcategories_id'] . "' parent='" . $parent . "' level='$level' class='$class' $style>" . $output . "";
                            } elseif ($data['itilcategories_id'] == $category_id && !isset($tableLi[$data['itilcategories_id']])) {
                                $tableLi[$data['itilcategories_id']] = $output;
                            } else {
                                $tableLi[$data['itilcategories_id']] .= $output;
                            }
                        }
                        $i++;
                    } else {
                        if ($have_sons > 0) {
                            if (0 == $choose_category) {
                                $opt['choose_category'] = $category_id;
                                $output = self::returnCategoryDetail($opt, false);
                            } else {
                                $opt['choose_category'] = $choose_category;
                                $output = self::returnCategoryDetail($opt, false);
                            }
                        } else {
                            $opt['choose_category'] = 0;
                            $output = self::returnCategoryDetail($opt, false);
                        }
                        $cat_parent = new ITILCategory();
                        $cat_parent->getFromDB($data['itilcategories_id']);
                        $parent = 0;

                        if (isset($cat_parent->fields["itilcategories_id"])) {
                            $parent = $cat_parent->fields["itilcategories_id"];
                        }

                        $class = "";
                        $style = "";
                        $class = "thumbnail_grid";
                        $style = "style='display:grid;'";
                        if ($display_favorite == 0) {
                            if (!isset($tableLi[$data['itilcategories_id']])) {
                                $tableLi[$data['itilcategories_id']] = "<li id='displaycat" . $data['itilcategories_id'] . "' parent='" . $parent . "' level='$level' class='$class' $style>" . $output . "";
                            } else {
                                $tableLi[$data['itilcategories_id']] .= $output;
                            }
                        } else {
                            //$favorite                            = (isset($data['favorite']) && $data['favorite'] == 1) ? "style='float: left;'" : "";
                            $tableLi[] .= $output;
                        }
                    }
                }
            }
        }

        $config = new PluginServicecatalogConfig();

        if (0 == $i) {

            if (count(PluginServicecatalogCategory::getSons($category_id, $type))) {
                $itilcat = new ITILCategory();
                $itilcat->getFromDB($category_id);
                $level = $itilcat->fields['level'];
                $id_parent = $itilcat->fields['itilcategories_id'];
                $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$category_id&choose_category=$id_parent";
            } else {
                $url = PLUGIN_SERVICECATALOG_WEBDIR . '/front/newticket.form.php?category_id=';
                $url .= $category_id;
                $url .= '&type=' . $type;
            }

            $cat = new PluginServicecatalogCategory();
            if ($cat->getFromDBByCategory($category_id)) {
                $use_website_url = $cat->fields['use_website_url'] ?? 0;
                $website_url = $cat->fields['website_url'] ?? '';
                $target = 1;
                if ($use_website_url == 1) {
                    $target = $cat->fields['website_target'] ?? 1;
                }

                if ($use_website_url && !empty($website_url)) {
                    $url = $website_url;
                }
            }

            if ($display) {
                $layout = $config->getLayout();
                echo "<script>$(document).ready(function() {
              let layout = $layout;
              let target = $target;
              $('#launchcat$category_id').click(function() {
                  console.log('thumbnail-2');
                  sessionStorage.setItem('categoryload', $category_id);
                  if (target == 0) {
                        window.open('" . $url . "', '_blank');
                     } else {
                        window.location.href = '" . $url . "';
                     }
                });
                });</script>";
            } else {
                $layout = $config->getLayout();
                $ret["script"][] = "<script>$(document).ready(function() {
              let layout = $layout;

              $('#launchcat$category_id').click(function() {
                  console.log('thumbnail-3');
                  sessionStorage.setItem('categoryload', $category_id);
                  window.location.href = '" . $url . "';
                });
                });</script>";
            }
        } else {
            $favorites = PluginServicecatalogFavorite::getFavoritesVisibility();
            $favs = json_encode($favorites);
            $url = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/showdetails.php?showalerts&category_id=';
            $url .= $category_id;

            $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($type, $category_id, 4);
            $name = $treename['name'];
            $treescript = json_decode($treename['script']);
            //         $name .= "4";

            if ($display) {
                $layout = $config->getLayout();
                echo "<script>$(document).ready(function() {

              $('#launchcat$category_id').click(function() {
                  console.log('thumbnail-4');
                  sessionStorage.setItem('categoryload', $category_id);
                  let layout = $layout;
                  $('ul.events li').hide();
                  $('.categories_list').hide();
                  if (layout != -1) {
                     $('#title_cat').show();
                     $('#categories_title').show();
                     document.getElementById('title_cat').innerHTML = \"$name\";
                  }
                  $('#displaycat$category_id').show();
                  let cats = $favs;
           
                  $('#favorites_title').hide();
                  $.each(cats, function (i, elem) {
                      $('#favorites_list'+elem).hide();
                  });
                  if ($('#favorites_list$category_id').length > 0) {
                      $('#favorites_title').show();
                  }
                  $('#favorites_list$category_id').show();
                  $('#displaycat$category_id').attr(\"selected\",\"selected\");
                  $('.faq').hide();
                  $('#faq$category_id').show();
                  $('#faq$category_id').css(\"margin-bottom\", \"10px\");
                  $('#launch_details').show();
                  $('#launch_details').load('$url');
                });

                });</script>";
            } else {
                $layout = $config->getLayout();
                $ret["script"][] = "<script>$(document).ready(function() {

              $('#launchcat$category_id').click(function() {
                  console.log('thumbnail-5');
                  sessionStorage.setItem('categoryload', $category_id);
                  let layout = $layout;
                  $('ul.events li').hide();
                  $('.categories_list').hide();
                  if (layout != -1) {
                     $('#title_cat').show();
                     $('#categories_title').show();
                     document.getElementById('title_cat').innerHTML = \"$name\";
                     let newScript = document.createElement('script');
                     newScript.type = 'text/javascript';
                     let scriptContent = document.createTextNode( $treescript ); 
                     newScript.appendChild( scriptContent ); //add the text node to the newly created div. 
                     document.body.appendChild( newScript ); //add the text node to the newly created div. 
                  }
                  $('#displaycat$category_id').show();
                  let cats = $favs;
           
                  $('#favorites_title').hide();
                  $.each(cats, function (i, elem) {
                      $('#favorites_list'+elem).hide();
                  });
                  if ($('#favorites_list$category_id').length > 0) {
                      $('#favorites_title').show();
                  }
                  $('#favorites_list$category_id').show();
                  $('#displaycat$category_id').attr(\"selected\",\"selected\");
                  $('.faq').hide();
                  $('#faq$category_id').show();
                  $('#faq$category_id').css(\"margin-bottom\", \"10px\");
                  $('#launch_details').show();
                  $('#launch_details').load('$url');
                });

                });</script>";
            }
        }
//        $TIME = $TIMER->getTime();
        //      Toolbox::logWarning($TIME);
        if ($display) {
            foreach ($tableLi as $key => $value) {
                echo $value;
            }
        }
        if (!$display) {
            $ret["table"] = $tableLi;
            return $ret;
        }
        //      return $tableLi;
    }

    /**
     * Details of subcategories
     *
     * @param $options
     * @param $display
     *
     * @return string
     * @throws \GlpitestSQLError
     * @throws \GlpitestSQLError
     */
    public static function returnCategoryDetail($options, $display)
    {
        $type = $options['type']; //DEMAND OR INCIDENT
        $category_id = $options['category_id']; //id glpi_itilcategories
        $level = $options['level']; //level of category
        $category = $options['category'];//fields of id from glpi_itilcategories
        $choose_category = $options['choose_category']; //is a parent category ?
        $display_favorite = $options['display_favorite'];
        $mostused = $options['mostused'] ?? 0;
        $output = "";

        $config = new PluginServicecatalogConfig();
        $onclick = "";

        if (!$choose_category) { //Final launch create ticket
            $url_details = '';
            if (count(PluginServicecatalogCategory::getSons($category_id, $type))) {
                $itilcat = new ITILCategory();
                $itilcat->getFromDB($category_id);
                $level = $itilcat->fields['level'];
                $id_parent = $itilcat->fields['itilcategories_id'];
                $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$category_id&choose_category=$id_parent";
            } else {
                $url = PLUGIN_SERVICECATALOG_WEBDIR . '/front/newticket.form.php?category_id=';
                $url .= $category_id;
                $url .= '&type=' . $type;
            }
            $use_website_url = $category['use_website_url'] ?? 0;
            $website_url = $category['website_url'] ?? '';
            $target = 1;
            if ($use_website_url == 1) {
                $target = $category['website_target'] ?? 1;
            }
            if ($use_website_url && !empty($website_url)) {
                $url = $website_url;
            }

            $switch_to_md = $category_id . '0';
            $url_md = "";
            if (Plugin::isPluginActive("metademands")) {
                $myticket = new Ticket();
                $myticket->fields['id'] = 0;
                $myticket->input['type'] = $type;
                $myticket->input['itilcategories_id'] = $category_id;
                if ($md_exists = PluginMetademandsMetademand::redirectForm($myticket, 'show')) {
                    //               $_SESSION['servicecatalog']['sc_itilcategories_id'] = $category_id;
                    $url_md = $md_exists;
                    $switch_to_md = $category_id . '1';
                }
            }

            $faq_exist = $category_id . '0';
            $cat = new ITILCategory();
            if ($cat->getFromDB($category_id)) {
                $kbitem = new KnowbaseItem();
                $found_kbitem = $kbitem->find([KnowbaseItem::getTable() . '.id' => KnowbaseItem::getForCategory($cat->fields['knowbaseitemcategories_id']),
                    'is_faq' => 1
                ]);
                $parent = (isset($cat->fields['itilcategories_id'])) ? $cat->fields['itilcategories_id'] : 0;
                if (count($found_kbitem)) {
                    $faq_exist = $category_id . '1';
                }
            }
            $layout = $config->getLayout();
            $output .= "<script>$(document).ready(function() {
                    console.log('thumbnail-6');
                    let layout = $layout;
                    let switch_to_md = $switch_to_md;
                    let faq = $faq_exist;
                    let parent = $parent;
                    let mostused = $mostused;
                    let target = $target;
                    $('#launchcat" . $category_id . "').click(function(e){
                        sessionStorage.setItem('categoryload', $category_id);
                        if (target == 0) {
                            window.open('" . $url . "', '_blank');
                         } else {
                            window.location.href = '" . $url . "';
                         }
                      });
//                      
//                      $('#urlcat" . $category_id . "').click(function(e){
//                            if (target == 0) {
//                                window.open('" . $url . "', '_blank');
//                             } else {
//                                window.location.href = '" . $url . "';
//                             }
//                             e.stopPropagation();
//});

                    $('#launchfavcat" . $category_id . "').click(function() {
                       sessionStorage.setItem('categoryload', $category_id);
                       window.location.href = '" . $url . "';
                      });
                      $('#launchmostcat" . $category_id . "').click(function() {
                       sessionStorage.setItem('categoryload', $category_id);
                       window.location.href = '" . $url . "';
                      });
                      });

                      </script>";
        } else {
            $url_details = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/showdetails.php?showalerts&category_id=';
            $url_details .= $category_id;
            $faq_exist = $category_id . '0';
            $cat = new ITILCategory();
            if ($cat->getFromDB($category_id)) {
                $kbitem = new KnowbaseItem;
                $found_kbitem = $kbitem->find([KnowbaseItem::getTable() . '.id' => KnowbaseItem::getForCategory($cat->fields['knowbaseitemcategories_id']),
                    'is_faq' => 1
                ]);
                if (count($found_kbitem)) {
                    $faq_exist = $category_id . '1';
                }
            }

            $favorites = PluginServicecatalogFavorite::getFavoritesVisibility();
            $favs = json_encode($favorites);

            $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($type, $category_id, 5);
            $name = $treename['name'];
            $treescript = json_decode($treename['script']);
            //         $name .= "5";

            $conf = json_encode($config);
            $layout = $config->getLayout();
            $root_doc = PLUGIN_SERVICECATALOG_WEBDIR;
            $output .= "<script>$(document).ready(function() {
                      let faq = $faq_exist;
                      let layout = $layout;
                      $('#launchcat" . $category_id . "').click(function() {
                      sessionStorage.setItem('categoryload', $category_id);
                      $('#ajax_loader').show();
                     data = {};
                     data.choose_category = $choose_category;
                     data.type            = $type;
                     data.category_id     = $category_id;
                     data.level           = $level+1;
                     data.display_favorite = 0;
//                     data.config          = $conf;
                        $.ajax({
                                 'url': '$root_doc/ajax/addChild.php',
                                 'data': data,
                                 'dataType': 'json',
                                  'async': true, // Mode synchrone
                                 'type': 'POST'
                              
                              }).done(function (data) {
                                 if(data != 'ok'){
                                    console.log('thumbnail-returnCategoryDetail-addChilds');
                                    $('#events').append(data.script[0]);
                                    $.each(data.table, function(i, item) {
                                        $('#events').append(item);
                                    });
                                 }
                                 let width = (window.innerWidth > 0) ? window.innerWidth : document.documentElement.clientWidth;
                                  if(width < 768){
                                      $('.cats_list').hide();
                                  }
                                 $('ul.events li').hide();
                                 $('#displaycat$category_id').show();
                                 $('#ajax_loader').hide();
            
                        }).fail(function (jqXHR, textStatus, errorThrown) {
                             $('#ajax_loader').hide();
                            window.console.log(jqXHR);
                            window.console.log(textStatus);
                            window.console.log(errorThrown);
                        });
                        
                        $('ul.events li').hide();
                        $('.categories_list').hide();
                        if (layout != -1) {
                           $('#title_cat').show();
                           $('#categories_title').show();
                           document.getElementById('title_cat').innerHTML = \"$name\";
                           
                           let newScript = document.createElement('script');
                           newScript.type = 'text/javascript';
                           let scriptContent = document.createTextNode( $treescript ); 
                           newScript.appendChild( scriptContent ); //add the text node to the newly created div. 
                           document.body.appendChild( newScript ); //add the text node to the newly created div. 
                        }
                        $('#displaycat" . $category_id . "').show();
                        //favs
                         let cats = $favs;
                         $('#favorites_title').hide();
                         $('.favorites_list').hide();
                        $.each(cats, function (i, elem) {
                            $('#favorites_list'+elem).hide();
                        });
                        if ($('#favorites_list$category_id').length > 0) {
                            $('#favorites_title').show();
                            $('.favorites_list').show();
                        }
                        $('#favorites_list$category_id').show();
                        //end favs
                        $('#displaycat" . $category_id . "').attr(\"selected\",\"selected\");

                        //Thumbnail Jquery

                          $('#launch_ticket').hide();
                          $('#launch_details').show();
                          $('#launch_details').load('$url_details');
                          if (faq == " . $category_id . "1) {
                              $('#faq').show();
                              $('#faq$category_id').show();
                              $('#faq$category_id').css(\"margin-bottom\", \"10px\");
                           } else {
                              $('#faq').hide();
                              $('#faq$category_id').hide();
                           }
                        //End Thumbnail Jquery

                      });
                      $('#launchfavcat" . $category_id . "').click(function() {
                        $('ul.events li').hide();
                        $('.categories_list').hide();
                        let layout = $layout;
                        if (layout != -1) {
                           $('#title_cat').show();
                           $('#categories_title').show();
                           document.getElementById('title_cat').innerHTML = \"$name\";
                        }
                         data = {};
                        data.choose_category = $choose_category;
                        data.type            = $type;
                        data.category_id     = $category_id;
                        data.level           = $level+1;
                        data.display_favorite = 0;
//                        data.config          = $conf;
                        data.launchFav          = 1;
                           $.ajax({
                                    'url': '$root_doc/ajax/addChild.php',
                                    'data': data,
                                    'dataType': 'json',
                                     'async': true, // Mode synchrone
                                    'type': 'POST'
                                 
                                 }).done(function (data) {
                                    if(data != 'ok'){
                                       console.log('thumbnail-returnCategoryDetail-addChilds2');
                                       $('#events').append(data.script[0]);
                                       $.each(data.table, function(i, item) {
                                           $('#events').append(item);
                                       });
                                    }
                                    let width = (window.innerWidth > 0) ? window.innerWidth : document.documentElement.clientWidth;
                                     if(width < 768){
                                         $('.cats_list').hide();
                                     }
                                     $('#displaycat" . $category_id . "').show();
                                    $('#displaycat" . $category_id . "').attr(\"selected\",\"selected\");
                                    $('.faq').hide();
                                    //Thumbnail Jquery
            
                                    $('#launch_ticket').hide();
                                      $('#launch_details').show();
                                      $('#launch_details').load('$url_details');
                                      if (faq == " . $category_id . "1) {
                                          $('#faq').show();
                                          $('#faq$category_id').show();
                                          $('#faq$category_id').css(\"margin-bottom\", \"10px\");
                                       } else {
                                          $('#faq').hide();
                                          $('#faq$category_id').hide();
                              }
               
                           }).fail(function (jqXHR, textStatus, errorThrown) {
                                $('#ajax_loader').hide();
                               window.console.log(jqXHR);
                               window.console.log(textStatus);
                               window.console.log(errorThrown);
                           });
                           
                          
                              
   //                        $('#launch_ticket').hide();
   //                        $('#css_ticket').hide();
   //                        $('li[id^=\"launchcat\"]').hide();
   //                        $('li[id=\"launchcat$category_id\"]').show();
   //                        //End Thumbnail Jquery
   //                     $('#faq" . $category_id . "').show();
                         });
                         $('#launchmostcat" . $category_id . "').click(function() {
                         sessionStorage.setItem('categoryload', $category_id);
                        $('ul.events li').hide();
                        $('.categories_list').hide();
                        if (layout != -1) {
                           $('#title_cat').show();
                           $('#categories_title').show();
                           document.getElementById('title_cat').innerHTML = \"$name\";
                        }
                         data = {};
                        data.choose_category = $choose_category;
                        data.type            = $type;
                        data.category_id     = $category_id;
                        data.level           = $level+1;
                        data.display_favorite = 0;
//                        data.config          = $conf;
                        data.launchFav          = 1;
                           $.ajax({
                                    'url': '$root_doc/ajax/addChild.php',
                                    'data': data,
                                    'dataType': 'json',
                                     'async': true, // Mode synchrone
                                    'type': 'POST'
                                 
                                 }).done(function (data) {
                                    if(data != 'ok'){
                                       console.log('thumbnail-returnCategoryDetail-addChilds3');
                                       $('#events').append(data.script[0]);
                                       $.each(data.table, function(i, item) {
                                           $('#events').append(item);
                                       });
                                    }
                                    let width = (window.innerWidth > 0) ? window.innerWidth : document.documentElement.clientWidth;
                                     if(width < 768){
                                         $('.cats_list').hide();
                                     }
                                     $('#displaycat" . $category_id . "').show();
                                    $('#displaycat" . $category_id . "').attr(\"selected\",\"selected\");
                                    $('.faq').hide();
                                    //Thumbnail Jquery
            
                                    $('#launch_ticket').hide();
                                      $('#launch_details').show();
                                      $('#launch_details').load('$url_details');
                                      if (faq == " . $category_id . "1) {
                                          $('#faq').show();
                                          $('#faq$category_id').show();
                                          $('#faq$category_id').css(\"margin-bottom\", \"10px\");
                                       } else {
                                          $('#faq').hide();
                                          $('#faq$category_id').hide();
                              }
               
                           }).fail(function (jqXHR, textStatus, errorThrown) {
                                $('#ajax_loader').hide();
                               window.console.log(jqXHR);
                               window.console.log(textStatus);
                               window.console.log(errorThrown);
                           });
                           
                          
                              
   //                        $('#launch_ticket').hide();
   //                        $('#css_ticket').hide();
   //                        $('li[id^=\"launchcat\"]').hide();
   //                        $('li[id=\"launchcat$category_id\"]').show();
   //                        //End Thumbnail Jquery
   //                     $('#faq" . $category_id . "').show();
   });
  
                         });</script>";
        }
        $title = $category['name'];
        if (isset($category['comment'])) {
            $title = Toolbox::stripTags(nl2br($category['comment']));
        }

        if ($config->seeCategoryDetails() && $display_favorite == 0) {
            $title = "";
        }

        $use_website_url = $category['use_website_url'] ?? 0;
        $website_url = $category['website_url'] ?? '';

        $helpdesk_category = new PluginServicecatalogCategory();
        //find category in helpdesk category
        $helpdesk_category->getFromDBByCategory($category_id);

        $cat = new ITILCategory();
        $cat->getFromDB($category_id);

        $stylea = "";
        $target = "";

        $itilcat = new ITILCategory();
        $itilcat->getFromDB($category_id);
        $level = $itilcat->fields['level'];
        $id_parent = $itilcat->fields['itilcategories_id'];
        if (count(PluginServicecatalogCategory::getSons($category_id, $type))) {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$category_id&choose_category=$id_parent";
        } else {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . '/front/newticket.form.php?category_id=';
            $url .= $category_id;
            $url .= '&type=' . $type;
        }
        if ($use_website_url && !empty($website_url)) {
            if ($use_website_url && $category['website_target'] == 0) {
                $target = 'target="_blank"';
            }
            $url = $website_url;
            $output .= "<a href='" . $url . "' $target $stylea class=\"subcat1\" title=\"" . $title . "\">";
        } else {
            if ($mostused == 1) {
                $output .= "<a href='#' $target $stylea class=\"subcat2\" id=launchmostcat" . $category_id . " title=\"" . $title . "\">";
            } else {
                if ($display_favorite == 0) {
//                    $output .= "<a href='" . $url . "' $stylea class=\"subcat3\" id=launchcat" . $category_id . " title=\"" . $title . "\">";
                } elseif ($display_favorite == 1) {
                    $output .= "<a href='#' $stylea class=\"subcat4\" id=launchfavcat" . $category_id . " title=\"" . $title . "\">";
                }
            }
        }
        $btn = "btnsc-";
        //TODO XAV

        if ($display_favorite == 1
            //            && isset($category['favorite'])
            //            && $category['favorite'] == 1
        ) {
            $btn = "favsc-";
        }
        if ($mostused == 1) {
            $btn = "mostsc-";
        }
        $addstyle = "";
        if ($mostused == 0 && $display_favorite == 0) {
            $addstyle = "style='min-height: 150px;'";
        }

        $addclass = "";

        if ($display_favorite == 1) {
            $addstyle = "style='margin-right: 5px;'";
        }

        $comment = !empty($category['comment']) ? $category['comment'] : "";
        $color = PluginServicecatalogCategory::getUsedConfig("inherit_config", $category_id, "background_color");
        $size = "normal";
        $glue = "";
        $addcenter = "";

//        if ($color == -1) {
//            $output .= "<div title=\"$comment\" class='$btn" . $size . " " . $glue . " child-nav $addclass $addcenter'  $addstyle id=cat" . $category_id . " who='returnCategoryDetailidCreate' " . $onclick . ">";
//        } else {
//            if ($display_favorite == 0) {
//        $onclick="onclick=\"window.location='$url';\"";
//        $output .= "<script>$(document).ready(function() {
//                        $('#cat$category_id').click(function(e) {
//  window.location='$url';
//return false;
//                        });
//    });</script>";

        $output .= "<div id='cat$category_id'  title=\"$comment\" class='$btn" . $size . " " . $glue . " $addclass ' style='background: " . $color . ";margin-right: 5px;' id=cat" . $category_id . " who='returnCategoryDetailidCreate' " . $onclick . ">";
//            } else {
//                $output .= "<div title=\"$comment\" class='$btn" . $size . " " . $glue . " $addclass '  style='background: " . $color . ";margin-right: 5px;' who='returnCategoryDetailidCreate' " . $onclick . ">";
//            }
//        }


        $opt['id_cat'] = $category_id;
        $opt['display'] = false;

        $opt['first'] = 0;
        $opt['display_favorite'] = $display_favorite;
        $opt['display_mostused'] = $mostused;
        $opt['btn'] = $btn;

        if ($display_favorite == 0) {
            $onclick = "onclick=\"window.location='$url';\"";
        }
        $output .= "<div style='height: 100%;cursor:pointer' $onclick>";

        if ($display_favorite == 0) {
            $output .= self::showCategoryLogo($helpdesk_category, $opt);
        }
        //        }
        $style = "";
        //color title child categories
//        if (isset($category['background_color'])) {
//            $color = $category['background_color'];
        $style = "style='color: $color !important;'";
//        }


        if ($display_favorite == 1) {
            $output .= "<div class=\"label_favtitle bottom_title\" $style title=\"" . $title . "\">";
        } else {
            $output .= "<div class=\"label_title bottom_title\" $style>";
        }

        if ($display_favorite == 1) {
            $output .= self::showCategoryLogo($helpdesk_category, $opt);
            $output .= "&nbsp;";
        }

        if ($display_favorite == 0) {
            if (!$choose_category) {
                $fa_style = "fas fa-caret-right";
            } else {
                $fa_style = "far fa-folder-open";
            }
            $output .= "<i class=\"$fa_style sc-fa-color fa-2x\" aria-hidden=\"true\" $style></i>&nbsp;";
        }
        if ($type == Ticket::INCIDENT_TYPE) {
            $field = $category['simplified_name_incident'] ?? "";
        } else {
            $field = $category['simplified_name_request'] ?? "";
        }
        $r = 70;
        if ($display_favorite == 1) {
            $r = 35;
        }
        if (isset($field) && $field != "") {
            $name = Html::resume_text($field, $r);
        } elseif ($category['name'] != "") {
            $name = Html::resume_text($category['name'], $r);
        } else {
            $name = NOT_AVAILABLE;
        }
        $output .= $name;

        if ($config->seeCategoryDetails()) {
            $detail = new PluginServicecatalogCategory();
            if ($detail->getFromDBByCategory($category_id)) {
                $output .= "&nbsp;";
                $output .= PluginServicecatalogMain::getServiceDetailsText($detail, $type, false);
            }
        }
        $output .= "</div></div>";

        if ($display_favorite == 0) {
            if ($mostused != 1) {
                $color = PluginServicecatalogCategory::getUsedConfig("inherit_config", $category_id, "background_color");
                $color = ($color == null ? $config->getGeneralColor() : $color);

                $style = "style=\"color: $color !important;\"";
                $stylefa = "style=\"color: $color !important;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';bottom: 5px;float: right;position: absolute;right: 5px;\"";

                if (Session::haveRight('plugin_servicecatalog_favorites', CREATE)) {
                    $output .= "<div class='headfavorite right' $style>";

                    $output .= "<script>$(document).ready(function() {
                        $('#addfav" . $category_id . "', '#deletefav" . $category_id . "').click(function(e){
                            var href = $(this).attr('data-bs-target');
                        });
                    });</script>";
                    $favorite = new PluginServicecatalogFavorite();
                    if ($favorite->getFromDBByCrit(['itilcategories_id' => $category_id,
                        'favorite_itilcategories_id' => 0,
                        'users_id' => Session::getLoginUserID()])) {
                        if ($category['have_sons'] == 0) {
                            $output .= "<span id='deletefav$category_id' data-bs-toggle='modal' data-bs-target='#deletefavorite$category_id' title=\"" . __('Delete favorite', 'servicecatalog') . "\">";
                            $output .= "<i $stylefa class='right fas fa-star fa-1x'></i>";
                            $output .= "</span>";
                            $output .= Ajax::createIframeModalWindow(
                                'deletefavorite' . $category_id,
                                PLUGIN_SERVICECATALOG_WEBDIR . "/front/managefavorite.form.php?delete_favorite=1&category_id=" . $category_id,
                                ['title' => __('Delete favorite', 'servicecatalog'),
                                    'display' => false,
                                    'width' => 1050,
                                    'height' => 100,
                                    //                             'reloadonclose' => true
                                ]
                            );
                        }
                    } else {
                        if ($category['have_sons'] == 0) {
                            $output .= "<span href='#' id='addfav$category_id' class='addfav' data-bs-toggle='modal' data-bs-target='#addfavorite$category_id' title=\"" . __('Add as favorite at homepage', 'servicecatalog') . "\">";
                            $output .= "<i $stylefa class='right far fa-star fa-1x'></i>";
                            $output .= "</span>";
                            $output .= Ajax::createIframeModalWindow(
                                'addfavorite' . $category_id,
                                PLUGIN_SERVICECATALOG_WEBDIR . "/front/managefavorite.form.php?add_favorite=1&type=$type&category_id=" . $category_id,
                                ['title' => __('Add as favorite at homepage', 'servicecatalog'),
                                    'display' => false,
                                    'width' => 1050,
                                    'height' => 100,
                                    //                             'reloadonclose' => true
                                ]
                            );
                        } else {
//                            $output .= "<i $stylefa class='far fa-1x'></i>";
                        }
                    }

                    $output .= "</div>";

                }
            }
        }
        $output .= "</div>";
        $output .= "</a>";

        if ($display) {
            echo $output;
        } else {
            return $output;
        }
        //      return $output;
    }
}
