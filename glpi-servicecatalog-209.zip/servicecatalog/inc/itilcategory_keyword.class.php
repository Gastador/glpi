<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogItilcategory_Keyword
 */
class PluginServicecatalogItilcategory_Keyword extends CommonDBTM
{
    public static $rightname = "plugin_servicecatalog_setup";


    /**
     * Get the Search options for the given Type
     *
     * This should be overloaded in Class
     *
     * @return array an *indexed* array of search options
     *
     * @see https://glpi-developer-documentation.rtfd.io/en/master/devapi/search.html
     **/
    public function rawSearchOptions()
    {
        $tab = [];

        $tab[] = [
            'id' => 'common',
            'name' => __('Characteristics')
        ];

        $tab[] = [
            'id' => '2',
            'table' => $this->getTable(),
            'field' => 'plugin_servicecatalog_categories_id',
            'name' => PluginServicecatalogMain::getTypeName() . " - " . __('ID'),
            'searchtype' => 'equals',
            'datatype' => 'id'
        ];

        $tab[] = [
            'id' => '3',
            'table' => $this->getTable(),
            'field' => 'name',
            'name' => __('Keywords', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        return $tab;
    }


    /**
     * Get keywords
     *
     * @param $servicecatalog_categories_id
     *
     * @return all|array
     */
    public function getKeywords($servicecatalog_categories_id)
    {
        $keywords = [];
        if ($servicecatalog_categories_id > 0) {
            $keywords = $this->find(['plugin_servicecatalog_categories_id' => $servicecatalog_categories_id], "id");
        }
        return $keywords;
    }

   /**
    * Get keywords in string separated by ;
    *
    * @param $servicecatalog_categories_id
    *
    * @return all|array
    */
    public function getKeywordsInString($servicecatalog_categories_id)
    {
        $tab = [];

        $keywords = $this->find(['plugin_servicecatalog_categories_id' => $servicecatalog_categories_id], "id");
        foreach ($keywords as $keyword) {
            $tab[] = $keyword['name'];
        }
        $string_keywords = implode(", ", $tab);
        return $string_keywords;
    }

   /**
    * update keywords in database
    *
    * @param type  $keywords_add
    * @param type  $servicecatalog_categories_id
    *
    * @global type $DB
    *
    */
    public function updateKeywords($keywords_add, $servicecatalog_categories_id)
    {
        global $DB;

        $keywords = [];
        $iterator = $DB->request([
                                  'FROM'  => getTableForItemType(__CLASS__),
                                  'WHERE' => [
                                     'plugin_servicecatalog_categories_id' => $servicecatalog_categories_id,
                                  ],
                               ]);
        if (count($iterator)) {
            foreach ($iterator as $data) {
                $keywords[addslashes($data['name'])] = addslashes($data['name']);
            }
        }
        $input                                        = [];
        $input['plugin_servicecatalog_categories_id'] = $servicecatalog_categories_id;

        foreach ($keywords_add as $key => $data) {
            if (!empty($data)) {
                if (!in_array($data, $keywords)) {
                    $input['name'] = $data;
                    $this->add($input);
                }
                unset($keywords[$data]);
            }
        }

        //delete old keywords
        if (count($keywords) > 0) {
            foreach ($keywords as $data) {
                $this->deleteByCriteria(['name'                                => stripslashes($data),
                                     'plugin_servicecatalog_categories_id' => $servicecatalog_categories_id], 1);
            }
        }
    }

   /**
    * Clean keywords
    *
    * @param type $servicecatalog_categories_id
    */
    public function cleanKeywords($servicecatalog_categories_id)
    {
        $this->deleteByCriteria(['plugin_servicecatalog_categories_id' => $servicecatalog_categories_id], 1);
    }

    /**
     * @param datas $input
     *
     * @return bool|datas
     */
    public function prepareInputForAdd($input)
    {
        if (isset($input['name']) && empty($input['name'])) {
            return false;
        }

        return $input;
    }
}
