<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

use Glpi\Toolbox\Sanitizer;

/**
 * Class PluginServicecatalogKnowbase
 */
class PluginServicecatalogKnowbase extends CommonDBTM
{
    public static $rightname = 'plugin_servicecatalog';

    /**
     * @param $opt
     *
     * @throws \GlpitestSQLError
     */
    public static function createFaqDiv($opt, $datas)
    {
        if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)) {
            $type = $opt['type'];
            //         $datas      = PluginServicecatalogCategory::getCategoriesCache($type);
            $categories = isset($datas) ? $datas : [];

            $cats = $categories;
            while (!empty($categories)) {
                $temp = [];
                foreach ($categories as $k => $v) {
                    if (isset($v["subcategories"])) {
                        $temp = array_merge($temp, $v['subcategories']);
                    }
                }
                $cats       = array_merge($cats, $temp);
                $categories = $temp;
            }

            $config = new PluginServicecatalogConfig();
            if (count($cats) > 0 && $config->seeFAQ()) {
                foreach ($cats as $id => $value) {
                    if (isset($value['knowbaseitemcategories_id'])
                        && $value['knowbaseitemcategories_id'] > 0
                        && Session::haveRightsOr('knowbase', [READ, KnowbaseItem::READFAQ])) {
                        $opt['knowbaseitemcategories_id'] = $value['knowbaseitemcategories_id'];
                        $opt['categories_id']             = $value['id'];
                        self::showKnowbaseItemList($opt, $config, 'browse');
                    }
                }
                //            echo "<br>";
            }
        }
    }

    /**
     * Print out list kb item
     *
     * @param $options $_GET
     * @param $type      string   search type : browse / search (default search)
     * @param $config
     *
     * @throws \GlpitestSQLError
     */
    public static function showKnowbaseItemList($options, $config, $type = 'search')
    {
        // Default values of parameters
        $params['faq']                       = !Session::haveRight(KnowbaseItem::$rightname, READ);
        $params["start"]                     = "0";
        $params["knowbaseitemcategories_id"] = "0";
        $params["contains"]                  = "";
        $params["hidden"]                    = "hidden";
        $params["target"]                    = $_SERVER['PHP_SELF'];

        if (is_array($options) && count($options)) {
            foreach ($options as $key => $val) {
                $params[$key] = $val;
            }
        }

        if (!$params["start"]) {
            $params["start"] = 0;
        }

        $criteria = KnowbaseItem::getListRequest($params, $type);
        $DBread   = DBConnection::getReadConnection();

        $main_iterator = $DBread->request($criteria);
        $rows          = count($main_iterator);
        $numrows       = $rows;

        // Get it from database
        $KbCategory = new KnowbaseItemCategory();
        $title      = "";
        if ($KbCategory->getFromDB($params["knowbaseitemcategories_id"])) {
            $title = (empty($KbCategory->fields['name']) ? "(" . $params['knowbaseitemcategories_id'] . ")"
                : $KbCategory->fields['name']);
            $title = sprintf(__('%1$s: %2$s'), __('Category'), $title);
        }

        Session::initNavigateListItems('KnowbaseItem', $title);

        $list_limit = $_SESSION['glpilist_limit'];

        // Limit the result, if no limit applies, use prior result
        if (($numrows > $list_limit)
            && !isset($_GET['export_all'])) {
            $criteria['START'] = (int)$params['start'];
            $criteria['LIMIT'] = (int)$list_limit;
            $main_iterator     = $DBread->request($criteria);
            $numrows           = count($main_iterator);
        }

        if ($numrows > 0) {
            echo "<div id='faq" . $params["categories_id"] . "' class='faq " . $params["hidden"] . "'>"; //bt-container
            if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
                echo "<div id='content' class='details'>";
            }
            $style  = "";
            $config = new PluginServicecatalogConfig();
            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                $style = 'style="border: 1px solid transparent;border-radius: 0;margin: 0px;margin-bottom: 10px;"';
            }
            if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL
                || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                $style = 'style="border-radius: 0;margin: 0px;margin-bottom: 10px;"';
            }

            $title = PluginServicecatalogConfig::displayField($config, 'select_title_faq_article');

            if ($config->getLayout() != PluginServicecatalogConfig::THUMBNAIL
                && $config->getLayout() != PluginServicecatalogConfig::THUMBNAIL_WRAPPER
                && $config->getLayout() != PluginServicecatalogConfig::SLY
                && $config->getLayout() != PluginServicecatalogConfig::WRAPPER
                && $config->getLayout() != PluginServicecatalogConfig::WRAPPERSLY
                && $config->getLayout() != PluginServicecatalogConfig::SHOPER) {
                echo "<h4>";
            } else {
                echo "<h5>";
            }

            if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
                || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY
                || $config->getLayout() == PluginServicecatalogConfig::SHOPER) {
                echo "<div class='alert alert-secondary' role='alert' $style>";
            } else {
                $class2 = "";
                if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    $class2 = "alert-bootstrapped";
                }
                echo "<div class='alert alert-secondary $class2' role='alert' $style>";
            }
            echo $title;
            echo "</div>";

            if ($config->getLayout() != PluginServicecatalogConfig::THUMBNAIL
                && $config->getLayout() != PluginServicecatalogConfig::THUMBNAIL_WRAPPER
                && $config->getLayout() != PluginServicecatalogConfig::SLY
                && $config->getLayout() != PluginServicecatalogConfig::WRAPPER
                && $config->getLayout() != PluginServicecatalogConfig::WRAPPERSLY
                && $config->getLayout() != PluginServicecatalogConfig::SHOPER) {
                echo "</h4>";
            } else {
                echo "</h5>";
            }

            $row_num = 1;

            foreach ($main_iterator as $data) {
                Session::addToNavigateListItems('KnowbaseItem', $data["id"]);
                // Column num
                $row_num++;
                echo "<div class=\"faqrow visitedchildbg\">";//bt-row

                $item = new KnowbaseItem;
                $item->getFromDB($data["id"]);
                $name   = $data["name"];
                $answer = $data["answer"];
                // Manage translations
                if (isset($data['transname']) && !empty($data['transname'])) {
                    $name = $data["transname"];
                }
                if (isset($data['transanswer']) && !empty($data['transanswer'])) {
                    $answer = $data["transanswer"];
                }

                $rand        = mt_rand();
                $url_details = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/showfaq.php?faq_id=';
                $url_details .= $data["id"];

                $icon = "<i class='fas fas fa-caret-right fa-1x' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>&nbsp;";
                echo "<div class='bt-col-xs-8'><a style=\"font-size: 14px\" class='pointer pubfaq'
                    onclick='loadfaq$rand()'>$icon" . Html::resume_text($name, 80) . "</a></div>
                                          <div class='kb_resume'>" .
                     Html::resume_text(
                         Toolbox::stripTags(Sanitizer::unsanitize($answer)),
                         300
                     ) . "</div>";

                // End Line
                echo "</div>";

                echo Html::scriptBlock("
                        function loadfaq$rand() {
                                 $('.faq_articles').hide();
                                 $('.faq_articles').show();
                                 $('#faq_articles').load('$url_details');
                                 }");
            }

            if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
                echo "</div>";
            }

            echo "</div>";
        }
    }

    /**
     * @param $datas
     *
     * @return void
     */
    public function showFAQItem($datas)
    {
        global $DB;

        $article = new KnowbaseItem();

        if (isset($datas['faq_id']) && $article->getFromDB($datas['faq_id'])) {
            $article->updateCounter();

            $config = new PluginServicecatalogConfig();
            $class= "";
            if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
                $class = "class='details'";
            }

            echo "<div id='content' $class>";
            echo "<div>";
            echo "<div class='bt-block bt-features'>";

            $title = __('FAQ item');
            echo PluginServicecatalogWidget::getNavigationTitle($title, true);

            echo "<div class=\"visitedchildbg widgetrow\">";

            echo "<div class=\"bt-row\">";
            echo "<div class=\"form-group\">";
            echo "<div class=\"bt-col-md-11\">";

            $title = __('Subject');
            echo PluginServicecatalogWidget::getNavigationTitle($title, true);

            echo "<div id='display-sc'>";
            if (KnowbaseItemTranslation::canBeTranslated($article)) {
                echo KnowbaseItemTranslation::getTranslatedValue($article, 'name');
            } else {
                echo nl2br($article->fields['name']);
            }
            echo "</div>";
            echo "</div>";
            echo "</div><br>";

            echo "<div class=\"bt-row\">";
            echo "<div class=\"form-group\">";
            echo "<div class=\"bt-col-md-11\">";

            $title = __('Content');
            echo PluginServicecatalogWidget::getNavigationTitle($title, true);

            echo "<div id='display-sc'>";
            $rand      = mt_rand();
            $rand_text = mt_rand();

            Html::initEditorSystem("answer" . $rand, $rand, true, true);
            if (!isset($article->fields['answer'])) {
                $article->fields['answer'] = '';
            }
            echo "<div id='answer$rand_text'>";
            Html::textarea(['name'            => 'answer',
                            'value'           => $article->getAnswer(),
                            'editor_id'       => 'answer' . $rand,
                            'enable_richtext' => false,
                            'rows'            => '3']);
            echo "</div>";
            echo "</div>";
            echo "</div>";

            $iterator = $DB->request([
                                         'FIELDS' => 'documents_id',
                                         'FROM'   => 'glpi_documents_items',
                                         'WHERE'  => [
                                             'items_id' => $article->fields["id"],
                                             'itemtype' => 'KnowbaseItem'
                                         ]
                                     ]);

            $numrows = count($iterator);

            if ($numrows > 0) {
                echo "<div class=\"bt-row\">";

                echo "<div class=\"form-group\">";
                echo "<div class=\"bt-col-md-11\">";

                $title = _n('Document', 'Documents', $numrows);
                echo PluginServicecatalogWidget::getWidgetTitle($title, true);

                echo "<div id='display-sc'>";

                $j = 0;

                foreach ($iterator as $docs) {
                    $doc = new Document();
                    $doc->getFromDB($docs["documents_id"]);
                    echo $doc->getDownloadLink();
                    $j++;
                    if ($j > 1) {
                        echo "<br>";
                    }
                }

                echo "</div>";
                echo "</div>";
                echo "</div>";
            }

            echo "<br>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
        }
    }

    /**
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     */
    public static function getWidgetDocbase($widget, $bloc_class)
    {
        global $CFG_GLPI;

        $buttons = "";

        //DOCBASE
        if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)
            && $widget->fields['linked_kbcategory'] > 0
            && $widget->fields['docbase_widgetactions'] == 1) {
            //         $link = 'helpdesk.faq.php';
            //         if (Session::getCurrentInterface() == 'central') {
            //            $link = 'knowbaseitem.php';
            //         }
            //
            //         $url     = $CFG_GLPI['root_doc'] . "/front/$link?forcetab=Knowbase$2&knowbaseitemcategories_id=" . $config->fields['linked_kbcategory'];
            $url     = PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php?docbase=1";
            $title   = PluginServicecatalogConfig::displayField($widget, 'title_database');
            $url_img = "picture.send.php";
            $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img"     => $widget->fields['img_database'],
                                                                                         "url_img" => $url_img,
                                                                                         "fa"      => $widget->fields['fa_database'],
                                                                                         "title"   => $title,
                                                                                         "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_database')]);
        }

        return $buttons;
    }

    /**
     * @param $widget
     *
     * @return string
     */
    public static function showNavBarMenuDocbase($widget)
    {
        $menu = [];
        if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)
            && $widget->fields['linked_kbcategory'] > 0) {
            $url           = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/faq.php?docbase=1";
            $title         = PluginServicecatalogConfig::displayField($widget, 'title_database');
            $menu['title'] = $title;
            $menu['page']  = $url;
            if (!empty($widget->fields['fa_database'])) {
                $icon          = $widget->fields['fa_database'];
                $menu['icon']  = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "docbase_bar";
        }
        return $menu;
    }

    public static function showFirstKBCats()
    {
        PluginServicecatalogConfig::loadForLayout();

        echo "<div id='content' class='sc-content'>";
        echo "<div class='bt-container'>";
        echo "<div class='bt-block bt-features' style='padding-top: 5px;'>";
        echo "<h5><div class='alert alert-info' role='alert'>";

        //      echo "<div class='bt-container'>";
        //      echo "<div class='wrapper'>";
        //      echo "<div class='wrap'>";

        $widget = new PluginServicecatalogWidget();
        echo PluginServicecatalogConfig::displayField($widget, 'title_faq');
        echo "</div>
               </h5>";
        self::getFirstCatList();

        //      echo "</div>";
        //      echo "</div>";
        //      echo "</div>";

        echo "</div>";
        echo "</div>";
        echo "</div>";
    }

    public static function getFirstCatList()
    {
        global $CFG_GLPI;

        echo "<script>$(document).ready(function() {
                       $('#click').click(function() {
                            window.location.href = '" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php';
                       });
                  });</script>";
        $widget = new PluginServicecatalogWidget();
        $items  = self::getKbItems();
        if (count($items) > 0) {
            foreach ($items as $item) {
                $knowbasecat = new KnowbaseItemCategory();
                if ($knowbasecat->getFromDB($item["knowbaseitemcategories_id"])) {
                    if ($knowbasecat->fields['level'] == 1) {
                        $cats[$item["knowbaseitemcategories_id"]] = $knowbasecat->fields['comment'];
                    }
                }
            }

            foreach ($cats as $id => $comment) {
                echo '<div class="linksc-normal visitedchildbg" >';
                $target = "";
                echo "<a class='bt-buttons' href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php?catid=$id' $target >";
                $fasize = "fa-5x";
                echo "<div class='center'>";
                echo "<i class='bt-interface fa-menu-sc fas " . $widget->fields['fa_faq'] . " $fasize' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>";//$style
                echo "</div>";
                echo "</a>";
                echo "<a class='bt-buttons' style='display: block;width: 100%; height: 100%;' href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php?catid=$id' $target >";
                echo "<h5 class=\"bt-title center\">";
                echo Dropdown::getDropdownName("glpi_knowbaseitemcategories", $id);
                echo "</h5>";
                echo "<em><span style=\"font-weight: normal;font-size: 11px;\">";
                $commentcat = DropdownTranslation::getTranslatedValue($id, 'KnowbaseItemCategory', 'comment', $_SESSION['glpilanguage']);
                if (empty($commentcat)) {
                    $commentcat = $comment;
                }
                echo $commentcat;
                echo "</span></em>";
                echo "</a>";
                echo '</div>';
            }
        }

        if (count($cats) == 0) {
            echo '<div class="bt-feature bt-col-sm-5 bt-col-md-2">';
            echo '<h5 class="bt-title">';
            echo '<span class="de-em">' . __('No article founded', 'servicecatalog') . '</span></h5>';
            echo '</div>';
            echo '</div>';
        }
    }

    /**
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     */
    public static function getWidgetFAQ($widget, $bloc_class)
    {
        $buttons = "";

        //FAQ
        if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)
            && $widget->fields['faq_widgetactions'] == 1) {
            //         $url     = $CFG_GLPI['root_doc'] . "/front/helpdesk.faq.php?knowbaseitemcategories_id=0";
            $url     = PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php";
            $title   = PluginServicecatalogConfig::displayField($widget, 'title_faq');
            $url_img = "picture.send.php";
            $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img"     => $widget->fields['img_faq'],
                                                                                         "url_img" => $url_img,
                                                                                         "fa"      => $widget->fields['fa_faq'],
                                                                                         "title"   => $title,
                                                                                         "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_faq')]);
        }

        return $buttons;
    }

    /**
     * @param     $id
     * @param     $class
     *
     * @return string
     * @throws \GlpitestSQLError
     */
    public static function getWidgetSearchFAQ($id, $class)
    {
        $items = self::getKbItems();

        $delclass = "";
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $delclass = "delclass";
        }
        $display = Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . '/scripts/kbsearch.js.php');
        $display .= "<div id='$id' class=\"bt-row $delclass\">";
        $display .= "<div class=\"bt-feature bt-col-md-12 $class\">";

        $config = new PluginServicecatalogConfig();
        $title  = PluginServicecatalogConfig::displayField($config, 'select_title_faq_article');
        if (isset($title) && !empty($title)) {
            $title_widget = $title;
        } else {
            $title_widget = __('Search a solution into FAQ ?', 'servicecatalog');
        }
        $display .= PluginServicecatalogWidget::getWidgetTitle($title_widget);

        if (count($items) > 0) {
            $config = new PluginServicecatalogConfig();

            $display .= "<div id='plugin_servicecatalog_search_kb_Bar'>";
            $display .= '<form name="servicecatalog_search" onsubmit="javascript: return false;" >';
            //         $display .= '<input type="text" name="words" id="servicecatalog_search_input"/>';
            $display .= Html::input('words', ['id' => 'servicecatalog_search_input', 'size' => 40]);
            //         $display .= '<input type="hidden" name="layout" id="layout_id" value="' . $config->getLayout() . '"/>';
            $display .= Html::hidden('layout', ['id'    => 'layout_id',
                                                'value' => $config->getLayout()]);
            $display .= '<span id="servicecatalog_search_input_bar"></span>';
            $display .= '<label for="servicecatalog_search_input">' . PluginServicecatalogConfig::displayField($config, 'title_searchbar_kb') . '</label>';
            $display .= '</form>';
            $display .= "</div>";

            $display .= "<div id='plugin_servicecatalog_kb_results'>";
            $display .= "</div>";
        } else {
            $display .= __('No data available', 'servicecatalog');
        }

        $display .= "</div>";
        $display .= "</div>";

        return $display;
    }

    /**
     * get list of categories in fact the type
     *
     * @param string $criteria
     * @param array  $knowbaseitemcategories_id
     * @param int    $id glpi_knowbaseitems.id
     *
     * @return array
     * @throws \GlpitestSQLError
     */
    public static function getKbItems($criteria = "", $knowbaseitemcategories_id = [], $id = 0)
    {
        global $DB, $CFG_GLPI;

        $faq       = Session::haveRight('knowbase', KnowbaseItem::READFAQ);
        $orderby   = "ORDER BY `glpi_knowbaseitemcategories`.`name`,`glpi_knowbaseitems`.`name`";
        $faq_limit = "";
        // Force all joins for not published to verify no visibility set
        $join = KnowbaseItem::addVisibilityJoins(true);
        $join .= " LEFT JOIN `glpi_knowbaseitems_knowbaseitemcategories` ON (`glpi_knowbaseitems`.`id` = `glpi_knowbaseitems_knowbaseitemcategories`.`knowbaseitems_id`)";
        $join .= " LEFT JOIN `glpi_knowbaseitemcategories` ON (`glpi_knowbaseitemcategories`.`id` = `glpi_knowbaseitems_knowbaseitemcategories`.`knowbaseitemcategories_id`)";
        if (Session::getLoginUserID()) {
            $faq_limit .= "WHERE " . KnowbaseItem::addVisibilityRestrict();
        } else {
            // Anonymous access
            if (Session::isMultiEntitiesMode()) {
                $faq_limit .= " WHERE (`glpi_entities_knowbaseitems`.`entities_id` = '0'
                                         AND `glpi_entities_knowbaseitems`.`is_recursive` = '1')";
            } else {
                $faq_limit .= " WHERE 1";
            }
        }

        // Only published
        $faq_limit .= " AND (`glpi_entities_knowbaseitems`.`entities_id` IS NOT NULL
                                 OR `glpi_knowbaseitems_profiles`.`profiles_id` IS NOT NULL
                                 OR `glpi_groups_knowbaseitems`.`groups_id` IS NOT NULL
                                 OR `glpi_knowbaseitems_users`.`users_id` IS NOT NULL)";

        if ($faq) { // FAQ
            $faq_limit .= " AND (`glpi_knowbaseitems`.`is_faq` = '1')";
        }

        if (isset($knowbaseitemcategories_id) && !$CFG_GLPI["use_public_faq"]) { // FAQ
            $faq_limit .= " AND `glpi_knowbaseitems_knowbaseitemcategories`.`knowbaseitemcategories_id` != 0";
        }

        if (count($knowbaseitemcategories_id) > 0) { // FAQ
            $faq_limit .= " AND (`glpi_knowbaseitems_knowbaseitemcategories`.`knowbaseitemcategories_id` $criteria (" . implode(",", $knowbaseitemcategories_id) . "))";
        }

        if ($id > 0) {
            $faq_limit .= " AND (`glpi_knowbaseitems`.`id` = $id)";
        }

        $publication_limit = " AND (`glpi_knowbaseitems`.`begin_date` IS NULL OR `glpi_knowbaseitems`.`begin_date` < NOW())";
        $publication_limit .= " AND (`glpi_knowbaseitems`.`end_date` IS NULL OR `glpi_knowbaseitems`.`end_date` > NOW())";
        $query             = "SELECT DISTINCT `glpi_knowbaseitems`.`id`, 
                                `glpi_knowbaseitems`.`name`,
                                `glpi_knowbaseitemcategories`.`name` as catname,
                                `glpi_knowbaseitems`.`answer`,
                                `glpi_knowbaseitems`.`is_faq`, 
                                `glpi_knowbaseitems_knowbaseitemcategories`.`knowbaseitemcategories_id`, 
                                `glpi_knowbaseitems`.`date_creation`, 
                                `glpi_knowbaseitems`.`date_mod`
                      FROM `glpi_knowbaseitems`
                      $join
                      $faq_limit
                      $publication_limit
                      $orderby ";
        $result            = $DB->query($query);//glpi_knowbaseitems_knowbaseitemcategories

        $datastoadd = [];

        while ($data = $DB->fetchAssoc($result)) {
            $kbarticle = new KnowbaseItem();
            $kbarticle->getFromDB($data['id']);
            if (KnowbaseItemTranslation::canBeTranslated($kbarticle)) {
                $name   = KnowbaseItemTranslation::getTranslatedValue($kbarticle, 'name');
                $answer = KnowbaseItemTranslation::getTranslatedValue($kbarticle, 'answer');
            } else {
                $name   = $kbarticle->fields["name"];
                $answer = $kbarticle->fields["answer"];
            }

            $answer       = Toolbox::stripTags(Sanitizer::unsanitize(html_entity_decode(
                $answer,
                ENT_QUOTES,
                "UTF-8"
            )));
            $datastoadd[] = ['id'                        => $data["id"],
                             'name'                      => $name,
                             'knowbaseitemcategories_id' => $data["knowbaseitemcategories_id"],
                             'answer'                    => $answer];
        }

        return $datastoadd;
    }

    /**
     * @param $type
     * @param $widget
     *
     * @return string
     */
    //   static function showLinkMenu($type, $widget) {
    //      global $CFG_GLPI;
    //
    //      $form = "";
    //      if (Session::haveRight('knowbase', KnowbaseItem::READFAQ) && $widget->fields["faq_topmenu"] == 1) {
    //         $url   = PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php";
    //         $form  .= "<a class='box' href='" . $url . "'>";
    //         $title = PluginServicecatalogConfig::displayField($widget, 'title_faq');
    //         if (!empty($widget->fields['fa_faq'])) {
    //            $icon = $widget->fields['fa_faq'];
    //            $form .= "<i class='fas $icon fa-2x sc-hover' title='" . $title . " ' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>&nbsp;";
    //         }
    //         $form .= "<span>" . $title . "</span>";
    //         $form .= "</a>";
    //      }
    //      return $form;
    //   }

    /**
     * @param $widget
     *
     * @return string
     */
    public static function showNavBarMenuFAQ($widget)
    {
        global $CFG_GLPI;

        $menu = [];
        if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)
            || $CFG_GLPI["use_public_faq"]) {
            $url           = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/faq.php";
            $title         = PluginServicecatalogConfig::displayField($widget, 'title_faq');
            $menu['title'] = $title;
            $menu['page']  = $url;
            if (!empty($widget->fields['fa_faq'])) {
                $icon          = $widget->fields['fa_faq'];
                $menu['icon']  = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "faq_bar";
        }
        return $menu;
    }

    /**
     * @param $crit
     *
     * @throws \GlpitestSQLError
     */
    public static function showFAQ($crit)
    {
        global $DB, $CFG_GLPI;

        echo "<div class='faqpage sc-content'>";

//        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . '/scripts/faqsearch.js.php');
        $config = new PluginServicecatalogConfig();
        $widget = new PluginServicecatalogWidget();
        $title  = PluginServicecatalogConfig::displayField($widget, 'title_faq');

        if (isset($title) && !empty($title)) {
            $title_widget = $title;
        } else {
            $title_widget = __('FAQ');
        }

        echo PluginServicecatalogWidget::getPageTitle($title_widget);

        //      echo "<div class='faq_searchbar full_glpi_policy' id='plugin_servicecatalog_search_faq_Bar'>";
        //      echo "<span id='servicecatalog_search_inputfaq_bar'></span>";
        //      echo __('Search') . "&nbsp;";
        //      echo "<input type='search' class='form-control-sm' id='search'  placeholder='" . $title . "' name='search'>";
        //      echo Html::hidden('layout', ['id' => 'layout_id', 'value' => 4]);
        //      echo "</div>";

        $docbase  = [];
        $criteria = "";
        if (isset($crit['docbase']) && $crit['docbase'] == 1) {
            $docbase = getSonsOf("glpi_knowbaseitemcategories", $config->fields['linked_kbcategory']);
            unset($docbase[$config->fields['linked_kbcategory']]);
            $criteria = "IN";
        }
        $id = 0;
        if (isset($crit['id']) && $crit['id'] > 0 && is_numeric($crit['id'])) {
            $id       = (int)$crit['id'];
            $criteria = "IN";
        }

        if (isset($crit['catid']) && is_numeric($crit['catid'])) {
            $docbase  = getSonsOf("glpi_knowbaseitemcategories", (int)$crit['catid']);
            $criteria = "IN";
        }

        $kbitems             = self::getKbItems($criteria, $docbase, $id);
        $kbitems_by_category = [];

        foreach ($kbitems as $key => $kbitem) {
            $kbitems_by_category[$kbitem['knowbaseitemcategories_id']][] = $kbitem;
        }

        $count  = count($kbitems_by_category);
        $height = ($count > 0) ? $count * 50 : "200";
        echo "<section class='cd-faq' style='min-height:" . $height . "px; display:flex;'>";

        echo "<div class='cd-faq-categories cattree'>";
        $i = 1;

        //      foreach ($kbitems_by_category as $key => $details) {
        //         $selected = "";
        //         if ($i == 1) {
        //            $selected = "selected";
        //         }
        //         $kbcat = new KnowbaseItemCategory();
        //         if (DropdownTranslation::canBeTranslated($kbcat)
        //             && Session::haveTranslations(KnowbaseItemCategory::class, 'name')) {
        //            $catname = DropdownTranslation::getTranslatedValue(
        //               $key,
        //               KnowbaseItemCategory::class,
        //               'name',
        //               $_SESSION['glpilanguage']
        //            );
        //         } else {
        //            $kbcat->getFromDB($key);
        //            $catname = isset($kbcat->fields["name"]) ? $kbcat->fields["name"] : __('Without category', 'servicecatalog');
        //         }
        //         echo "<li><a href='#$key' class='menu $selected'>" . $catname . "</a></li>";
        //         $i++;
        //
        //      }
        $cats = [];
        self::kbCategoriesDropdown($cats);
        self::cleanField($cats, '#', $kbitems_by_category);
        self::createTreeView($cats, '#', $kbitems_by_category);
        echo "</div>";

        echo "<div class=\"cd-faq-items full_glpi_policy\" style='float: left; width: 75%'>";

        echo "<div id='plugin_servicecatalog_faq_results'>";
        echo "</div>";

        if (count($kbitems_by_category) > 0) {
            foreach ($kbitems_by_category as $key => $details) {
                echo "<ul id=\"$key\" class=\"cd-faq-group\">";
                $kbcat = new KnowbaseItemCategory();
                if (DropdownTranslation::canBeTranslated($kbcat)
                    && Session::haveTranslations(KnowbaseItemCategory::class, 'name')) {
                    $catname = DropdownTranslation::getTranslatedValue(
                        $key,
                        KnowbaseItemCategory::class,
                        'name',
                        $_SESSION['glpilanguage']
                    );
                } else {
                    $kbcat->getFromDB($key);
                    $catname = isset($kbcat->fields["name"]) ? $kbcat->fields["name"] : __('Without category', 'servicecatalog');
                }
                echo "<li class=\"cd-faq-title alert alert-secondary\">";
                if ($id > 0) {
                    echo "<a style=\"float: right;\" href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php' class='menu'>" . __('Return to list', 'servicecatalog') . "</a>";
                }
                echo "<h5>" . $catname . "</h5></li>";

                foreach ($details as $detail) {
                    $kbarticle = new KnowbaseItem();
                    $kbarticle->getFromDB($detail['id']);
                    $rand        = mt_rand();
                    $url_counter = PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/updatecounterfaq.php?faq_id=';
                    $url_counter .= $detail["id"];
                    echo Html::scriptBlock("
                        function loadfaq$rand() {
                           var xhttp = new XMLHttpRequest();
                           xhttp.open('GET', '$url_counter', true);
                           xhttp.send();
                        }");
                    echo "<li style='list-style-type: none;'><a class=\"cd-faq-trigger full_glpi_policy\" href=\"#0\" onclick='loadfaq$rand()'>";
                    if (KnowbaseItemTranslation::canBeTranslated($kbarticle)) {
                        echo KnowbaseItemTranslation::getTranslatedValue($kbarticle, 'name');
                    } else {
                        echo $kbarticle->fields["name"];
                    }
                    echo "</a>";

                    if ($id > 0) {
                        echo "<div class=\"no-js\">";
                    } else {
                        echo "<div class=\"cd-faq-content full_glpi_policy\">";
                    }

                    $answer = $kbarticle->getAnswer();

                    //               if ($id > 0) {
                    //                  $kbarticle->updateCounter();
                    //                  $rand      = mt_rand();
                    //                  $rand_text = mt_rand();
                    //                  Html::initEditorSystem("answer" . $rand, $rand, true, true);
                    //                  echo "<div id='answer$rand_text'>";
                    //                  Html::textarea(['name'            => 'answer',
                    //                                  'value'           => stripslashes($answer),
                    //                                  'editor_id'       => 'answer' . $rand,
                    //                                  'enable_richtext' => false]);
                    //                  echo "</div>";
                    //               } else {
                    echo Glpi\RichText\RichText::getSafeHtml($answer);
                    //               }
                    $iterator = $DB->request([
                                                 'FIELDS' => 'documents_id',
                                                 'FROM'   => 'glpi_documents_items',
                                                 'WHERE'  => [
                                                     'items_id' => $detail['id'],
                                                     'itemtype' => 'KnowbaseItem'
                                                 ]
                                             ]);

                    $numrows = count($iterator);

                    if ($numrows > 0) {
                        echo "<br>";
                        $j = 0;
                        foreach ($iterator as $docs) {
                            $doc = new Document();
                            $doc->getFromDB($docs["documents_id"]);
                            echo $doc->getDownloadLink();
                            $j++;
                            if ($j > 1) {
                                echo "<br>";
                            }
                        }
                    }
                    echo "<span class='faq-author'>";
                    if ($kbarticle->fields["users_id"]) {
                        echo sprintf(__('%1$s: %2$s'), __('Writer'), getUserName($kbarticle->fields["users_id"]));
                    }
                    if ($kbarticle->fields["date_mod"]) {
                        //TRANS: %s is the datetime of update
                        echo " - ";
                        echo sprintf(__('Last update on %s'), Html::convDateTime($kbarticle->fields["date_mod"]));
                    }
                    echo "</span>";
                    echo "</div>";
                    if (isset($crit['from_ticket']) && $crit['from_ticket'] > 0) {
                        echo "<div>";
                        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php'>";
                        echo "<button form='' class='submit btn btn-success btn-sm'>
<i class='far fa-thumbs-up' data-hasqtip='0' aria-hidden='true'></i>";
                        echo "&nbsp;";
                        echo __('Thanks It works!', 'servicecatalog');
                        echo "</button>";
                        echo "</a>";

                        echo "&nbsp;";

                        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?category_id=" . $crit['itilcategories_id'] . "&type=" . $crit['type'] . "'>";
                        echo "<button form='' class='submit btn btn-danger btn-sm'>
<i class='far fa-thumbs-down' data-hasqtip='0' aria-hidden='true'></i>";
                        echo "&nbsp;";
                        echo __('No, sorry i want to open a new ticket!', 'servicecatalog');
                        echo "</button>";
                        echo "</a>";
                        echo "</div>";
                    }
                    echo "</li>";
                }

                echo "</ul>";
            }
        } else {
            if (!$CFG_GLPI["use_public_faq"]) {
                if (Session::haveRight('knowbase', KnowbaseItem::READFAQ)) {
                    echo __('No data available', 'servicecatalog');
                } else {
                    Html::redirectToLogin();
                }
            } else {
                echo __('No data available', 'servicecatalog');
            }
        }
        echo "</div></section><a href=\"#0\" class=\"cd-close-panel\">" . __('Close') . "</a>";
        // Back to top button
        echo "<span class='fa-stack fa-lg' id='backtotop' style='display: none'>" .
             "<i class='fa fa-circle fa-stack-2x primary-fg-inverse'></i>" .
             "<a href='#' class='fa fa-arrow-up fa-stack-1x primary-fg' title='" .
             __s('Back to top of the page') . "'>" .
             "<span class='sr-only'>Top of the page</span>" .
             "</a></span>";
        echo "</div>";
        echo "<script src=\"../scripts/faqdisplay.js\"></script>";
    }


    public static function kbCategoriesDropdown(&$cats)
    {
        $category = new KnowbaseItemCategory();

        $find = $category->find([]);
        foreach ($find as $key => $vals) {
            $cats[$vals['id']] = $vals;
        }
        $cats['0'] = [
            'id'                        => '0',
            'name'                      => __('Root category'),
            'knowbaseitemcategories_id' => '#'
        ];
    }

    /**
     * @param        $array
     * @param        $currentParent
     * @param        $items
     * @param string $parent_id
     * @param int    $currLevel
     * @param int    $prevLevel
     */
    public static function createTreeView($array, $currentParent, $items, $parent_id = '#', $currLevel = 0, $prevLevel = -1)
    {
        foreach ($array as $categoryId => $category) {
            if (strval($currentParent) === strval($category['knowbaseitemcategories_id'])) {
                if ($currLevel > $prevLevel) {
                    echo "<ol id='ol$parent_id' style='list-style-type: none;' > ";
                }


                if ($currLevel == $prevLevel) {
                    echo "  ";
                }

                //            echo '<li> <label for="subfolder2">' . $category['name'] . '</label> <input type="checkbox" name="subfolder2">';
                $kbcat = new KnowbaseItemCategory();
                $kbcat->getFromDB($categoryId);
                if (DropdownTranslation::canBeTranslated($kbcat)
                    && Session::haveTranslations(KnowbaseItemCategory::class, 'name')) {
                    $catname = DropdownTranslation::getTranslatedValue(
                        $categoryId,
                        KnowbaseItemCategory::class,
                        'name',
                        $_SESSION['glpilanguage']
                    );
                } else {
                    $catname = isset($kbcat->fields["name"]) ? $kbcat->fields["name"] : __('Without category', 'servicecatalog');
                    if ($categoryId == 0) {
                        $catname = " ";
                    }
                }

                echo "<li>";
                echo "<span>";
                if (($categoryId > 0 && $kbcat->haveChildren()) || $categoryId == 0) {
                    echo "<i id='up" . $categoryId . "' class='fa-1x fas fa-folder-open pointer faq-folder' style='right: 20px;'></i>";
                } else {
                    echo "<i class='fa-1x fas fa-caret-right pointer faq-folder' style='right: 20px;'></i>";
                }

                $rand = mt_rand();
                echo Html::scriptBlock("
                     var myelement$rand = '#up" . $categoryId . "';
//                     var parent$rand = $(myelement$rand).parent('span');
//                     var children$rand = parent$rand.children('ol');
                     $(myelement$rand).click(function() {     
                         if( $(myelement$rand).parent().siblings('ol').css('display') != 'none') {
                             $('#ol$categoryId').hide();
                             $(myelement$rand).toggleClass('fa-folder-open fa-folder');
                         } else {
                             $('#ol$categoryId').show();
                             $(myelement$rand).toggleClass('fa-folder-open fa-folder');
                         }
                     });");
                echo "</span>";

                echo "<span>";

                if (isset($items[$categoryId])) {
                    echo " <a href='#$categoryId' class='menu full_glpi_policy'>";
                } else {
                    echo " <a href='#$categoryId' class='menu full_glpi_policy' style='pointer-events: none;  cursor: default;
                       text-decoration: none;'>";
                }
                echo $catname . "</a></span>";
                if ($currLevel > $prevLevel) {
                    $prevLevel = $currLevel;
                }

                $currLevel++;

                self::createTreeView($array, $categoryId, $items, $categoryId, $currLevel, $prevLevel);
                echo "</span>";
                echo "</li>";
                $currLevel--;
            }
        }

        if ($currLevel == $prevLevel) {
            echo "</ol>";
        }
    }

    public static function cleanField(&$array, $currentParent, $items, $parent_id = '#', $currLevel = 0, $prevLevel = -1)
    {
        if (isset($items[$currentParent]) || ($currentParent == "#" && isset($items[0]))) {
            $toDisplay = true;
        } else {
            $toDisplay = false;
        }

        foreach ($array as $categoryId => $category) {
            if (strval($currentParent) === strval($category['knowbaseitemcategories_id'])) {
                $retrun = self::cleanField($array, $categoryId, $items, $categoryId, $currLevel, $prevLevel);

                $toDisplay = $toDisplay || $retrun;


                $currLevel--;
            }
        }
        if ($toDisplay == false) {
            unset($array[$currentParent]);
        }

        return $toDisplay;
    }

    /**
     * Manage events from js/fuzzysearch.js
     *
     * @param string $action action to switch (should be actually 'getHtml' or 'getList')
     *
     * @return string
     * @since 9.2
     *
     */
    public static function fuzzySearch($action = '', $type = 0)
    {
        $config = new PluginServicecatalogConfig();
        $title  = PluginServicecatalogConfig::displayField($config, 'title_searchbar_kb');
        if (empty($title)) {
            $title = __("Start typing to find a FAQ article", "servicecatalog");
        }
        switch ($action) {
            case 'getHtml':
                $modal_header = __('Search');
                $placeholder  = $title;
                $alert        = "";
                //            $alert        = sprintf(
                //               __("Tip: You can call this modal with %s keys combination"),
                //               "<kbd><kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>G</kbd></kbd>"
                //            );

                $html = <<<HTML
               <div class="modal" tabindex="-1" id="fuzzysearch">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">
                              <i class="fas fa-arrow-right me-2"></i>
                              {$modal_header}
                           </h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                           <input type="text" class="form-control" placeholder="{$placeholder}">
                           <ul class="results list-group mt-2"></ul>
                        </div>
                     </div>
                  </div>
               </div>

HTML;
                return $html;
                break;

            default:
                $fuzzy_entries = [];

                $kbitems = self::getKbItems();
                if (count($kbitems) > 0) {
                    foreach ($kbitems as $kbitem) {
                        $kbarticle = new KnowbaseItem();
                        $kbarticle->getFromDB($kbitem['id']);
                        if (KnowbaseItemTranslation::canBeTranslated($kbarticle)) {
                            $name   = KnowbaseItemTranslation::getTranslatedValue($kbarticle, 'name');
                            $answer = KnowbaseItemTranslation::getTranslatedValue($kbarticle, 'answer');
                        } else {
                            $name   = $kbarticle->fields["name"];
                            $answer = $kbarticle->fields["answer"];
                        }
                        $keyword  = new PluginServicecatalogKnowbaseitem_Keyword();
                        $keywords = $keyword->getKeywordsInString($kbitem['id']);
                        $widget          = new PluginServicecatalogWidget();
                        $identity        = __('FAQ');
                        $fuzzy_entries[] = [
                            'url'   => PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php?id=" . $kbitem['id'],
                            'title' => $name, //. " ".Glpi\RichText\RichText::getTextFromHtml($answer)
                            'icon'  => $widget->fields['fa_faq'],
                            'order'     => "1",
                            'keywords' => $keywords,
                            'comment' => ($answer != null)?Html::resume_text(Glpi\RichText\RichText::getTextFromHtml($answer), "50"):"",
                            'type'  => $identity
                        ];
                    }
                }
                // return the entries to ajax call
                return json_encode($fuzzy_entries);
                break;
        }
    }
}
