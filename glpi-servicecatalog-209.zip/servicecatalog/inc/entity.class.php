<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogEntity
 */
class PluginServicecatalogEntity extends CommonDBTM
{
    public static $rightname         = "plugin_servicecatalog_setup";
    public $can_be_translated = true;

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        return PluginServicecatalogMain::getTypeName();
    }

    /**
     * Get Tab Name used for itemtype
     *
     * NB : Only called for existing object
     *      Must check right on what will be displayed + template
     *
     * @param CommonGLPI $item Item on which the tab need to be displayed
     * @param int        $withtemplate is a template object ? (default 0)
     *
     * @return string tab name
     **@since version 0.83
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if (!$withtemplate) {
            if ($item->getType() == 'Entity' && $this->canUpdate()) {
                return self::getTypeName();
            }
        }
        return '';
    }

    /**
     * show Tab content
     *
     * @param CommonGLPI $item Item on which the tab need to be displayed
     * @param integer    $tabnum tab number (default 1)
     * @param int        $withtemplate is a template object ? (default 0)
     *
     * @return boolean
     **@since version 0.83
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case 'Entity':
                $entity = new self();
                $entity->showSetup($item->getID());

                if (PluginServicecatalogContact::canView()) {
                    $contact = new PluginServicecatalogContact();
                    $contact->showContactMenu();
                }
                break;
        }

        return true;
    }

    /**
     * Configuring Entity Comments
     *
     * @param $ID
     */
    public static function showSetup($ID)
    {
        $entity = new self();
        if (!$entity->getFromDBByCrit(['entities_id' => $ID])) {
            $entity->add(['entities_id' => $ID]);
        }
        $entity->getFromDBByCrit(['entities_id' => $ID]);

        echo "<form name='form' method='post' action='" . self::getFormURL() . "' enctype='multipart/form-data'>";

        echo "<div align='center'><table class='tab_cadre_fixe'>";

        echo "<tr class='tab_bg_1'><th colspan='3'>" . __('Plugin setup', 'servicecatalog') . "</th></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Picture') . "</td>";
        echo "<td>";
        $rand = mt_rand();
        echo "<div style='width:190px;border-radius: 6px; border: 2px inset #969595;text-align:center;' id='picture$rand'>";
        echo "<img alt=\"" . __s('Picture') . "\" src='" .
             self::getThumbnailURLForPicture($entity->fields['picture']) . "'>";
        echo "</div>";
        echo "</td><td>";
        echo "<input class='form-control' type='file' name='picture' accept='image/*'>";
        echo "<input type='checkbox' name='_blank_picture'>&nbsp;" . __('Clear');
        echo "<p>" . sprintf(__('%1$s (%2$s)'), __('It is recommended to use a png file of size 140px x 130px', 'servicecatalog'), Document::getMaxUploadSize()) . "</p>";
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Icon', 'servicecatalog');
        echo "</td>";
        echo "<td colspan='2'>";
        $icon_selector_id = 'icon_' . mt_rand();
        echo Html::select(
            'fa_icon',
            [$entity->fields['fa_icon'] => $entity->fields['fa_icon']],
            [
                'id'       => $icon_selector_id,
                'selected' => $entity->fields['fa_icon'],
                'style'    => 'width:175px;'
            ]
        );

        echo Html::script('js/Forms/FaIconSelector.js');
        echo Html::scriptBlock(
            <<<JAVASCRIPT
         $(
            function() {
               var icon_selector = new GLPI.Forms.FaIconSelector(document.getElementById('{$icon_selector_id}'));
               icon_selector.init();
            }
         );
JAVASCRIPT
        );

        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Comment for the context of the ticket', 'servicecatalog') . "</td>";
        echo "<td colspan='2'>";
        Html::textarea(['name'            => 'comment',
                        'value'           => $entity->fields["comment"],
                        'enable_richtext' => false,
                        'cols'            => '80',
                        'rows'            => '3']);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td><label for='theme-selector'>" . __("Layout for categories", 'servicecatalog') . "</label></td><td>";

        $layout = [-1 => Dropdown::EMPTY_VALUE,
                    0 => 'sly',
                    1 => 'wrapper',
                    2 => 'wrappersly',
                    3 => 'thumbnail',
                    4 => 'thumbnail_wrapper',
                    5 => 'bootstrapped',
                    6 => 'bootstrapped_color',
            7 => 'shoper'];
        Dropdown::showFromArray(
            'layout',
            $layout,
            [
                'id'    => 'layout',
                'value' => $entity->fields['layout']
            ]
        );


        echo "</td>";
        echo "</tr>";

        echo Html::hidden('id', ['value' => $entity->getID()]);
        echo "<tr class='tab_bg_1'><td class='center' colspan='3'>";
        echo Html::submit(_sx('button', 'Save'), ['name' => 'update', 'class' => 'btn btn-primary']);
        echo "</td></tr>";

        echo "</table></div>";

        Html::closeForm();
    }

    /**
     * @return mixed
     */
    public static function getLayout()
    {
        $entity = new self();
        if ($entity->getFromDBByCrit(['entities_id' => $_SESSION['glpiactive_entity']])) {
            return $entity->fields['layout'];
        }
        return false;
    }

    /**
     * @param $fieldref
     * @param $entities_id
     * @param $fieldval
     * @param $default_value
     *
     * @return float|int|mixed|string
     */
    public static function getUsedConfig($default_value = -1)
    {
        global $DB;

        $entities_id = $_SESSION['glpiactive_entity']??0;
        $fieldref    = 'entities_id';
        $fieldval    = 'layout';
        if (empty($fieldval)) {
            $fieldval = $fieldref;
        }
        $entities_query = [
            'SELECT' => [$fieldref, 'id'],
            'FROM'   => self::getTable(),
            'WHERE'  => [$fieldref => array_merge([$entities_id], getAncestorsOf(Entity::getTable(), $entities_id))]
        ];

        if ($fieldval !== $fieldref) {
            $entities_query['SELECT'][] = $fieldval;
        }
        $entities_data = iterator_to_array($DB->request($entities_query));
        $val           = $default_value;

        foreach ($entities_data as $entity_data) {
            if (isset($entity_data[$fieldval])
                && $entity_data[$fieldval] != -1) {
                $val = $entity_data[$fieldval];
            }
        }

        return $val;
    }

    /**
     * Wigdet to return to the list of entities
     *
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     */
    public static function getWidgetListEntity($widget, $bloc_class)
    {
        $buttons = "";
        if (self::isViewOtherEntity()) {
            $url     = PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php?changeactiveentity";
            $url_img = "picture.send.php";

            $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img"     => $widget->fields['img_entity'],
                                                                                         "url_img" => $url_img,
                                                                                         "fa"      => $widget->fields['fa_entity'],
                                                                                         "title"   => PluginServicecatalogConfig::displayField($widget, 'title_entity'),
                                                                                         "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_entity')]);
        }
        return $buttons;
    }

    /**
     * @param $widget
     *
     * @return array
     */
    public static function showNavBarMenu($widget)
    {
        $menu = [];
        if (self::isViewOtherEntity()) {
            $url           = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/main.form.php?changeactiveentity";
            $title         = PluginServicecatalogConfig::displayField($widget, 'title_entity');
            $menu['title'] = $title;
            $menu['page']  = $url;
            if (!empty($widget->fields['fa_entity'])) {
                $icon          = $widget->fields['fa_entity'];
                $menu['icon']  = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "entity_bar";
        }
        return $menu;
    }

    /**
     * @param $entity
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     */
    public static function getWidgetEntity($entity, $widget, $bloc_class)
    {
        $entities_id = $entity->getID();

        $sc_entity = new self();
        $sc_entity->getFromDBByCrit(['entities_id' => $entities_id]);

        if ($widget->getDisplayEntityName()) {
            $entity_name = Dropdown::getDropdownName(Entity::getTable(), $entities_id);
            $entity_tab  = explode('>', $entity_name, 2);
        } else {
            $entity_tab[0] = $entity->getField('name');
        }

        $title = "<span class=\"de-em\">" . $entity_tab[0] . "&nbsp;</span>";
        if (isset($entity_tab[1])) {
            $title .= $entity_tab[1];
        }

        $url    = PLUGIN_SERVICECATALOG_WEBDIR . '/front/main.form.php?active_entity=' . $entities_id;
        $class  = "menusc-normal menusc-entity-normal center wbutton sc-widget";
        $config = new PluginServicecatalogConfig();
        if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $class = "menusc-normal center wbutton sc-widget";
        }

        $url_img = "document.send.php";
        $picture = "";
        if (isset($sc_entity->fields['picture'])) {
            $picture = $sc_entity->fields['picture'];
        }
        $comment = "";
        if (isset($sc_entity->fields['comment'])) {
            $comment = $sc_entity->fields['comment'];
        }
        $icon = $widget->fields['fa_entity'];
        if (isset($sc_entity->fields['fa_icon'])) {
            $icon = $sc_entity->fields['fa_icon'];
        }
        $addstyle = "margin:30px 15px 15px 40px;";

        return PluginServicecatalogWidget::getWidgetTemplate($url, $class, ["img"      => $picture,
                                                                            "url_img"  => $url_img,
                                                                            "css_img"  => "bt-img-entity-responsive",
                                                                            "fa"       => $icon,
                                                                            "fa_style" => $addstyle,
                                                                            "title"    => $title,
                                                                            "comment"  => $comment]);
    }

    /**
     * @return bool
     */
    public static function isViewOtherEntity()
    {
        $profiles_id = $_SESSION['glpiactiveprofile']["id"] ?? 0;
        $dbu         = new DbUtils();

        if ($profiles_id > 0) {
            $list_entities = $_SESSION['glpiprofiles'][$profiles_id]['entities'];

            if (isset($list_entities)) {
                if (count($list_entities) == 1) {
                    foreach ($list_entities as $entity) {
                        if ($entity['is_recursive']) {
                            $entities = $dbu->getSonsOf("glpi_entities", $entity['id']);
                            if (count($entities)) {
                                return true;
                            }
                        }
                    }
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Entity selection interface
     *
     * @param $id
     * @param $class
     * @param $iswidget
     *
     * @return string
     */
    public static function getWidgetEntities($id, $class, $iswidget)
    {
        $widget     = new PluginServicecatalogWidget();
        $bloc_class = 'wbutton sc-widget';
        $buttons    = "";
        if ($iswidget == false) {
            $buttons .= PluginServicecatalogConfig::loadForLayout(false);
        }

        $delclass = "";
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $delclass = "delclass";
        }
        if ($iswidget == true) {
            $buttons .= "<div id='" . $id . "' class=\"bt-row $delclass\">";
            $buttons .= "<div class=\" $class \">";
        }
        $title   = PluginServicecatalogConfig::displayField($widget, 'title_entity_list');
        $buttons .= PluginServicecatalogWidget::getWidgetTitle($title, !$widget);

        if (!empty($widget->fields['comment_entity_list'])) {
            $buttons .= "<div class='left small-comments'>" . PluginServicecatalogConfig::displayField($widget, 'comment_entity_list') . "</div>";
        }
        $buttons .= "<div class=\"entity-buttons\">";
        if (isset($_SESSION["glpiactiveentities"])) {
            foreach ($_SESSION["glpiactiveentities"] as $entities_id) {
                $entity = new Entity();
                if ($entity->getFromDB($entities_id)) {
                    $buttons .= self::getWidgetEntity($entity, $widget, $bloc_class);
                }
            }
        }


        $buttons .= "</div>";
        if ($iswidget == true) {
            $buttons .= "</div></div>";
        }
        return $buttons;
    }

    /**
     * Change of entity by default entity
     */
    public static function changeActiveEntities()
    {
        global $_SESSION;

        $profiles_id = $_SESSION['glpiactiveprofile']["id"];

        $data['entities'] = $_SESSION['glpiprofiles'][$profiles_id]['entities'];

        $active_entity_done = false;
        foreach ($data['entities'] as $key => $val) {
            if ($val['id'] == $_SESSION["glpidefault_entity"]) {
                if (Session::changeActiveEntities($val['id'], $val['is_recursive'])) {
                    $active_entity_done = true;
                }
            }
        }
        if (!$active_entity_done) {
            // Try to load default entity
            if (!Session::changeActiveEntities($_SESSION["glpidefault_entity"], true)) {
                // Load all entities
                Session::changeActiveEntities("all");
            }
        }
    }

    /**
     * Initialize entity, clear categories cache
     */
    public static function changeEntity()
    {
        global $GLPI_CACHE;
        if (isset($_GET['ignore_redirect'])) {  //Use to bypass redirection from setup.php (shortcut)
            $_SESSION["glpi_plugin_servicecatalog_loaded"] = 1;
        } else {
            $_SESSION["glpi_plugin_servicecatalog_loaded"] = 0;
        }
        $cat                                           = new PluginServicecatalogCategory();
        $types                                         = [Ticket::INCIDENT_TYPE, Ticket::DEMAND_TYPE];
        foreach ($types as $type) {
            $ckey = 'sc_cache_' . md5($cat->getTable() . $type);
            $GLPI_CACHE->delete($ckey);
        }
        if (isset($_SESSION["glpi_plugin_servicecatalog_categories"])) {
            unset($_SESSION["glpi_plugin_servicecatalog_categories"]);
        }
        if (isset($_SESSION["plugin_servicecatalog"])) {
            unset($_SESSION["plugin_servicecatalog"]);
        }

//        if (isset($_SESSION["glpidefault_entity"])) {
//            Session::changeActiveEntities($_SESSION["glpidefault_entity"], true);
//        }
    }

    /**
     * Get picture URL from picture field
     *
     * @param $picture picture field
     *
     * @return string URL to show picture
     **@since version 0.85
     *
     */
    public static function getThumbnailURLForPicture($picture)
    {
        if (!empty($picture)) {
            $tmp = explode(".", $picture);

            if (count($tmp) == 2) {
                return PLUGIN_SERVICECATALOG_WEBDIR . "/front/document.send.php?file=_plugins/" . $tmp[0] .
                       "." . $tmp[1];
            }
        }
        return PLUGIN_SERVICECATALOG_WEBDIR . "/pics/entity.png";
    }


    /**
     * @param datas $input
     *
     * @return bool|datas
     */
    public function prepareInputForAdd($input)
    {
        //picture manually uploaded by category
        if (isset($input["_blank_picture"]) && $input["_blank_picture"]) {
            PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
            $input['picture'] = 'NULL';
        } else {
            if (isset($_FILES['picture'])) {
                if (!count($_FILES['picture'])
                    || empty($_FILES['picture']['name'])
                    || !is_file($_FILES['picture']['tmp_name'])) {
                    switch ($_FILES['picture']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            Session::addMessageAfterRedirect(
                                __('File too large to be added.'),
                                false,
                                ERROR
                            );
                            return false;
                            break;

                        case UPLOAD_ERR_NO_FILE:
                            unset($input['picture']);
                            //                     Session::addMessageAfterRedirect(__('No file specified.'), false, ERROR);
                            //                     return false;
                            break;
                    }
                } else {
                    if (Toolbox::getMime($_FILES['picture']['tmp_name'], 'image')) {
                        // Unlink old picture (clean on changing format)
                        PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
                        // Move uploaded file
                        $filename     = uniqid($this->fields['id'] . '_');
                        $tmp          = explode(".", $_FILES['picture']['name']);
                        $extension    = array_pop($tmp);
                        $picture_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";
                        PluginServicecatalogCategory::dropPictureFiles($filename . "." . $extension);

                        if (in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'bmp', 'gif'])
                            && Document::renameForce($_FILES['picture']['tmp_name'], $picture_path)) {
                            Session::addMessageAfterRedirect(__('The file is valid. Upload is successful.'));
                            // For display
                            $input['picture'] = "servicecatalog/{$filename}.$extension";

                            //prepare a thumbnail
                            $thumb_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";

                            $img_infos = getimagesize($picture_path);
                            if ($img_infos[2] == IMAGETYPE_PNG) {
                                PluginServicecatalogCategory::resizePicture($picture_path, $thumb_path, $img_infos, 140, 130);
                            } else {
                                Toolbox::resizePicture($picture_path, $thumb_path, 140, 130);
                            }
                        } else {
                            Session::addMessageAfterRedirect(
                                __('Potential upload attack or file too large. Moving temporary file failed.'),
                                false,
                                ERROR
                            );
                            return false;
                        }
                    } else {
                        Session::addMessageAfterRedirect(
                            __('The file is not an image file.'),
                            false,
                            ERROR
                        );
                        return false;
                    }
                }
            } else {
                unset($input['picture']);
            }
        }

        return $input;
    }

    /**
     * @param datas $input
     *
     * @return bool|datas
     */
    public function prepareInputForUpdate($input)
    {
        //picture manually uploaded by category
        if (isset($input["_blank_picture"]) && $input["_blank_picture"]) {
            PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
            $input['picture'] = 'NULL';
        } else {
            if (isset($_FILES['picture'])) {
                if (!count($_FILES['picture'])
                    || empty($_FILES['picture']['name'])
                    || !is_file($_FILES['picture']['tmp_name'])
                ) {
                    switch ($_FILES['picture']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            Session::addMessageAfterRedirect(
                                __('File too large to be added.'),
                                false,
                                ERROR
                            );
                            return false;
                            break;

                        case UPLOAD_ERR_NO_FILE:
                            unset($input['picture']);
                            //                     Session::addMessageAfterRedirect(__('No file specified.'), false, ERROR);
                            //                     return false;
                            break;
                    }
                } else {
                    if (Toolbox::getMime($_FILES['picture']['tmp_name'], 'image')) {
                        // Unlink old picture (clean on changing format)
                        PluginServicecatalogCategory::dropPictureFiles($this->fields['picture']);
                        // Move uploaded file
                        $filename     = uniqid($this->fields['id'] . '_');
                        $tmp          = explode(".", $_FILES['picture']['name']);
                        $extension    = array_pop($tmp);
                        $picture_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";
                        PluginServicecatalogCategory::dropPictureFiles($filename . "." . $extension);
                        if (in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'bmp', 'gif'])
                            && Document::renameForce($_FILES['picture']['tmp_name'], $picture_path)
                        ) {
                            Session::addMessageAfterRedirect(__('The file is valid. Upload is successful.'));
                            // For display
                            $input['picture'] = "servicecatalog/{$filename}.$extension";

                            //prepare a thumbnail
                            $thumb_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";

                            $img_infos = getimagesize($picture_path);
                            if ($img_infos[2] == IMAGETYPE_PNG) {
                                PluginServicecatalogCategory::resizePicture($picture_path, $thumb_path, $img_infos, 140, 130);
                            } else {
                                Toolbox::resizePicture($picture_path, $thumb_path, 140, 130);
                            }
                        } else {
                            Session::addMessageAfterRedirect(
                                __('Potential upload attack or file too large. Moving temporary file failed.'),
                                false,
                                ERROR
                            );
                            return false;
                        }
                    } else {
                        Session::addMessageAfterRedirect(
                            __('The file is not an image file.'),
                            false,
                            ERROR
                        );
                        return false;
                    }
                }
            } else {
                unset($input['picture']);
            }
        }
        return $input;
    }
}
