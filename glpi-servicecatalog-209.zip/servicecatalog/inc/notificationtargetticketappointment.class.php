<?php
/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */


if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogNotificationTargetTicketappointment
 */
class PluginServicecatalogNotificationTargetTicketappointment extends NotificationTarget
{

    const APPOINTMENT_REQUESTER   = 6001;
    const APPOINTMENT_ASSIGN_TECH = 6002;

    public function getEvents()
    {
        return ['newappointement'    => __('A new appointment has been added', 'servicecatalog'),
              'cancelappointement' => __('A appointment has been cancelled', 'servicecatalog'),
        ];
    }

   /**
    * Get additionnals targets for Tickets
    */
    function addAdditionalTargets($event = '')
    {

        $this->addTarget(self::APPOINTMENT_REQUESTER, _n('Requester', 'Requesters', 1));
        $this->addTarget(self::APPOINTMENT_ASSIGN_TECH, __('Technician in charge of the ticket'));
    }


   /**
    * Add targets by a method not defined in NotificationTarget (specific to an itemtype)
    *
    * @param array $data Data
    * @param array $options Options
    *
    * @return void
    **/
    function addSpecificTargets($data, $options)
    {

       //Look for all targets whose type is Notification::ITEM_USER
        switch ($data['items_id']) {
            case self::APPOINTMENT_ASSIGN_TECH:
                $this->getTechAddress($this->obj->fields['id']);
                break;
            case self::APPOINTMENT_REQUESTER:
                $this->getRequesterAddress($this->obj->fields['id']);
                break;
        }
    }


   //Get recipient
    function getTechAddress($appointments_id)
    {
        global $DB;

        $query = "SELECT DISTINCT `glpi_users`.`id` AS id,
                          `glpi_users`.`language` AS language
                   FROM `glpi_plugin_servicecatalog_ticketappointments`
                   LEFT JOIN `glpi_users` ON (`glpi_users`.`id` = `glpi_plugin_servicecatalog_ticketappointments`.`users_id_tech`)
                   WHERE `glpi_plugin_servicecatalog_ticketappointments`.`id` = '" . $appointments_id . "'";

        foreach ($DB->request($query) as $data) {
            $data['email'] = UserEmail::getDefaultForUser($data['id']);
            $this->addToRecipientsList($data);
        }
    }

    function getRequesterAddress($appointments_id)
    {
        global $DB;

        $query = "SELECT DISTINCT `glpi_users`.`id` AS id,
                          `glpi_users`.`language` AS language
                   FROM `glpi_plugin_servicecatalog_ticketappointments`
                   LEFT JOIN `glpi_users` ON (`glpi_users`.`id` = `glpi_plugin_servicecatalog_ticketappointments`.`users_id_requester`)
                   WHERE `glpi_plugin_servicecatalog_ticketappointments`.`id` = '" . $appointments_id . "'";

        foreach ($DB->request($query) as $data) {
            $data['email'] = UserEmail::getDefaultForUser($data['id']);
            $this->addToRecipientsList($data);
        }
    }

   /**
    * Get all data needed for template processing
    * Provides minimum information for alerts
    * Can be overridden by each NotificationTartget class if needed
    *
    * @param string $event Event name
    * @param array  $options Options
    *
    * @return void
    **/
    public function addDataForTemplate($event, $options = [])
    {
        global $CFG_GLPI;

        $events = $this->getAllEvents();

        $this->data['##lang.ticketappointement.title##'] = $events[$event];

        $this->data['##lang.ticketappointement.url##'] = __('Ticket URL', 'servicecatalog');

        $ticket = new Ticket();
        if ($ticket->getFromDB($this->obj->getField("tickets_id"))) {
            $this->data['##ticketappointement.name##'] = $ticket->getName();
            $this->data['##ticketappointement.url##']  = urldecode($CFG_GLPI["url_base"] . "/front/ticket.form.php?id=" . $ticket->getID());
        }

        $this->data['##lang.ticketappointement.writer##']     = __('Appointment added by', 'servicecatalog');
        $this->data['##ticketappointement.writer##']          = getUserName($this->obj->getField("users_id"));
        $this->data['##lang.ticketappointement.requester##']  = _n('Requester', 'Requesters', 1);
        $this->data['##ticketappointement.requester##']       = getUserName($this->obj->getField("users_id_requester"));
        $this->data['##lang.ticketappointement.technician##'] = __('Technician in charge of the ticket');
        $this->data['##ticketappointement.technician##']      = getUserName($this->obj->getField("users_id_tech"));

        $this->data['##lang.ticketappointement.begin##'] = __('Begin date');
        $this->data['##ticketappointement.begin##']      = Html::convDateTime($this->obj->getField("begin"));
        $this->data['##lang.ticketappointement.end##']   = __('End date');
        $this->data['##ticketappointement.end##']        = Html::convDateTime($this->obj->getField("end"));

        $this->data['##lang.ticketappointement.content##'] = __('Description');

        if ($event == "cancelappointement") {
            $content = __('Your planified appointment has been cancelled', 'servicecatalog') . " : " . __('Appointment with', 'servicecatalog') . " " . getUserName($this->obj->getField("users_id_tech"));
        } else {
            $content = __('You have a planified appointment', 'servicecatalog') . " : " . __('Appointment with', 'servicecatalog') . " " . getUserName($this->obj->getField("users_id_tech"));
        }


        $this->data['##ticketappointement.content##'] = $content;
    }


   /**
    * @return array|void
    */
    function getTags()
    {

        $tags = ['ticketappointement.writer'     => __('Appointment added by', 'servicecatalog'),
               'ticketappointement.technician' => __('Technician in charge of the ticket'),
               'ticketappointement.requester'  => _n('Requester', 'Requesters', 1),
               'ticketappointement.begin'      => __('Begin date'),
               'ticketappointement.end'        => __('End date'),
               'ticketappointement.content'    => __('Description'),
        ];
        foreach ($tags as $tag => $label) {
            $this->addTagToList(['tag'   => $tag, 'label' => $label,
                              'value' => true]);
        }

        $this->addTagToList(['tag'     => 'ticketappointement',
                           'label'   => __('At new or cancel of a appointement', 'servicecatalog'),
                           'value'   => false,
                           'foreach' => true,
                           'events'  => ['newappointement', 'cancelappointement']]);

        asort($this->tag_descriptions);
    }
}
