<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}


//TODO
//add update -> used by default
//add traduction for comments
//better link with web applications - use webapplication dashboard
//add link to right typology ? - list only appliance with profile rights ?

/**
 * Class PluginServicecatalogApplianceLink
 */
class PluginServicecatalogApplianceLink extends CommonDBTM
{
    public static $rightname = "plugin_servicecatalog_appliancelinks";

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        return _n('Appliance', 'Appliances', $nb);
    }

   /**
    * @return string
    */
    public static function getIcon()
    {
        return "ti ti-apps";
    }

   /**
    * Get Tab Name used for itemtype
    *
    * NB : Only called for existing object
    *      Must check right on what will be displayed + template
    *
    * @param CommonGLPI $item Item on which the tab need to be displayed
    * @param int        $withtemplate is a template object ? (default 0)
    *
    * @return string tab name
    * @since version 0.83
    *
    */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if (!$withtemplate) {
            if ($item->getType() == 'Appliance' && $this->canUpdate()) {
                if ($_SESSION['glpishow_count_on_tabs']) {
                    $dbu = new DbUtils();
                    return self::createTabEntry(
                        PluginServicecatalogMain::getTypeName(),
                        $dbu->countElementsInTable(
                            "glpi_plugin_servicecatalog_appliancelinks",
                            ["appliances_id" => $item->getField('id')]
                        )
                    );
                }
                return PluginServicecatalogMain::getTypeName();
            }
        }
        return '';
    }

   /**
    * show Tab content
    *
    * @param CommonGLPI $item Item on which the tab need to be displayed
    * @param integer    $tabnum tab number (default 1)
    * @param int        $withtemplate is a template object ? (default 0)
    *
    * @return boolean
    * @since version 0.83
    *
    */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case 'Appliance':
                $ID   = $item->getField('id');
                $self = new self();

                if (!$self->getFromDBByAppliance($ID)) {
                    $self->createAccess($ID);
                }
                $self->getFromDBByAppliance($ID);
                $self->showForm($self->fields['id']);
                break;
        }

        return true;
    }

   /**
    * Returns if appliances_id is present
    *
    * @param type  $appliances_id
    *
    * @return boolean
    * @global type $DB
    *
    */
    public function getFromDBByAppliance($appliances_id)
    {
        global $DB;

        $iterator = $DB->request([
                                  'FROM'  => getTableForItemType(__CLASS__),
                                  'WHERE' => [
                                     'appliances_id' => $appliances_id,
                                  ],
                               ]);

        if (count($iterator) != 1) {
            return false;
        }
        foreach ($iterator as $data) {
            $this->fields = $data;
            if (is_array($this->fields) && count($this->fields)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

   /**
    * Create the first access
    *
    * @param type $ID
    */
    public function createAccess($ID)
    {
        $this->add([
                    'use_with_sc'   => 0,
                    'appliances_id' => $ID,
                    'groups'        => "[]",
                    'comment'       => ""]);
    }


   /**
    * Get the Search options for the given Type
    *
    * This should be overloaded in Class
    *
    * @return array an *indexed* array of search options
    *
    * @see https://glpi-developer-documentation.rtfd.io/en/master/devapi/search.html
    **/
    public function rawSearchOptions()
    {
        $tab = [];

        $tab[] = [
         'id'   => 'common',
         'name' => __('Characteristics')
        ];

        $tab[] = [
         'id'            => '2',
         'table'         => $this->getTable(),
         'field'         => 'id',
         'name'          => __('ID'),
         'massiveaction' => false,
         'datatype'      => 'number'
        ];

        $tab[] = [
            'id'            => '3',
            'table'         => $this->getTable(),
            'field'         => 'name',
            'name'          => __('Name'),
            'massiveaction' => false,
            'datatype'      => 'text'
        ];

        $tab[] = [
         'id'       => '4',
         'table'    => $this->getTable(),
         'field'    => 'comment',
         'name'     => __('Comments'),
         'datatype' => 'text'
        ];

        return $tab;
    }

   /**
    * @param       $ID
    * @param array $options
    */
    public function showForm($ID, $options = [])
    {
        $this->initForm($ID, $options);
        $appliance = new Appliance();
        if (isset($this->fields['appliances_id']) && $appliance->getFromDB($this->fields['appliances_id'])) {
            $options['friendlyname'] = $appliance->getName();
        }
        $this->showFormHeader($options);

        echo "<tr class='tab_bg_1'>";
        echo "<td>";
        echo __('Display on navigation menu and use it on ticket creation', 'servicecatalog');
        echo "</td>";
        echo "<td>";
        Dropdown::showYesNo('use_with_sc', $this->fields['use_with_sc']);
        echo "</td></tr>";

        $groups    = [];
        $group     = new Group();
        $condition = [];

        $dbu       = new DbUtils();
        $condition += $dbu->getEntitiesRestrictCriteria($group->getTable(), '', '', $group->maybeRecursive());
        $dataGroup = $group->find($condition, 'name');
        if ($dataGroup) {
            foreach ($dataGroup as $field) {
                $groups[$field['id']] = $field['completename'];
            }
        }
        echo "<tr class='tab_bg_1'>";
        // Dropdown group
        echo "<td>";
        echo __('Appliance user groups', 'servicecatalog');
        echo "</td>";
        echo "<td>";

        $used = !empty($this->fields["groups"]) ? json_decode($this->fields["groups"], true) : "[]";
        Dropdown::showFromArray("groups", $groups, ['name'     => 'groups',
                                                  //                                                     'width'    => '150',
                                                  'values'   => $used,
                                                  'multiple' => true
        ]);

        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Comment for display on simplified interface', 'servicecatalog') . "</td>";
        echo "<td colspan='2'>";
        Html::textarea(['name'            => 'comment',
                      'value'           => $this->fields["comment"],
                      'enable_richtext' => false,
                      'cols'            => '80',
                      'rows'            => '3']);
        echo "</td>";
        echo "</tr>";

        $options['candel'] = false;
        $this->showFormButtons($options);

        Html::closeForm();
    }

   /**
    * Check if user can see the appliance using group restriction
    *
    * @param $appliance_id
    *
    * @return bool
    * @throws \GlpitestSQLError
    */
    public static function isApplianceAllowed($appliance_id)
    {
        $group_user_data = Group_User::getUserGroups($_SESSION['glpiID']);

        $apps       = [];
        $app        = new self();
        $appliances = $app->find(['use_with_sc' => 1]);

        foreach ($appliances as $appliance) {
            if (!empty($appliance['groups'])) {
                $used = json_decode($appliance['groups'], true);

                if (count($used) > 0) {
                    foreach ($group_user_data as $groups) {
                        if (in_array($groups['id'], $used)) {
                            $apps[] = $appliance['appliances_id'];
                        }
                    }
                } else {
                    $apps[] = $appliance['appliances_id'];
                }
            } else {
                $apps[] = $appliance['appliances_id'];
            }
        }

        if (in_array($appliance_id, $apps)) {
            return true;
        } else {
            return false;
        }

        return false;
    }

   /**
    * @param $widget
    *
    * @return string
    */
    public static function showNavBarMenu($widget, $config)
    {
        global $DB;

        $menu = [];

        $applink = new self();
        if (!$applink->canView()) {
            return $menu;
        }
        $dbu      = new DbUtils();
        $nb       = 0;
        $iterator = $DB->request([
                                  'FROM'      => 'glpi_plugin_servicecatalog_appliancelinks',
                                  'LEFT JOIN' => [
                                     'glpi_appliances' => [
                                        'ON' => [
                                           'glpi_plugin_servicecatalog_appliancelinks' => 'appliances_id',
                                           'glpi_appliances'                           => 'id'
                                        ]
                                     ]
                                  ],
                                  'WHERE'     => [
                                                    'glpi_plugin_servicecatalog_appliancelinks' . '.use_with_sc' => 1,
                                                 ] + $dbu->getEntitiesRestrictCriteria('glpi_appliances', '', '', true)
                               ]);

        if (count($iterator) > 0) {
            $nb = count($iterator);
            foreach ($iterator as $link) {
                $appliance = new Appliance();
                if ($appliance->getFromDB($link['appliances_id'])) {
                    if (!self::isApplianceAllowed($link['appliances_id'])) {
                        $nb--;
                    }
                }
            }
            if ($nb > 0) {
                $url   = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/appliancelink.form.php?see_links";
                $title = PluginServicecatalogConfig::displayField($config, 'title_myappliances_menu');

                $menu['title'] = $title;
                $menu['page']  = $url;
                $icon          = $applink::getIcon();
                if (!empty($config->fields['fa_myappliances_menu'])) {
                    $icon = $config->fields['fa_myappliances_menu'];
                }
                $menu['icon'] = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
                $menu['id']   = "appliancelink_bar";
            }
        }
        return $menu;
    }

   /**
    * @param $widget
    *
    * @return string|void
    */
    public static function showAppLinks($widget = false)
    {
        $display = "";

        $display .= PluginServicecatalogConfig::loadForLayout(false);
        $display .= "<div id='content' class='sc-content'>";
        $display .= "<div class='bt-container'>";
        $display .= "<div class='bt-block bt-features' style='padding-top: 5px;'>";
        $config  = new PluginServicecatalogConfig();
        $widget  = new PluginServicecatalogWidget();
        $title_widget = PluginServicecatalogConfig::displayField($config, 'title_myappliances_menu');
        $display .= PluginServicecatalogWidget::getPageTitle($title_widget);
        $display .= self::getList($widget);

        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";

        echo $display;
    }


    public static function fuzzySearchForm($name)
    {

    }

    /**
     * @param $widget
     *
     * @return string|void
     * @throws \GlpitestSQLError
     */
    public static function getList($widget = false)
    {
        global $DB;

        $display = "";

        $config = new PluginServicecatalogConfig();

        $strict_search = $config->useStrictSearch();
        $modal_header = __('Search');
        $title  = __("Start typing to find a appliance", "servicecatalog");

        $display .= "<div tabindex='-1' id='fuzzysearch'>";

        $display .= "<div class='modal-content'>";
        $display .= "<div class='modal-body' style='padding: 10px;'>";
        $display .= "<input type='text' class='sc-appliancelink-trigger-fuzzy form-control' placeholder='".$title."'>";
        $display .= "<input type='hidden' name='fuzzy-strict' id='fuzzy-strict' value='".$strict_search."'/>";

        $display .= "<ul class='results list-group mt-2' style='background: #FFF;border: 1px solid #d9dbde;'></ul>";
        $display .= "</div>";
        $display .= "</div>";
        $display .= "</div>";


        $applink = new self();
        $dbu     = new DbUtils();

        $iterator = $DB->request([
                                  'SELECT' => ['appliances_id', 'glpi_plugin_servicecatalog_appliancelinks.comment'],
                                  'FROM'      => 'glpi_plugin_servicecatalog_appliancelinks',
                                  'LEFT JOIN' => [
                                     'glpi_appliances' => [
                                        'ON' => [
                                           'glpi_plugin_servicecatalog_appliancelinks' => 'appliances_id',
                                           'glpi_appliances'                           => 'id'
                                        ]
                                     ]
                                  ],
                                  'WHERE'     => [
                                                    'glpi_plugin_servicecatalog_appliancelinks' . '.use_with_sc' => 1,
                                                 ] + $dbu->getEntitiesRestrictCriteria('glpi_appliances', '', '', true)
                               ]);

        if (count($iterator) > 0) {
            foreach ($iterator as $link) {
                $appliance = new Appliance();
                if ($appliance->getFromDB($link['appliances_id'])) {
                    if (!self::isApplianceAllowed($link['appliances_id'])) {
                        continue;
                    }

                    $display .= '<div class="linksc-normal center visitedchildbg" >';

                    $class = "bt-list-links";
                   //               if (!empty($link['icon'])) {
                   //                  $class = "";
                   //               }
                   //               if (empty($link['picture']) && empty($link['icon'])) {
                   //                  $class = "";
                   //               }
                   //               if (isset($link['picture']) && !empty($link['picture'])) {
                   //                  $display .= "<span>";
                   //                  $display .= '<img style="margin: 0 auto;display: block;" src="' . PLUGIN_SERVICECATALOG_WEBDIR . '/front/document.send.php?file=_plugins/' . $link['picture'] . '">';
                   //                  $display .= "</span>";
                   //               } else {
                   //                  //                  $display .= "<a class='bt-buttons $class' href='" . $link['url'] . "' $target >";
                   //               }
                   //
                   //               if (empty($link['picture']) && !empty($link['icon'])) {
                   //                  $fasize  = "fa-5x";
                   //                  $display .= "<div class='center'>";
                   //                  $display .= "<i class='bt-interface fa-menu-sc fas " . $link['icon'] . " $fasize' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>";//$style
                   //                  $display .= "</div>";
                   //               } else if (empty($link['picture']) && empty($link['icon']) && !empty($config->fields['fa_links'])) {
                   //                  $fasize  = "fa-5x";
                   //                  $display .= "<div class='center'>";
                   //                  $display .= "<i class='bt-interface fa-menu-sc fas " . $config->fields['fa_links'] . " $fasize' style=\"font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';\"></i>";//$style
                   //                  $display .= "</div>";
                   //               }

                    if (isset($appliance->fields['pictures'])
                    && !empty($appliance->fields['pictures'])) {
                        $pictures = json_decode($appliance->fields['pictures'], true);
                        if (is_array($pictures)) {
                            foreach ($pictures as $picture) {
                                $picture_url = Toolbox::getPictureUrl($picture);
                                $display     .= "<img style='margin-top: 20px;' class='appliancepicture_small center' alt=\"" . _sn('Picture', 'Pictures', 1) . "\" src='" .
                                        $picture_url . "'>";
                            }
                        }
                    } else {
                        $fasize = "fa-5x";
                        $icon   = $applink::getIcon();
                        $config = new PluginServicecatalogConfig();
                        if (!empty($config->fields['fa_myappliances_menu'])) {
                            $icon = $config->fields['fa_myappliances_menu'];
                        }
                        $display .= "<div class='center'>";
                        $display .= "<i class='bt-interface fa-menu-sc fas $icon $fasize' style=\"font-size: 5em;\"></i>";//$style
                        $display .= "</div>";
                    }
                    $display .= "<span class='bt-buttons' style='display: block;width: 100%; height: 100%;margin-top: 20px;'>";
                    $display .= "<h5 class=\"bt-title\">";
                    $display .= $appliance->getName();
                    $display .= "</h5></span>";
                    $url     = "";
                    if (Plugin::isPluginActive('webapplications')) {
                        $webapp_appliance = new PluginWebapplicationsAppliance();
                        $webapp_appliance->getFromDBByCrit(['appliances_id' => $link['appliances_id']]);
                        $url = isset($webapp_appliance->fields['address'])??"";
                    }

                    if (!empty($link['comment']) || !empty($url)) {
                        $id      = $link['appliances_id'];
                        $display .= "<div class='bottominfo'>";
                        $display .= "<a style='color: #d4d4d5!important;' href='#' data-bs-toggle='modal' data-bs-target='#appliancedetails$id' title=\"" . __('More informations', 'servicecatalog') . "\" >";
                        $display .= __('More informations', 'servicecatalog');
                        $display .= "</a>";
                        $display .= Ajax::createIframeModalWindow(
                            'appliancedetails' . $id,
                            PLUGIN_SERVICECATALOG_WEBDIR . "/front/appliancedetail.form.php?appliance_id=" . $id,
                            ['title'   => __('More informations', 'servicecatalog'),
                                                          'display' => false,
                                                          'width'   => 1050,
                                                          'height'  => 500]
                        );
                        $display .= '</div>';
                    }
                    $display .= "</div>";
                }
            }
        }

        if (count($iterator) == 0) {
            $display .= "<h5>";
            $display .= "<div class='alert alert-warning' role='alert'>";
            $display .= "<span>" . __('No appliance founded', 'servicecatalog') . "</span>";
            $display .= "</div>";
            $display .= "</h5>";
        }

        if ($widget == true) {
            return $display;
        } else {
            echo $display;
        }
    }

   /**
    * Manage events from js/fuzzysearch.js
    *
    * @param string $action action to switch (should be actually 'getHtml' or 'getList')
    *
    * @return string
    * @since 9.2
    *
    */
    public static function fuzzySearch($action = '')
    {
        global $DB;

        switch ($action) {
            default:
                $fuzzy_entries = [];

                $dbu      = new DbUtils();
                $applink  = new self();
                $iterator = $DB->request(['SELECT'  => ['glpi_plugin_servicecatalog_appliancelinks.appliances_id',
                                                        'glpi_plugin_servicecatalog_appliancelinks.comment',],
                                        'FROM'      => 'glpi_plugin_servicecatalog_appliancelinks',
                                        'LEFT JOIN' => [
                                           'glpi_appliances' => [
                                              'ON' => [
                                                 'glpi_plugin_servicecatalog_appliancelinks' => 'appliances_id',
                                                 'glpi_appliances'                           => 'id'
                                              ]
                                           ]
                                        ],
                                        'WHERE'     => [
                                                          'glpi_plugin_servicecatalog_appliancelinks' . '.use_with_sc' => 1,
                                                       ] + $dbu->getEntitiesRestrictCriteria('glpi_appliances', '', '', true)
                                     ]);

                if (count($iterator) > 0) {

                    foreach ($iterator as $link) {
                        $appliance = new Appliance();
                        if ($appliance->getFromDB($link['appliances_id'])) {
                            if (!self::isApplianceAllowed($link['appliances_id'])) {
                                continue;
                            }

                            $name   = $appliance->getName();
                            $url    = '';

                            if (Plugin::isPluginActive('webapplications')) {
                                $webapp_appliance = new PluginWebapplicationsAppliance();
                                $webapp_appliance->getFromDBByCrit(['appliances_id' => $link['appliances_id']]);
                                $url = $webapp_appliance->fields['address'];
                            }
                            $icon = $applink::getIcon();
                            $comment = $link['comment'];
                            $config = new PluginServicecatalogConfig();
                            if (!empty($config->fields['fa_myappliances_menu'])) {
                                $icon = $config->fields['fa_myappliances_menu'];
                            }
                            $fuzzy_entries[] = [
                            'url'   => $url,
                            'title' => $name,
                                'comment' => ($comment != null)?Html::resume_text(Glpi\RichText\RichText::getTextFromHtml($comment), "50"):"",
                            'icon'  => $icon,
                                'order'     => "1",
                            ];
                        }
                    }
                }
                // return the entries to ajax call
                return json_encode($fuzzy_entries);
                break;
        }
    }

   /**
    * @param      $helpdesk_category
    * @param      $type
    * @param bool $display
    *
    * @return \nothing|string
    */
    public static function getApplianceDetailsText($appliance_link)
    {
        $class = "class='tooltip-details' style='margin-left: 10px;margin-right: 10px;'";
        $text  = "";

        $title = __('Appliance details', 'servicecatalog');
        $text  .= "<div $class><div class='alert alert-secondary'><b>" . $title . "</b></div>";
        $text  .= (!empty($appliance_link->fields['comment'])) ?
         "<div style='margin-bottom: 5px'> " . Glpi\RichText\RichText::getSafeHtml($appliance_link->fields['comment']) . " </div>" : "";

        if (Plugin::isPluginActive('webapplications')) {
            $webapp_appliance = new PluginWebapplicationsAppliance();
            $webapp_appliance->getFromDBByCrit(['appliances_id' => $appliance_link->fields['appliances_id']]);
            $text .= (!empty($webapp_appliance->fields['address'])) ?
            "<div style='margin-bottom: 5px'><b>" . __('URL') . "</b><br><br><a href='" . $webapp_appliance->fields['address'] . "' target='_blank'>" . $webapp_appliance->fields['address'] . "</a></div>" : "";
        }

        echo $text;
    }

   /**
    * @param \MassiveAction $ma
    *
    * @return bool
    */
    public static function showMassiveActionsSubForm(MassiveAction $ma)
    {
        switch ($ma->getAction()) {
            case 'UseWithSC':
                echo __('Display on navigation menu and use it on ticket creation', 'servicecatalog');
                echo "&nbsp;";
                echo Dropdown::showYesNo("use_with_sc", 0, -1, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;
        }
        return parent::showMassiveActionsSubForm($ma);
    }

   /**
    * @param \MassiveAction $ma
    * @param \CommonDBTM    $item
    * @param array          $ids
    */
    public static function processMassiveActionsForOneItemtype(
        MassiveAction $ma,
        CommonDBTM $item,
        array         $ids
    ) {
        switch ($ma->getAction()) {
            case 'UseWithSC':
                $input = $ma->getInput();

                foreach ($ids as $id) {
                    $applink = new self();
                    if ($item->getFromDB($id)
                     && $applink->UseWithSC($input, $id)) {
                        $ma->itemDone($item->getType(), $id, MassiveAction::ACTION_OK);
                    } else {
                        $ma->itemDone($item->getType(), $id, MassiveAction::ACTION_KO);
                        $ma->addMessage(__("Something went wrong"));
                    }
                }
                return;
        }
        parent::processMassiveActionsForOneItemtype($ma, $item, $ids);
    }

   /**
    * @param $input
    * @param $id
    *
    * @return bool
    */
    public function UseWithSC($input, $id)
    {
        if ($this->getFromDBByCrit(["appliances_id" => $id])) {
            $input["id"]            = $this->getID();
            $input["appliances_id"] = $id;
            if ($this->update($input)) {
                return true;
            }
        } else {
            $input["appliances_id"] = $id;
            $input["comment"]       = "";
            $input["groups"]        = "[]";
            if ($this->add($input)) {
                return true;
            }
        }
        return false;
    }
}
