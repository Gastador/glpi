<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogProfile
 *
 * This class manages the profile rights of the plugin
 *
 * @package    Servicecatalog
 */
class PluginServicecatalogProfile extends Profile
{
    /**
     * @param int $nb
     *
     * @return string|\translated
     */
    public static function getTypeName($nb = 0)
    {
        return PluginServicecatalogMain::getTypeName();
    }

    /**
     * Get tab name for item
     *
     * @param CommonGLPI $item
     * @param int|type   $withtemplate
     *
     * @return string
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item->getType() == 'Profile') {
            return self::getTypeName(2);
        }
        return '';
    }

    /**
     * display tab content for item
     *
     * @param CommonGLPI $item
     * @param int|type   $tabnum
     * @param int|type   $withtemplate
     *
     * @return bool
     * @global type      $CFG_GLPI
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if ($item->getType() == 'Profile') {
            $ID   = $item->getID();
            $prof = new self();

            self::addDefaultProfileInfos(
                $ID,
                ['plugin_servicecatalog'                    => 0,
                  'plugin_servicecatalog_incidents'          => 0,
                  'plugin_servicecatalog_requests'           => 0,
                  'plugin_servicecatalog_add_actor'          => 0,
                  'plugin_servicecatalog_cancel_ticket'      => 0,
                  'plugin_servicecatalog_ticket_appointment' => 0,
                  'plugin_servicecatalog_setup'              => 0,
                  'plugin_servicecatalog_links'              => 0,
                  'plugin_servicecatalog_appliancelinks'     => 0,
                  'plugin_servicecatalog_myelements'         => 0,
                  'plugin_servicecatalog_contacts'           => 0,
                  'plugin_servicecatalog_checkticket'        => 0,
                  'plugin_servicecatalog_defaultview'        => READ,
                  'plugin_servicecatalog_view'               => 0,
                  'plugin_servicecatalog_resize'             => 0,
                   'plugin_servicecatalog_favorites'         => 0,
                    'plugin_servicecatalog_api'              => 0,
                    'plugin_servicecatalog_shortcuts'        => 0]
            );
            $prof->showForm($ID);
        }

        return true;
    }

    /**
     * @param $profiles_id
     */
    public static function createFirstAccess($profiles_id)
    {
        $rights = ['plugin_servicecatalog'                    => 0,
                   'plugin_servicecatalog_incidents'          => 0,
                   'plugin_servicecatalog_requests'           => 0,
                   'plugin_servicecatalog_add_actor'          => 0,
                   'plugin_servicecatalog_cancel_ticket'      => 0,
                   'plugin_servicecatalog_ticket_appointment' => 0,
                   'plugin_servicecatalog_checkticket'        => CREATE,
                   'plugin_servicecatalog_defaultview'        => CREATE,
                   'plugin_servicecatalog_view'               => 0,
                   'plugin_servicecatalog_setup'              => CREATE + UPDATE + PURGE,
                   'plugin_servicecatalog_links'              => READ + CREATE + UPDATE + PURGE,
                   'plugin_servicecatalog_appliancelinks'     => READ + CREATE + UPDATE + PURGE,
                   'plugin_servicecatalog_contacts'           => READ + CREATE + UPDATE + PURGE,
                   'plugin_servicecatalog_myelements'         => READ,
                   'plugin_servicecatalog_resize'             => CREATE,
                   'plugin_servicecatalog_favorites'          => CREATE,
                    'plugin_servicecatalog_api'               => READ + CREATE + UPDATE + PURGE,
                    'plugin_servicecatalog_shortcuts'         => CREATE];

        self::addDefaultProfileInfos(
            $profiles_id,
            $rights,
            true
        );
    }

    /**
     * show profile form
     *
     * @param int  $profiles_id
     * @param bool $openform
     * @param bool $closeform
     *
     * @return void
     * @internal param type $ID
     * @internal param type $options
     */
    public function showForm($profiles_id = 0, $openform = true, $closeform = true)
    {
        echo "<div class='firstbloc'>";
        if (($canedit = Session::haveRightsOr(self::$rightname, [READ + UPDATE + CREATE + PURGE]))
            && $openform) {
            $profile = new Profile();
            echo "<form method='post' action='" . $profile->getFormURL() . "'>";
        }

        $profile = new Profile();
        $profile->getFromDB($profiles_id);

        $rights = $this->getAllRights();
        $profile->displayRightsChoiceMatrix($rights, ['canedit'       => $canedit,
                                                      'default_class' => 'tab_bg_2',
                                                      'title'         => __('General')]);

        echo "<table class='tab_cadre_fixehov'>";
        echo "<tr class='tab_bg_1'><th colspan='4'>" . __('Ticket creation', 'servicecatalog') . "</th></tr>\n";

        $effective_rights_plugin_servicecatalog = ProfileRight::getProfileRights($profiles_id, ['plugin_servicecatalog']);
        echo "<tr class='tab_bg_2'>";
        echo "<td width='20%'>" . __('Use plugin', 'servicecatalog') . "</td>";
        echo "<td colspan='5'>";
        Html::showCheckbox(['name'    => '_plugin_servicecatalog',
                            'checked' => $effective_rights_plugin_servicecatalog['plugin_servicecatalog']]);
        echo "</td></tr>\n";

        $effective_rights_plugin_servicecatalog = ProfileRight::getProfileRights($profiles_id, ['plugin_servicecatalog_incidents']);
        echo "<tr class='tab_bg_2'>";
        echo "<td width='20%'>" . __('Create incidents', 'servicecatalog') . "</td>";
        echo "<td colspan='5'>";
        Html::showCheckbox(['name'    => '_plugin_servicecatalog_incidents',
                            'checked' => $effective_rights_plugin_servicecatalog['plugin_servicecatalog_incidents']]);
        echo "</td></tr>\n";

        $effective_rights_plugin_servicecatalog = ProfileRight::getProfileRights($profiles_id, ['plugin_servicecatalog_requests']);
        echo "<tr class='tab_bg_2'>";
        echo "<td width='20%'>" . __('Create requests', 'servicecatalog') . "</td>";
        echo "<td colspan='5'>";
        Html::showCheckbox(['name'    => '_plugin_servicecatalog_requests',
                            'checked' => $effective_rights_plugin_servicecatalog['plugin_servicecatalog_requests']]);
        echo "</td></tr>\n";

        $effective_rights_plugin_servicecatalog_add_actor = ProfileRight::getProfileRights($profiles_id, ['plugin_servicecatalog_add_actor']);
        echo "<tr class='tab_bg_2'>";
        echo "<td width='20%'>" . __('Can add actors', 'servicecatalog') . "</td>";
        echo "<td colspan='5'>";
        Html::showCheckbox(['name'    => '_plugin_servicecatalog_add_actor',
                            'checked' => $effective_rights_plugin_servicecatalog_add_actor['plugin_servicecatalog_add_actor']]);
        echo "</td></tr>\n";

        $effective_rights_plugin_servicecatalog_cancel_ticket = ProfileRight::getProfileRights($profiles_id, ['plugin_servicecatalog_cancel_ticket']);
        echo "<tr class='tab_bg_2'>";
        echo "<td width='20%'>" . __('Can cancel ticket', 'servicecatalog') . "</td>";
        echo "<td colspan='5'>";
        Html::showCheckbox(['name'    => '_plugin_servicecatalog_cancel_ticket',
                            'checked' => $effective_rights_plugin_servicecatalog_cancel_ticket['plugin_servicecatalog_cancel_ticket']]);
        echo "</td></tr>\n";

        $effective_rights_plugin_servicecatalog_ticket_appointment = ProfileRight::getProfileRights($profiles_id, ['plugin_servicecatalog_ticket_appointment']);
        echo "<tr class='tab_bg_2'>";
        echo "<td width='20%'>" . __('Can create appointments with technicians', 'servicecatalog') . "</td>";
        echo "<td colspan='5'>";
        Html::showCheckbox(['name'    => '_plugin_servicecatalog_ticket_appointment',
                            'checked' => $effective_rights_plugin_servicecatalog_ticket_appointment['plugin_servicecatalog_ticket_appointment']]);
        echo "</td></tr>\n";

        echo "</table>";

        if ($canedit
            && $closeform) {
            echo "<div class='center'>";
            echo Html::hidden('id', ['value' => $profiles_id]);
            echo Html::submit(_sx('button', 'Save'), ['name' => 'update', 'class' => 'btn btn-primary']);
            echo "</div>\n";
            Html::closeForm();
        }
        echo "</div>";

        $this->showLegend();
    }

    /**
     * Get all rights
     *
     * @param bool $all
     *
     * @return array
     */
    public static function getAllRights($all = false)
    {
        $rights = [
            ['itemtype' => 'PluginServicecatalogConfig',
             'label'    => PluginServicecatalogMain::getTypeName(),
             'field'    => 'plugin_servicecatalog_setup'
            ],
            ['itemtype' => 'PluginServicecatalogLink',
             'label'    => PluginServicecatalogLink::getTypeName(2),
             'field'    => 'plugin_servicecatalog_links'
            ],
            ['itemtype' => 'PluginServicecatalogApplianceLink',
             'label'    => PluginServicecatalogApplianceLink::getTypeName(2),
             'field'    => 'plugin_servicecatalog_appliancelinks'
            ],
            ['itemtype' => 'PluginServicecatalogContact',
             'label'    => PluginServicecatalogContact::getTypeName(2),
             'field'    => 'plugin_servicecatalog_contacts'
            ],
            ['itemtype' => 'PluginServicecatalogApiclient',
                'label'    => PluginServicecatalogApiclient::getTypeName(2),
                'field'    => 'plugin_servicecatalog_api'
            ],
            ['itemtype' => 'PluginServicecatalogShortcut',
                'label'    => PluginServicecatalogShortcut::getTypeName(2),
                'field'    => 'plugin_servicecatalog_shortcuts'
            ]
        ];

        $rights[] = ['itemtype' => 'PluginServicecatalogTicketcheck',
                     'label'    => __('Use category ticket check', 'servicecatalog'),
                     'field'    => 'plugin_servicecatalog_checkticket'];

        $rights[] = ['itemtype' => 'PluginServicecatalogUsercard',
                     'label'    => __('See your equipments', 'servicecatalog'),
                     'field'    => 'plugin_servicecatalog_myelements'];

        $rights[] = ['itemtype' => 'PluginServicecatalogDashboard',
                     'label'    => __('Update default view', 'servicecatalog'),
                     'field'    => 'plugin_servicecatalog_defaultview'];

        $rights[] = ['itemtype' => 'PluginServicecatalogDashboard',
                     'label'    => __('Update his view', 'servicecatalog'),
                     'field'    => 'plugin_servicecatalog_view'];

        $rights[] = ['itemtype' => 'PluginServicecatalogDashboard',
                     'label'    => __('Resize dashboards', 'servicecatalog'),
                     'field'    => 'plugin_servicecatalog_resize'];

        $rights[] = ['itemtype' => 'PluginServicecatalogFavorite',
                     'label'    => __('Favorites', 'servicecatalog'),
                     'field'    => 'plugin_servicecatalog_favorites'];
        if ($all) {
            $rights[] = ['itemtype' => 'PluginServicecatalogMain',
                         'label'    => __('Use plugin', 'servicecatalog'),
                         'field'    => 'plugin_servicecatalog'];

            $rights[] = ['itemtype' => 'PluginServicecatalogMain',
                         'label'    => __('Create incidents', 'servicecatalog'),
                         'field'    => 'plugin_servicecatalog_incidents'];

            $rights[] = ['itemtype' => 'PluginServicecatalogMain',
                         'label'    => __('Create requests', 'servicecatalog'),
                         'field'    => 'plugin_servicecatalog_requests'];

            $rights[] = ['itemtype' => 'PluginServicecatalogMain',
                         'label'    => __('Can add actors', 'servicecatalog'),
                         'field'    => 'plugin_servicecatalog_add_actor'];

            $rights[] = ['itemtype' => 'PluginServicecatalogMain',
                         'label'    => __('Can cancel ticket', 'servicecatalog'),
                         'field'    => 'plugin_servicecatalog_cancel_ticket'];

            $rights[] = ['itemtype' => 'PluginServicecatalogMain',
                         'label'    => __('Can create appointments with technicians', 'servicecatalog'),
                         'field'    => 'plugin_servicecatalog_ticket_appointment'];
        }

        return $rights;
    }

    /**
     * Init profiles
     *
     * @param $old_right
     *
     * @return int
     */

    public static function translateARight($old_right)
    {
        switch ($old_right) {
            case 'r':
                return READ;
            case 'w':
                return ALLSTANDARDRIGHT;
            case '0':
            case '1':
                return $old_right;

            default:
                return 0;
        }
    }


    /**
     * @param $profiles_id the profile ID
     *
     * @return bool
     * @throws \GlpitestSQLError
     * @since 0.85
     * Migration rights from old system to the new one for one profile
     */
    public static function migrateOneProfile($profiles_id)
    {
        global $DB;
        //Cannot launch migration if there's nothing to migrate...
        if (!$DB->tableExists('glpi_plugin_servicecatalog_profiles')) {
            return true;
        }

        foreach ($DB->request(
            'glpi_plugin_servicecatalog_profiles',
            "`profiles_id`='$profiles_id'"
        ) as $profile_data) {
            $matching       = ['servicecatalog' => 'plugin_servicecatalog'];
            $current_rights = ProfileRight::getProfileRights($profiles_id, array_values($matching));
            foreach ($matching as $old => $new) {
                if (!isset($current_rights[$old])) {
                    $query = "UPDATE `glpi_profilerights` 
                         SET `rights`='" . self::translateARight($profile_data[$old]) . "' 
                         WHERE `name`='$new' AND `profiles_id`='$profiles_id'";
                    $DB->query($query);
                }
            }
        }
    }

    /**
     * Initialize profiles, and migrate it necessary
     */
    public static function initProfile()
    {
        global $DB;
        $profile = new self();
        $dbu     = new DbUtils();
        //Add new rights in glpi_profilerights table
        foreach ($profile->getAllRights(true) as $data) {
            if ($dbu->countElementsInTable(
                "glpi_profilerights",
                ["name" => $data['field']]
            ) == 0) {
                ProfileRight::addProfileRights([$data['field']]);
            }
        }

        //Migration old rights in new ones
        foreach ($DB->request("SELECT `id` FROM `glpi_profiles`") as $prof) {
            self::migrateOneProfile($prof['id']);
        }
        foreach ($DB->request("SELECT *
                           FROM `glpi_profilerights` 
                           WHERE `profiles_id`='" . $_SESSION['glpiactiveprofile']['id'] . "' 
                              AND `name` LIKE '%plugin_servicecatalog%'") as $prof) {
            $_SESSION['glpiactiveprofile'][$prof['name']] = $prof['rights'];
        }
    }

    /**
     * Initialize profiles, and migrate it necessary
     */
    public static function changeProfile()
    {
        global $DB, $GLPI_CACHE;

        foreach ($DB->request("SELECT *
                           FROM `glpi_profilerights` 
                           WHERE `profiles_id`='" . $_SESSION['glpiactiveprofile']['id'] . "' 
                              AND `name` LIKE '%plugin_servicecatalog%'") as $prof) {
            $_SESSION['glpiactiveprofile'][$prof['name']] = $prof['rights'];
        }

        $_SESSION["glpi_plugin_servicecatalog_loaded"] = 0;
        $cat                                           = new PluginServicecatalogCategory();
        $types                                         = [Ticket::INCIDENT_TYPE, Ticket::DEMAND_TYPE];
        foreach ($types as $type) {
            $ckey = 'sc_cache_' . md5($cat->getTable() . $type);
            $GLPI_CACHE->delete($ckey);
        }
        if (isset($_SESSION["glpi_plugin_servicecatalog_categories"])) {
            unset($_SESSION["glpi_plugin_servicecatalog_categories"]);
        }
        if (isset($_SESSION["plugin_servicecatalog"])) {
            unset($_SESSION["plugin_servicecatalog"]);
        }
    }

    /**
     * @param      $profiles_id
     * @param      $rights
     * @param bool $drop_existing
     */
    public static function addDefaultProfileInfos($profiles_id, $rights, $drop_existing = false)
    {
        $dbu          = new DbUtils();
        $profileRight = new ProfileRight();
        foreach ($rights as $right => $value) {
            if ($dbu->countElementsInTable(
                'glpi_profilerights',
                ["profiles_id" => $profiles_id, "name" => $right]
            ) && $drop_existing) {
                $profileRight->deleteByCriteria(['profiles_id' => $profiles_id, 'name' => $right]);
            }
            if (!$dbu->countElementsInTable(
                'glpi_profilerights',
                ["profiles_id" => $profiles_id, "name" => $right]
            )) {
                $myright['profiles_id'] = $profiles_id;
                $myright['name']        = $right;
                $myright['rights']      = $value;
                $profileRight->add($myright);

                //Add right to the current session
                $_SESSION['glpiactiveprofile'][$right] = $value;
            }
        }
    }
}
