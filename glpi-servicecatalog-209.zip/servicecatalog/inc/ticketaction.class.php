<?php
/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogTicketaction
 */
class PluginServicecatalogTicketaction extends CommonITILObject
{
    /**
     * @param $params
     */
    public static function showActionsForm($params)
    {
        $item = $params['item'];
        if ($item->getType() == "Ticket") {
            $config = new PluginServicecatalogConfig();

            if ($_SESSION["glpiactiveprofile"]["interface"] == "helpdesk"
                && (($item->isUser(CommonITILActor::REQUESTER, Session::getLoginUserID())
                     || $item->fields["users_id_recipient"] === Session::getLoginUserID())
                    && $item->fields['status'] != self::SOLVED
                    && $item->fields['status'] != self::CLOSED
                    && $item->numberOfFollowups() == 0
                    && $item->numberOfTasks() == 0)
                && Session::haveRight("plugin_servicecatalog_cancel_ticket", READ)
                && $config->getTicketTemplateAssociatedToCancelTicket() > 0
            ) {
                echo "<button class='submit btn btn-danger answer-action mb-2' data-bs-toggle='modal' data-bs-target='#cancelticket' style='margin-right: 12px;'>"
                     . "<i class='fas fa-window-close'></i><span>" . __("Cancel my ticket", 'servicecatalog') . "</span></button>";

                echo Ajax::createIframeModalWindow(
                    'cancelticket',
                    PLUGIN_SERVICECATALOG_WEBDIR . '/front/cancelticket.form.php?tickets_id=' . $item->fields['id'],
                    ['title'         => __("Cancel my ticket", 'servicecatalog'),
                     'display'       => false,
                     'width'         => 150,
                     'height'        => 250,
                     'reloadonclose' => true]
                );
            }

            if (($item->isUser(CommonITILActor::REQUESTER, Session::getLoginUserID())
                 || $item->fields["users_id_recipient"] === Session::getLoginUserID())
                && ($config->addRequestersFromTickets() || $config->addObserversFromTickets())
                && Session::haveRight("plugin_servicecatalog_add_actor", READ)
                && !in_array($item->fields["status"], [Ticket::SOLVED, Ticket::CLOSED])) {
                echo "<button class='submit btn btn-secondary answer-action mb-2' data-bs-toggle='modal' data-bs-target='#addactorsticket' style='margin-right: 12px;'>"
                     . "<i class='fas fa-user'></i><span>" . __("Add an actor", 'servicecatalog') . "</span></button>";

                echo Ajax::createIframeModalWindow(
                    'addactorsticket',
                    PLUGIN_SERVICECATALOG_WEBDIR . '/front/addactorsticket.form.php?tickets_id=' . $item->fields['id'],
                    ['title'         => __("Add an actor", 'servicecatalog'),
                     'display'       => false,
                     'width'         => 200,
                     'height'        => 400,
                     'reloadonclose' => true]
                );
            }

            //      echo "<script type='text/javascript' >\n";
            //      echo "function revive" . $item->fields['id'] . "$rand(itemtype) {\n";
            //      $params = ['action'     => 'revive',
            //                 'type'       => 'itemtype',
            //                 'parenttype' => $objType,
            //                 $foreignKey  => $item->fields['id'],
            //                 'id'         => -1];
            //      $out    = Ajax::updateItemJsCode("viewitem" . $item->fields['id'] . "$rand",
            //                                       PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/timeline.php",
            //                                       $params, "", false);
            //      echo str_replace("\"itemtype\"", "itemtype", $out);
            //      echo "$('#approbation_form$rand').remove()";
            //      echo "};";
            //      echo "</script>\n";
            //
            //      echo "<li class='revive' onclick='" .
            //           "javascript:revive" . $item->fields['id'] . "$rand(\"PluginServicecatalogTicketaction\");'>"
            //           . "<i class='fas fa-phone-volume'></i>" . __("Revive", 'servicecatalog') . "</li>";
        }
    }

    public static function addToTimeline($options)
    {
        $item      = $options['item'];
        $config    = new PluginServicecatalogConfig();
        $itemtypes = [];
        $users     = [];
        foreach ($item->getUsers(CommonITILActor::ASSIGN) as $data) {
            $users[$data['users_id']] = getUserName($data['users_id']);
        }

        $user_requester = [];
        foreach ($item->getUsers(CommonITILActor::REQUESTER) as $data) {
            $user_requester[$data['users_id']] = getUserName($data['users_id']);
        }

        if (count($user_requester) > 0) {
            if (count($users) > 0
                && !in_array($item->fields["status"], [Ticket::SOLVED, Ticket::CLOSED])
                && Session::haveRight("plugin_servicecatalog_ticket_appointment", READ)
            ) {
                $itemtypes['appointment'] = [
                    'type'  => 'PluginServicecatalogTicketAppointment',
                    'class' => 'PluginServicecatalogTicketAppointment',
                    'icon'  => 'fas fa-calendar-check',
                    'label' => __("Make an appointment", 'servicecatalog'),
                    //               'template' => '@servicecatalog/add_appointement_ticket.html.twig',
                    'item'  => new PluginServicecatalogTicketAppointment()
                ];
            }
        }
        return $itemtypes;
    }

    /**
     * @param $id
     * @param $params
     */
    public function showReviveForm($id, $params)
    {
        //TODO Check ticket lock - right update ticket
        if (isset($_SESSION["glpiactiveprofile"]["interface"])
            && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
            echo __('You want to relaunch the people in charge of the ticket?', 'servicecatalog');
        } else {
            echo __('You want to relaunch the requester?', 'servicecatalog');
        }
    }


    /**
     * @param $id
     * @param $params
     */
    public static function showCancelForm($params)
    {
        if (isset($_SESSION["glpiactiveprofile"]["interface"])
            && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
            echo "<div class='alert alert-danger center' role='alert'>";
            echo "<i class='fas fa-windows-close fa-2x'></i>&nbsp;";
            echo __('You want to cancel your ticket?', 'servicecatalog');
            echo "<br><br>";
            $form = self::getFormURL() . "?cancelticket=1";
            echo "<form name='form' method='post' action='" . $form . "'>";
            echo "<button class='submit btn btn-danger'>";
            echo "<i class='fas fa-window-close'></i>&nbsp;";
            echo __('Cancel my ticket', 'servicecatalog');
            echo "</button>";
            echo Html::hidden('tickets_id', ['value' => $params['tickets_id']]);
            echo Html::hidden('cancelticket', ['value' => 1]);
            Html::closeForm();
            echo "</div>";
            echo "<br><br>";
            echo "<div class='alert alert-warning'>";
            echo "<h4 class='alert-title'>" . __('Cancel my ticket', 'servicecatalog') . "</h4>";
            echo "<div class='text-muted'>";
            echo __('If you cancel your ticket, the ticket will be resolved', 'servicecatalog');
            echo "</div>";
        }
    }

    /**
     * @param $id
     * @param $params
     */
    public static function showAddActorForm($params)
    {
        echo "<div class='alert alert-info center' role='alert'>";
        echo "<i class='fas fa-user fa-2x'></i>&nbsp;";
        echo __('You want to add a actor on the ticket?', 'servicecatalog');
        echo "</div>";
        echo "<form name='form' method='post' action='" . self::getFormURL() . "'>";
        echo "<table class='tab_cadre_fixe'>";
        //         echo "<tr><th>";
        //
        //         echo "</th></tr>";
        echo "<tr><td>";
        //         $ticket = new PluginServicecatalogTicket();
        //         $ticket->showActorAddForm($type);
        $types[0] = Dropdown::EMPTY_VALUE;

        $config = new PluginServicecatalogConfig();
        if ($config->addRequestersFromTickets()) {
            $types[CommonITILActor::REQUESTER] = __('Requester');
        }
        if ($config->addObserversFromTickets()) {
            $types[CommonITILActor::OBSERVER] = __('Watcher');
        }
        $rand = Dropdown::showFromArray('actortype', $types);

        $paramsmassaction = ['actortype' => '__VALUE__'];

        Ajax::updateItemOnSelectEvent(
            "dropdown_actortype$rand",
            "show_massiveaction_field",
            PLUGIN_SERVICECATALOG_WEBDIR .
            "/ajax/dropdownMassiveActionAddActor.php",
            $paramsmassaction
        );
        echo "<span id='show_massiveaction_field'>&nbsp;</span>\n";
        echo Html::hidden('tickets_id', ['value' => $params["tickets_id"]]);
        if ($config->addRequestersFromTickets() || $config->addRequestersFromTickets()) {
            echo "<br><br>";
            echo "<div class='alert alert-warning'>";
            if ($config->addRequestersFromTickets()) {
                echo "<h4 class='alert-title'>" . __('Add a requester', 'servicecatalog') . "</h4>";
                echo "<div class='text-muted'>";
                echo __('If you add a requester on the ticket, he can see the ticket on his interface, receive notifications, and add followup on it', 'servicecatalog');
                echo "</div>";
            }
            if ($config->addRequestersFromTickets()) {
                echo "<br>";
                echo "<h4 class='alert-title'>" . __('Add an observer', 'servicecatalog') . "</h4>";
                echo "<div class='text-muted'>";
                echo __('If you add an observer on the ticket, he can see the ticket on his interface, receive notifications, but cannot add followup on it', 'servicecatalog');
                echo "</div>";
            }
            echo "</div>";
        }
        echo "</td></tr></table>";
        Html::closeForm();
    }

    /**
     * @param integer $entity entities_id usefull if function called by cron (default 0)
     **@since 9.5.0
     *
     */
    public static function getDefaultValues($entity = 0)
    {
        // TODO: Implement getDefaultValues() method.
    }

    public static function getItemLinkClass(): string
    {
        return false;
    }

    public static function getTaskClass()
    {
        // TODO: Implement getTaskClass() method.
    }

    public static function getContentTemplatesParametersClass(): string
    {
        // TODO: Implement getContentTemplatesParametersClass() method.
    }
}
