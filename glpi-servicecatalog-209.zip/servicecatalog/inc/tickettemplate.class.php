<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogTicketTemplate
 */
class PluginServicecatalogTicketTemplate extends CommonDBTM
{

    static $rightname = 'plugin_servicecatalog_setup';

   //List of fields
    const FIELD_IMPACT            = 1;
    const FIELD_TIMETORESOLVE     = 2;
    const FIELD_VALIDATIONREQUEST = 3;
    const FIELD_REQUESTER         = 4;

    const FIELDS = [self::FIELD_IMPACT, self::FIELD_TIMETORESOLVE, self::FIELD_VALIDATIONREQUEST];

   /**
    * functions mandatory
    * getTypeName(), canCreate(), canView()
    *
    * @param int $nb
    *
    * @return string
    */
    static function getTypeName($nb = 0)
    {
        PluginServicecatalogMain::getTypeName();
    }

   /**
    * Display image tab for each category
    *
    * @param CommonGLPI $item
    * @param int        $withtemplate
    *
    * @return array|string
    */
    function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {

        if (!$withtemplate) {
            if ($item->getType() == 'TicketTemplate' && $this->canUpdate()) {
                if ($_SESSION['glpishow_count_on_tabs']) {
                    $dbu = new DbUtils();
                    return self::createTabEntry(
                        PluginServicecatalogMain::getTypeName(),
                        $dbu->countElementsInTable(
                            self::getTable(),
                            ["tickettemplates_id" => $item->getField('id')]
                        )
                    );
                }
                return PluginServicecatalogMain::getTypeName();
            }
        }
        return '';
    }

   /**
    * Display tab's content for each computer
    *
    * @static
    *
    * @param CommonGLPI $item
    * @param int        $tabnum
    * @param int        $withtemplate
    *
    * @return bool|true
    */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {

        switch ($item->getType()) {
            case 'TicketTemplate':
                $tickettemplate = new self();
                $tickettemplate->showForTicketTemplate($item);
                break;
        }

        return true;
    }

   /**
    * Returns the list of fields
    *
    * @return array
    */
    static function getFields()
    {
        $fields = [];

        foreach (self::FIELDS as $field) {
            $fields[$field] = self::getFieldName($field);
        }
        return $fields;
    }

   /**
    * Returns the variable of the field
    *
    * @param $field
    *
    * @return string
    */
    static function getFieldDBName($field)
    {
        switch ($field) {
            case self::FIELD_IMPACT:
                return 'impact';
            case self::FIELD_TIMETORESOLVE:
                return 'time_to_resolve';
            case self::FIELD_VALIDATIONREQUEST:
                return 'users_id_validate';
            default:
                return "";
        }
    }

   /**
    * Returns the name of the field
    *
    * @param $field
    *
    * @return string|\translated
    */
    static function getFieldName($field)
    {
        switch ($field) {
            case self::FIELD_IMPACT:
                return __('Impact');
            case self::FIELD_TIMETORESOLVE:
                return __('Time to resolve');
            case self::FIELD_VALIDATIONREQUEST:
                return __('Validation request');
            default:
                return "";
        }
    }

   /**
    * Returns the default value of the field
    *
    * @param $field
    * @param $default_values
    *
    */
    static function getDefaultValue($field, &$default_values)
    {
        switch ($field) {
            case self::FIELD_IMPACT:
                $default_values[self::getFieldName(self::FIELD_IMPACT)] = 3;
                break;
            case self::FIELD_TIMETORESOLVE:
                $default_values[self::getFieldName(self::FIELD_TIMETORESOLVE)] = 'NULL';
                break;
            case self::FIELD_VALIDATIONREQUEST:
                $default_values[self::getFieldName(self::FIELD_VALIDATIONREQUEST)] = [];
                break;
        }
    }


   /**
    * Check if the field is enabled in the template
    *
    * @param \TicketTemplate $tt
    * @param                 $field
    *
    * @return bool
    */
    static function isFieldActivated(TicketTemplate $tt, $field)
    {

        $tickettemplate = new self();
        if ($tickettemplate->find(['tickettemplates_id' => $tt->getID(),
                                 'field'              => $field])) {
            return true;
        }
        return false;
    }

   /**
    * Form for managing the fields to be added to the service catalogue as standard interface
    *
    * @param \TicketTemplate $tt
    *
    * @return bool
    */
    static function showForTicketTemplate(TicketTemplate $tt)
    {
        global $DB;

        $ID = $tt->fields['id'];

        if (!$tt->getFromDB($ID) || !$tt->can($ID, READ)) {
            return false;
        }

        $canedit = true;
        $rand    = mt_rand();

        $iterator = $DB->request([
                                  'FROM'  => self::getTable(),
                                  'WHERE' => ['tickettemplates_id' => $ID],
                                  'ORDER' => 'id'
                               ]);

        $fields  = [];
        $used    = [];
        $numrows = count($iterator);
        foreach ($iterator as $data) {
            $fields[$data['id']]  = $data;
            $used[$data['field']] = $data['field'];
        }

       //Form to add fields
        if ($canedit) {
            echo "<div class='firstbloc'>";
            echo "<form name='scfields_form$rand' id='scfields_form$rand' method='post'
                   action='" . Toolbox::getItemTypeFormURL(__CLASS__) . "'>";

            echo "<table class='tab_cadre_fixe'>";
            echo "<tr class='tab_bg_2'><th colspan='2'>" . __('Add a field to the form', 'servicecatalog') . "</th></tr>";
            echo "<tr class='tab_bg_2'><td class='right'>";
            echo Html::hidden('tickettemplates_id', ['value' => $ID]);
            Dropdown::showFromArray('field', self::getFields(), ['used' => $used]);
            echo "</td><td class='center'>";
            echo Html::submit(_sx('button', 'Add'), ['name' => 'add', 'class' => 'btn btn-primary']);
            echo "</td></tr>";
            echo "</table>";

            Html::closeForm();
            echo "</div>";
        }

       //List of fields
        echo "<div class='spaced'>";

        if ($canedit && $numrows) {
            Html::openMassiveActionsForm('mass' . __CLASS__ . $rand);
            $massiveactionparams = ['num_displayed' => min($_SESSION['glpilist_limit'], $numrows),
                                 'container'     => 'mass' . __CLASS__ . $rand];
            Html::showMassiveActions($massiveactionparams);
        }
        echo "<table class='tab_cadre_fixehov'>";
        echo "<tr class='tab_bg_2'><th colspan='2'>" . __('Fields added to the form', 'servicecatalog') . "</th></tr>";
        if ($numrows) {
            $header_begin  = "<tr>";
            $header_top    = '';
            $header_bottom = '';
            $header_end    = '';
            if ($canedit) {
                $header_top    .= "<th width='10'>";
                $header_top    .= Html::getCheckAllAsCheckbox('mass' . __CLASS__ . $rand) . "</th>";
                $header_bottom .= "<th width='10'>";
                $header_bottom .= Html::getCheckAllAsCheckbox('mass' . __CLASS__ . $rand) . "</th>";
            }
            $header_end .= "<th>" . __('Name') . "</th>";
            $header_end .= "</tr>";
            echo $header_begin . $header_top . $header_end;

            foreach ($fields as $data) {
                echo "<tr class='tab_bg_2'>";
                if ($canedit) {
                    echo "<td>" . Html::getMassiveActionCheckBox(__CLASS__, $data["id"]) . "</td>";
                }
                echo "<td>" . self::getFieldName($data['field']) . "</td>";
                echo "</tr>";
            }
            echo $header_begin . $header_bottom . $header_end;
        } else {
            echo "<tr><th colspan='2'>" . __('No item found') . "</th></tr>";
        }

        echo "</table>";
        if ($canedit && $numrows) {
            $massiveactionparams['ontop'] = false;
            Html::showMassiveActions($massiveactionparams);
            Html::closeForm();
        }
        echo "</div>";
    }

   /**
    * @return an|array
    */
    function getForbiddenStandardMassiveAction()
    {

        $forbidden   = parent::getForbiddenStandardMassiveAction();
        $forbidden[] = 'update';
        return $forbidden;
    }
}
