<?php
/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

use Ramsey\Uuid\Uuid;

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogTicketAppointment
 */
class PluginServicecatalogTicketAppointment extends CommonITILTask
{

    static $rightname = "plugin_servicecatalog_ticket_appointment";

   /**
    * functions mandatory
    * getTypeName(), canCreate(), canView()
    *
    * @param int $nb
    *
    * @return string
    */
    static function getTypeName($nb = 0)
    {
        return _n('Ticket appointment', 'Ticket appointments', $nb, 'servicecatalog');
    }

   /**
    * @param $id
    * @param $params
    */
    function showForm($ID, $options = [])
    {
        global $CFG_GLPI;

        $item                 = $options['parent'];
        $params['tickets_id'] = $item->fields['id'];
        $check                = self::chekIfAppointmentExists($params);

        if ($check === false) {
            echo "<div class='alert alert-success center' role='alert'>";
            echo "<i class='fas fa-map-marker-alt fa-2x'></i>&nbsp;";
            if (isset($_SESSION["glpiactiveprofile"]["interface"])
             && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
                echo __('You want to make a appointment with the technician in charge of the ticket ?', 'servicecatalog');
                echo "&nbsp;" . __('Select a niche', 'servicecatalog');
            } else {
                echo __('You want to make a appointment with the requester ?', 'servicecatalog');
            }
            echo "</div><br>";

            $opt = ['checkavailability' => 'checkavailability',
                 'itemtype'          => 'Ticket',
                 'tickets_id'        => $params["tickets_id"],
                 '_in_modal'         => 0];


            echo "<script type='text/javascript'>";
            echo "$(function() {";
            Ajax::updateItemJsCode(
                "planning_tech",
                PLUGIN_SERVICECATALOG_WEBDIR .
                "/ajax/planningcheck.php",
                $opt,
                "buttonplanningcheck"
            );
            echo "});</script>";
            echo "<div id='planning_tech' class=\"input-group\">";
            echo "</div>";
        } else {
            echo "<div class='alert alert-success center' role='alert'>";
            echo "<i class='fas fa-map-marker-alt fa-2x'></i>&nbsp;";
            echo __('You have a planified appointment', 'servicecatalog');
            echo "<br><br>";
            if (isset($_SESSION["glpiactiveprofile"]["interface"])
             && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
                echo __('Appointment with', 'servicecatalog') . "&nbsp;" . getUserName($check['users_id_tech']);
            } else {
                echo __('Appointment with the requester', 'servicecatalog') . "&nbsp;" . getUserName($check['users_id_requester']);
            }
            echo "<br>";
            echo __('The', 'servicecatalog') . "&nbsp;" . Html::convDateTime($check['begin']) . " / " . Html::convDateTime($check['end']);
            echo "<br><br>";
            $form = PLUGIN_SERVICECATALOG_WEBDIR . "/front/planning.php?deleteappointment=1";
            echo "<form name='form' method='post' action='" . $form . "'>";
            echo "<button class='submit btn btn-danger' " .
              Html::addConfirmationOnAction(__('Confirm appointment cancellation?', 'servicecatalog')) . ">";
            echo __('Cancel the appointment', 'servicecatalog');
            echo "</button>";
            echo Html::hidden('id', ['value' => $check['id']]);
            echo Html::hidden('deleteappointment', ['value' => 1]);
            Html::closeForm();
            echo "</div>";
        }
    }


   /**
    * @param integer $entity entities_id usefull if function called by cron (default 0)
    **@since 9.5.0
    *
    */
    static function getDefaultValues($entity = 0)
    {
       // TODO: Implement getDefaultValues() method.
    }

    public static function getItemLinkClass(): string
    {
        return false;
    }

    static function isWeekend($date, $begin = true)
    {
        if (date('H:i:s', strtotime($date)) == "00:00:00") {
            if ($begin) {
                $date = date("Y-m-d H:i:s", strtotime("+1 minutes", strtotime($date)));
            } else {
                $date = date("Y-m-d H:i:s", strtotime("-1 minutes", strtotime($date)));
            }
        }

        return (date('N', strtotime($date)) >= 6);
    }

   /**
    * Show the availability of a user
    *
    * @param $params   array of params
    *    must contain :
    *          - begin: begin date to check (default '')
    *          - end: end date to check (default '')
    *          - itemtype : User or Object type (Ticket...)
    *          - foreign key field of the itemtype to define which item to used
    *    optional :
    *          - limitto : limit display to a specific user
    *
    * @return void
    **@since 0.83
    *
    */
    static function checkAvailability($params = [])
    {
        global $CFG_GLPI;

        if (!isset($params['itemtype'])) {
            return false;
        }
        if (!($item = getItemForItemtype($params['itemtype']))) {
            return false;
        }
        if (!isset($params[$item->getForeignKeyField()])
          || !$item->getFromDB($params[$item->getForeignKeyField()])) {
            return false;
        }

       // No limit by default
        if (!isset($params['limitto'])) {
            $params['limitto'] = 0;
        }
        if (isset($params['begin']) && !empty($params['begin'])) {
            $begin = $params['begin'];
        } else {
            $begin = date("Y-m-d");
        }
        if (isset($params['end']) && !empty($params['end'])) {
            $end = $params['end'];
        } else {
            $end = date("Y-m-d");
           //         $end = date("Y-m-d", strtotime($end . "+1 days"));
        }

        if ($end < $begin) {
            $end = $begin;
        }
        $realbegin = $begin . " " . $CFG_GLPI["planning_begin"];
        $realend   = $end . " " . $CFG_GLPI["planning_end"];
        if ($CFG_GLPI["planning_end"] == "24:00") {
            $realend = $end . " 23:59:59";
        }

        $users = [];

        switch ($item->getType()) {
            case 'User':
                $users[$item->getID()] = $item->getName();
                break;

            default:
                if (is_a($item, 'CommonITILObject', true)) {
                    foreach ($item->getUsers(CommonITILActor::ASSIGN) as $data) {
                        $users[$data['users_id']] = getUserName($data['users_id']);
                    }
                   //               foreach ($item->getGroups(CommonITILActor::ASSIGN) as $data) {
                   //                  foreach (Group_User::getGroupUsers($data['groups_id']) as $data2) {
                   //                     $users[$data2['id']] = formatUserName($data2["id"], $data2["name"],
                   //                                                           $data2["realname"], $data2["firstname"]);
                   //                  }
                   //               }
                }
               //            if ($itemtype = 'Ticket') {
               //               $task = new TicketTask();
               //            } else if ($itemtype = 'Problem') {
               //               $task = new ProblemTask();
               //            }
               //            if ($task->getFromDBByCrit(['tickets_id' => $item->fields['id']])) {
               //               $users['users_id'] = getUserName($task->fields['users_id_tech']);
               //               $group_id = $task->fields['groups_id_tech'];
               //               if ($group_id) {
               //                  foreach (Group_User::getGroupUsers($group_id) as $data2) {
               //                     $users[$data2['id']] = formatUserName($data2["id"], $data2["name"],
               //                                                           $data2["realname"], $data2["firstname"]);
               //                  }
               //               }
               //            }
                break;
        }

        asort($users);

        $user_requester = [];
        if (is_a($item, 'CommonITILObject', true)) {
            foreach ($item->getUsers(CommonITILActor::REQUESTER) as $data) {
                $user_requester[$data['users_id']] = getUserName($data['users_id']);
            }
        }
        asort($user_requester);

        echo "<style type='text/css'>
      input.form-control {
          width: auto!important;
          height: auto;
      }</style>";
        echo "<script>
                      function searchavailability(tickets_id) {

                          $('#ajax_loader').show();
                          begin_date = $('[name=\"begin\"]').val();
                          end_date = $('[name=\"end\"]').val();
                          limit = $('[name=\"limitto\"]').val();
                          
                          $.ajax({
                             url: '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/planningcheck.php',
                                type: 'POST',
                                data:
                                  {
                                    tickets_id: tickets_id,
                                    itemtype: 'Ticket',
                                    begin: begin_date,
                                    end: end_date,
                                    limitto: limit,
                                  },
                                success: function(response){
                                    $('#response').html(response);
                                    $('#ajax_loader').hide();
    
                                 },
                                error: function(xhr, status, error) {
                                   console.log(xhr);
                                   console.log(status);
                                   console.log(error);
                                 } 
                             });
                       };
                     </script>";


        echo "<div id='response'>\n";
        echo "<div class='center'><form method='GET' name='form' action=''>\n";
        echo "<table class='tab_cadre_fixe'>";
        $colspan = 5;
        if (count($users) > 1) {
            $colspan++;
        }
        echo "<tr class='tab_planningcheck center' style='background-color: whitesmoke;'>";
        echo "<td colspan='$colspan'>" . __('Availability') . "</td>";
        echo "</tr>";

        echo "<tr class='tab_planningtitlecheck'>";
        echo "<td>" . __('Start') . "</td>\n";
        echo "<td>";
        Html::showDateField("begin", ['value'      => $begin,
                                    'maybeempty' => false]);
        echo "</td>\n";
        echo "<td>" . __('End') . "</td>\n";
        echo "<td>";
        Html::showDateField("end", ['value'      => $end,
                                  'maybeempty' => false]);
        echo "</td>\n";
        if (count($users) > 1) {
            echo "<td>";
            $data = [0 => __('All')];
            $data += $users;
            Dropdown::showFromArray('limitto', $data, ['width' => '100%',
                                                    'value' => $params['limitto']]);
            echo "</td>";
        }

        echo "<td class='center'>";
        echo Html::hidden($item->getForeignKeyField(), ['value' => $item->getID()]);
        echo Html::hidden('itemtype', ['value' => $item->getType()]);
        echo "<button class='submit btn btn-success' form='' onclick=\"searchavailability(" . $item->getID() . ")\">";
        echo _sx('button', 'Search');
        echo "</button>";
        echo "</td>\n";

        echo "</tr>";
        echo "</table>";

        echo "</div>\n";
        if (($params['limitto'] > 0) && isset($users[$params['limitto']])) {
            $displayuser[$params['limitto']] = $users[$params['limitto']];
        } else {
            $displayuser = $users;
        }

        if (count($displayuser)) {
            foreach ($displayuser as $who => $whoname) {
                $params = [
                'who'      => $who,
                'whogroup' => 0,
                'begin'    => $realbegin,
                'end'      => $realend
                ];

                $interv = [];
                foreach ($CFG_GLPI['planning_types'] as $itemtype) {
                    $interv = array_merge($interv, $itemtype::populatePlanning($params));
                    if (method_exists($itemtype, 'populateNotPlanned')) {
                        $interv = array_merge($interv, $itemtype::populateNotPlanned($params));
                    }
                }

                $range    = "hour";
                $delay    = HOUR_TIMESTAMP;
                $morecols = 1;
                $fasize   = "fa-2x";
                if ($range == "half") {
                    $delay    = HOUR_TIMESTAMP / 2;
                    $morecols = 2;
                    $fasize   = "fa-1x";
                }
                if ($range == "quarter") {
                    $delay    = HOUR_TIMESTAMP / 4;
                    $morecols = 4;
                    $fasize   = "fa-1x";
                }
               // Print Headers
                echo "<br><div class='center'><table class='tab_cadre_fixe'>";
                $colnumber  = 1;
                $plan_begin = explode(":", $CFG_GLPI["planning_begin"]);
                $plan_end   = explode(":", $CFG_GLPI["planning_end"]);
                $begin_hour = intval($plan_begin[0]);
                $end_hour   = intval($plan_end[0]);
                if ($plan_end[1] != 0) {
                    $end_hour++;
                }
                $colsize    = floor((100 - 15) / ($end_hour - $begin_hour));
                $timeheader = '';
                for ($i = $begin_hour; $i < $end_hour; $i++) {
                    $from       = ($i < 10 ? '0' : '') . $i;
                    $timeheader .= "<td width='$colsize%' colspan='$morecols'>" . $from . ":00</td>";
                    $colnumber  += $morecols;
                }

               // Print Headers
                echo "<tr class='tab_planningcheck center' style='background-color: whitesmoke;'><td colspan='$colnumber'>";
                echo $whoname;
                echo "</td></tr>";
                echo "<tr class='tab_planningcheck center'><td width='15%'>&nbsp;</td>";
                echo $timeheader;
                echo "</tr>";

                $day_begin = strtotime($realbegin);
                $day_end   = strtotime($realend);

                for ($time = $day_begin; $time < $day_end; $time += DAY_TIMESTAMP) {
                    $current_day = date('Y-m-d', $time);
                    echo "<tr class='tab_planningcheck'><td>" . Html::convDate($current_day) . "</td>";
                    $begin_quarter = $begin_hour * $morecols;
                    $end_quarter   = $end_hour * $morecols;
                    for ($i = $begin_quarter; $i < $end_quarter; $i++) {
                        $begin_time = date("Y-m-d H:i:s", strtotime($current_day) + ($i) * $delay);
                        $end_time   = date("Y-m-d H:i:s", strtotime($current_day) + ($i + 1) * $delay);
                       // Init activity interval
                        $begin_act = $end_time;
                        $end_act   = $begin_time;

                        reset($interv);
                        while ($data = current($interv)) {
                            if (($data["begin"] >= $begin_time)
                             && ($data["end"] <= $end_time)) {
                             // In
                                if ($begin_act > $data["begin"]) {
                                    $begin_act = $data["begin"];
                                }
                                if ($end_act < $data["end"]) {
                                    $end_act = $data["end"];
                                }
                                unset($interv[key($interv)]);
                            } elseif (($data["begin"] < $begin_time)
                                && ($data["end"] > $end_time)) {
                            // Through
                                $begin_act = $begin_time;
                                $end_act   = $end_time;
                                next($interv);
                            } elseif (($data["begin"] >= $begin_time)
                                && ($data["begin"] < $end_time)) {
                            // Begin
                                if ($begin_act > $data["begin"]) {
                                    $begin_act = $data["begin"];
                                }
                                $end_act = $end_time;
                                next($interv);
                            } elseif (($data["end"] > $begin_time)
                                && ($data["end"] <= $end_time)) {
                            //End
                                $begin_act = $begin_time;
                                if ($end_act < $data["end"]) {
                                    $end_act = $data["end"];
                                }
                                unset($interv[key($interv)]);
                            } else { // Default case
                                next($interv);
                            }
                        }
                        if ($begin_act < $end_act) {
                            if (($begin_act <= $begin_time)
                            && ($end_act >= $end_time)) {
                                // Activity in quarter
                                echo "<td class='notavailablecheck'>&nbsp;</td>";
                            } else {
                               // Not all the quarter
                                if ($begin_act <= $begin_time) {
                                    echo "<td class='partialavailableend'>&nbsp;</td>";
                                } else {
                                    echo "<td class='partialavailablebegin'>&nbsp;</td>";
                                }
                            }
                        } else {
                            if ($begin_time < $_SESSION["glpi_currenttime"] || self::isWeekend($begin_time, true)) {
                                echo "<td class='notavailablecheck'>&nbsp;</td>";
                            } else {
                                $users_id_requester = 0;
                               // No activity
                                foreach ($user_requester as $who_requester => $whoname_requester) {
                                    $users_id_requester = $who_requester;
                                }
                                echo "<td class='availablecheck center'>";
                                $form  = PLUGIN_SERVICECATALOG_WEBDIR . "/front/planning.php?addappointment=1";
                                $msg   = __('Do you confirm the appointment ?', 'servicecatalog');
                                $msg   .= "<br><br>";
                                $whois = $whoname_requester;
                                if (isset($_SESSION["glpiactiveprofile"]["interface"])
                                && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
                                    $whois = $whoname;
                                }
                                $msg .= __('Appointment with', 'servicecatalog') . "&nbsp;" . $whois;
                                $msg .= "<br><br>";
                                $msg .= __('The', 'servicecatalog') . "&nbsp;" . Html::convDateTime($end_act) . " / " . Html::convDateTime($begin_act);
                                echo Html::getSimpleForm(
                                    $form,
                                    'addappointment',
                                    __('Add a appointment', 'servicecatalog'),
                                    ["itemtype"           => 'Ticket',
                                                  "items_id"           => $item->getID(),
                                                  "users_id_requester" => $users_id_requester,
                                                  "users_id_tech"      => $who,
                                                  "begin"              => $end_act,
                                                  "end"                => $begin_act
                                                 ],
                                    "fa-map-marker-alt $fasize fa-white pointer",
                                    "",
                                    Glpi\RichText\RichText::getTextFromHtml($msg)
                                );
                                echo "</td>";
                            }
                        }
                    }
                    echo "</tr>";
                }
                echo "<tr class='tab_planningcheck' style='background-color: whitesmoke;'><td colspan='$colnumber'>&nbsp;</td></tr>";
                echo "</table></div>";
            }
        }

        echo "</div><br>";
    }

   /**
    * @param $params
    */
    static function addAppointment($params)
    {

        $appoint                     = new self();
        $input                       = [];
        $input['users_id']           = Session::getLoginUserID();
        $input['content']            = __('Appointment added by', 'servicecatalog') . " " . getUserName($input['users_id']);
        $input['tickets_id']         = $params["items_id"];
        $input['users_id_requester'] = $params["users_id_requester"];
        $input['users_id_tech']      = $params["users_id_tech"];
        $input['plan']['begin']      = $params["begin"];
        $input['plan']['end']        = $params["end"];

        $appoint->add($input);
    }


    function prepareInputForAdd($input)
    {

        if (empty($input['content'])) {
            Session::addMessageAfterRedirect(
                __("You can't add a appointment without description.", 'servicecatalog'),
                false,
                ERROR
            );
            return false;
        }

        if (!isset($input['uuid'])) {
            $input['uuid'] = Uuid::uuid4();
        }

        Toolbox::manageBeginAndEndPlanDates($input['plan']);

        if (isset($input["plan"])) {
            $input["begin"] = $input['plan']["begin"];
            $input["end"]   = $input['plan']["end"];

            $timestart           = strtotime($input["begin"]);
            $timeend             = strtotime($input["end"]);
            $input["actiontime"] = $timeend - $timestart;

            unset($input["plan"]);
            if (!$this->test_valid_date($input)) {
                Session::addMessageAfterRedirect(
                    __('Error in entering dates. The starting date is later than the ending date'),
                    false,
                    ERROR
                );
                return false;
            }
        }

        $input["_job"] = new Ticket();

        if (!$input["_job"]->getFromDB($input[$input["_job"]->getForeignKeyField()])) {
            return false;
        }

       // Pass old assign From object in case of assign change
        if (isset($input["_old_assign"])) {
            $input["_job"]->fields["_old_assign"] = $input["_old_assign"];
        }

        if (!isset($input["users_id"])
          && ($uid = Session::getLoginUserID())) {
            $input["users_id"] = $uid;
        }

        if (!isset($input["date"])) {
            $input["date"] = $_SESSION["glpi_currenttime"];
        }

        $input['timeline_position'] = CommonITILObject::TIMELINE_LEFT;

        return $input;
    }

    function post_addItem()
    {
        global $CFG_GLPI;

        if ($CFG_GLPI["notifications_mailing"]) {
            NotificationEvent::raiseEvent('newappointement', $this);
        }

       // Add log entry in the ITIL object
        $changes = [
         0,
         '',
         $this->fields['id'],
        ];
        Log::history(
            $this->getField($this->input["_job"]->getForeignKeyField()),
            $this->input["_job"]->getType(),
            $changes,
            $this->getType(),
            Log::HISTORY_ADD_SUBITEM
        );
    }

   /**
    * Actions done before the DELETE of the item in the database /
    * Maybe used to add another check for deletion
    *
    * @return bool : true if item need to be deleted else false
    **/
    function pre_deleteItem()
    {
        global $CFG_GLPI;

        if ($CFG_GLPI["notifications_mailing"]
          && isset($this->input['_purge'])
        ) {
            NotificationEvent::raiseEvent("cancelappointement", $this);
        }

        return true;
    }

   /**
    * @param $params
    */
    static function deleteAppointment($params)
    {

        $appoint     = new self();
        $input['id'] = $params["id"];

        $appoint->delete($input, true);
    }

    function post_deleteFromDB()
    {

        $itemtype = new Ticket();
        $item     = new $itemtype();
        $item->getFromDB($this->fields[$item->getForeignKeyField()]);

       // Add log entry in the ITIL object
        $changes = [
         0,
         '',
         $this->fields['id'],
        ];
        Log::history(
            $this->getField($item->getForeignKeyField()),
            "Ticket",
            $changes,
            $this->getType(),
            Log::HISTORY_DELETE_SUBITEM
        );
    }

   /**
    * @param $params
    */
    static function chekIfAppointmentExists($params)
    {

        $appoint = new self();
        $appoint->getFromDBByCrit(["tickets_id" => $params["tickets_id"],
                                 "begin"      => [">", $_SESSION["glpi_currenttime"]]]);
        if (count($appoint->fields) > 0) {
            return ($appoint->fields);
        }
        return false;
    }

    static function addToTimeline($options)
    {

        $appClass = 'PluginServicecatalogTicketAppointment';
        $app_obj  = new $appClass;
        $item     = $options['item'];
        if ($app_obj->canview()) {
            if (isset($item->fields['id']) && $item->fields['id'] > 0) {
                $apps = $app_obj->find(['tickets_id' => $item->fields['id']], ['date DESC', 'id DESC']);

                foreach ($apps as $apps_id => $app) {
                    $app_obj->getFromDB($apps_id);
                    $app['can_edit']                                        = false;
                    $options['timeline'][$app['date'] . "_app_" . $apps_id] = ['type'     => $appClass,
                                                                          'item'     => $app,
                                                                          'itiltype' => 'Appointment'];
                }
            }
        }
        $timeline = $options['timeline'];

        return $timeline;
    }
}
