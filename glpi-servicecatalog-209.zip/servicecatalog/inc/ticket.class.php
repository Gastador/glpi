<?php
/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogTicket
 */
class PluginServicecatalogTicket extends CommonDBTM
{
    public static $rightname = 'plugin_servicecatalog';

    const NBCOLUMNS = 14;
    const ID_PRIORITY = 0;
    const DATE = 1;
    const REQUESTER = 2;
    const STATUS = 3;
    const ITEM = 4;
    const TITLE = 5;
    const ID = 6;
    const PRIORITY = 7;
    const CATEGORY = 8;
    const TYPE = 9;
    const ASSIGNED = 10;
    const TTR = 11;
    const ENTITY = 12;
    const ASSIGNED_TECH = 13;

    public static function customtabs($params)
    {
        if (Session::getCurrentInterface() != "central") {
            unset($params['item']['KnowbaseItem_Item$1']);
            unset($params['item']['Ticket$4']);
            unset($params['item']['Item_Ticket$1']);
            unset($params['item']['Log$1']);
        }
        return $params['item'];
    }

    /**
     * @param \Ticket $ticket
     */
    public static function emptyTicket(Ticket $ticket)
    {
        if (isset($_REQUEST['tickets_id'])
            && $_REQUEST['tickets_id'] == 0) {
            if (Session::haveRight('plugin_servicecatalog', READ)) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
        }
    }

    /**
     * @param $params
     *
     * @throws \GlpitestSQLError
     */
    //   static function showTopMenuTitle($params, $config) {
    //
    //      if ($config->getDisplayTopMenu()) {
    //
    //         $manage_favorites = $params['manage_favorites'] ?? 0;
    //         $config           = new PluginServicecatalogConfig();
    //         if ($config->getLayout() != PluginServicecatalogConfig::BOOTSTRAPPED
    //             && $config->getLayout() != PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
    //            echo "<div id='plugin_servicecatalog_searchBar'>";
    //         }
    //
    //         $title = '';
    //         //            if ($manage_favorites == 0
    //         //                && (Ticket::INCIDENT_TYPE == $params['type'] || Ticket::DEMAND_TYPE == $params['type'])) {
    //         //                if ($params['type'] == Ticket::DEMAND_TYPE) {
    //         //                    $title = PluginServicecatalogConfig::displayField($config, 'title_searchbar_request');
    //         //                } else {
    //         //                    $title = PluginServicecatalogConfig::displayField($config, 'title_searchbar_incident');
    //         //                }
    //         //            }
    //
    //         echo "<div id='ajax_loader' class='ajax_loader hidden'></div>";
    //
    //         //            PluginServicecatalogMain::showTopMenu($config, $params['type'], $title, $manage_favorites, $params['from_ticket'], $params['category_id']);
    //         if ($config->getLayout() != PluginServicecatalogConfig::BOOTSTRAPPED
    //             && $config->getLayout() != PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
    //            echo "</div>";
    //         }
    //      }
    //   }


    public static function launchTicketForm($params)
    {
        if (!Ticket::canCreate()) {
            return false;
        }

        if (!isset($params['type'])) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }
        $config = new PluginServicecatalogConfig();

        if ($config->getDemoMode() == 1) {
            echo "<div class='alert alert-warning demo alert-dismissible' role='alert'>";
            echo "<a href='#' class='close' data-bs-dismiss='alert' aria-label='close'>&times;</a>";
            $config->showTicketWizardSelector();
            echo "</div>";
            echo Html::scriptBlock('$(document).ready(function() {
                    setTimeout(function() {
                        $(".demo").alert("close");
                    }, 10000);
                    });');
        }

        $itil_category = new ITILCategory();
        if ($config->getBypassCategories() == 0) {
            if (!isset($params['category_id'])) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
            if (!$itil_category->getFromDB($params['category_id'])) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
        } else {
            $params['category_id'] = 0;
        }
        //Prevent direct access to page
        $config = new PluginServicecatalogConfig();
        if ($config->getEnableGroupRestriction() == 1) {
            $disabled = PluginServicecatalogCategory::getDisabledCategory($params['type'], $params['category_id']);
            if ($disabled == 1) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
        }
        if ($config->getBypassCategories() == 0) {
            $sons = count(PluginServicecatalogCategory::getSons($params['category_id'], $params['type']));
            if ($sons > 0) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
            if ($itil_category->getFromDB($params['category_id'])
                && $itil_category->fields['is_request'] == 0
                && $params['type'] == Ticket::DEMAND_TYPE) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
            if ($itil_category->getFromDB($params['category_id'])
                && $itil_category->fields['is_incident'] == 0
                && $params['type'] == Ticket::INCIDENT_TYPE) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
        }
        echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/bootstrap/sc_bootstrap_new.scss");
        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/servicecatalog_create_ticket.css");

        PluginServicecatalogConfig::loadForLayout();

        if (Plugin::isPluginActive('mydashboard')) {
            $style = "border: solid #E6DCDC 1px;background: white;";

            echo Html::script(PLUGIN_MYDASHBOARD_NOTFULL_DIR . "/lib/jquery-advanced-news-ticker/jquery.newsTicker.min.js");

            echo "<div id='content' class='sc-content'>";
            echo '<style type="text/css">
                    #gs4 #display-sc #nt_alert-container::before,
                    #gs5 #display-sc #nt_maint-container::before,
                    #gs6 #display-sc #nt_info-container::before
                     {
                      margin-left: 25px;!important;
                    }
                </style>';
            $class = "col-md-12";
            if (Plugin::isPluginActive('mydashboard')
                && method_exists("PluginMydashboardWidget", "getWidgetMydashboardAlert")) {
                //                $cats   = [];
                //                $id     = PluginServicecatalogCategory::getUsedConfig("inherit_alert", $params['category_id'], "itilcategories_id");
                $cats[] = $params['category_id'];
                $cats = array_filter($cats);
                $cats = array_diff($cats, [-1]);
                if (PluginMydashboardAlert::countForAlerts(0, 0, $cats) > 0) {
                    echo PluginMydashboardWidget::getWidgetMydashboardAlert($class, true, $cats, $style);
                    echo "<br>";
                }
            }
            if (Plugin::isPluginActive('mydashboard')
                && method_exists("PluginMydashboardWidget", "getWidgetMydashboardMaintenance")) {
                $cat = [];
                //                $id     = PluginServicecatalogCategory::getUsedConfig("inherit_alert", $params['category_id'], "itilcategories_id");
                $cats[] = $params['category_id'];
                $cats = array_filter($cats);
                $cats = array_diff($cats, [-1]);
                if (PluginMydashboardAlert::countForAlerts(0, 1, $cats) > 0) {
                    echo PluginMydashboardWidget::getWidgetMydashboardMaintenance($class, true, $cats, $style);
                    echo "<br>";
                }
            }

            if (Plugin::isPluginActive('mydashboard')
                && method_exists("PluginMydashboardWidget", "getWidgetMydashboardInformation")) {
                $cats = [];
                //                $id     = PluginServicecatalogCategory::getUsedConfig("inherit_alert", $params['category_id'], "itilcategories_id");
                $cats[] = $params['category_id'];
                $cats = array_filter($cats);
                $cats = array_diff($cats, [-1]);
                if (PluginMydashboardAlert::countForAlerts(0, 2, $cats) > 0) {
                    echo PluginMydashboardWidget::getWidgetMydashboardInformation($class, true, $cats, $style);
                    echo "<br>";
                }
            }
            echo "</div>";
        }
        echo "<div class='bt-container'>";
        echo "<div class='bt-block bt-features'>";
        $config = new PluginServicecatalogConfig();
        $seedetail = $config->getDetailBeforeFormRedirect();
        if ($seedetail != 1) {
            //Metademands / formcreator etc..
            $pluglink = PluginServicecatalogPlugin::showLinkCategory($params['type'], $params['category_id']);
            if ($pluglink) {
                Html::redirect($pluglink);
            }
            if ($config->getBypassCategories() == 0) {
                self::showAlreadyOpenedTickets();
            }
        }

        $opt['manage_favorites'] = 0;
        $opt['type'] = $params['type'];
        $opt['category_id'] = $params['category_id'];
        $opt['items_id'] = $params['items_id'] ?? 0;
        $opt['itemtype'] = $params['itemtype'] ?? "";
        $opt['from_ticket'] = 1;


        //show tree categories
        $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($params['type'], $params['category_id'], 0, true);
        $name = $treename['name'];
        $treescript = json_decode($treename['script']);

        echo "<script>$(document).ready(function() {
                          $('#title_cat').show();
                             $('#categories_title').show();
                             document.getElementById('title_cat').innerHTML = \"$name\";
                             let newScript = document.createElement('script');
                             newScript.type = 'text/javascript';
                             let scriptContent = document.createTextNode( $treescript ); 
                             newScript.appendChild( scriptContent ); //add the text node to the newly created div. 
                             document.body.appendChild( newScript ); //add the text node to the newly created div. 
                        });</script>";

        echo "<span id='categories_title' style='display: none'>";
        $alert = "alert-secondary";
        $style = 'style="margin-top: 10px;"';
//        if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//            || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//            $alert_hide = "alert-light";
//        }
        if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $style = 'style="border-radius: 1px;margin-top: 10px;"';
        }
        if ($config->getBypassCategories() == 0) {
            echo "<div class='alert $alert' role='alert' $style>";
            echo "<span id='title_cat'>";
            echo "</span>";
            echo "</div>";
        }
        echo "</span>";
        echo "</h5>";

        echo "<h4 class='bt-title-divider full_glpi_policy'>";
        echo "<small>";


        if ($config->seeCategoryDetails()
            && ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR)) {
            $detail = new PluginServicecatalogCategory();
            $id = $params['category_id'];
            if (isset($id)
                && $detail->getFromDBByCategory($id)) {
                if ($detail->fields['comment'] != null ||
                    $detail->fields['service_detail'] != null ||
                    $detail->fields['service_users'] ||
                    $detail->fields['service_ttr'] ||
                    $detail->fields['service_use'] ||
                    $detail->fields['service_supervision'] ||
                    $detail->fields['service_rules']) {
                    echo "<button form='' class='btn btn-info btn-sm' href='#' data-bs-toggle='modal' data-bs-target='#categorydetails$id' title=\"" . __('More informations', 'servicecatalog') . "\"> ";
                    echo __('More informations of this category ? click here', 'servicecatalog');
                    echo "</button>";

                    echo Ajax::createIframeModalWindow(
                        'categorydetails' . $id,
                        PLUGIN_SERVICECATALOG_WEBDIR . "/front/categorydetail.form.php?type=" . $params['type'] . "&category_id=" . $id,
                        ['title' => __('More informations', 'servicecatalog'),
                            'display' => false,
                            'width' => 1050,
                            'height' => 500]
                    );
                }
            }
        }
        echo "</small>";
        echo "</h4>";

        echo "<div class='sc-row-ticket visitedchildbg'>";

        $opt['users_id'] = Session::getLoginUserID();

        if ($config->seeMore()) {
            echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/scripts/seemoredefault.js");
        } else {
            echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/scripts/seemoreafter.js");
        }
        self::showFormHelpdesk($opt);

        echo "</div>";

        if ($config->hideMailFollowup()) {
            echo Html::scriptBlock("$(document).ready(function () {remove_notif();});");
        }

        echo "</div>";
        echo "</div>";
        echo "</div>";
    }

    /**
     * @param $params
     *
     * @throws \GlpitestSQLError
     */
    public static function launchCategoryDetailForm($params)
    {
        if (!Ticket::canCreate()) {
            return false;
        }

        if (!isset($params['type'])) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }
        $config = new PluginServicecatalogConfig();


        $itil_category = new ITILCategory();
        if (!isset($params['category_id'])) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }
        if (!$itil_category->getFromDB($params['category_id'])) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }

        //Prevent direct access to page
        $config = new PluginServicecatalogConfig();
        if ($config->getEnableGroupRestriction() == 1) {
            $disabled = PluginServicecatalogCategory::getDisabledCategory($params['type'], $params['category_id']);
            if ($disabled == 1) {
                Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
            }
        }
        $sons = count(PluginServicecatalogCategory::getSons($params['category_id'], $params['type']));
        if ($sons > 0) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }
        if ($itil_category->getFromDB($params['category_id'])
            && $itil_category->fields['is_request'] == 0
            && $params['type'] == Ticket::DEMAND_TYPE) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }
        if ($itil_category->getFromDB($params['category_id'])
            && $itil_category->fields['is_incident'] == 0
            && $params['type'] == Ticket::INCIDENT_TYPE) {
            Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
        }

        echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/bootstrap/sc_bootstrap_new.scss");
        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/servicecatalog_create_ticket.css");

        PluginServicecatalogConfig::loadForLayout();

        echo "<div class='bt-container'>";
        echo "<div class='bt-block bt-features'>";

        //show tree categories
        $treename = PluginServicecatalogCategory::getTreeCategoryFriendlyName($params['type'], $params['category_id'], 0, true);
        $name = $treename['name'];
        $treescript = json_decode($treename['script']);

        echo "<script>$(document).ready(function() {
                          $('#title_cat').show();
                             $('#categories_title').show();
                             document.getElementById('title_cat').innerHTML = \"$name\";
                             let newScript = document.createElement('script');
                             newScript.type = 'text/javascript';
                             let scriptContent = document.createTextNode( $treescript ); 
                             newScript.appendChild( scriptContent ); //add the text node to the newly created div. 
                             document.body.appendChild( newScript ); //add the text node to the newly created div. 
                        });</script>";

        echo "<span id='categories_title' style='display: none'>";
        $alert = "alert-secondary";
        $style = 'style="margin-top: 10px;"';
//        if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//            || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//            $alert_hide = "alert-light";
//        }
        if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $style = 'style="border-radius: 1px;margin-top: 10px;"';
        }
        if ($config->getBypassCategories() == 0) {
            echo "<div class='alert $alert' role='alert' $style>";
            echo "<span id='title_cat'>";
            echo "</span>";
            echo "</div>";
        }
        echo "</span>";
        echo "</h5>";

        $style = "background: #FFF;max-width: unset;padding:10px;";
        echo "<div id='content' class='details' style='$style'>";

        echo "<div class='col-auto' style='margin-bottom: 10px;'>";
        $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $params['type'] . "&level=1&category_id=" . $params['category_id'];
        $itilcat = new ITILCategory();
        $itilcat->getFromDB($params['category_id']);
        $level = $itilcat->fields['level'];
        $id_parent = $itilcat->fields['itilcategories_id'];
        if (count(PluginServicecatalogCategory::getSons($params['category_id'], $params['type']))) {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $params['type'] . "&level=$level&category_id=" . $params['category_id'] . "&choose_category=$id_parent";
        } else {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $params['type'] . "&level=$level&category_id=" . $id_parent . "&choose_category=0";
        }

        echo "<a href='" . $url."'>";
        echo "<button form='' class='submit btn btn-success float-left'>";
        echo __('Previous', 'servicecatalog') ;
        echo "</button>";
        echo "</a>";

        $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?launch_creation=1&category_id=" . $params['category_id'] . "&type=" . $params['type'];
        echo "<a href='" . $url."'>";
        echo "<button style='float:right;' form='' class='submit btn btn-primary pull-right'>";
        echo PluginServicecatalogConfig::displayField($config, 'title_submit_message_button');
        echo "</button>";
        echo "</a>";
        echo "</div>";

        $detail = new PluginServicecatalogCategory();
        $id = $params['category_id'];
        if (isset($id)
            && $detail->getFromDBByCategory($id)) {

            $rand = mt_rand();
            $picture_detail = PluginServicecatalogCategory::getUsedConfig("inherit_detail", $id, "picture_detail");
            $picture_detail_width = PluginServicecatalogCategory::getUsedConfig("inherit_detail", $id, "picture_detail_width");

            $width = $picture_detail_width.'%';
            if ($picture_detail) {
                echo "<div id='picture$rand' class='center'>";
                echo "<img width='$width' alt=\"" . __s('Picture') . "\" src='" .
                    PluginServicecatalogCategory::getThumbnailURLForPicture($picture_detail) . "'>";
                echo "</div>";
            } else {
                $style = "background: #FFF;max-width: unset;margin-bottom: 10px;";
                $detail->showDetails(['category' => $id], $style);
            }
        }
        echo "</div>";

        echo "</div>";
        echo "</div>";
    }

    /**
     * @param $input
     * @param $config
     *
     * @return mixed
     */
    public static function formatAdditionalPhonesNumber($input, $config)
    {
        $title = __('Phone');
        $content = "";
        if (!empty($input['phone_number']) || !empty($input['other_phone_number'])) {
            $content = "<tr><td colspan='2' style='text-align: center;'>" . PluginServicecatalogConfig::displayField($config, 'title_phone_number') . "</td></tr>";

            if (!empty($input['phone_number'])) {
                $content .= "<tr>";
                $content .= "<td>" . $title . "</td>";
                $content .= "<td>" . $input['phone_number'] . "</td>";
                $content .= "</tr>";
                $title = __('Other');
            } else {
            }
            if (!empty($input['other_phone_number'])) {
                $content .= "<tr>";
                $content .= "<td>" . $title . "</td>";
                $content .= "<td>" . $input['other_phone_number'] . "</td>";
                $content .= "</tr>";
            }
            //         $content          = addslashes($content);
        }
        return $content;
    }


    /**
     * @param $item
     */
    public static function showTicketForm($params)
    {
        //            echo Html::scriptBlock("$('.saved-searches-panel').remove();");
        $item = $params['item'];
        echo Html::scriptBlock("$('.select2-selection--single').css('font-size','12px');");
        echo Html::scriptBlock("$('#service-levels').hide();");
        $canViewMyHardware = Session::haveRight('helpdesk_hardware', pow(2, Ticket::HELPDESK_MY_HARDWARE));
        if (!$canViewMyHardware) {
            echo Html::scriptBlock("$('#items-heading').hide();");
            echo Html::scriptBlock("$('#items').hide();");
        }
        echo Html::scriptBlock("$('#service-levels-heading').hide();");
        echo Html::scriptBlock("$('#service-levels').hide();");
        $config = new PluginServicecatalogConfig();
        if ($config->showLinkedTicketsSimplifiedform() == 0) {
            echo Html::scriptBlock("$('#linked_tickets-heading').hide();");
            echo Html::scriptBlock("$('#linked_tickets').hide();");
        }
        echo Html::scriptBlock("$(\"button[name='delete']\").remove();");

        if ($item->getType() != 'TicketSatisfaction') {
            echo Html::scriptBlock("$(\"button[name='update']\").remove();");
        }
        if (!Session::haveRight(ITILFollowup::$rightname, ITILFollowup::UPDATEMY)) {
            echo Html::scriptBlock("$(\"button[id^='more-actions-']\").remove();");
        }
        echo Html::scriptBlock("$(\"select[name='urgency']\").attr('disabled', 'disabled');");
        echo Html::scriptBlock("$(\"select[name='itilcategories_id']\").attr('disabled', 'disabled');");
    }


    /**
     * show actor add div
     *
     * @param $type         string   actor type
     *
     * @return void|boolean Nothing if displayed, false if not applicable
     */
    public function showActorAddForm($type)
    {
        $rand_type = mt_rand();
        $entities_id = $_SESSION['glpiactive_entity'];
        $types = ['user' => User::getTypeName(1)];

        $withgroup = false;
        if (Session::getCurrentInterface() == "central") {
            $withgroup = true;
        }
        if ($withgroup) {
            $types['group'] = Group::getTypeName(1);
        }

        $typename = Ticket::getActorFieldNameType($type);

        echo "<div id='itilactor$rand_type' class='actor-dropdown'>";
        $rand = Dropdown::showFromArray(
            "_itil_" . $typename . "[_type]",
            $types,
            ['display_emptychoice' => true]
        );
        $params = ['type' => '__VALUE__',
            'actortype' => $typename,
            'itemtype' => 'Ticket',
            'allow_email' => (($type == CommonITILActor::OBSERVER)
                || $type == CommonITILActor::REQUESTER),
            'entity_restrict' => $entities_id,
            'use_notif' => Entity::getUsedConfig('is_notif_enable_default', $entities_id, '', 1)];

        Ajax::updateItemOnSelectEvent(
            "dropdown__itil_" . $typename . "[_type]$rand",
            "showitilactor" . $typename . "_$rand",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/dropdownItilActors.php",
            $params
        );
        echo "<span id='showitilactor" . $typename . "_$rand' class='actor-dropdown'>&nbsp;</span>";

        echo "</div>";
    }

    /**
     * @param $name
     *
     * @return mixed
     */
    public static function escapeTabName($name)
    {
        $name = str_replace("$", "\\\\$", $name);
        return $name;
    }

    /**
     * @param $item
     */
    public function showSummary($item)
    {
        if (isset($item->fields['id'])) {
            $validation = new TicketValidation();
            $dbu = new DbUtils();
            $datas = $dbu->getAllDataFromTable($validation->getTable(), ["tickets_id" => $item->fields['id']]);
            $number = sizeof($datas);
        }

        if ($number) {
            foreach ($datas as $data) {
                $rand = mt_rand();
                if ($data["users_id_validate"] == Session::getLoginUserID()
                    //                && $data['status'] == CommonITILValidation::WAITING
                ) {
                    $this->showValidationForm($rand, $data["id"], ['parent' => $item->fields['id']]);
                }
            }
        } else {
            echo "<br>";
            echo "<br>";
            echo "<div class=\"form-group center\">";
            echo "<label class=\"center bt-col-md-12\">";
            echo __('Not subject to approval');
            echo "</label>";
            echo "</div>";
        }
    }

    /**
     * Print the validation form
     *
     * @param $rand
     * @param $ID        integer  ID of the item
     * @param $options   array    options used
     *
     *
     * @return bool
     */
    public function showValidationForm($rand, $ID, $options = [])
    {
        $dbu = new DbUtils();
        $options['colspan'] = 1;
        $options['candel'] = false;
        $options['formtitle'] = '';
        $options['formoptions'] = "id='formvalidation$rand'";

        $validation = new TicketValidation();

        $validation->initForm($ID, $options);
        $validation->showFormHeader($options);

        $validator = ($validation->fields["users_id_validate"] == Session::getLoginUserID());


        if ($validator) {
            if ($validation->fields["status"] == CommonITILValidation::WAITING) {
                echo "<div class=\"form-group left\">";
                echo "<label class=\"b bt-col-md-3\">";
                echo __('Approval requester');
                echo "</label>";
                echo "<div class=\"bt-col-md-3\">";
                echo $dbu->getUserName($validation->fields["users_id"]);
                echo "</div>";

                echo "<label class=\"b bt-col-md-3\">";
                echo __('Approver');
                echo "</label>";
                echo "<div class=\"bt-col-md-3\">";
                echo $dbu->getUserName($validation->fields["users_id_validate"]);
                echo "</div>";
                echo "</div>";
                //            echo "<br>";
                //            echo "<br>";

                echo "<div class=\"form-group center\">";
                echo "<label class=\"b center bt-col-md-12\">";
                if (!empty($validation->fields["comment_submission"])) {
                    echo $validation->fields["comment_submission"];
                } else {
                    echo __('Do you approve this ticket ?', 'servicecatalog');
                }
                echo "</label>";
                echo "</div>";
                echo "<div class=\"form-group center\">";
                //            echo "<br>";
                echo "<div class=\"bt-col-md-6\">";
                echo "<div style='color:forestgreen'><i id='accept_ticket'  class='question fas fa-check-circle fa-4x'></i><br>" . __('Accept ticket', 'servicecatalog') . "</div>";
                echo Html::hidden('accept_ticket', ['value' => 0]);
                echo "</div>";
                echo "<div class=\"bt-col-md-6\">";
                echo "<div style='color:darkred'><i id='refuse_ticket' class='question fas fa-times-circle fa-4x'></i><br>" . __('Refuse ticket', 'servicecatalog') . "</div>";
                echo Html::hidden('refuse_ticket', ['value' => 0]);
                echo Html::hidden('validation_date', ['value' => date('Y-m-d H:i:s')]);
                echo Html::hidden('id', ['value' => $validation->fields['id']]);
                echo "</div>";

                echo "</div>";
                //            echo "<br>";
                //            echo "<br>";
                echo "<script>$('#accept_ticket').click(function() {
                                 var form
                                $( '#formvalidation$rand' ).append('<input type=\'hidden\' name=\'accept_ticket\' value=\'1\' />');
                                $( '#formvalidation$rand' ).append('<input type=\'hidden\' name=\'status\' value=\'3\' />');
                                $( '#formvalidation$rand' ).append('<input type=\'hidden\' name=\'update\' value=\'1\' />');
                                $( '#formvalidation$rand' ).submit();
                              });
                              $('#refuse_ticket').click(function() {
                                $( '#formvalidation$rand' ).append('<input type=\'hidden\' name=\'refuse_ticket\' value=\'1\' />');
                                $( '#formvalidation$rand' ).append('<input type=\'hidden\' name=\'status\' value=\'4\' />');
                                $( '#formvalidation$rand' ).append('<input type=\'hidden\' name=\'update\' value=\'1\' />');
                                $( '#formvalidation$rand' ).submit();
                              });";
                echo "</script>";
            } else {
                $style = " ";
                if ($validation->fields["status"] == CommonITILValidation::ACCEPTED) {
                    $style = "validation_validated";
                } elseif ($validation->fields["status"] == CommonITILValidation::REFUSED) {
                    $style = "validation_refused";
                }

                echo "<div class=\"form-group center $style\">";

                echo "<div class=\"center bt-col-md-2\" style='margin: 15px;'>";
                if ($validation->fields["status"] == CommonITILValidation::ACCEPTED) {
                    echo "<div style='color:forestgreen'><i class='fas fa-check-circle fa-4x'></i></div>";
                } else {
                    echo "<div style='color:darkred'><i class='fas fa-times-circle fa-4x'></i></div>";
                }

                echo "<label><br>";
                echo CommonITILValidation::getStatus($validation->fields["status"]);
                echo "&nbsp;(";
                echo Html::convDateTime($validation->fields["validation_date"]);
                echo ")</label>";
                echo "</div>";

                echo "<div class=\"center bt-col-md-8\" style='margin: 15px;'>";

                echo "<div class=''>";
                echo "<label class=\"b left bt-col-md-4\">";
                echo __('Approval requester');
                echo "</label>";
                echo "<label class=\"left bt-col-md-6\">";
                echo $dbu->getUserName($validation->fields["users_id"]);
                echo "</label>";
                echo "</div>";

                echo "<div class=''>";
                echo "<label class=\"b left bt-col-md-4\">";
                echo __('Approver');
                echo "</label>";
                echo "<label class=\"left bt-col-md-6\">";
                echo $dbu->getUserName($validation->fields["users_id_validate"]);
                echo "</label>";
                echo "</div>";

                if (!empty($validation->fields["comment_validation"])) {
                    echo "<div class=''>";
                    echo "<label class=\"b left bt-col-md-4\">";
                    echo __('Comments');
                    echo "</label>";
                    echo "<label class=\"left bt-col-md-6\">";
                    echo $validation->fields["comment_validation"];
                    echo "</label>";
                    echo "</div>";
                }
                echo "</div>";
            }
        }
        if ($ID > 0) {
            if ($validator && $validation->fields["status"] == CommonITILValidation::WAITING) {
                echo "<div class=\"form-group left\">";
                echo "<label class=\"b bt-col-md-2\">";
                echo __('Approval comments') . "<br>(" . __('Optional when approved');
                echo ")</label>";
                echo "<div class=\"bt-col-md-9\">";
                Html::textarea(['name' => 'comment_validation',
                    'value' => $validation->fields['comment_validation'],
                    'cols' => 110,
                    'rows' => 6,
                    'enable_richtext' => false]);
                echo "</div>";
                echo "</div>";
            }
        }

        $options['formfooter'] = '';
        $options['colspan'] = 1;
        $options['canedit'] = false;
        $validation->showFormButtons($options);
        Html::closeForm();
        return true;
    }


    public static function showAlreadyOpenedTickets()
    {
        global $CFG_GLPI;

        $type = $_GET['type'];
        $itilcategories_id = $_GET['category_id'];
        $left = "LEFT JOIN glpi_entities 
                  ON (`glpi_tickets`.`entities_id` = `glpi_entities`.`id`) ";
        $left .= "LEFT JOIN `glpi_tickets_users`
                          ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id` AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "') ";
        $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

        $search_request = "  `glpi_tickets_users`.`users_id` = " . Session::getLoginUserID() . " ";

        if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)
            && count($_SESSION['glpigroups'])) {
            $left .= "LEFT JOIN `glpi_groups_tickets`
                          ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id` AND `glpi_groups_tickets`.`type` = '" . CommonITILActor::REQUESTER . "') ";
            $groups = implode("','", $_SESSION['glpigroups']);
            $search_request .= " OR (`glpi_groups_tickets`.`groups_id` IN ('" . $groups . "'))";
        }
        //not resolved incidents
        $total_tickets = PluginServicecatalogIndicator::queryGroupUserTickets($type, $left, $is_deleted, $search_request, $itilcategories_id);

        if ($total_tickets > 0) {
            $warnings = sprintf(__('You have already opened %s', 'servicecatalog'), $total_tickets);
            if ($total_tickets == 1) {
                $warnings .= " " . strtolower(__('ticket'));
            } else {
                $warnings .= " " . strtolower(__('tickets'));
            }
            $warnings .= " " . __('for this category', 'servicecatalog');

            echo "<div class='center alert alert-warning alert-dismissible fade show' role='alert'>";
            echo "<a href='#' class='close' data-bs-dismiss='alert' aria-label='close'>&times;</a>";
            echo "<i class='fas fa-exclamation-triangle fa-2x'></i>";

            $options['reset'] = 'reset';

            $options['criteria'][0]['criteria'][] = [
                'field' => 4,//requester
                'searchtype' => 'equals',
                'value' => Session::getLoginUserID(),
                'link' => 'AND'
            ];

            if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)
                && count($_SESSION['glpigroups'])) {
                $options['criteria'][0]['criteria'][] = [
                    'field' => 71, // groups_id_requester
                    'searchtype' => 'equals',
                    'value' => 'mygroups',
                    'link' => 'OR',
                ];
            }

            $options['criteria'][] = [
                'field' => 12,//status
                'searchtype' => 'equals',
                'value' => 'notold',
                'link' => 'AND'
            ];

            $options['criteria'][] = [
                'field' => 14, // type
                'searchtype' => 'equals',
                'value' => $type,
                'link' => 'AND',
            ];

            $options['criteria'][] = [
                'field' => 7, // itilcategories_id
                'searchtype' => 'equals',
                'value' => $itilcategories_id,
                'link' => 'AND',
            ];

            echo "<br>";
            echo $warnings;
            echo "<br>";

            if (Session::getCurrentInterface() == "central") {
                $url = $CFG_GLPI["root_doc"] . "/front/ticket.php?" . Toolbox::append_params($options, '&amp;');
            } else {
                $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php?type=" . $type . "&itilcategories_id=" . $itilcategories_id;
            }

            echo "<a target='_blank' href=\"" . $url . "\">";

            if ($total_tickets == 1) {
                echo __('Do you want to see him ?', 'servicecatalog');
            } else {
                echo __('Do you want to see them ?', 'servicecatalog');
            }

            echo "</a>";
            echo "</div>";
        }
    }

    /**
     * Print the helpdesk form
     *
     * @param $params
     *
     * @return bool
     */
    public static function showFormHelpdesk($params)
    {
        global $CFG_GLPI;

        $ticket_template = false;
        $config = new PluginServicecatalogConfig();
        $config->getFromDB(1);
        $widget = new PluginServicecatalogWidget();
        if (!Ticket::canCreate()) {
            return false;
        }
        $type = $params['type'];
        if ($config->getBypassCategories() == 0) {
            $category_id = $params['category_id'];
        } else {
            $category_id = 0;
        }
        $users_id = $params['users_id'];
        $item_id = $params['items_id'];
        $itemtype = $params['itemtype'];

        $ticket = new Ticket();

        $email = UserEmail::getDefaultForUser($users_id);
        $default_use_notif = Entity::getUsedConfig('is_notif_enable_default', $_SESSION['glpiactive_entity'], '', 1);

        $user = new User();
        $user->getFromDB($users_id);
        $default_location = $user->getField('locations_id');
        $default_responsible = $user->getField('users_id_supervisor');
        $force_delegating = 0;
        if ($config->forceDelegating()
            && Session::haveRight("ticket", Ticket::READGROUP)) {
            $force_delegating = 1;
        }
        // Set default values...
        $default_values = ['_users_id_requester_notif'
        => ['use_notification'
            => (($email == "") ? 0 : $default_use_notif)],
            'nodelegate' => 1,
            '_users_id_requester' => 0,
            '_users_id_observer' => [0],
            '_users_id_observer_notif'
            => ['use_notification' => $default_use_notif],
            'name' => '',
            'content' => '',
            'itilcategories_id' => $category_id,
            'locations_id' => $default_location,
            'users_id_supervisor' => $default_responsible,
            'urgency' => 3,
            'phone_number' => '',
            'other_phone_number' => '',
            '_groups_id_requester' => 0,
            'impact' => 3,
            'items_id' => 0,
            'entities_id' => $_SESSION['glpiactive_entity'],
            'plan' => [],
            'global_validation' => CommonITILValidation::NONE,
            '_add_validation' => 0,
            'type' => $type,
            '_right' => "id",
            '_content' => [],
            '_tag_content' => [],
            '_filename' => [],
            '_tag_filename' => []];

        //INFOTEL
        if (Session::getCurrentInterface() == 'central') {
            foreach (PluginServicecatalogTicketTemplate::FIELDS as $field) {
                if (!isset($default_values[PluginServicecatalogTicketTemplate::getFieldName($field)])) {
                    PluginServicecatalogTicketTemplate::getDefaultValue($field, $default_values);
                }
            }
        }

        // Get default values from posted values on reload form
        if (!$ticket_template) {
            if (isset($_POST)) {
                $values = Html::cleanPostForTextArea($_POST);
            }
        }
        // Restore saved value or override with page parameter
        $self = new self();

        $saved = $self->restoreInput();

        foreach ($default_values as $name => $value) {
            if (!isset($values[$name])) {
                if (isset($saved[$name])) {
                    $values[$name] = $saved[$name];
                } else {
                    $values[$name] = $value;
                }
            }
        }

        // Check category / type validity
        if ($values['itilcategories_id']) {
            $cat = new ITILCategory();
            if ($cat->getFromDB($values['itilcategories_id'])) {
                switch ($values['type']) {
                    case Ticket::INCIDENT_TYPE:
                        if (!$cat->getField('is_incident')) {
                            $values['itilcategories_id'] = 0;
                        }
                        break;

                    case Ticket::DEMAND_TYPE:
                        if (!$cat->getField('is_request')) {
                            $values['itilcategories_id'] = 0;
                        }
                        break;

                    default:
                        break;
                }
            }
        }

        $helpdesk_category = new PluginServicecatalogCategory();
        if ($helpdesk_category->getFromDBByCategory($values['itilcategories_id'])
            && !empty($helpdesk_category->fields['display_warning'])) {
            echo "<h5>";
            echo "<div class='alert alert-danger' role='alert'>";
            echo "<i class='fas fa-exclamation-circle fa-2x'></i>";
            echo "&nbsp;" . nl2br(PluginServicecatalogCategory::displayField($helpdesk_category, 'display_warning'));
            echo "</div>";
            echo "</h5>";
        }

        if ($helpdesk_category->getFromDBByCategory($values['itilcategories_id'])
            && !empty($helpdesk_category->fields['knowbaseitems_id'])
        && Session::haveRight('knowbase', KnowbaseItem::READFAQ)) {
            $know_id = $helpdesk_category->fields['knowbaseitems_id'];
            echo "<h5>";
            echo "<div class='alert alert-warning' role='alert'>";
            echo "<i class='fas fa-exclamation-triangle fa-2x'></i>";
            echo "&nbsp;";
            echo __('Did you know that there is an FAQ article that may be able to help you?', 'servicecatalog');
            echo "&nbsp;";
            echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php?from_ticket=1&itilcategories_id=" . $values['itilcategories_id'] . "&type=" . $values['type'] . "&id=" . $know_id . "'>";
            echo "<button form='' class='submit btn btn-info btn-sm'>
<i class='fas fa-link' data-hasqtip='0' aria-hidden='true'></i>";
            echo "&nbsp;";
            echo __('Click here for more informations', 'servicecatalog');
            echo "</button>";
            echo "</a>";
            echo "</div>";
            echo "</h5>";
        }
        $delegating = User::getDelegateGroupsForUser($values['entities_id']);

        if (count($delegating) < 1 || $force_delegating) {
            // User as requester
            $values['_users_id_requester'] = Session::getLoginUserID();

            if ($CFG_GLPI['use_check_pref']) {
                $class = "bt-col-md-12";
                echo PluginServicecatalogPreference::getWidgetPreferences("gs24", $class, true);
            }
        }

        if (!$ticket_template) {
            echo "<form class=\"form-horizontal\" method='post' name='helpdeskform' id='helpdeskform' action='" .
                PLUGIN_SERVICECATALOG_WEBDIR . "/front/tracking.injector.php' enctype='multipart/form-data'>";
            echo "<br>";
        }

        if ($config->getDefaultRequestTemplate() > 0 || $config->getDefaultIncidentTemplate() > 0) {
            if ($values['type'] == Ticket::INCIDENT_TYPE && $config->getDefaultIncidentTemplate() > 0) {
                $idt = $config->getDefaultIncidentTemplate();
                $tt = $ticket->getITILTemplateToUse(
                    $idt,
                    $values['type'],
                    $values['itilcategories_id'],
                    $_SESSION["glpiactive_entity"]
                );
            }
            if ($values['type'] == Ticket::DEMAND_TYPE && $config->getDefaultRequestTemplate() > 0) {
                $idt = $config->getDefaultRequestTemplate();
                $tt = $ticket->getITILTemplateToUse(
                    $idt,
                    $values['type'],
                    $values['itilcategories_id'],
                    $_SESSION["glpiactive_entity"]
                );
            }
        } else {
            // Load ticket template if available :
            $tt = $ticket->getITILTemplateToUse(
                $ticket_template,
                $values['type'],
                $values['itilcategories_id'],
                $_SESSION["glpiactive_entity"]
            );
        }

        // Predefined fields from template : reset them
        if (isset($values['_predefined_fields'])) {
            $values['_predefined_fields'] = Toolbox::decodeArrayFromInput($values['_predefined_fields']);
        } else {
            $values['_predefined_fields'] = [];
        }

        // Store predefined fields to be able not to take into account on change template
        $predefined_fields = [];

        if (isset($tt->predefined) && count($tt->predefined)) {
            foreach ($tt->predefined as $predeffield => $predefvalue) {
                if (isset($values[$predeffield]) && isset($default_values[$predeffield])) {
                    // Is always default value : not set
                    // Set if already predefined field
                    // Set if ticket template change
                    if (((count($values['_predefined_fields']) == 0)
                            && ($values[$predeffield] == $default_values[$predeffield]))
                        || (isset($values['_predefined_fields'][$predeffield])
                            && ($values[$predeffield] == $values['_predefined_fields'][$predeffield]))
                        || (isset($values['_tickettemplates_id'])
                            && ($values['_tickettemplates_id'] != $tt->getID()))
                    ) {
                        if (!isset($saved[$predeffield])) {
                            $values[$predeffield] = $predefvalue;
                        }

                        $predefined_fields[$predeffield] = $predefvalue;
                    }
                } else { // Not defined options set as hidden field
                    echo Html::hidden($predeffield, ['value' => $predefvalue]);
                }
            }
            // All predefined override : add option to say predifined exists
            if (count($predefined_fields) == 0) {
                $predefined_fields['_all_predefined_override'] = 1;
            }
        } else { // No template load : reset predefined values
            if (count($values['_predefined_fields'])) {
                foreach ($values['_predefined_fields'] as $predeffield => $predefvalue) {
                    if ($values[$predeffield] == $predefvalue) {
                        if (!isset($saved[$predeffield])) {
                            $values[$predeffield] = $default_values[$predeffield];
                        }
                    }
                }
            }
        }

        if (($CFG_GLPI['urgency_mask'] == (1 << 3))
            || $tt->isHiddenField('urgency')) {
            // Dont show dropdown if only 1 value enabled or field is hidden
            echo Html::hidden('urgency', ['value' => $values['urgency']]);
        }

        // Display predefined fields if hidden
        if ($tt->isHiddenField('items_id')) {
            if (!empty($values['items_id'])) {
                foreach ($values['items_id'] as $itemtype => $items) {
                    foreach ($items as $items_id) {
                        echo Html::hidden("items_id[$itemtype][$items_id]", ['value' => $items_id]);
                    }
                }
            }
        }
        if ($tt->isHiddenField('locations_id')) {
            echo Html::hidden('locations_id', ['value' => $values['locations_id']]);
        }
        echo Html::hidden('entities_id', ['value' => $_SESSION["glpiactive_entity"]]);

        $use_as_step = $config->getFormDisplayAsStep();
        if ($use_as_step == 0) {
            echo "<div class='row' style='margin-left: 15px;margin-right: 15px'>";
        }

        if ($use_as_step == 0) {
            if (count($delegating) || $force_delegating) {
                echo "<div class=\"form-group col-md-6 borderpanel\">";

                echo "<h5>";
                $alert = "alert-secondary";
                $style = "";
//                if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//                    || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//                    $alert_hide = "alert-light";
//                }
                if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    $style = 'style="border-radius: 1px"';
                }
                echo "<div class='alert $alert' role='alert' $style>";
                $title = PluginServicecatalogConfig::displayField($config, 'title_delegation');
                if (empty($title)) {
                    $title = __('This ticket concerns you', 'servicecatalog');
                    $title .= "&nbsp;?&nbsp;";
                }
                echo $title;
                echo "</div>";
                echo "</h5>";

                echo "<div class=\"\"><i class='ti fa-fw ti-user mx-1'></i>&nbsp;";
                $rand = Dropdown::showYesNo("nodelegate", $values['nodelegate']);
                echo "</div>";

                $right = "helpdesk";
                if ($config->forceDelegatingUsers() == 0) {
                    $right = "all";
                } elseif ($config->forceDelegatingUsers() == 1) {
                    $right = "groups";
                }

                $params = ['nodelegate' => '__VALUE__',
                    'rand' => $rand,
                    '_right' => $right,
                    '_users_id_requester'
                    => $values['_users_id_requester'],
                    '_users_id_requester_notif'
                    => $values['_users_id_requester_notif'],
                    'use_notification'
                    => $values['_users_id_requester_notif']['use_notification'],
                    'entity_restrict'
                    => $_SESSION["glpiactive_entity"],
                    'itilcategories_id'
                    => $values['itilcategories_id']];

                Ajax::updateItemOnSelectEvent(
                    "dropdown_nodelegate" . $rand,
                    "show_result" . $rand,
                    PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/dropdownDelegationUsers.php",
                    $params
                );

                echo "</div>";

                echo "<div class=\"form-group col-md-6\">";
                echo "<div id='show_result$rand'>";
                echo "</div>";
                echo "</div>";

                echo Html::hidden('_users_id_recipient', ['value' => Session::getLoginUserID()]);
            }
        }
        echo Html::hidden('_from_helpdesk', ['value' => 1]);
        echo Html::hidden('requesttypes_id', ['value' => RequestType::getDefault('helpdesk')]);

        $fieldsOrder = new PluginServicecatalogFieldorder();
        $condition = [];
        if ($config->getBypassCategories() == 0) {
            $condition[] = ['NOT' => ['name' => 'itilcategories']];
        }

        if (!PluginServicecatalogTicketTemplate::isFieldActivated($tt, PluginServicecatalogTicketTemplate::FIELD_TIMETORESOLVE)) {
            $condition[] = ['NOT' => ['name' => 'timeToResolve']];
        }

        $force_validation = 0;
        $helpdesk_category = new PluginServicecatalogCategory();
        if ($helpdesk_category->getFromDBByCategory($values['itilcategories_id'])
            && $helpdesk_category->fields["force_validation"] == 1) {
            $force_validation = 1;
        }
        if (!PluginServicecatalogTicketTemplate::isFieldActivated($tt, PluginServicecatalogTicketTemplate::FIELD_VALIDATIONREQUEST)
            || (!Session::haveRight('ticketvalidation', TicketValidation::CREATEINCIDENT)
                && !Session::haveRight('ticketvalidation', TicketValidation::CREATEREQUEST)) || !$force_validation) {
            $condition[] = ['NOT' => ['name' => 'approvalRequest']];
        }
        if (!PluginServicecatalogTicketTemplate::isFieldActivated($tt, PluginServicecatalogTicketTemplate::FIELD_IMPACT)) {
            $condition[] = ['NOT' => ['name' => 'impact']];
        }

        if ($config->forceDelegating() || $config->hideMailFollowup() == 1 || $CFG_GLPI['notifications_mailing'] == 0) {
            $condition[] = ['NOT' => ['name' => 'InformMe']];
        }
        if ($config->getDisplayPhoneNumber() == 0 && $config->IsPhoneNumberMandatory() == 0) {
            $condition[] = ['NOT' => ['name' => 'phonenumber']];
        }
        $cond = getEntitiesRestrictCriteria(Group::getTable(), '', '', true);
        $users_id = $values["_users_id_requester"];
        if ($values["_users_id_requester"] == 0) {
            $users_id = Session::getLoginUserID();
        }

        $group_user_data = Group_User::getUserGroups($users_id, $cond);
        if ($config->getDisplayRequesterGroup() == 0 || count($group_user_data) <= 1) {
            $condition[] = ['NOT' => ['name' => 'requester_group']];
        }
        if ($use_as_step == 1) {
            $condition[] = ['NOT' => ['name' => 'title']];
        }

        if (($_SESSION["glpiactiveprofile"]["helpdesk_hardware"] == 0)
            || (count($_SESSION["glpiactiveprofile"]["helpdesk_item_type"]) == 0)) {
            $condition[] = ['NOT' => ['name' => 'hardwareType']];
        }
        //      $morefields = $config->getFieldsMoreInformations();
        //      foreach ($morefields as $field) {
        //         $condition[] = ['NOT' => ['name' => $field]];
        //      }

        /***TODO**/
        /* Other information bloc ?
        * placeholder description ?
        * display different template on incident or demand ?
        */
        $fields = $fieldsOrder->find($condition, "ranking");

        $i = 0;
        $newfields = [];
        if ($use_as_step == 1 && (count($delegating) || $force_delegating)) {
            $newfields[0] = ['id' => 0,
                'name' => 'use_delegation',
                'ranking' => 0];
            foreach ($fields as $field) {
                $newfields[$field['id']]['id'] = $field['id'];
                $newfields[$field['id']]['name'] = $field['name'];
                $newfields[$field['id']]['ranking'] = $field['ranking'] + 1;
            }
            $fields = $newfields;
        }

        $newfields = [];
        if ($force_validation == 1) {
            foreach ($fields as $field) {
                if ($field['name'] == "approvalRequest") {
                    unset($fields[$field['id']]);
                }
            }
            $newfields[0] = ['id' => 0,
                'name' => 'approvalRequest',
                'ranking' => 0];
            foreach ($fields as $field) {
                $newfields[$field['id']]['id'] = $field['id'];
                $newfields[$field['id']]['name'] = $field['name'];
                $newfields[$field['id']]['ranking'] = $field['ranking'] + 1;
            }
            $fields = $newfields;
        }

        $count = 0;
        $columns = 2;

        foreach ($fields as $field) {
            switch ($field["name"]) {
                case "use_delegation":
                    $fieldglpi = "use_delegation";
                    break;
                case "urgencies":
                    $fieldglpi = "urgency";
                    break;
                case "itilcategories":
                    $fieldglpi = "itilcategories_id";
                    break;
                case "timeToResolve":
                    $fieldglpi = "time_to_resolve";
                    break;
                case "approvalRequest":
                    $fieldglpi = "_add_validation";
                    break;
                case "hardwareType":
                    $fieldglpi = "items_id";
                    break;
                case "location":
                    $fieldglpi = "locations_id";
                    break;
                case "watcher":
                    $fieldglpi = "_users_id_observer";
                    break;
                case "impact":
                    $fieldglpi = "impact";
                    break;
                case "title":
                    $fieldglpi = "name";
                    break;
                case "contentAndFile":
                    $fieldglpi = "content";
                    break;
                case "phonenumber":
                    $fieldglpi = "phonenumber";
                    break;
                case "requester_group":
                    $fieldglpi = "_groups_id_requester";
                    break;
                case "informMe":
                    $fieldglpi = "informMe";
                    break;
            }
            $morefields = $config->getFieldsMoreInformations();
            if (($tt->getMandatoryMark($fieldglpi) && !$tt->isHiddenField($fieldglpi))
                || (!$tt->isHiddenField($fieldglpi) && !in_array($field["name"], $morefields))) {
                if ($use_as_step == 1) {
                    echo "<div class='tab-sc'>";
                }
                self::loadField($field["name"], $tt, $values, $delegating, $morefields, $ticket_template, $item_id, $itemtype, $force_validation);
                $count = $count + $columns;
                $i++;
                $objects = self::getItemsCountForUser($values);
                if ($use_as_step == 1) {
                    echo "</div>";
                } else if ($count > $columns
                    || ($field["name"] == "title"
                        || ($field["name"] == "hardwareType" && count($objects) > 4)
                        || $field["name"] == "contentAndFile")) {
                    echo "</div>";
                    echo "<div class='row' style='margin-left: 15px;margin-right: 15px'>";
                    $count = 0;
                }
            }
        }
        if (Plugin::isPluginActive('fields') && $use_as_step == 1) {
            self::seePluginFields($ticket, $params, 1);
            $i++;
        }

        /***TODO**/
        /* placeholder description ?
        * display different template on incident or demand ?
        */

        if ($use_as_step == 1) {
            $morefields = $config->getFieldsMoreInformations();
            $hiddencondition[] = ['name' => $morefields];
            if (!empty($morefields)) {
                $hiddenfields = $fieldsOrder->find($hiddencondition, "ranking");
                if (count($hiddenfields) > 0) {
                    echo "<div class='tab-sc'>";
                    echo "<div class='form-group center w-75 mx-auto borderpanel'>";
                    echo "<h5>";
                    $alert = "alert-secondary";
                    $style = "";
//                    if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//                        || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//                        $alert_hide = "alert-light";
//                    }
                    if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                        || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                        $style = 'style="border-radius: 1px"';
                    }
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_others_infos');
                    if (empty($title)) {
                        $title = __('Other informations', 'servicecatalog');
                    }
                    echo $title;
                    echo "</div>";
                    echo "</h5>";
                    foreach ($hiddenfields as $hiddenfield) {
                        switch ($hiddenfield["name"]) {
                            case "use_delegation":
                                $fieldglpi = "use_delegation";
                                break;
                            case "urgencies":
                                $fieldglpi = "urgency";
                                break;
                            case "itilcategories":
                                $fieldglpi = "itilcategories_id";
                                break;
                            case "timeToResolve":
                                $fieldglpi = "time_to_resolve";
                                break;
                            case "approvalRequest":
                                $fieldglpi = "_add_validation";
                                break;
                            case "hardwareType":
                                $fieldglpi = "items_id";
                                break;
                            case "location":
                                $fieldglpi = "locations_id";
                                break;
                            case "watcher":
                                $fieldglpi = "_users_id_observer";
                                break;
                            case "impact":
                                $fieldglpi = "impact";
                                break;
                            case "title":
                                $fieldglpi = "name";
                                break;
                            case "contentAndFile":
                                $fieldglpi = "content";
                                break;
                            case "phonenumber":
                                $fieldglpi = "phonenumber";
                                break;
                            case "requester_group":
                                $fieldglpi = "_groups_id_requester";
                                break;
                            case "informMe":
                                $fieldglpi = "informMe";
                                break;
                        }

                        if (!$tt->getMandatoryMark($fieldglpi)
                            && !$tt->isHiddenField($fieldglpi)) {
                            self::loadField($hiddenfield["name"], $tt, $values, $delegating, $morefields, $ticket_template, $item_id, $itemtype, $force_validation);
                        }
                    }
                    $i++;
                    echo "</div>";
                    echo "</div>";
                }
            }
            //      <div class="tab">Name:
            //      <p><input placeholder="First name..." oninput="this.className = \'\'" name="fname"></p>
            //      <p><input placeholder="Last name..." oninput="this.className = \'\'" name="lname"></p>
            //   </div>


            if (!$ticket_template) {
                echo "<div class=\"form-group\">";
                echo "<div class='center'>";
                if ($tt->isField('id') && ($tt->fields['id'] > 0)) {
                    echo Html::hidden('_tickettemplates_id', ['value' => $tt->fields['id']]);
                    echo Html::hidden('_predefined_fields', ['value' => Toolbox::prepareArrayForInput($predefined_fields)]);
                }
                if ($config->getBypassCategories() == 0) {
                    echo Html::hidden('itilcategories_id', ['value' => $category_id]);
                }
                echo Html::hidden('type', ['value' => $type]);
                echo Html::hidden('add', ['value' => 1]);
                echo "<div style='overflow:auto;'>";
                echo "<button type='button' id='prevBtn' class='btn btn-primary ticket-button' onclick='nextPrev(-1)'>";
                echo "<i class='ti ti-chevron-left'></i>&nbsp;" . __('Previous', 'servicecatalog') . "</button>";
                echo "<button type='button' id='nextBtn' class='btn btn-primary ticket-button' onclick='nextPrev(1)'>";
                echo __('Next', 'servicecatalog') . "&nbsp;<i class='ti ti-chevron-right'></i></button>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "<br>";
            }


            //Circles which indicates the steps of the form:
            echo "<div style='text-align:center;margin-top:40px;'>";

            for ($j = 1; $j <= $i; $j++) {
                echo "<span class='step'></span>";
            }
            echo "</div>";

            $nexttitle = __('Next', 'servicecatalog') . "&nbsp;<i class=\"ti ti-chevron-right\"></i>";
            $submittitle = "<i class=\"ti ti-save\"></i>&nbsp;" . PluginServicecatalogConfig::displayField($config, 'title_submit_message_button');

            echo "<script>
                  var nexttitle = '$nexttitle';
                  var submittitle = '$submittitle';
                  var currentTab = 0; // Current tab is set to be the first tab (0)
                  showTab(currentTab, nexttitle, submittitle); // Display the current tab
                  
                  function showTab(n) {
                     // This function will display the specified tab of the form...
                     var x = document.getElementsByClassName('tab-sc');
                     x[n].style.display = 'block';
                     //... and fix the Previous/Next buttons:
                     if (n == 0) {
                        document.getElementById('prevBtn').style.display = 'none';
                     } else {
                        document.getElementById('prevBtn').style.display = 'inline';
                     }
                     if (n == (x.length - 1)) {
                        document.getElementById('nextBtn').innerHTML = submittitle;
                     } else {
                        document.getElementById('nextBtn').innerHTML = nexttitle;
                     }
                     //... and run a function that will display the correct step indicator:
                     fixStepIndicator(n)
                  }
               
                  function nextPrev(n) {
                     // This function will figure out which tab to display
                     var x = document.getElementsByClassName('tab-sc');
                     // Exit the function if any field in the current tab is invalid:
                     if (n == 1 && !validateForm()) return false;
                     // Hide the current tab:
                     x[currentTab].style.display = 'none';
                     // Increase or decrease the current tab by 1:
                     currentTab = currentTab + n;
                     // if you have reached the end of the form...
                     if (currentTab >= x.length) {
                        // ... the form gets submitted:
                        document.getElementById('helpdeskform').submit();
                        return false;
                     }
                     // Otherwise, display the correct tab:
                     showTab(currentTab);
                  }
               
                  function validateForm() {
                     // This function deals with validation of the form fields
                     var x, y, i, valid = true;
                     x = document.getElementsByClassName('tab-sc');
                     y = x[currentTab].getElementsByTagName('input');
                     z = x[currentTab].getElementsByTagName('select');
                     // A loop that checks every input field in the current tab:
                     var ko = 0;
                     for (i = 0; i < y.length; i++) {
                        // If a field is empty...
                        fieldname = y[i].name;
                        fieldmandatory = y[i].required;
                        if (fieldname != 'other_phone_number' 
                               && fieldname != '_users_id_requester_notif[alternative_email][]'
                               && fieldname != '_users_id_observer_notif[alternative_email][]'
                                 && fieldname != '_uploader_filename[]'
                                    && fieldname != '_uploader_content[]') {
                           if (y[i].value == '' && fieldmandatory == true) {
                              // add an 'invalid' class to the field:
                              y[i].className += ' invalid';
                              // and set the current valid status to false
                              valid = false;
                           }
                        }
                        if (y[i].name == 'my_items' && y[i].type == 'radio') {
                           if (y[i].checked == false) {
                              ko += 1;
                              y[i].className += ' invalid';
                           }
                           if (y[i].checked == true) {
                              ko -= 1;
                           }
                        }
                     }
                     //for select
                     if (z.length > 0) {
                        for (i = 0; i < z.length; i++) {
                           fieldmandatory = z[i].required;
                           // If a field is empty...
                           var fieldname = z[i].name;
                           if (z[i].value == 0 && fieldmandatory == true && fieldname != '_users_id_requester_notif[alternative_email][]'
                               && fieldname != '_users_id_observer_notif[alternative_email][]'
                               && fieldname != '_users_id_requester_notif[use_notification][]'
                               && fieldname != '_users_id_observer_notif[use_notification][]') {
                              // add an 'invalid' class to the field:
                              var res = $('[name=\"' + fieldname + '\"]').closest('[bloc-id]').css('display');
                              if (res != 'none') {
                                 $('[name=\"' + fieldname + '\"]').addClass('invalid');
//                                 $('[name=\"' + fieldname + '\"]').attr('required', 'required');
                                 $('[for=\"' + fieldname + '\"]').css('color', 'red');
                                 ko++;
                              } else {
                                 $('[name=\"' + fieldname + '\"]').removeClass('invalid');
//                                 $('[name=\"' + fieldname + '\"]').removeAttr('required');
                                 $('[for=\"' + fieldname + '\"]').css('color', 'unset');
                              }
                  
                           } else {
                              z[i].classList.remove('invalid');
                           }
                        }
                     }
                     tinyMCE.triggerSave();
                     if (ko > 0 && ko >= y.length) {
                         valid = false;
                         var tooltip = document.querySelector('.alertelt');
                         tooltip.classList.add('active');
                     }
                     // If the valid status is true, mark the step as finished and valid:
                     if (valid) {
                        document.getElementsByClassName('step')[currentTab].className += ' finish';
                     }
                     return valid; // return the valid status
                  }
               
                  function fixStepIndicator(n) {
                     // This function removes the 'active' class of all steps...
                     var i, x = document.getElementsByClassName('step');
                     for (i = 0; i < x.length; i++) {
                        x[i].className = x[i].className.replace(' active', '');
                     }
                     //... and adds the 'active' class on the current step:
                     x[n].className += ' active';
                  }
               </script>";
        } else {
            self::seePluginFields($ticket, $params, false);

//            echo "<br>";

            echo "<div id='flip' class='pointer form-group col-md-12'>";

            $class = "fa-caret-right";
            if ($config->seeMore()) {
                $class = "fa-caret-down";
            }
            echo "<h5>";
            $alert = "alert-secondary";
            $style = "";
//            if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//                || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//                $alert_hide = "alert-light";
//            }
            if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                $style = 'style="border-radius: 1px"';
            }
            echo "<div class='alert $alert' role='alert' $style>";
            echo "<i class=\"fas $class flipper-info\"></i>&nbsp;";
            $title = PluginServicecatalogConfig::displayField($config, 'title_others_infos');
            if (empty($title)) {
                $title = __('Other informations', 'servicecatalog');
            }
            echo $title;
            echo "</div>";
            echo "</h5>";

            echo "</div>";

            $count = 0;
            $columns = 2;
            if ($use_as_step == 0) {
                echo "<div class='row' style='margin-left: 15px;margin-right: 15px'>";
            }
            foreach ($fields as $field) {
                switch ($field["name"]) {
                    case "urgencies":
                        $fieldglpi = "urgency";
                        break;
                    case "itilcategories":
                        $fieldglpi = "itilcategories_id";
                        break;
                    case "timeToResolve":
                        $fieldglpi = "time_to_resolve";
                        break;
                    case "approvalRequest":
                        $fieldglpi = "_add_validation";
                        break;
                    case "hardwareType":
                        $fieldglpi = "items_id";
                        break;
                    case "location":
                        $fieldglpi = "locations_id";
                        break;
                    case "watcher":
                        $fieldglpi = "_users_id_observer";
                        break;
                    case "impact":
                        $fieldglpi = "impact";
                        break;
                    case "title":
                        $fieldglpi = "name";
                        break;
                    case "contentAndFile":
                        $fieldglpi = "content";
                        break;
                    case "phonenumber":
                        $fieldglpi = "phonenumber";
                        break;
                    case "requester_group":
                        $fieldglpi = "_groups_id_requester";
                        break;
                    case "informMe":
                        $fieldglpi = "informMe";
                        break;
                }
                $morefields = $config->getFieldsMoreInformations();
                if (!$tt->getMandatoryMark($fieldglpi)
                    && !$tt->isHiddenField($fieldglpi)
                    && in_array($field["name"], $morefields)) {
                    self::loadField($field["name"], $tt, $values, $delegating, $morefields, $ticket_template, $item_id, $itemtype, $force_validation);
                    $count = $count + $columns;
                    if ($count > $columns) {
                        echo "</div>";
                        echo "<div class='row' style='margin-left: 15px;margin-right: 15px'>";
                        $count = 0;
                    }
                }
            }
            echo "</div>";
            if (!$ticket_template) {
                echo "<div class='row' style='margin-left: 15px;margin-right: 15px'>";
                echo "<div class=\"form-group\">";
                echo "<div class='center'>";
                if ($tt->isField('id') && ($tt->fields['id'] > 0)) {
                    echo Html::hidden('_tickettemplates_id', ['value' => $tt->fields['id']]);
                    echo Html::hidden('_predefined_fields', ['value' => Toolbox::prepareArrayForInput($predefined_fields)]);
                }
                if ($config->getBypassCategories() == 0) {
                    echo Html::hidden('itilcategories_id', ['value' => $category_id]);
                }
                echo Html::hidden('type', ['value' => $type]);
                echo Html::submit(PluginServicecatalogConfig::displayField($config, 'title_submit_message_button'), ['name' => 'add', 'class' => 'btn btn-primary ticket-button']);
                echo "</div>";
                echo "</div>";
                echo "</div>";
//                echo "<br>";
            }
        }

        if (!PluginServicecatalogTicketTemplate::isFieldActivated($tt, PluginServicecatalogTicketTemplate::FIELD_IMPACT)
            && $tt->isPredefinedField('impact')) {
            echo Html::hidden('impact', ['value' => $tt->predefined['impact']]);
        }
        if (!$ticket_template) {
            Html::closeForm();
        }

        echo Html::scriptBlock("
        $('.tooltipelt').hide();
        function changeColor(idLabel,newCss,itemType){
           if(itemType == 'urgencies'){
              urgencies.forEach(function(item, index, array) {
                 document.getElementById(item).className='btn btn-default';
              });
           }
           if(itemType == 'impacts'){
              impacts.forEach(function(item, index, array) {
                 document.getElementById(item).className='btn btn-default';
              });
           }
           document.getElementById(idLabel).className='btn btn-default '+newCss;
        }");

        echo Html::scriptBlock("
        function changeBackgroundColor(idLabel,newCss){
        
           hardwareType.forEach(function(item, index, array) {
                 document.getElementById(item).className='btn buttonelt col-md-2 center';
              });
           document.getElementById(idLabel).className='btn buttonelt col-md-2 center '+newCss;
           
           var buttonelt = document.getElementById('hardwareType_0');
           var tooltip = document.querySelector('.tooltipelt');
           
           if (buttonelt.innerHTML.length > 0) {
               tooltip.classList.remove('active');
               $('.tooltipelt').hide();
               buttonelt.addEventListener('click', function() {
                 tooltip.classList.add('active');
                 $('.tooltipelt').show();
               });
            } else {
                $('.tooltipelt').hide();
            }
        }");
    }


    /**
     * @param $field
     * @param $tt
     * @param $values
     * @param $delegating
     * @param $ticket
     * @param $ticket_template
     */
    public static function loadField($field, $tt, $values, $delegating, $morefields, $ticket_template, $selected_items_id = 0, $selected_itemtype = "", $force_validation = 0)
    {
        global $CFG_GLPI;

        $config = new PluginServicecatalogConfig();
        $widget = new PluginServicecatalogWidget();
        $use_as_step = $config->getFormDisplayAsStep();
        $align = "";
        $center = "";
        if ($use_as_step == 1) {
            $align = "center w-75 mx-auto";
            $center = "w-25 mx-auto";
        }
        $config = new PluginServicecatalogConfig();
        $alert = "alert-secondary";
        $alert_hide = "alert-secondary";

//        if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//            || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//            $alert = "alert-light";
//            $alert_hide = "alert-light";
//        }
        $style = "";
        if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $style = 'style="border-radius: 1px"';
        }
        switch ($field) {
            case "use_delegation":
                echo "<div class=\"form-group col-md-6 $align borderpanel\">";

                echo "<h5>";
                echo "<div class='alert $alert' role='alert' $style>";
                $title = PluginServicecatalogConfig::displayField($config, 'title_delegation');
                if (empty($title)) {
                    $title = __('This ticket concerns you', 'servicecatalog');
                    $title .= "&nbsp;?&nbsp;";
                }
                echo $title;
                echo "</div>";
                echo "</h5>";

                echo "<div><i class='ti fa-fw ti-user mx-1'></i>&nbsp;";
                $rand = Dropdown::showYesNo("nodelegate", $values['nodelegate']);
                echo "</div>";

                $right = "helpdesk";
                if ($config->forceDelegatingUsers() == 0) {
                    $right = "all";
                } elseif ($config->forceDelegatingUsers() == 1) {
                    $right = "groups";
                }

                $params = ['nodelegate' => '__VALUE__',
                    'rand' => $rand,
                    '_right' => $right,
                    '_users_id_requester'
                    => $values['_users_id_requester'],
                    '_users_id_requester_notif'
                    => $values['_users_id_requester_notif'],
                    'use_notification'
                    => $values['_users_id_requester_notif']['use_notification'],
                    'entity_restrict'
                    => $_SESSION["glpiactive_entity"],
                    'itilcategories_id'
                    => $values['itilcategories_id']];

                Ajax::updateItemOnSelectEvent(
                    "dropdown_nodelegate" . $rand,
                    "show_result" . $rand,
                    PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/dropdownDelegationUsers.php",
                    $params
                );

                echo "</div>";

                echo "<div class=\"form-group col-md-6 $center center\">";
                echo "<div id='show_result$rand'>";
                echo "</div>";
                echo "</div>";

                echo Html::hidden('_users_id_recipient', ['value' => Session::getLoginUserID()]);
                break;
            case "urgencies":
                if ($CFG_GLPI['urgency_mask'] != (1 << 3)) {

                    if ($use_as_step == 0) {
                        if (!$tt->getMandatoryMark('urgency') && in_array($field, $morefields)) {
                            echo "<div class='panel form-group col-md-6' style='display: none;'>";
                            $alert = $alert_hide;
                        } else {
                            echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                        }
                    } else {
                        echo "<div class=\"form-sc-group $align borderpanel\">";
                    }
                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_urgency');
                    if (empty($title)) {
                        $title = __('Urgency');
                    }
                    echo sprintf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('urgency'));
                    echo "</div>";
                    echo "</h5>";


                    $comment_urgency = PluginServicecatalogConfig::displayField($config, 'comment_urgency');
                    if (!empty($comment_urgency)) {
                        echo "<div class='alert alert-info'>";
                        echo "<div class='d-flex'>";
                        echo "<div class='left text-muted'>" . Glpi\RichText\RichText::getSafeHtml($comment_urgency) . "</div>";
                        echo "</div>";
                        echo "</div>";
                    }

                    $urgencies = [];
                    if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 1)) {
                        $urgencies[1] = Ticket::getUrgencyName(1);
                    }
                    if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 2)) {
                        $urgencies[2] = Ticket::getUrgencyName(2);
                    }
                    $urgencies[3] = Ticket::getUrgencyName(3);
                    if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 4)) {
                        $urgencies[4] = Ticket::getUrgencyName(4);
                    }
                    if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 5)) {
                        $urgencies[5] = Ticket::getUrgencyName(5);
                    }
                    $class = 'bt-col-md-6';
                    if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL
                        || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER
                        || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                        || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                        $class = "bt-col-md-8";
                    }
                    echo "<div class='$class' data-toggle='buttons'>";
                    $persoColor = "";
                    echo Html::scriptBlock("var urgencies = [];");

                    foreach ($urgencies as $k => $v) {
                        echo Html::scriptBlock("urgencies.push('urgency_$k');");
                        $persoColor .= self::setPersonalStyle('urgency', $k);

                        echo "<label id='urgency_$k' class='submit btn btn-default " .
                            (($k == $values["urgency"]) ? "active urgency_color_" . $k : "") . "' 
                         onclick='changeColor(\"urgency_$k\",\"urgency_color_$k\",\"urgencies\")'>";

                        if ($k == $values["urgency"]) {
                            $checked = "checked";
                        } else {
                            $checked = "";
                        }
                        echo "<input type='radio' name='urgency' value='$k' $checked>";
                        echo $v;
                        //                     echo "&nbsp;<span class='fas fa-check'></span>";
                        echo "</label>";
                    }
                    echo "<span id='justification'></span>";
                    echo "</div>";

                    echo "</div>";
                    echo $persoColor;
//                    if (!$tt->getMandatoryMark('urgency') && in_array($field, $morefields) && $use_as_step == 0) {
//                        echo "</div>";
//                    }
                }
                break;
            case "itilcategories":
                if ($use_as_step == 0) {
                    if (!$tt->getMandatoryMark('itilcategories_id') && in_array($field, $morefields)) {
                        echo "<div class='panel form-group col-md-6' style='display: none;'>";
                        $alert = $alert_hide;
                    } else {
                        echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                    }
                } else {
                    echo "<div class=\"form-sc-group $align borderpanel\">";
                }
                echo "<h5>";
                echo "<div class='alert $alert' role='alert' $style>";
                $title = PluginServicecatalogConfig::displayField($config, 'title_category');
                if (empty($title)) {
                    $title = __('Category');
                }
                printf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('itilcategories_id'));
                echo "</div>";
                echo "</h5>";
                $center = "w-50 mx-auto";
                echo "<div class=\"input-group $center\">";
                echo "<div class='input-group-prepend'><span class='input-group-text' style='padding: 10px;'><i class=\"fas fa-question\"></i></span></div>";
                $condition = ['is_helpdeskvisible' => 1];
                switch ($values['type']) {
                    case Ticket::DEMAND_TYPE:
                        $condition['is_request'] = 1;
                        break;
                    default: // Ticket::INCIDENT_TYPE :
                        $condition['is_incident'] = 1;
                }
                $opt = ['name' => 'itilcategories_id',
                    'value' => $values['itilcategories_id'],
                    'condition' => $condition,
                    'width' => '200px',
                    'class' => 'form-select',
                    'entity' => $_SESSION["glpiactive_entity"],
                    //                  'on_change' => 'this.form.submit()'
                ];

                if ($values['itilcategories_id'] && $tt->isMandatoryField("itilcategories_id")) {
                    $opt['display_emptychoice'] = false;
                }
                ITILCategory::dropdown($opt);
                echo "</div>";
                echo "</div>";

//                if (!$tt->getMandatoryMark('itilcategories_id') && in_array($field, $morefields) && $use_as_step == 0) {
//                    echo "</div>";
//                }
                break;
            case "timeToResolve":
                //TIME TO RESOLVE
                if (PluginServicecatalogTicketTemplate::isFieldActivated($tt, PluginServicecatalogTicketTemplate::FIELD_TIMETORESOLVE)) {
                    //               if ($tt->isPredefinedField('time_to_resolve')) {

                    if ($use_as_step == 0) {
                        if (!$tt->getMandatoryMark('time_to_resolve') && in_array($field, $morefields)) {
                            echo "<div class='panel form-group col-md-6' style='display: none;'>";
                            $alert = $alert_hide;
                        } else {
                            echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                        }
                    } else {
                        echo "<div class=\"form-sc-group $align borderpanel\">";
                    }
                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_time_to_resolve');
                    if (empty($title)) {
                        $title = __('Time to resolve');
                    }
                    printf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('time_to_resolve'));
                    echo "</div>";
                    echo "</h5>";

                    echo "<div class=\"input-group $center\">";
                    self::showForSLA($values, SLM::TTR, $tt);
                    echo "</div>";
                    echo "</div>";

//                    if (!$tt->getMandatoryMark('time_to_resolve') && in_array($field, $morefields) && $use_as_step == 0) {
//                        echo "</div>";
//                    }
                    //               }
                }
                break;
            case "approvalRequest":
                //Approval request
                if (PluginServicecatalogTicketTemplate::isFieldActivated($tt, PluginServicecatalogTicketTemplate::FIELD_VALIDATIONREQUEST) || $force_validation) {
                    //if ($tt->isPredefinedField('_add_validation')) {
                    if ($use_as_step == 0) {
                        if (!$tt->getMandatoryMark('_add_validation') && in_array($field, $morefields)) {
                            echo "<div class='panel form-group col-md-6' style='display: none;'>";
                            $alert = $alert_hide;
                        } else {
                            echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                        }
                    } else {
                        echo "<div class=\"form-sc-group $align borderpanel\">";
                    }
                    echo "<h5>";
                    if ($force_validation == 1) {
                        $alert = "alert-warning";
                    }
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_add_validation');
                    if (empty($title)) {
                        $title = __('Approval request');
                    }
                    printf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('_add_validation'));
                    echo "</div>";
                    echo "</h5>";

                    echo "<div class=\"input-group\">";
                    echo "<div class='input-group-prepend'>";
                    echo "<span class='input-group-text' style='padding: 10px;'><i class=\"fas fa-user\"></i>";

                    if ($force_validation == 1) {
                        echo "<div id='responsible_user'>";
                        if ($values["_users_id_requester"] == 0) {
                            $values['_users_id_requester'] = Session::getLoginUserID();
                        }
                        $_POST['value'] = $values['_users_id_requester'];
                        $_POST['users_id_supervisor'] = $values['users_id_supervisor'];
                        include(PLUGIN_SERVICECATALOG_DIR . "/ajax/uvalidationUpdate.php");
                        echo "</div>";
                        echo Html::hidden('_add_validation', ['value' => $values['_add_validation']]);
                    }
                    echo "</span></div>";
                    //                  echo $tt->getBeginHiddenFieldValue('_add_validation');
                    $validation_right = '';
                    //               if (($values['type'] == Ticket::INCIDENT_TYPE)
                    //                   && Session::haveRight('ticketvalidation', TicketValidation::CREATEINCIDENT)) {
                    $validation_right = 'validate_incident';
                    //               }
                    if (($values['type'] == Ticket::DEMAND_TYPE)
                        && Session::haveRight('ticketvalidation', TicketValidation::CREATEREQUEST)) {
                        $validation_right = 'validate_request';
                    }

                    if (!empty($validation_right) && !$force_validation) {
                        echo Html::hidden('_add_validation', ['value' => $values['_add_validation']]);

                        $params = ['name' => "users_id_validate",
                            'entity' => $values['entities_id'],
                            'right' => $validation_right,
                        ];
                        TicketValidation::dropdownValidator($params);
                    }
//                    $self = new self();
                    //                  echo $tt->getEndHiddenFieldValue('_add_validation', $self);
                    //                  if ($tt->isPredefinedField('global_validation')) {
                    //                     echo Html::hidden('global_validation', ['value' => $tt->predefined['global_validation']]);

                    //                  }

                    echo "</div>";
                    echo "</div>";

//                    if (!$tt->getMandatoryMark('_add_validation') && in_array($field, $morefields) && $use_as_step == 0) {
//                        echo "</div>";
//                    }
                    //               }
                }
                break;
            case "informMe":
                //            $force_delegating = 0;
                //            if ($config->forceDelegating()) {
                //               $force_delegating = 1;
                //            }
                if ($config->hideMailFollowup() == 0
                    //                && NotificationTargetTicket::isAuthorMailingActivatedForHelpdesk()
                ) {
                    if ($use_as_step == 0) {
                        if (!$tt->getMandatoryMark('informMe') && in_array($field, $morefields)) {
                            echo "<div class='panel form-group col-md-6' style='display: none;'>";
                            $alert = $alert_hide;
                        } else {
                            echo "<div id='notif_me' class=\"form-group col-md-6 $align borderpanel\">";
                        }
                    } else {
                        echo "<div class=\"form-sc-group $align borderpanel\">";
                    }
                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_inform_me');
                    if (empty($title)) {
                        $title = __('Would you like an email follow-up for this ticket ?', 'servicecatalog');
                    }
                    echo $title;
                    echo "</div>";
                    echo "</h5>";

                    echo "<div class='w-75'>";// style='display: inline-flex;'
                    if ($values["_users_id_requester"] == 0) {
                        $values['_users_id_requester'] = Session::getLoginUserID();
                    }
                    $_POST['value'] = $values['_users_id_requester'];
                    $_POST['field'] = '_users_id_requester_notif';
                    $_POST['use_notification'] = $values['_users_id_requester_notif']['use_notification'];
                    include(GLPI_ROOT . "/ajax/uemailUpdate.php");
                    echo "</div>";
                    echo "</div>";

//                    if (!$tt->getMandatoryMark('informMe') && in_array($field, $morefields) && $use_as_step == 0) {
//                        echo "</div>";
//                    }
                }
                break;
            case "hardwareType":
                if (($_SESSION["glpiactiveprofile"]["helpdesk_hardware"] != 0)
                    && (count($_SESSION["glpiactiveprofile"]["helpdesk_item_type"]))) {


                    $objects = self::getItemsCountForUser($values);
                    $nbcols = "col-md-6";
                    if (count($objects) > 4) {
                        $nbcols = "col-md-12";
                    }

                    if ($use_as_step == 0) {
                        if (!$tt->getMandatoryMark('items_id') && in_array($field, $morefields)) {
                            echo "<div class='panel form-group col-md-6' style='display: none;'>";
                            $alert = $alert_hide;
                        } else {
                            echo "<div class=\"form-group $nbcols $align borderpanel\">";
                        }
                    } else {
                        echo "<div class=\"form-sc-group $align borderpanel\">";
                    }
                    // My items
                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_items_dropdown');
                    if (empty($title)) {
                        $title = __('Hardware type');
                    }
                    printf(
                        __('%1$s%2$s'),
                        $title,
                        $tt->getMandatoryMark('items_id')
                    );
                    echo "</div>";
                    echo "</h5>";

                    $values['_canupdate'] = Session::haveRight('ticket', CREATE);
                    echo "<div id='item_user'>";
                    if ($values["_users_id_requester"] == 0) {
                        $values['_users_id_requester'] = Session::getLoginUserID();
                    }
                    $_POST['value'] = $values['_users_id_requester'];
                    $_POST['itilcategories_id'] = $values['itilcategories_id'];
                    $_POST['selected_items_id'] = $selected_items_id;
                    $_POST['selected_items_id'] = $selected_itemtype;
                    $_POST['is_mandatory'] = $tt->getMandatoryMark('items_id') ?? 0;
                    include(PLUGIN_SERVICECATALOG_DIR . "/ajax/uitemUpdate.php");
                    echo "</div>";

                    echo "</div>";

//                    if (!$tt->getMandatoryMark('items_id') && in_array($field, $morefields) && $use_as_step == 0) {
//                        echo "</div>";
//                    }
                }
                break;
            case "location":
                if ($use_as_step == 0) {
                    if (!$tt->getMandatoryMark('locations_id') && in_array($field, $morefields)) {
                        echo "<div class='panel form-group col-md-6' style='display: none;'>";
                        $alert = $alert_hide;
                    } else {
                        echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                    }
                } else {
                    echo "<div class=\"form-sc-group $align borderpanel\">";
                }
                echo "<h5>";
                echo "<div class='alert $alert' role='alert' $style>";
                $title = PluginServicecatalogConfig::displayField($config, 'title_location');
                if (empty($title)) {
                    $title = __('Location');
                }
                printf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('locations_id'));
                echo "</div>";
                echo "</h5>";

                echo "<div id='location_user'>";
                if ($values["_users_id_requester"] == 0) {
                    $values['_users_id_requester'] = Session::getLoginUserID();
                }
                $_POST['value'] = $values['_users_id_requester'];
                $_POST['locations_id'] = $values['locations_id'];
                include(PLUGIN_SERVICECATALOG_DIR . "/ajax/ulocationUpdate.php");
                echo "</div>";

                echo "</div>";

//                if (!$tt->getMandatoryMark('locations_id') && in_array($field, $morefields) && $use_as_step == 0) {
//                    echo "</div>";
//                }
                if ($tt->getMandatoryMark('locations_id')) {
                    echo Html::scriptBlock("
                    $('[name=\"locations_id\"]').addClass('invalid');
                    $('[for=\"locations_id\"]').css('color', 'red');
                    ");
                }
                break;
            case "watcher":
                if ($use_as_step == 0) {
                    if (!$tt->getMandatoryMark('_users_id_observer') && in_array($field, $morefields)) {
                        echo "<div class='panel form-group col-md-6' style='display: none;'>";
                        $alert = $alert_hide;
                    } else {
                        echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                    }
                } else {
                    echo "<div class=\"form-sc-group $align borderpanel\">";
                }

                echo "<h5>";
                echo "<div class='alert $alert' role='alert' $style>";
                printf(
                    __('%1$s%2$s'),
                    PluginServicecatalogConfig::displayField($config, 'title_watchers_dropdown'),
                    $tt->getMandatoryMark('_users_id_observer')
                );
                echo "</div>";
                echo "</h5>";

                $right = "helpdesk";
                if ($config->getActorUsers() == 0) {
                    $right = "all";
                } elseif ($config->getActorUsers() == 1) {
                    $right = "groups";
                }
                $values['_right'] = $right;

                if (!$tt->isHiddenField('_users_id_observer')) {
                    // Observer

                    if ($tt->isPredefinedField('_users_id_observer')
                        && !is_array($values['_users_id_observer'])) {
                        //convert predefined value to array
                        $values['_users_id_observer'] = [$values['_users_id_observer']];
                        $values['_users_id_observer_notif']['use_notification'] =
                            [$values['_users_id_observer_notif']['use_notification']];

                        // add new line to permit adding more observers
                        $values['_users_id_observer'][1] = 0;
                        $values['_users_id_observer_notif']['use_notification'][1] = 1;
                    }

                    if (isset($values['_users_id_observer'])) {
                        $observers = $values['_users_id_observer'];
                        foreach ($observers as $index_observer => $observer) {
                            $options = array_merge($values, ['_user_index' => $index_observer]);
                            self::showFormHelpdeskObserver($options, $use_as_step);
                        }
                    }
                } elseif ($tt->isPredefinedField('_users_id_observer')) { // predefined value
                    if (isset($values["_users_id_observer"]) && $values["_users_id_observer"]) {
                        echo "<i class='ti fa-fw ti-user mx-1'></i>&nbsp;";
                        //                  echo Ticket::getActorIcon('user', CommonITILActor::OBSERVER) . "&nbsp;";
                        echo Dropdown::getDropdownName("glpi_users", $values["_users_id_observer"]);
                        echo Html::hidden('_users_id_observer', ['value' => $values["_users_id_observer"]]);
                    }
                }
                echo "</div>";

//                if (!$tt->getMandatoryMark('_users_id_observer') && in_array($field, $morefields) && $use_as_step == 0) {
//                    echo "</div>";
//                }

                break;
            case "impact":
                //IMPACT
                if (PluginServicecatalogTicketTemplate::isFieldActivated($tt, PluginServicecatalogTicketTemplate::FIELD_IMPACT)) {
                    if ($CFG_GLPI['impact_mask'] != (1 << 3)) {
                        if (!$tt->isHiddenField('impact')) {

                            if ($use_as_step == 0) {
                                if (!$tt->getMandatoryMark('impact') && in_array($field, $morefields)) {
                                    echo "<div class='panel form-group col-md-6' style='display: none;'>";
                                    $alert = $alert_hide;
                                } else {
                                    echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                                }
                            } else {
                                echo "<div class=\"form-sc-group $align borderpanel\">";
                            }

                            echo "<h5>";
                            echo "<div class='alert $alert' role='alert' $style>";
                            $title = PluginServicecatalogConfig::displayField($config, 'title_impact');
                            if (empty($title)) {
                                $title = __('Impact');
                            }
                            echo sprintf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('impact'));
                            echo "</div>";
                            echo "</h5>";

                            $comment_impact = PluginServicecatalogConfig::displayField($config, 'comment_impact');
                            if (!empty($comment_impact)) {
                                echo "<div class='alert alert-info'>";
                                echo "<div class='d-flex'>";
                                echo "<div class='left text-muted'>" . Glpi\RichText\RichText::getSafeHtml($comment_impact) . "</div>";
                                echo "</div>";
                                echo "</div>";
                            }

                            $impacts = [];
                            if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 1)) {
                                $impacts[1] = Ticket::getImpactName(1);
                            }
                            if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 2)) {
                                $impacts[2] = Ticket::getImpactName(2);
                            }
                            $impacts[3] = Ticket::getImpactName(3);
                            if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 4)) {
                                $impacts[4] = Ticket::getImpactName(4);
                            }
                            if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 5)) {
                                $impacts[5] = Ticket::getImpactName(5);
                            }

                            $class = 'bt-col-md-6';
                            if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL
                                || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER
                                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                                || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                                $class = "bt-col-md-8";
                            }
                            echo "<div class='$class' data-toggle='buttons'>";
                            $persoColor = "";
                            echo Html::scriptBlock("var impacts = [];");
                            foreach ($impacts as $k => $v) {
                                echo Html::scriptBlock("impacts.push('impact_$k');");
                                $persoColor .= self::setPersonalStyle('impact', $k);

                                echo "<label id='impact_$k' class='submit btn btn-default " .
                                    (($k == $values["impact"]) ? "active impact_color_" . $k : "") . "' 
                         onclick='changeColor(\"impact_$k\",\"impact_color_$k\",\"impacts\")'>";

                                if ($k == $values["impact"]) {
                                    $checked = "checked";
                                } else {
                                    $checked = "";
                                }
                                echo "<input type='radio' name='impact' value='$k' $checked>";
                                echo $v;
                                //                        echo "&nbsp;<span class='fas fa-check'></span>";
                                echo "</label>";
                            }
                            echo "</div>";

                            echo "</div>";
                            echo $persoColor;
//                            if (!$tt->getMandatoryMark('impact') && in_array($field, $morefields) && $use_as_step == 0) {
//                                echo "</div>";
//                            }
                        }
                    }
                }
                break;
            case "title":
                if (!$tt->isHiddenField('name')
                    || $tt->isPredefinedField('name')) {
                    echo "<div class=\"form-group col-md-12 $align borderpanel\">";

                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_ticket');
                    printf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('name'));
                    echo "</div>";
                    echo "</h5>";

                    echo "<div class=\"input-group\">";
                    echo "<div class='input-group-prepend'>
                      <span class='input-group-text' style='padding: 10px;'><i class=\"fas fa-pencil-alt\"></i></span>
                    </div>";
                    if (!$tt->isHiddenField('name')) {
                        $opt = [
                            'value' => $values['name'],
                            'maxlength' => 250,
                            'class' => "form-control input-lg",
                            'placeholder' => $values['name'],
                        ];
                        if ($tt->isMandatoryField('name')) {
                            $opt['required'] = 'required';
                        }
                        echo Html::input('name', $opt);
                    } else {
                        echo $values['name'];
                        echo Html::hidden('name', ['value' => $values['name']]);
                    }
                    echo "</div>";

                    echo "</div>";
                }
                break;
            case "contentAndFile":
                if ($use_as_step == 1) {
                    if (!$tt->isHiddenField('name')
                        || $tt->isPredefinedField('name')) {
                        echo "<div class=\"form-group col-md-12 $align borderpanel\">";

                        echo "<h5>";
                        echo "<div class='alert $alert' role='alert' $style>";
                        $title = PluginServicecatalogConfig::displayField($config, 'title_ticket');
                        printf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('name'));
                        echo "</div>";
                        echo "</h5>";

                        echo "<div class=\"input-group\">";
                        echo "<div class='input-group-prepend'>
                      <span class='input-group-text' style='padding: 10px;'><i class=\"fas fa-pencil-alt\"></i></span>
                    </div>";
                        if (!$tt->isHiddenField('name')) {
                            $opt = [
                                'value' => $values['name'],
                                'maxlength' => 250,
                                'class' => "form-control input-lg",
                                'placeholder' => $values['name'],
                            ];
                            if ($tt->isMandatoryField('name')) {
                                $opt['required'] = 'required';
                            }
                            echo Html::input('name', $opt);
                        } else {
                            echo $values['name'];
                            echo Html::hidden('name', ['value' => $values['name']]);
                        }
                        echo "</div>";

                        echo "</div>";
                    }
                }
                if (!$tt->isHiddenField('content')
                    || $tt->isPredefinedField('content')) {
                    echo "<div class=\"form-group col-md-12 $align borderpanel \">";//ticket_description

                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title_description = PluginServicecatalogConfig::displayField($config, 'title_description_ticket');
                    printf(__('%1$s%2$s'), $title_description, $tt->getMandatoryMark('content'));
                    echo "</div>";
                    echo "</h5>";

                    $class = "bt-col-md-7";
                    if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL
                        || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER
                        || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                        || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                        $class = "bt-col-md-12";
                    }
                    echo "<div class=\"$class\">";
                    //               echo "<div class=\"input-group\">";
                    echo "<div class='input-group-prepend'>
                      <span class='input-group-text' style='padding: 10px;'><i class=\"fas fa-pencil-alt\"></i></span>
                    </div>";
                    $rand = mt_rand();
                    $rand_text = mt_rand();

                    $content_id = "content$rand";

                    $content = $values['content'];
                    //               if (!$ticket_template) {
                    //                  $content = Html::cleanPostForTextArea($values['content']);
                    //               }

                    //               $content = Html::setRichTextContent($content_id, $content, $rand);
                    //               $cols    = 100;
                    //               $rows    = 10;
                    //               echo "<div id='content$rand_text'>";
                    //               echo "<textarea id='$content_id' name='content' cols='$cols' rows='$rows'
                    //               " . ($tt->isMandatoryField('content') ? " required='required'" : '') . ">" .
                    //                    $content . "</textarea></div>";
                    //               echo "</div>";
                    $required = '';
                    if ($tt->isMandatoryField('content')) {
                        $required = 'required';
                    }

                    self::textarea(['name' => 'content',
                        'placeholder' => PluginServicecatalogConfig::displayField($config, 'placeholder_description_ticket'),
                        'value' => $content,
                        'rand' => $rand,
                        'editor_id' => $content_id,
                        'enable_fileupload' => true,
                        'enable_richtext' => true,
                        'enable_images' => true,
                        'required' => $required,
                        'cols' => 12,
                        'rows' => 20]);

                    //               echo "</div>";

                    //                    Html::file(['editor_id' => $content_id,
                    //                                'showtitle' => true,
                    //                                'multiple'  => true]);
                    echo "</div>";

                    echo "</div>";
                }
                break;
            case "phonenumber":
                $config = new PluginServicecatalogConfig();
                if ($config->getDisplayPhoneNumber()) {

                    if ($use_as_step == 0) {
                        if (in_array($field, $morefields)) {
                            echo "<div class='panel form-group col-md-6' style='display: none;'>";
                            $alert = $alert_hide;
                        } else {
                            echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                        }
                    } else {
                        echo "<div class=\"form-sc-group $align borderpanel\">";
                    }
                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = PluginServicecatalogConfig::displayField($config, 'title_phone_number');
                    $force = false;
                    if ($config->IsPhoneNumberMandatory() == 1) {
                        $force = true;
                    }
                    printf(__('%1$s%2$s'), $title, $tt->getMandatoryMark('phonenumber', $force));
                    echo "</div>";
                    echo "</h5>";

                    echo "<div id='phone_user'>";
                    if ($values["_users_id_requester"] == 0) {
                        $values['_users_id_requester'] = Session::getLoginUserID();
                    }
                    $_POST['value'] = $values['_users_id_requester'];
                    $_POST['phone_number'] = $values['phone_number'];
                    include(PLUGIN_SERVICECATALOG_DIR . "/ajax/uphoneUpdate.php");
                    echo "</div>";

                    echo "<div class=\"input-group\" >";
                    echo "<div class='input-group-prepend'>
                      <span class='input-group-text' style='padding: 10px;'><i class=\"fas fa-phone\"></i></span></div>";
                    echo "<input type='text' placeholder='" . __('Add a phone number ?', 'servicecatalog') . "' name='other_phone_number' value='' size='30' class=''>";
                    echo "</div>";

                    echo "</div>";

//                    if (in_array($field, $morefields) && $use_as_step == 0) {
//                        echo "</div>";
//                    }

                    if ($config->getDisplayPhoneNumber()) {

                        $phones = [];
                        $user = new User();
                        if ($user->getFromDB($_POST["value"])) {
                            $phones = self::getUsersPhoneNumbers($user);
                        }
                        if (count($phones) == 0) {
                            echo Html::scriptBlock("
                                $('[name=\"other_phone_number\"]').addClass('invalid');
                                $('[for=\"other_phone_number\"]').css('color', 'red');
                             ");
                        }

                    }
                }
                break;
            case "requester_group":
                $config = new PluginServicecatalogConfig();
                $condition = getEntitiesRestrictCriteria(Group::getTable(), '', '', true);
                $users_id = $_SESSION['glpiID'];
                if ($values["_users_id_requester"] == 0) {
                    $users_id = Session::getLoginUserID();
                }

                $group_user_data = Group_User::getUserGroups($users_id, $condition);
                if ($config->getDisplayRequesterGroup() && count($group_user_data) > 0) {

                    if ($use_as_step == 0) {
                        if (in_array($field, $morefields)) {
                            echo "<div class='panel form-group col-md-6' style='display: none;'>";
                            $alert = $alert_hide;
                        } else {
                            echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                        }
                    } else {
                        echo "<div class=\"form-sc-group $align borderpanel\">";
                    }
                    echo "<h5>";
                    echo "<div class='alert $alert' role='alert' $style>";
                    echo PluginServicecatalogConfig::displayField($config, 'title_requester_group');
                    echo "</div>";
                    echo "</h5>";

                    echo "<div id='group_requester'>";

                    if ($values["_users_id_requester"] == 0) {
                        $values['_users_id_requester'] = Session::getLoginUserID();
                    }
                    $_POST['value'] = $values['_users_id_requester'];
                    $_POST['requester_group'] = $values['_groups_id_requester'];
                    include(PLUGIN_SERVICECATALOG_DIR . "/ajax/ugroupUpdate.php");
                    echo "</div>";

                    echo "</div>";

//                    if (in_array($field, $morefields) && $use_as_step == 0) {
//                        echo "</div>";
//                    }
                }
                break;
        }
    }


    /**
     * show user add div on creation
     *
     * @param $type      integer  actor type
     * @param $options   array    options for default values ($options of showForm)
     *
     * @return integer Random part of inputs ids
     **/
    public
    function showActorAddFormOnCreate($type, array $options)
    {
        global $CFG_GLPI;

        $ticket = new Ticket();
        $typename = Ticket::getActorFieldNameType($type);

        $itemtype = $ticket->getType();

        //      echo Ticket::getActorIcon('user', $type);
        echo "<i class='ti fa-fw ti-user mx-1'></i>";
        // For ticket templates : mandatories
        $key = $ticket->getTemplateFormFieldName();
        if (isset($options[$key])) {
            echo $options[$key]->getMandatoryMark("_users_id_" . $typename);
        }
        echo "&nbsp;";

        if (!isset($options["_right"])) {
            $right = $ticket->getDefaultActorRightSearch($type);
        } else {
            $right = $options["_right"];
        }

        if ($options["_users_id_" . $typename] == 0
            && !isset($_REQUEST["_users_id_$typename"]) && !isset($ticket->input["_users_id_$typename"])) {
            $options["_users_id_" . $typename] = $ticket->getDefaultActor($type);
        }
        $rand = mt_rand();
        $actor_name = '_users_id_' . $typename;
        if ($type == CommonITILActor::OBSERVER) {
            $actor_name = '_users_id_' . $typename . '[]';
        }
        $params = ['name' => $actor_name,
            'value' => $options["_users_id_" . $typename],
            'right' => $right,
            'rand' => $rand,
            'entity' => $options['entity_restrict'],
            'itilcategories_id' => ($options['itilcategories_id'] ?? 0)];

        //only for active ldap and corresponding right
        //      $ldap_methods = getAllDataFromTable('glpi_authldaps', ['is_active' => 1]);
        //      if (count($ldap_methods)
        //          && Session::haveRight('user', User::IMPORTEXTAUTHUSERS)) {
        //         $params['ldap_import'] = true;
        //      }

        //      if ($type == CommonITILActor::REQUESTER) {
        //         //         $params['on_change'] = 'this.form.submit()';
        //         unset($params['entity']);
        //      }

        $params['_user_index'] = 0;
        if (isset($options['_user_index'])) {
            $params['_user_index'] = $options['_user_index'];
        }

        if ($CFG_GLPI['notifications_mailing']) {
            $paramscomment
                = ['value' => '__VALUE__',
                'field' => "_users_id_" . $typename . "_notif",
                '_user_index'
                => $params['_user_index'],
                'allow_email'
                => (($type == CommonITILActor::REQUESTER)
                    || ($type == CommonITILActor::OBSERVER)),
                'use_notification'
                => $options["_users_id_" . $typename . "_notif"]['use_notification']];
            if (isset($options["_users_id_" . $typename . "_notif"]['alternative_email'])) {
                $paramscomment['alternative_email']
                    = $options["_users_id_" . $typename . "_notif"]['alternative_email'];
            }
            $params['toupdate'] = ['value_fieldname'
            => 'value',
                'to_update' => "notif_" . $typename . "_$rand",
                'url' => $CFG_GLPI["root_doc"] . "/ajax/uemailUpdate.php",
                'moreparams' => $paramscomment];
        }

        if ($itemtype == 'Ticket') {
            $toupdate = [];
            if (isset($params['toupdate']) && is_array($params['toupdate'])) {
                $toupdate[] = $params['toupdate'];
            }

            $paramsval
                = ['value' => '__VALUE__'];

            $toupdate[] = ['value_fieldname'
            => 'value',
                'to_update' => "responsible_user",
                'url' => PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/uvalidationUpdate.php",
                'moreparams' => $paramsval];
            $params['toupdate'] = $toupdate;


            $paramsloc
                = ['value' => '__VALUE__'];

            $toupdate[] = ['value_fieldname'
            => 'value',
                'to_update' => "location_user",
                'url' => PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/ulocationUpdate.php",
                'moreparams' => $paramsloc];
            $params['toupdate'] = $toupdate;

            $paramsphone
                = ['value' => '__VALUE__'];

            $toupdate[] = ['value_fieldname'
            => 'value',
                'to_update' => "phone_user",
                'url' => PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/uphoneUpdate.php",
                'moreparams' => $paramsphone];
            $params['toupdate'] = $toupdate;

            $paramsitems
                = ['value' => '__VALUE__',
                'itilcategories_id' => $params['itilcategories_id']];

            $toupdate[] = ['value_fieldname'
            => 'value',
                'to_update' => "item_user",
                'url' => PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/uitemUpdate.php",
                'moreparams' => $paramsitems];
            $params['toupdate'] = $toupdate;

            $paramsgroup
                = ['value' => '__VALUE__'];

            $toupdate[] = ['value_fieldname'
            => 'value',
                'to_update' => "group_requester",
                'url' => PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/ugroupUpdate.php",
                'moreparams' => $paramsgroup];
            $params['toupdate'] = $toupdate;
        }

        if (($itemtype == 'Ticket')
            && ($type == CommonITILActor::ASSIGN)) {
            $toupdate = [];
            if (isset($params['toupdate']) && is_array($params['toupdate'])) {
                $toupdate[] = $params['toupdate'];
            }
            $toupdate[] = ['value_fieldname' => 'value',
                'to_update' => "countassign_$rand",
                'url' => $CFG_GLPI["root_doc"] .
                    "/ajax/actorinformation.php",
                'moreparams' => ['users_id_assign' => '__VALUE__']];
            $params['toupdate'] = $toupdate;
        }

        if (Plugin::isPluginActive('vip')) {
            $vip = new PluginVipGroup();
            $vip_groups_users = [];
            $used = [];
            foreach ($vip->find(['isvip' => 1]) as $data) {
                $vip_groups_users[] = Group_User::getGroupUsers($data['id']);
            }
            if (count($vip_groups_users) > 0) {
                foreach ($vip_groups_users as $groups => $users) {
                    foreach ($users as $id => $user) {
                        $used[] = $user['id'];
                    }
                }
                $params['used'] = $used;
            }
        }
        $params['display_emptychoice'] = false;

        // List all users in the active entities
        User::dropdown($params);

        if ($itemtype == 'Ticket') {
            // display opened tickets for user
            if (($type == CommonITILActor::REQUESTER)
                && ($options["_users_id_" . $typename] > 0)
                && (Session::getCurrentInterface() != "helpdesk")) {
                $options2 = [
                    'criteria' => [
                        [
                            'field' => 4, // users_id
                            'searchtype' => 'equals',
                            'value' => $options["_users_id_" . $typename],
                            'link' => 'AND',
                        ],
                        [
                            'field' => 12, // status
                            'searchtype' => 'equals',
                            'value' => 'notold',
                            'link' => 'AND',
                        ],
                    ],
                    'reset' => 'reset',
                ];

                $url = $ticket->getSearchURL() . "?" . Toolbox::append_params($options2, '&amp;');

                echo "&nbsp;<a href='$url' title=\"" . __s('Processing') . "\">(";
                printf(
                    __('%1$s: %2$s'),
                    __('Processing'),
                    $ticket->countActiveObjectsForUser($options["_users_id_" . $typename])
                );
                echo ")</a>";
            }

            // Display active tickets for a tech
            // Need to update information on dropdown changes
            if ($type == CommonITILActor::ASSIGN) {
                echo "<span id='countassign_$rand'>";
                echo "</span>";

                echo "<script type='text/javascript'>";
                echo "$(function() {";
                Ajax::updateItemJsCode(
                    "countassign_$rand",
                    $CFG_GLPI["root_doc"] . "/ajax/actorinformation.php",
                    ['users_id_assign' => '__VALUE__'],
                    "dropdown__users_id_" . $typename . $rand
                );
                echo "});</script>";
            }
        }

        if ($CFG_GLPI['notifications_mailing']) {
            echo "<div id='notif_" . $typename . "_$rand'>";
            echo "</div>";

            echo "<script type='text/javascript'>";
            echo "$(function() {";
            Ajax::updateItemJsCode(
                "notif_" . $typename . "_$rand",
                $CFG_GLPI["root_doc"] . "/ajax/uemailUpdate.php",
                $paramscomment,
                "dropdown_" . $actor_name . $rand
            );
            echo "});</script>";
        }

        echo "<script type='text/javascript'>";
        echo "$(function() {";
        Ajax::updateItemJsCode(
            "location_user",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/ulocationUpdate.php",
            $paramsloc,
            "dropdown_" . $actor_name . $rand
        );
        echo "});</script>";

        echo "<script type='text/javascript'>";
        echo "$(function() {";
        Ajax::updateItemJsCode(
            "responsible_user",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/uvalidationUpdate.php",
            $paramsloc,
            "dropdown_" . $actor_name . $rand
        );
        echo "});</script>";

        echo "<script type='text/javascript'>";
        echo "$(function() {";
        Ajax::updateItemJsCode(
            "phone_user",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/uphoneUpdate.php",
            $paramsphone,
            "dropdown_" . $actor_name . $rand
        );
        echo "});</script>";

        echo "<script type='text/javascript'>";
        echo "$(function() {";
        Ajax::updateItemJsCode(
            "item_user",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/uitemUpdate.php",
            $paramsitems,
            "dropdown_" . $actor_name . $rand
        );
        echo "});</script>";

        echo "<script type='text/javascript'>";
        echo "$(function() {";
        Ajax::updateItemJsCode(
            "group_requester",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/ugroupUpdate.php",
            $paramsitems,
            "dropdown_" . $actor_name . $rand
        );
        echo "});</script>";
        echo "<br>";
        echo "<br>";

        return $rand;
    }


    /**
     * @param $user
     *
     * @return array
     */
    public
    static function getUsersPhoneNumbers($user)
    {
        $values = [];

        if ($user->getField('phone') !== null
            && !empty(trim($user->getField('phone')))) {
            $phone = trim($user->getField('phone'));
            $values[$phone] = $phone;
        }
        if ($user->getField('phone2') !== null
            && !empty(trim($user->getField('phone2')))) {
            $phone2 = trim($user->getField('phone2'));
            $values[$phone2] = $phone2;
        }
        if ($user->getField('mobile') !== null
            && !empty(trim($user->getField('mobile')))) {
            $mobile = trim($user->getField('mobile'));
            $values[$mobile] = $mobile;
        }

        return $values;
    }

    /**
     * Display a single oberver selector
     *
     *  * @param $options array options for default values ($options of showActorAddFormOnCreate)
     **/
    public
    static function showFormHelpdeskObserver($options = [], $use_as_step = 0)
    {
        global $CFG_GLPI;

        //default values
        $ticket = new Ticket();
        $params['_users_id_observer_notif']['use_notification'] = true;
        $params['_users_id_observer'] = 0;
        $params['entities_id'] = $_SESSION["glpiactive_entity"];
        $options['_right'] = "all";

        // overide default value by function parameters
        if (is_array($options) && count($options)) {
            foreach ($options as $key => $val) {
                $params[$key] = $val;
            }
        }
        $config = new PluginServicecatalogConfig();
        $right = $params['_right'];
        if ($config->getActorUsers() == 0) {
            $right = "all";
        } elseif ($config->getActorUsers() == 1) {
            $right = "groups";
        }
        $params['_right'] = $right;

        $rand_observer = mt_rand();
        // add a user selector
        if (isset($params['click'])) {
            $align = "";
            if ($use_as_step == 1) {
                $align = "center w-75 mx-auto";
            }
            echo "<div id='usedobserver_$rand_observer' class='$align' >";
            $rand_newobserver = $ticket->showActorAddFormOnCreate(CommonITILActor::OBSERVER, $params);
            echo "&nbsp;<button id='removeObserver$rand_observer' style='float: left;'  class='remove-observer btn' onclick=\"$('#usedobserver_$rand_observer').remove();\">";
            echo "<i class='fas fa-minus-circle' title='" . __('Delete') . "' ></i>";
            echo "</button></div>";
            // add an additionnal observer on user selection
            Ajax::updateItemOnSelectEvent(
                "dropdown__users_id_observer[]$rand_observer",
                "observer_$rand_observer",
                PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/helpdesk_observer.php",
                $params
            );

            //         remove 'new observer' anchor on user selection
            echo Html::scriptBlock("
            $('#dropdown__users_id_observer__$rand_observer').on('change', function(event) {
               $('#addObserver$rand_observer').remove();
            });");
        }

        // add "new observer" anchor
        echo "<div style='margin: 10px;'><button id='addObserver$rand_observer' class='add-observer btn' onclick='this.remove()'>";
        echo "<i class='fas fa-plus-circle' title='" . __('Add') . "' ></i>&nbsp;" . __('Add');
        echo "</button></div>";
        $params['click'] = 1;
        // add an additionnal observer on anchor click
        Ajax::updateItemOnEvent(
            "addObserver$rand_observer",
            "observer_$rand_observer",
            PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/helpdesk_observer.php",
            $params,
            ['click']
        );

        // div for an additionnal observer
        echo "<div id='observer_$rand_observer'></div>";
    }

    /** Print the user personnal information for check
     *
     * @param $userid Interger ID of the user
     *
     * @return bool
     * @since version 0.84
     *
     */
    public
    static function showPersonalInformation($userid)
    {
        global $CFG_GLPI;

        $dbu = new DbUtils();
        $user = new User();
        if (!$user->can($userid, READ)
            && ($userid != Session::getLoginUserID())) {
            return false;
        }

        echo "<div class=\"row flex-row\">";

        echo "<div class=\"form-group col-md-6\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Name');
        echo "</label>";
        echo "<div class=\"col-form-label col-form-label-xd\">";
        echo $dbu->getUserName($userid);
        echo "</div>";
        echo "</div>";

        echo "<div class=\"form-group col-md-6\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Phone');
        echo "</label>";
        echo "<div class=\"col-form-label col-form-label-xd\">";
        echo $user->getField('phone');
        echo "</div>";
        echo "</div>";

        echo "</div>";

        echo "<div class=\"row flex-row\">";

        echo "<div class=\"form-group col-md-6\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Mobile phone');
        echo "</label>";
        echo "<div class=\"col-form-label col-form-label-xd\">";
        echo $user->getField('mobile');
        echo "</div>";
        echo "</div>";

        echo "<div class=\"form-group col-md-6\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo _n('Email', 'Emails', Session::getPluralNumber());
        echo "</label>";
        echo "<div class=\"col-form-label col-form-label-xd\">";
        $emails = $user->getAllEmails();
        foreach ($emails as $email) {
            echo $email . "<br>";
        }
        echo "</div>";
        echo "</div>";

        echo "</div>";

        echo "<div class=\"row flex-row\">";

        echo "<div class=\"form-group col-md-6\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Location');
        echo "</label>";
        echo "<div class=\"col-form-label col-form-label-xd\">";
        echo Dropdown::getDropdownName('glpi_locations', $user->getField('locations_id'));
        echo "</div>";
        echo "</div>";


        echo "<div class=\"form-group col-md-6\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo "</label>";
        echo "<div class=\"col-form-label col-form-label-xd\">";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/preference.php' target='_blank'>";
        echo "<button type='button' class='submit btn btn-primary btn-submit' >" . __('Edit') . "</button>";
        echo "</a>";
        echo "</div>";
        echo "</div>";

        echo "</div>";
    }

    /**
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     */
    public
    static function getWidgetIncident($widget, $bloc_class)
    {
        $buttons = "";
        $config = new PluginServicecatalogConfig();
        if (Session::haveRight('plugin_servicecatalog_incidents', READ)
            && Session::haveRight("ticket", CREATE)) {
            if ($widget->fields['incidents_widgetactions'] == 1) {
                // INCIDENT_TYPE

                if ($config->getBypassCategories() == 1) {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?type=" . Ticket::INCIDENT_TYPE;
                } else {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . Ticket::INCIDENT_TYPE . "&level=1";
                }

                $title = PluginServicecatalogConfig::displayField($widget, 'title_incident');
                $url_img = "picture.send.php";
                $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img" => $widget->fields['img_incident'],
                    "url_img" => $url_img,
                    "fa" => $widget->fields['fa_incident'],
                    "title" => $title,
                    "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_incident')], Ticket::INCIDENT_TYPE);
            }
        }

        return $buttons;
    }

    /**
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     */
    public
    static function getWidgetRequest($widget, $bloc_class)
    {
        $buttons = "";
        $config = new PluginServicecatalogConfig();
        if (Session::haveRight('plugin_servicecatalog_requests', READ)
            && Session::haveRight("ticket", CREATE)) {
            //DEMAND_TYPE
            if ($widget->fields['requests_widgetactions'] == 1) {
                if ($config->getBypassCategories() == 1) {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?type=" . Ticket::DEMAND_TYPE;
                } else {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . Ticket::DEMAND_TYPE . "&level=1";
                }

                $title = PluginServicecatalogConfig::displayField($widget, 'title_request');
                $url_img = "picture.send.php";
                $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img" => $widget->fields['img_request'],
                    "url_img" => $url_img,
                    "fa" => $widget->fields['fa_request'],
                    "title" => $title,
                    "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_request')], Ticket::DEMAND_TYPE);
            }
        }

        return $buttons;
    }

    /**
     * @param     $widget
     * @param     $bloc_class
     *
     * @param int $nb
     *
     * @return string
     */
    public
    static function getWidgetListIncidents($widget, $bloc_class, $nb = 0)
    {
        global $CFG_GLPI;

        $buttons = "";

        //List Incidents
        if ($widget->fields['incidents_list_widgetactions'] == 1) {
            if (Session::haveRight("ticket", CREATE)
                || Session::haveRight("ticket", Ticket::READMY)
                || Session::haveRight("followup", ITILFollowup::SEEPUBLIC)
            ) {
                $options['reset'] = 'reset';
                $options['criteria'][0]['field'] = 12; // status
                $options['criteria'][0]['searchtype'] = 'equals';
                $options['criteria'][0]['value'] = "notold";
                $options['criteria'][0]['link'] = 'AND';

                $options['criteria'][1]['field'] = 14; // type
                $options['criteria'][1]['searchtype'] = 'equals';
                $options['criteria'][1]['value'] = Ticket::INCIDENT_TYPE;
                $options['criteria'][1]['link'] = 'AND';

                if (Session::getCurrentInterface() == "central") {
                    $url = $CFG_GLPI["root_doc"] . "/front/ticket.php?" . Toolbox::append_params($options, '&');
                } else {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php?type=" . Ticket::INCIDENT_TYPE;
                }
                $title = PluginServicecatalogConfig::displayField($widget, 'title_incidents_list');
                if ($nb > 0) {
                    $title .= " (" . $nb . ")";
                }
                $url_img = "picture.send.php";
                $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img" => $widget->fields['img_incidents_list'],
                    "url_img" => $url_img,
                    "fa" => $widget->fields['fa_incidents_list'],
                    "title" => $title,
                    "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_incidents_list')]);
            }
        }

        return $buttons;
    }

    /**
     * @param     $widget
     * @param     $bloc_class
     *
     * @param int $nb
     *
     * @return string
     */
    public
    static function getWidgetListRequests($widget, $bloc_class, $nb = 0)
    {
        global $CFG_GLPI;

        $buttons = "";

        //List Requests
        if ($widget->fields['requests_list_widgetactions'] == 1) {
            if (Session::haveRight("ticket", CREATE)
                || Session::haveRight("ticket", Ticket::READMY)
                || Session::haveRight("followup", ITILFollowup::SEEPUBLIC)
            ) {
                $options['reset'] = 'reset';
                $options['criteria'][0]['field'] = 12; // status
                $options['criteria'][0]['searchtype'] = 'equals';
                $options['criteria'][0]['value'] = "notold";
                $options['criteria'][0]['link'] = 'AND';

                $options['criteria'][1]['field'] = 14; // type
                $options['criteria'][1]['searchtype'] = 'equals';
                $options['criteria'][1]['value'] = Ticket::DEMAND_TYPE;
                $options['criteria'][1]['link'] = 'AND';

                if (Session::getCurrentInterface() == "central") {
                    $url = $CFG_GLPI["root_doc"] . "/front/ticket.php?" . Toolbox::append_params($options, '&');
                } else {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php?type=" . Ticket::DEMAND_TYPE;
                }

                $title = PluginServicecatalogConfig::displayField($widget, 'title_requests_list');
                if ($nb > 0) {
                    $title .= " (" . $nb . ")";
                }
                $url_img = "picture.send.php";
                $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img" => $widget->fields['img_requests_list'],
                    "url_img" => $url_img,
                    "fa" => $widget->fields['fa_requests_list'],
                    "title" => $title,
                    "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_requests_list')]);
            }
        }

        return $buttons;
    }

    /**
     * @param     $widget
     * @param     $bloc_class
     *
     * @param int $nb
     *
     * @return string
     */
    public
    static function getWidgetListTickets($widget, $bloc_class, $nb = 0)
    {
        global $CFG_GLPI;

        $buttons = "";

        //List all tickets
        if ($widget->fields['tickets_list_widgetactions'] == 1) {
            if (Session::haveRight("ticket", CREATE)
                || Session::haveRight("ticket", Ticket::READMY)
                || Session::haveRight("followup", ITILFollowup::SEEPUBLIC)
            ) {
                if (Session::getCurrentInterface() == "central") {
                    $url = $CFG_GLPI['root_doc'] . "/front/ticket.php?is_deleted=0&reset=reset";
                } else {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php";
                }

                $title = PluginServicecatalogConfig::displayField($widget, 'title_tickets_list');
                if ($nb > 0) {
                    $title .= " (" . $nb . ")";
                }
                $url_img = "picture.send.php";
                $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img" => $widget->fields['img_tickets_list'],
                    "url_img" => $url_img,
                    "fa" => $widget->fields['fa_tickets_list'],
                    "title" => $title,
                    "comment" => PluginServicecatalogConfig::displayField($widget, 'comment_tickets')]);
            }
        }

        return $buttons;
    }


    /**
     * @param $widget
     * @param $bloc_class
     *
     * @return string
     * @throws \GlpitestSQLError
     */
    public
    static function getWidgetTicketValidation($widget, $bloc_class)
    {
        global $CFG_GLPI, $DB;

        $buttons = "";

        //VALIDATIONS
        if (Session::haveRightsOr('ticketvalidation', TicketValidation::getValidateRights())
            && $widget->fields['ticketvalidation_list_widgetactions'] > 0) {
            $opt = [];
            $opt['reset'] = 'reset';
            $opt['criteria'][0]['field'] = 55; // validation status
            $opt['criteria'][0]['searchtype'] = 'equals';
            $opt['criteria'][0]['value'] = TicketValidation::WAITING;
            $opt['criteria'][0]['link'] = 'AND';

            $opt['criteria'][1]['field'] = 59; // validation aprobator
            $opt['criteria'][1]['searchtype'] = 'equals';
            $opt['criteria'][1]['value'] = Session::getLoginUserID();
            $opt['criteria'][1]['link'] = 'AND';

            $opt['criteria'][2]['field'] = 12; // ticket status
            $opt['criteria'][2]['searchtype'] = 'equals';
            $opt['criteria'][2]['value'] = Ticket::SOLVED;
            $opt['criteria'][2]['link'] = 'AND NOT';

            $opt['criteria'][3]['field'] = 12; // ticket status
            $opt['criteria'][3]['searchtype'] = 'equals';
            $opt['criteria'][3]['value'] = Ticket::CLOSED;
            $opt['criteria'][3]['link'] = 'AND NOT';

            $opt['criteria'][4]['field'] = 52; // global validation status
            $opt['criteria'][4]['searchtype'] = 'equals';
            $opt['criteria'][4]['value'] = CommonITILValidation::WAITING;
            $opt['criteria'][4]['link'] = 'AND';

            $query = "SELECT DISTINCT `glpi_tickets`.`id`
                      FROM `glpi_tickets`
                      LEFT JOIN `glpi_tickets_users`
                           ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                      LEFT JOIN `glpi_groups_tickets`
                           ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`)
                      LEFT JOIN `glpi_ticketvalidations`
                                 ON (`glpi_tickets`.`id` = `glpi_ticketvalidations`.`tickets_id`)
                              WHERE `glpi_tickets`.`is_deleted` = 0
                                    AND `users_id_validate` = '" . Session::getLoginUserID() . "'
                                    AND `glpi_ticketvalidations`.`status` = '" . CommonITILValidation::WAITING . "'
                                    AND `glpi_tickets`.`global_validation` = '" . CommonITILValidation::WAITING . "'
                                    AND `glpi_tickets`.`status` NOT IN ('" . Ticket::CLOSED . "',
                                                                         '" . Ticket::SOLVED . "') ";
            $dbu = new DbUtils();
            $query .= $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");
            $query .= " ORDER BY `glpi_tickets`.`date_mod` DESC";
            $result = $DB->query($query);
            $numrows = $DB->numrows($result);

            $addstyle = "";
            if ($numrows > 0) {
                $addstyle = "style='color:firebrick;'";
            }

            if (Session::getCurrentInterface() == "central") {
                $url = $CFG_GLPI["root_doc"] . "/front/ticket.php?" . Toolbox::append_params($opt, '&');
            } else {
                $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket_validate.php";
            }

            if (!empty($widget->fields['title_validation'])) {
                $title = "<span $addstyle class=\"de-em\">" . PluginServicecatalogConfig::displayField($widget, 'title_validation') . "</span>";
            } else {
                $title = "<span $addstyle class=\"de-em\">" . __('Manage', 'servicecatalog') . " " . __('Ticket validations', 'servicecatalog') . "</span>";
            }

            $url_img = "picture.send.php";
            $comments = PluginServicecatalogConfig::displayField($widget, 'comment_validation');
            if ($numrows > 0) {
                $comments .= "<br><span $addstyle>";
                $comments .= sprintf(_n('You have %d ticket to validate !', 'You have %d tickets to validate !', $numrows, 'servicecatalog'), $numrows);
                $comments .= "</span>";
            }


            $buttons = PluginServicecatalogWidget::getWidgetTemplate($url, $bloc_class, ["img" => $widget->fields['img_validation'],
                "url_img" => $url_img,
                "fa" => $widget->fields['fa_validation'],
                "fa_style" => $addstyle,
                "title" => $title,
                "comment" => $comments]);
        }

        return $buttons;
    }

    /**
     * @param $widget
     *
     * @return string
     * @throws \GlpitestSQLError
     */
    public
    static function showNavBarMenuTicketValidation($widget, $total_validate)
    {
        global $CFG_GLPI;

        $menu = [];
        $config = new PluginServicecatalogConfig();
        //VALIDATIONS
        if (Session::haveRightsOr('ticketvalidation', TicketValidation::getValidateRights())) {
            $opt = [];
            $opt['reset'] = 'reset';
            $opt['criteria'][0]['field'] = 55; // validation status
            $opt['criteria'][0]['searchtype'] = 'equals';
            $opt['criteria'][0]['value'] = TicketValidation::WAITING;
            $opt['criteria'][0]['link'] = 'AND';

            $opt['criteria'][1]['field'] = 59; // validation aprobator
            $opt['criteria'][1]['searchtype'] = 'equals';
            $opt['criteria'][1]['value'] = Session::getLoginUserID();
            $opt['criteria'][1]['link'] = 'AND';

            $opt['criteria'][2]['field'] = 12; // ticket status
            $opt['criteria'][2]['searchtype'] = 'equals';
            $opt['criteria'][2]['value'] = Ticket::SOLVED;
            $opt['criteria'][2]['link'] = 'AND NOT';

            $opt['criteria'][3]['field'] = 12; // ticket status
            $opt['criteria'][3]['searchtype'] = 'equals';
            $opt['criteria'][3]['value'] = Ticket::CLOSED;
            $opt['criteria'][3]['link'] = 'AND NOT';

            $opt['criteria'][4]['field'] = 52; // global validation status
            $opt['criteria'][4]['searchtype'] = 'equals';
            $opt['criteria'][4]['value'] = CommonITILValidation::WAITING;
            $opt['criteria'][4]['link'] = 'AND';

            if (Session::getCurrentInterface() == "central") {
                $url = $CFG_GLPI["root_doc"] . "/front/ticket.php?" . Toolbox::append_params($opt, '&amp;');
            } else {
                $url = PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/front/ticket_validate.php";
            }

            $title = PluginServicecatalogConfig::displayField($config, 'title_your_tickets_to_validate');

            $menu['title'] = $title;
            $menu['page'] = $url;
            $menu['badge'] = $total_validate;
            if ($total_validate > 0) {
                $menu['style'] = "color:firebrick;font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands';";
            }
            if (!empty($widget->fields['fa_validation'])) {
                $icon = $widget->fields['fa_validation'];
                $menu['icon'] = "fas $icon fa-fw mr-3";
                $menu['style'] = "font-family:'Font Awesome 5 Free', 'Font Awesome 5 Brands'";
            }
            $menu['id'] = "ticketvalidation_bar";
        }
        return $menu;
    }


    /**
     * @param $showgrouptickets
     * @param $type
     * @param $itilcategories_id
     *
     * @return string
     */
    public
    static function queryYourTicketsInProgress($as_lists, $showgrouptickets, $type, $itilcategories_id = 0)
    {
        if (!Session::haveRightsOr(Ticket::$rightname, [CREATE, Ticket::READMY, ITILFollowup::SEEPUBLIC])) {
            return __('No data available', 'servicecatalog');
        }

        $search_users_id = "";
        $search_observer = "";
        $search_redactor = "";

        if (!$showgrouptickets) {
            $search_users_id = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "') ";
            $search_observer = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::OBSERVER . "')";
            $search_redactor = "`glpi_tickets`.`users_id_recipient` = '" . Session::getLoginUserID() . "' ";
        }
        $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

        if ($showgrouptickets) {
            if (count($_SESSION['glpigroups'])) {
                $groups = implode("','", $_SESSION['glpigroups']);

                $search_users_id .= "  (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::REQUESTER . "') ";

                $search_observer .= "  (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::OBSERVER . "') ";
            }
        }

        $query = "SELECT DISTINCT `glpi_tickets`.`id`
                FROM `glpi_tickets`
                LEFT JOIN `glpi_tickets_users`
                     ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`) ";

        if (!$showgrouptickets) {
            $query .= "WHERE $is_deleted
                             AND ( $search_users_id OR $search_observer OR $search_redactor) ";
        } else {
            $query .= "WHERE $is_deleted
                             AND ( $search_users_id OR $search_observer) ";
        }
        if ($type > 0) {
            $query .= "AND `glpi_tickets`.`type` = '" . $type . "' ";
        }
        if ($itilcategories_id > 0) {
            $query .= "AND `glpi_tickets`.`itilcategories_id` = '" . $itilcategories_id . "' ";
        }
        $dbu = new DbUtils();
        $query .= "AND `glpi_tickets`.`status` NOT IN ('" . Ticket::CLOSED . "',
                                                                         '" . Ticket::SOLVED . "') " .
            $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $query .= " ORDER BY `glpi_tickets`.`date` DESC";

        if ($as_lists == 0) {
            $config = new PluginServicecatalogConfig();
            $nbrows = $config->getDefaultNumberRows();
            $query .= " LIMIT $nbrows";
        }
        return $query;
    }


    /**
     * @return string
     */
    public
    static function queryYourTicketsToValidate($as_lists)
    {
        $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

        $query = "SELECT DISTINCT `glpi_tickets`.`id`
                FROM `glpi_tickets`
                LEFT JOIN `glpi_tickets_users`
                     ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`)
                LEFT JOIN `glpi_ticketvalidations`
                                 ON (`glpi_tickets`.`id` = `glpi_ticketvalidations`.`tickets_id`)";

        $query .= "WHERE $is_deleted
                             AND `users_id_validate` = '" . Session::getLoginUserID() . "' ";

        $query .= "AND `glpi_ticketvalidations`.`status` = '" . CommonITILValidation::WAITING . "' ";
        $query .= "AND `glpi_tickets`.`global_validation` = '" . CommonITILValidation::WAITING . "' ";
        $dbu = new DbUtils();
        $query .= "AND `glpi_tickets`.`status` NOT IN ('" . Ticket::CLOSED . "',
                                                                         '" . Ticket::SOLVED . "') " .
            $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $query .= " ORDER BY `glpi_tickets`.`date` DESC";

        if ($as_lists == 0) {
            $config = new PluginServicecatalogConfig();
            $nbrows = $config->getDefaultNumberRows();
            $query .= " LIMIT $nbrows";
        }

        return $query;
    }

    /**
     * @param $showgrouptickets
     *
     * @return string
     */
    public
    static function queryYourTicketsToClose($as_lists, $showgrouptickets)
    {
        $search_users_id = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "') ";
        $search_observer = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::OBSERVER . "')";
        $search_redactor = "`glpi_tickets`.`users_id_recipient` = '" . Session::getLoginUserID() . "' ";
        $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

        if ($showgrouptickets) {
            if (count($_SESSION['glpigroups'])) {
                $groups = implode("','", $_SESSION['glpigroups']);

                if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                    $search_users_id .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::REQUESTER . "') ";
                }

                if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                    $search_observer .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::OBSERVER . "') ";
                }
            }
        }

        $query = "SELECT DISTINCT `glpi_tickets`.`id`
                FROM `glpi_tickets`
                LEFT JOIN `glpi_tickets_users`
                     ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`)";

        $dbu = new DbUtils();
        $query .= "WHERE $is_deleted
                             AND ( $search_users_id OR $search_observer OR $search_redactor)
                             AND `glpi_tickets`.`status` = '" . Ticket::SOLVED . "' " .
            $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $query .= " ORDER BY `glpi_tickets`.`date` DESC";

        if ($as_lists == 0) {
            $config = new PluginServicecatalogConfig();
            $nbrows = $config->getDefaultNumberRows();
            $query .= " LIMIT $nbrows";
        }

        return $query;
    }

    /**
     * @param $showgrouptickets
     *
     * @return string
     */
    public
    static function queryYourClosedTickets($as_lists, $showgrouptickets)
    {
        $search_users_id = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "') ";
        $search_observer = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::OBSERVER . "')";
        $search_redactor = "`glpi_tickets`.`users_id_recipient` = '" . Session::getLoginUserID() . "' ";
        $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

        if ($showgrouptickets) {
            if (count($_SESSION['glpigroups'])) {
                $groups = implode("','", $_SESSION['glpigroups']);

                if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                    $search_users_id .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::REQUESTER . "') ";

                    if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                        $search_observer .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::OBSERVER . "') ";
                    }
                }
            }
        }

        $query = "SELECT DISTINCT `glpi_tickets`.`id`
                FROM `glpi_tickets`
                LEFT JOIN `glpi_tickets_users`
                     ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`)";

        $dbu = new DbUtils();
        $query .= "WHERE $is_deleted
                             AND ( $search_users_id OR $search_observer OR $search_redactor)
                             AND `glpi_tickets`.`status` = '" . Ticket::CLOSED . "' " .
            $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $query .= " ORDER BY `glpi_tickets`.`date` DESC";

        if ($as_lists == 0) {
            $config = new PluginServicecatalogConfig();
            $nbrows = $config->getDefaultNumberRows();
            $query .= " LIMIT $nbrows";
        }

        return $query;
    }


    /**
     * @param $showgrouptickets
     *
     * @return string
     */
    public
    static function queryYourSatisfactionSurveys($as_lists, $showgrouptickets)
    {
        $search_users_id = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "') ";
        $search_observer = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::OBSERVER . "')";
        $search_redactor = "`glpi_tickets`.`users_id_recipient` = '" . Session::getLoginUserID() . "' ";
        $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

        if ($showgrouptickets) {
            if (count($_SESSION['glpigroups'])) {
                $groups = implode("','", $_SESSION['glpigroups']);

                if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                    $search_users_id .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::REQUESTER . "') ";

                    if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
                        $search_observer .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::OBSERVER . "') ";
                    }
                }
            }
        }

        $query = "SELECT DISTINCT `glpi_tickets`.`id`
                FROM `glpi_tickets`
                LEFT JOIN `glpi_tickets_users`
                     ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`)
                INNER JOIN `glpi_ticketsatisfactions`
                     ON (`glpi_tickets`.`id` = `glpi_ticketsatisfactions`.`tickets_id`)
                INNER JOIN `glpi_entities`
                     ON (`glpi_tickets`.`entities_id` = `glpi_entities`.`id`)";

        $dbu = new DbUtils();
        $query .= "WHERE $is_deleted
                             AND ( $search_users_id OR $search_observer OR $search_redactor)
                             AND `glpi_tickets`.`status` = '" . Ticket::CLOSED . "' 
                             AND `glpi_ticketsatisfactions`.`date_answered` is null 
                              AND (`glpi_entities`.`inquest_duration` = 0
                              OR DATEDIFF(ADDDATE(`glpi_ticketsatisfactions`.`date_begin`, INTERVAL
                                           `glpi_entities`.`inquest_duration` DAY),CURDATE() )> 0)" .
            $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $query .= " ORDER BY `glpi_tickets`.`date` DESC";

        if ($as_lists == 0) {
            $config = new PluginServicecatalogConfig();
            $nbrows = $config->getDefaultNumberRows();
            $query .= " LIMIT $nbrows";
        }

        return $query;
    }

    /**
     * Get all languages for a specific library
     *
     * @return array $languages
     * @internal param string $name name of the library :
     *    Currently available :
     *        sDashboard (for Datatable),
     *        mydashboard (for our own)
     */
    public
    static function getJsLanguages()
    {
        $languages = [];
        $languages['sEmptyTable'] = __('No data available in table', 'servicecatalog');
        $languages['sInfo'] = __('Showing _START_ to _END_ of _TOTAL_ entries', 'servicecatalog');
        $languages['sInfoEmpty'] = __('Showing 0 to 0 of 0 entries', 'servicecatalog');
        $languages['sInfoFiltered'] = __('(filtered from _MAX_ total entries)', 'servicecatalog');
        $languages['sInfoPostFix'] = __('');
        $languages['sInfoThousands'] = __(',');
        $languages['sLengthMenu'] = __('Show _MENU_ entries', 'servicecatalog');
        $languages['sLoadingRecords'] = __('Loading') . "...";
        $languages['sProcessing'] = __('Processing') . "...";
        $languages['sSearch'] = __('Search') . ":";
        $languages['sZeroRecords'] = __('No matching records found', 'servicecatalog');
        $languages['oPaginate'] = [
            'sFirst' => __('First', "servicecatalog"),
            'sLast' => __('Last', "servicecatalog"),
            'sNext' => " " . __('Next', "servicecatalog"),
            'sPrevious' => __('Previous', "servicecatalog")
        ];
        $languages['oAria'] = [
            'sSortAscending' => __(': activate to sort column ascending', 'servicecatalog'),
            'sSortDescending' => __(': activate to sort column descending', 'servicecatalog')
        ];
        $languages['close'] = __("Close", "servicecatalog");
        $languages['maximize'] = __("Maximize", "servicecatalog");
        $languages['minimize'] = __("Minimize", "servicecatalog");
        $languages['refresh'] = __("Refresh", "servicecatalog");

        $languages['buttons'] = [
            'colvis' => __('Column visibility', 'servicecatalog'),
            'pageLength' => __('Show %d rows', 'servicecatalog'),
        ];

        $languages['select'] = [
            'rows' => __('%d rows selected', 'servicecatalog'),
        ];

        return $languages;
    }

    /**
     * @param $table
     * @param $headers
     * @param $output
     *
     * @return string
     */
    public
    static function getTableHeader($table, $entities_id, $type = 0, $showgroup = 0)
    {
        $languages = json_encode(self::getJsLanguages());
        $colReorder = 1;
        $btn = "";
        if (Session::haveRight("plugin_servicecatalog_view", CREATE) ||
            Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $colReorder = 1;
            $btn = "'colvis',
                              {
                                  extend: 'collection',
                                  text: 'Export',
                                  buttons: [
                                      'copy',
                                      'excel',
                                      'csv',
                                      'pdf',
                                      'print',
                                  ]
                              }";
        }
        $root_doc = PLUGIN_SERVICECATALOG_WEBDIR;
        $config = new PluginServicecatalogConfig();
        $nbrows = $config->getDefaultNumberRows();

        $stateSave = true;
        $widget = "<script type='text/javascript'>
//         setTimeout(function () {

        $(document).ready(
            function() {
                $('#$table$type$showgroup').DataTable(
                    {
                        'pageLength': $nbrows,
                        lengthMenu: [
                            [3, 5, 10, 25, 50, 100],
                            [3, 5, 10, 25, 50, 100],
                        ],
                        'stateSave': $stateSave,
                        'stateSaveParams': function (settings, data) {
                          data.type = $type;
                          data.entities_id = $entities_id;
                        }, 
                        'stateSaveCallback': function (settings, data) {
                            // Send an Ajax request to the server with the state object
                            
                            $.ajax({
                               'url': '$root_doc/ajax/state_save.php',
                               'data': data,
                               'dataType': 'json',
                               'type': 'POST',
                               'success': function(response) {
                               },
                               'error': function(response) {
                               }
                            });
                       },
                       'stateLoadCallback': function (settings, callback) {
                        $.ajax({
                            url: '$root_doc/ajax/state_load.php?type={$type}&entities_id={$entities_id}',
                            dataType: 'json',
                            success: function (json) {
                                json.time = +new Date();   
                                callback(json);
                            },
                            error: function () {
                                callback(null);
                            }
                        })
                       },
                       'colReorder': $colReorder,
                       rowReorder: {
                         selector: 'td:nth-child(2)'
                       },
                       responsive: true,
                       'language': $languages,
                       dom: 'Bfrtip',
                       select: true,
                       buttons: [
                          $btn,
                          'pageLength'
                       ]
                    }
                );
            }
        );
         //         }, 1000);
        </script>";

        return $widget;
    }

    /**
     * @param $table
     * @param $output
     *
     * @return string
     */
    public
    static function getTabledisplay($table, $output, $type = 0, $showgroup = 0)
    {
        $config = new PluginServicecatalogConfig();
        $columns = json_decode($config->fields["columns_for_table"], true);
        if (count($columns) == 0) {
            $columns = self::getListColumnsForTable();
        }
        $widget = '<table id="' . $table . $type . $showgroup . '" 
      class="display responsive" cellspacing="0" width="100%" data-order=\'[[ 1, "desc" ]]\'>';

        $widget .= '<thead>';
        $widget .= '<tr>';
        foreach ($columns as $th) {
            $widget .= '<th>' . self::getColumnsName($th) . '</th>';
        }
        $widget .= '</tr>';
        $widget .= '</thead><tfoot><tr>';
        foreach ($columns as $th) {
            $widget .= '<th>' . self::getColumnsName($th) . '</th>';
        }
        $widget .= '</tr></tfoot>';
        $widget .= ' <tbody>';

        foreach ($output as $id => $data) {
            $widget .= '<tr>';
            for ($i = 0; $i < self::NBCOLUMNS; $i++) {
                if (array_search($i, $columns) !== false && isset($data[$i])) {
                    $widget .= '<td>' . $data[$i] . '</td>';
                }
            }
            $widget .= '</tr>';
        }
        $widget .= '</tbody>';
        $widget .= '</table>';

        return $widget;
    }

    /**
     * @param $table
     * @param $output
     *
     * @return string
     */
    public
    static function getBubbledisplay($tablename, $output, $type, $list)
    {
        $widget = "<table id='" . $tablename . "' class='responsive tab_cadre' width='100%' >";

        $widget .= "<tbody>";
        foreach ($output as $id => $data) {
            $widget .= "<tr>";
            $widget .= "<td>";
            $widget .= "<table class='tab_cadre bubble'>";
            $widget .= "<tr>";
            $widget .= "<td class='left' rowspan='3' style='background-color: " . $data[7] . ";width: 10px;'>";
            $widget .= "</td>";

            $widget .= "<td class='left' colspan='3' style='border: 0;'>";
            $widget .= "<span style='font-weight: bold'>" . $data[5] . "</span>";// $data[6]
            $widget .= "</td>";
            $widget .= "</tr>";

            $widget .= "<tr>";
            $widget .= "<td class='left' style='border: 0;'>";
            $widget .= "<span style='color:#a2a2a2;'>" . __('Category') . " : </span>";
            $widget .= $data[8] ?? "N/A";
            if ($data[9] == Ticket::DEMAND_TYPE) {
                $widget .= "<br><span style='color:#a2a2a2;'>" . __('Request made by', 'servicecatalog') . " </span>";
            } else {
                $widget .= "<br><span style='color:#a2a2a2;'>" . __('Incident reported by', 'servicecatalog') . " </span>";
            }
            $widget .= $data[2];
            $widget .= "<span style='color:#a2a2a2;'> " . __('the', 'servicecatalog') . " </span>";
            $widget .= Html::convDateTime($data[1]);
            $widget .= "</td>";

            $widget .= "<td class='right' style='border: 0;'>";
            $widget .= $data[3];
            $widget .= "<br><span style='color:#a2a2a2;'>" . __('Assigned to') . " : </span>";
            $widget .= $data[10] ?? "N/A";
            $widget .= "</td>";

            $widget .= "</tr>";

            $widget .= "</table>";

            $widget .= "</td>";

            $widget .= "</tr>";
        }
        $widget .= "</tbody>";
        $widget .= "</table>";

        if ($list == "IncidentsGroup"
            || $list == "RequestsGroup"
            || $list == "YourTickets"
            || $list == "Incidents"
            || $list == "Requests") {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php?type=$type";
        } elseif ($list == "old") {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/resolved_ticket.php";
        } elseif ($list == "validate") {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket_validate.php";
        } elseif ($list == "closed") {
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/closed_ticket.php";
        } else {
            $url = '';
        }
        if ($list != "satisfaction") {
            $widget .= "<a href='" . $url . "' class='btn pull-right'>" . __('See complete list', 'servicecatalog') . "</a>";
        }

        return $widget;
    }


    /**
     * @param $ID
     * @param $forcetab  string   name of the tab to force at the display (default '')
     *
     * @return array
     */
    public
    static function showVeryShort($ID, $forcetab)
    {
        $colnum = 0;
        $output = [];
        $dbu = new DbUtils();

        // Prints a job in short form
        // Should be called in a <table>-segment
        // Print links or not in case of user view
        // Make new job object and fill it from database, if success, print it
        $showprivate = Session::haveRight("show_full_ticket", 1);

        $job = new Ticket();
        $rand = mt_rand();
        $config = new PluginServicecatalogConfig();
        $columns = json_decode($config->fields["columns_for_table"], true);
        if (count($columns) == 0) {
            $columns = self::getListColumnsForTable();
        }
        if ($job->getFromDBwithData($ID, 0)) {
            $bgcolor = $_SESSION["glpipriority_" . $job->fields["priority"]];

            $link = "<a id='ticket" . $job->fields["id"] . $rand . "' href='" . PLUGIN_SERVICECATALOG_WEBDIR .
                "/front/ticket.form.php?id=" . $job->fields["id"];
            if ($forcetab != '') {
                $link .= "&amp;forcetab=" . $forcetab;
            }
            $link .= "'>";
            $textColor = "color:black!important;";
            if ($bgcolor == '#000000') {
                $textColor = "color:white!important;";
            }
            //0
            if (array_search(self::ID_PRIORITY, $columns) !== false) {
                $colnum = self::ID_PRIORITY;
                $output[$colnum] = '';
                $output[$colnum] = "<div class='center' style='background-color:$bgcolor; padding: 10px;'>" .
                    $link . "<span class='b' style='$textColor'>" . __('ID') . " : " . $job->fields["id"] . "</span></a>" . "</div>";
                $colnum++;

            }
            //1
            if (array_search(self::DATE, $columns) !== false) {
                $colnum = self::DATE;
                $output[$colnum] = '';
                $output[$colnum] = "<div class='center'>" . $job->fields["date"] . "</div>";
                $colnum++;
            }
            //2
            if (array_search(self::REQUESTER, $columns) !== false) {
                $colnum = self::REQUESTER;
                $output[$colnum] = '';
                $userrequesters = $job->getUsers(CommonITILActor::REQUESTER);
                if (isset($userrequesters)
                    && count($userrequesters)
                ) {
                    foreach ($userrequesters as $d) {
                        if ($d["users_id"] > 0) {
                            $userdata = getUserName($d["users_id"], 2);
                            $name = "<div class='b center'>" . $userdata['name'];
                            //                  $name     = sprintf(__('%1$s %2$s'), $name,
                            //                                      Html::showToolTip($userdata["comment"],
                            //                                                        array('link'    => $userdata["link"],
                            //                                                              'display' => false)));

                            $output[$colnum] .= $name . "</div>";
                        } else {
                            $output[$colnum] .= $d['alternative_email'] . "&nbsp;";
                        }

                        $output[$colnum] .= "<br>";
                    }
                }
                $grouprequester = $job->getGroups(CommonITILActor::REQUESTER);
                if (isset($grouprequester)
                    && count($grouprequester)
                ) {
                    foreach ($grouprequester as $d) {
                        $output[$colnum] .= Dropdown::getDropdownName("glpi_groups", $d["groups_id"]) . "<br>";
                    }
                }

                $colnum++;
            }
            //3
            if (array_search(self::STATUS, $columns) !== false) {
                $colnum = self::STATUS;
                $output[$colnum] = '';
                $output[$colnum] = "<div class='center'>" . Ticket::getStatus($job->fields["status"]) . "</div>";

                $colnum++;
            }
            //4
            if (array_search(self::ITEM, $columns) !== false) {
                $colnum = self::ITEM;
                $output[$colnum] = '';
                if (!empty($job->hardwaredatas)) {
                    foreach ($job->hardwaredatas as $hardwaredatas) {
                        if ($hardwaredatas->canView()) {
                            $output[$colnum] .= $hardwaredatas->getTypeName() . " - ";
                            $output[$colnum] .= "<span class='b'>" . $hardwaredatas->getLink() . "</span><br/>";
                        } elseif ($hardwaredatas) {
                            $output[$colnum] .= $hardwaredatas->getTypeName() . " - ";
                            $output[$colnum] .= "<span class='b'>" . $hardwaredatas->getNameID() . "</span><br/>";
                        }
                    }
                } else {
                    $output[$colnum] .= __('General');
                }

                $colnum++;
            }
            //5
            if (array_search(self::TITLE, $columns) !== false) {
                $colnum = self::TITLE;
                $output[$colnum] = '';
                $description = sprintf(
                    __('%1$s (%2$s)'),
                    $link . $job->getNameID() . "</a>",
                    sprintf(
                        __('%1$s - %2$s'),
                        $job->numberOfFollowups($showprivate),
                        $job->numberOfTasks($showprivate)
                    )
                );
                $output[$colnum] = $description;

                $colnum++;
            }
            //6
            if (array_search(self::ID, $columns) !== false) {
                $colnum = self::ID;
                $output[$colnum] = '';
                $link = "<a id='ticket" . $job->fields["id"] . $rand . "' href='" . PLUGIN_SERVICECATALOG_WEBDIR .
                    "/front/ticket.form.php?id=" . $job->fields["id"];
                if ($forcetab != '') {
                    $link .= "&amp;forcetab=" . $forcetab;
                }
                $link .= "'>";
                $output[$colnum] = $link . "<span class='b'>" . $job->fields["id"] . "</span></a>";

                $colnum++;
            }
            //7
            if (array_search(self::PRIORITY, $columns) !== false) {
                $colnum = self::PRIORITY;
                $output[$colnum] = '';
                $bgcolor = $_SESSION["glpipriority_" . $job->fields["priority"]];


                $output[$colnum] = "<div class='center' style='background-color:$bgcolor; padding: 10px;$textColor'>
                                <span>" . $job->fields["priority"] . " - " . Ticket::getPriorityName($job->fields["priority"]) . "</span>
                             </div>";

                $colnum++;
            }
            //8
            if (array_search(self::CATEGORY, $columns) !== false) {
                $colnum = self::CATEGORY;
                $output[$colnum] = '';
                $output[$colnum] = '';
                $config = new PluginServicecatalogConfig();
                $config->getFromDB(1);
                $itilCategory = new ITILCategory();
                $itilCategory->getFromDB($job->fields['itilcategories_id']);

                $helpdesk_category = new PluginServicecatalogCategory();
                if ($helpdesk_category->getFromDBByCategory($itilCategory->getID())) {
                    if ($job->fields['type'] == Ticket::INCIDENT_TYPE) {
                        $haystack = PluginServicecatalogCategory::displayField($helpdesk_category, 'simplified_name_incident');
                    } else {
                        $haystack = PluginServicecatalogCategory::displayField($helpdesk_category, 'simplified_name_request');
                    }
                }
                if (empty($haystack)) {
                    $haystack = Dropdown::getDropdownName('glpi_itilcategories', $itilCategory->getID());
                }

                $needle = '>';
                $offset = 0;
                $allpos = [];

                while (($pos = strpos($haystack, $needle, $offset)) !== false) {
                    $offset = $pos + 1;
                    $allpos[] = $pos;
                }

                if (isset($allpos[$config->getField('levelCat') - 1])) {
                    $pos = $allpos[$config->getField('levelCat') - 1];
                } else {
                    $pos = strlen($haystack);
                }
                $output[$colnum] = substr($haystack, 0, $pos);

                $colnum++;
            }
            //9
            if (array_search(self::TYPE, $columns) !== false) {
                $colnum = self::TYPE;
                $output[$colnum] = '';
                $output[$colnum] = Ticket::getTicketTypeName($job->fields["type"]);

                $colnum++;
            }
            //10
            if (array_search(self::ASSIGNED, $columns) !== false) {
                $colnum = self::ASSIGNED;
                $output[$colnum] = '';

                $entity = $job->getEntityID();
                $anonymize_helpdesk = Entity::getUsedConfig('anonymize_support_agents', $entity);

                if ($anonymize_helpdesk) {
                } else {
                    $grouptechs = $job->getGroups(CommonITILActor::ASSIGN);
                    if (isset($grouptechs)
                        && count($grouptechs)
                    ) {
                        foreach ($grouptechs as $d) {
                            $output[$colnum] .= Dropdown::getDropdownName("glpi_groups", $d["groups_id"]) . "<br>";
                        }
                    }
                }
                $colnum++;
            }
            //11
            if (array_search(self::TTR, $columns) !== false) {
                $colnum = self::TTR;
                $output[$colnum] = '';
                $output[$colnum] = $job->fields['time_to_resolve'];

                $colnum++;
            }
            //12
            if (array_search(self::ENTITY, $columns) !== false) {
                $colnum = self::ENTITY;
                $output[$colnum] = '';
                $entity = new Entity();
                $entity->getFromDB($job->fields['entities_id']);
                $output[$colnum] = $entity->fields['name'];
            }
            //13
            if (array_search(self::ASSIGNED_TECH, $columns) !== false) {
                $colnum = self::ASSIGNED_TECH;
                $output[$colnum] = '';

                $entity = $job->getEntityID();
                $anonymize_helpdesk = Entity::getUsedConfig('anonymize_support_agents', $entity);

                if ($anonymize_helpdesk) {
                    $output[$colnum] .= __("Helpdesk");
                    $output[$colnum] .= "<br>";
                } else {
                    $usertechs = $job->getUsers(CommonITILActor::ASSIGN);
                    if (isset($usertechs)
                        && count($usertechs)
                    ) {
                        foreach ($usertechs as $d) {
                            if ($d["users_id"] > 0) {
                                $userdata = $dbu->getUserName($d["users_id"], 2);
                                $name = "<div class='b center'>" . $userdata['name'];
                                //                  $name     = sprintf(__('%1$s %2$s'), $name,
                                //                                      Html::showToolTip($userdata["comment"],
                                //                                                        array('link'    => $userdata["link"],
                                //                                                              'display' => false)));

                                $output[$colnum] .= $name . "</div>";
                            } else {
                                $output[$colnum] .= $d['alternative_email'] . "&nbsp;";
                            }

                            $output[$colnum] .= "<br>";
                        }
                    }
                }

                $colnum++;
            }
        }

        return $output;
    }


    /**
     * @param $ID
     * @param $forcetab  string   name of the tab to force at the display (default '')
     *
     * @return array
     */
    public
    static function showVeryShortForBubble($ID, $forcetab)
    {
        $colnum = 0;
        $output = [];
        $dbu = new DbUtils();

        // Prints a job in short form
        // Should be called in a <table>-segment
        // Print links or not in case of user view
        // Make new job object and fill it from database, if success, print it
        $showprivate = Session::haveRight("show_full_ticket", 1);

        $job = new Ticket();
        $rand = mt_rand();
        if ($job->getFromDBwithData($ID, 0)) {
            $bgcolor = $_SESSION["glpipriority_" . $job->fields["priority"]];

            $link = "<a id='ticket" . $job->fields["id"] . $rand . "' href='" . PLUGIN_SERVICECATALOG_WEBDIR .
                "/front/ticket.form.php?id=" . $job->fields["id"];
            if ($forcetab != '') {
                $link .= "&amp;forcetab=" . $forcetab;
            }
            $link .= "'>";
            $textColor = "color:black!important;";
            if ($bgcolor == '#000000') {
                $textColor = "color:white!important;";
            }
            $output[$colnum] = "<div class='center' style='background-color:$bgcolor; padding: 10px;'>" .
                $link . "<span class='b' style='$textColor'>" . __('ID') . " : " . $job->fields["id"] . "</span></a>" . "</div>";

            $colnum++;
            $output[$colnum] = $job->fields["date"];

            $colnum++;
            $output[$colnum] = '';

            $userrequesters = $job->getUsers(CommonITILActor::REQUESTER);
            if (isset($userrequesters)
                && count($userrequesters)
            ) {
                foreach ($userrequesters as $d) {
                    if ($d["users_id"] > 0) {
                        $userdata = getUserName($d["users_id"], 2);
                        $name = $userdata['name'];
                        //                  $name     = sprintf(__('%1$s %2$s'), $name,
                        //                                      Html::showToolTip($userdata["comment"],
                        //                                                        array('link'    => $userdata["link"],
                        //                                                              'display' => false)));

                        $output[$colnum] .= $name;
                    } else {
                        $output[$colnum] .= $d['alternative_email'] . "&nbsp;";
                    }

                    //                    $output[$colnum] .= "<br>";
                }
            }
            $grouprequester = $job->getGroups(CommonITILActor::REQUESTER);
            if (isset($grouprequester)
                && count($grouprequester)
            ) {
                foreach ($grouprequester as $d) {
                    $output[$colnum] .= "<br>" . Dropdown::getDropdownName("glpi_groups", $d["groups_id"]) . "<br>";
                }
            }

            $colnum++;
            $output[$colnum] = '';
            $output[$colnum] = Ticket::getStatus($job->fields["status"]);

            $colnum++;
            $output[$colnum] = '';
            if (!empty($job->hardwaredatas)) {
                foreach ($job->hardwaredatas as $hardwaredatas) {
                    if ($hardwaredatas->canView()) {
                        $output[$colnum] .= $hardwaredatas->getTypeName() . " - ";
                        $output[$colnum] .= "<span class='b'>" . $hardwaredatas->getLink() . "</span><br/>";
                    } elseif ($hardwaredatas) {
                        $output[$colnum] .= $hardwaredatas->getTypeName() . " - ";
                        $output[$colnum] .= "<span class='b'>" . $hardwaredatas->getNameID() . "</span><br/>";
                    }
                }
            } else {
                $output[$colnum] .= __('General');
            }

            $colnum++;

            //            $description     = sprintf(
            //                __('%1$s (%2$s)'),
            //                $link . $job->getNameID() . "</a>",
            //                sprintf(
            //                    __('%1$s - %2$s'),
            //                    $job->numberOfFollowups($showprivate),
            //                    $job->numberOfTasks($showprivate)
            //                )
            //            );
            $output[$colnum] = $link . $job->getNameID();

            //Ticket ID
            $colnum++;
            $link = "<a id='ticket" . $job->fields["id"] . $rand . "' href='" . PLUGIN_SERVICECATALOG_WEBDIR .
                "/front/ticket.form.php?id=" . $job->fields["id"];
            if ($forcetab != '') {
                $link .= "&amp;forcetab=" . $forcetab;
            }
            $link .= "'>";
            $output[$colnum] = $link . "<span class='b'>" . $job->fields["id"] . "</span></a>";

            //Priority
            $colnum++;
            $bgcolor = $_SESSION["glpipriority_" . $job->fields["priority"]];


            $output[$colnum] = $bgcolor;

            //Categories
            $colnum++;
            $output[$colnum] = '';
            $config = new PluginServicecatalogConfig();
            $config->getFromDB(1);
            $itilCategory = new ITILCategory();
            $itilCategory->getFromDB($job->fields['itilcategories_id']);

            $helpdesk_category = new PluginServicecatalogCategory();
            if ($helpdesk_category->getFromDBByCategory($itilCategory->getID())) {
                if ($job->fields['type'] == Ticket::INCIDENT_TYPE) {
                    $haystack = PluginServicecatalogCategory::displayField($helpdesk_category, 'simplified_name_incident');
                } else {
                    $haystack = PluginServicecatalogCategory::displayField($helpdesk_category, 'simplified_name_request');
                }
            }
            if (empty($haystack)) {
                $haystack = Dropdown::getDropdownName('glpi_itilcategories', $itilCategory->getID());
            }

            $needle = '>';
            $offset = 0;
            $allpos = [];

            while (($pos = strpos($haystack, $needle, $offset)) !== false) {
                $offset = $pos + 1;
                $allpos[] = $pos;
            }

            if (isset($allpos[$config->getField('levelCat') - 1])) {
                $pos = $allpos[$config->getField('levelCat') - 1];
            } else {
                $pos = strlen($haystack);
            }
            $output[$colnum] = substr($haystack, 0, $pos);
            $colnum++;
            $output[$colnum] = $job->fields["type"];
            $colnum++;
            $output[$colnum] = '';

            $entity = $job->getEntityID();
            $anonymize_helpdesk = Entity::getUsedConfig('anonymize_support_agents', $entity);

            if ($anonymize_helpdesk) {
                $output[$colnum] .= __("Helpdesk");
                $output[$colnum] .= "<br>";
            } else {
                $usertechs = $job->getUsers(CommonITILActor::ASSIGN);
                if (isset($usertechs)
                    && count($usertechs)
                ) {
                    foreach ($usertechs as $d) {
                        if ($d["users_id"] > 0) {
                            $userdata = $dbu->getUserName($d["users_id"], 2);
                            $name = "<span class='b center'>" . $userdata['name'];
                            //                  $name     = sprintf(__('%1$s %2$s'), $name,
                            //                                      Html::showToolTip($userdata["comment"],
                            //                                                        array('link'    => $userdata["link"],
                            //                                                              'display' => false)));

                            $output[$colnum] .= $name . "</div>";
                        } else {
                            $output[$colnum] .= $d['alternative_email'] . "&nbsp;";
                        }

                        $output[$colnum] .= "<br>";
                    }
                }
            }
            if ($anonymize_helpdesk) {
            } else {
                $grouptechs = $job->getGroups(CommonITILActor::ASSIGN);
                if (isset($grouptechs)
                    && count($grouptechs)
                ) {
                    foreach ($grouptechs as $d) {
                        $output[$colnum] .= Dropdown::getDropdownName("glpi_groups", $d["groups_id"]) . "<br>";
                    }
                }
            }
            $colnum++;
            $output[$colnum] = Html::convDateTime($job->fields['time_to_resolve']);

            $colnum++;
            $entity = new Entity();
            $entity->getFromDB($job->fields['entities_id']);
            $output[$colnum] = $entity->fields['name'];
        }
        return $output;
    }


    /**
     * @param      $entities_id
     * @param      $type
     *
     * @param bool $showgroup
     *
     * @param int $itilcategories_id
     *
     * @return string
     * @throws \GlpitestSQLError
     */
    public
    static function getYourTickets($widgetname, $list, $as_lists, $entities_id, $type = 0, $showgroup = true, $toppage = false, $itilcategories_id = 0)
    {
        global $DB;

        $config = new PluginServicecatalogConfig();
        $config->getFromDB(1);

        $showgrouptickets = false;
        if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
            if ($showgroup) {
                $showgrouptickets = true;
            }
        }
        //title case
        if ($list == "IncidentsGroup") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_and_group_open_incidents');
        } elseif ($list == "RequestsGroup") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_and_group_open_requests');
        } elseif ($list == "YourTickets") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_open_tickets');
        } elseif ($list == "Incidents") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_open_incidents');
        } elseif ($list == "Requests") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_open_requests');
        } elseif ($list == "old") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_resolved_tickets');
        } elseif ($list == "validate") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_tickets_to_validate');
        } elseif ($list == "closed") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_closedtickets_menu');
        } elseif ($list == "satisfaction") {
            $title = __("Satisfaction") . " : " . __("Invitation to fill out the survey");
        }

        //right case

        if ($list == "IncidentsGroup") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_and_group_open_incidents');
        } elseif ($list == "RequestsGroup") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_and_group_open_requests');
        } elseif ($list == "YourTickets") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_open_tickets');
        } elseif ($list == "Incidents") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_open_incidents');
        } elseif ($list == "Requests") {
            $title = PluginServicecatalogConfig::displayField($config, 'title_your_open_requests');
        }


        if ($list == "validate") {
            if (!Session::haveRightsOr('ticketvalidation', TicketValidation::getValidateRights())) {

                $display = false;
                return $display;

//                if ($toppage == 1) {
//                    $widget = PluginServicecatalogWidget::getPageTitle($title);
//                } else {
//                    $widget = PluginServicecatalogWidget::getWidgetTitle($title);
//                }
//
//                $widget .= "<div class='alert alert-info' role='alert'>";
//                $widget .= __('No data available', 'servicecatalog');
//                $widget .= "</div>";
//                return $widget;
            }
            $query = self::queryYourTicketsToValidate($as_lists);
            $result = $DB->query($query);
            $numrows = $DB->numrows($result);
            if ($numrows == 0) {
                $display = false;
                return $display;
            }
        } else {
            if (!Session::haveRightsOr(Ticket::$rightname, [CREATE, Ticket::READMY, ITILFollowup::SEEPUBLIC])) {
                if ($toppage == 1) {
                    $widget = PluginServicecatalogWidget::getPageTitle($title);
                } else {
                    $widget = PluginServicecatalogWidget::getWidgetTitle($title);
                }

                $widget .= "<div class='alert alert-info' role='alert'>";
                $widget .= __('No data available', 'servicecatalog');
                $widget .= "</div>";
                return $widget;
            }
        }

        //table name
        if ($as_lists) {
            $widget = self::getTableHeader($list, $entities_id, $type, $showgroup);
        } else {
            $widget = "";
        }

        //query
        if ($list == "IncidentsGroup"
            || $list == "RequestsGroup"
            || $list == "YourTickets"
            || $list == "Incidents"
            || $list == "Requests"
        ) {
            $query = self::queryYourTicketsInProgress($as_lists, $showgrouptickets, $type, $itilcategories_id);
        } elseif ($list == "old") {
            $query = self::queryYourTicketsToClose($as_lists, $showgrouptickets);
        } elseif ($list == "validate") {
            $query = self::queryYourTicketsToValidate($as_lists);
        } elseif ($list == "closed") {
            $query = self::queryYourClosedTickets($as_lists, $showgrouptickets);
        } elseif ($list == "satisfaction") {
            $query = self::queryYourSatisfactionSurveys($as_lists, $showgrouptickets);
        }
        $result = $DB->query($query);
        $numrows = $DB->numrows($result);
        //forcetab
        if ($list == "IncidentsGroup"
            || $list == "RequestsGroup"
            || $list == "YourTickets"
            || $list == "Incidents"
            || $list == "Requests") {
            $forcetab = '';
        } elseif ($list == "old" || $list == "closed") {
            $forcetab = 'Ticket$1';
        } elseif ($list == "validate") {
            $forcetab = 'TicketValidation$1';
        } elseif ($list == "satisfaction") {
            $forcetab = 'Ticket$3';
        }
        $output = [];
        Session::initNavigateListItems('Ticket');

        if ($numrows > 0) {
            for ($i = 0; $i < $numrows; $i++) {
                $ID = $DB->result($result, $i, "id");
                if ($as_lists) {
                    $output[$i] = self::showVeryShort($ID, $forcetab);
                } else {
                    $output[$i] = self::showVeryShortForBubble($ID, $forcetab);
                }
                Session::addToNavigateListItems('Ticket', $ID);
            }
        }

        $class = "bt-col-md-12";
        $delclass = "";
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $delclass = "delclass";
        }
//        $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?id=";
//        $name = "$list$type$showgroup";

//        $widget .= Html::scriptBlock("
//
//                $(document).ready(function () {
//                        var table = $('#$name').DataTable();
//
//                        $('#$name tbody').on('click', 'tr', function () {
//                            var data = table.row(this).data();
//                            alert('You clicked on ' + data[0]);
//                    //        window.location.href = '$url' + data[0];
//                        });
//                    });
//                ");

        //widget id
        $widget .= "<div id='$widgetname' class=\"bt-row sc-content  $delclass\">";

        $widget .= "<div class=\"bt-feature $class \">";

        if ($toppage == 1) {
            $widget .= PluginServicecatalogWidget::getPageTitle($title);
        } else {
            $widget .= PluginServicecatalogWidget::getWidgetTitle($title);
        }

        if ($numrows == 0 && $as_lists == 0) {
            $widget .= "<div class='alert alert-info' role='alert'>";
            $widget .= __('No data available', 'servicecatalog');
            $widget .= "</div>";
        }

        $widget .= "<div id=\"display-sc\" class='ticket-list' style='width: 95%;'>";

        if ($as_lists) {
            $widget .= self::getTabledisplay($list, $output, $type, $showgroup);
        } else {
            $widget .= self::getBubbledisplay($list, $output, $type, $list);
        }
        $widget .= "</div>";
        $widget .= "</div>";
        $widget .= "</div>";
        return $widget;
    }

    /**
     * @param $values
     * @param $type
     * @param $tt
     */
    public
    static function showForSLA($values, $type, $tt)
    {
        list($dateField, $laField) = SLA::getFieldNames($type);

        if (!isset($values[$dateField]) || $values[$dateField] == 'NULL') {
            $values[$dateField] = '';
        }

        echo "<td>";
        Html::showDateTimeField($dateField, ['value' => $values[$dateField],
            'timestep' => 1,
            'maybeempty' => false,
            //                                           'canedit'    => $canupdate,
            'required' => $tt->isMandatoryField($dateField)]);
        echo "</td>";
    }

    /**
     * @param $file
     * @param $filename
     */
    public
    static function sendFile($file, $filename)
    {
        // Test securite : document in DOC_DIR
        $tmpfile = str_replace(GLPI_PLUGIN_DOC_DIR . "/servicecatalog/", "", $file);

        if (strstr($tmpfile, "../") || strstr($tmpfile, "..\\")) {
            \Glpi\Event::log(
                $file,
                "sendFile",
                1,
                "security",
                $_SESSION["glpiname"] . " try to get a non standard file."
            );
            die("Security attack !!!");
        }

        if (!file_exists($file)) {
            die("Error file $file does not exist");
        }

        $splitter = explode("/", $file);
        $mime = "application/octet-stream";

        if (preg_match('/\.(....?)$/', $file, $regs)) {
            switch ($regs[1]) {
                case "jpg":
                case "jpeg":
                    $mime = "image/jpeg";
                    break;
            }
        }
        //print_r($file);

        // Now send the file with header() magic
        header("Expires: Mon, 26 Nov 1962 00:00:00 GMT");
        header('Pragma: private'); /// IE BUG + SSL
        header('Cache-control: private, must-revalidate'); /// IE BUG + SSL
        header("Content-disposition: filename=\"$filename\"");
        header("Content-type: " . $mime);

        readfile($file) or die("Error opening file $file");
    }

    /**
     * @param $type
     * @param $id
     *
     * @return string
     */
    public
    static function setPersonalStyle($type, $id)
    {
        $persoColor = "";
        $config = new PluginServicecatalogConfig();

        $colorHexa = $config->getColor($type, $id);
        $colorHexArray = str_split(substr($colorHexa, 1));
        $colorHexArray = [$colorHexArray[0] . $colorHexArray[1], $colorHexArray[2] . $colorHexArray[3], $colorHexArray[4] . $colorHexArray[5]];
        $colorRgbaArray = array_map('hexdec', $colorHexArray);
        foreach ($colorRgbaArray as $key => $color) {
            $colorRgbaArray[$key] = $color - 25;
        }
        $persoColor .= "<style> ." . $type . "_color_" . $id . "{
                            color:#ffffff!important;
                            background-color: " . $colorHexa . "!important;
                            border-color: " . $colorHexa . "!important;
                        }." . $type . "_color_" . $id . ":hover{
                            color:#ffffff!important;
                            background-color: rgba(" . implode(",", $colorRgbaArray) . ")!important;
                            border-color: rgba(" . implode(",", $colorRgbaArray) . ")!important;
                        }
                        </style>";
        return $persoColor;
    }

    public
    static function getItemsCountForUser($values)
    {
        global $CFG_GLPI;

        $objects = $CFG_GLPI["ticket_types"];
        $objects[] = "Other";

        $helpdesk_category = new PluginServicecatalogCategory();
        if ($helpdesk_category->getFromDBByCategory($values['itilcategories_id'])) {
            $itemtypes = PluginServicecatalogCategory::getUsedConfig("inherit_itemtypes", $values['itilcategories_id'], 'itemtypes');
            $itemtype_items_id = PluginServicecatalogCategory::getUsedConfig("inherit_itemtypes", $values['itilcategories_id'], 'items_id');
            if (!empty($itemtypes)) {
                $objects = json_decode($itemtypes, true);
                $objects_items_id = json_decode($itemtype_items_id, true);

                if (is_array($objects)
                    && is_array($objects_items_id)
                    && count($objects_items_id) != 1 || !is_array($objects_items_id)) {
                    $objects[] = "Other";
                }
            }
        }
        return $objects;
    }


    public
    static function getItemsForUser($values)
    {
        global $CFG_GLPI, $DB;

        if (!isset($values['users_id'])) {
            return false;
        }
        $config = new PluginServicecatalogConfig();
        $users_id_requester = $values['users_id'];

        if ($config->useItemtypesDisplay() == 1) {
            echo "<div class='container' style='display:contents;'>";
            echo "<div class='row' data-toggle='buttons' style='margin-left: 1px;'>";

            $objects_items_id = [];
            $objects = $CFG_GLPI["ticket_types"];
            $objects[] = "Other";

            $helpdesk_category = new PluginServicecatalogCategory();
            if ($helpdesk_category->getFromDBByCategory($values['itilcategories_id'])) {
                $itemtypes = PluginServicecatalogCategory::getUsedConfig("inherit_itemtypes", $values['itilcategories_id'], 'itemtypes');
                $itemtype_items_id = PluginServicecatalogCategory::getUsedConfig("inherit_itemtypes", $values['itilcategories_id'], 'items_id');
                if (!empty($itemtypes)) {
                    $objects = json_decode($itemtypes, true);
                    $objects_items_id = json_decode($itemtype_items_id, true);

                    if (is_array($objects)
                        && is_array($objects_items_id)
                        && count($objects_items_id) != 1 || !is_array($objects_items_id)) {
                        $objects[] = "Other";
                    }
                }
            }

            echo Html::scriptBlock("var hardwareType = [];");

            foreach ($objects as $itemtype) {
                if (($item = getItemForItemtype($itemtype))
                    && Ticket::isPossibleToAssignType($itemtype)
                    && $itemtype != "Other"
                    && $itemtype != "Certificate"
                    && $itemtype != "Rack"
                    && $itemtype != "DatabaseInstance"
                    && $itemtype != "Simcard"
                    && $itemtype != "PluginSimcardSimcard"
                    && $itemtype != "PluginOrderOrder"
                    && $itemtype != "Other"
                    && $itemtype != "Domain"
                    && $itemtype != "Line"
                    && $itemtype != "PDU"
                    && $itemtype != "PluginBadgesBadge"
                    && $itemtype != "PluginResourcesResource"
                ) {
                    $where = [];
                    $itemtable = getTableForItemType($itemtype);
                    //TODO Add restrictions..
                    //               if ($itemtype == "Computer"
                    //                   || $itemtype == "Monitor"
                    //                   || $itemtype == "NetworkEquipment"
                    //                   || $itemtype == "Peripheral"
                    //                   || $itemtype == "Phone"
                    //                   || $itemtype == "Printer"
                    //                   || $itemtype == "Software"
                    //                   || $itemtype == "SoftwareLicense"
                    //                   || $itemtype == "Item_DeviceSimcard") {
                    if ($config->getBypassCategories() == 1) {
                        $where['users_id'] = $users_id_requester;
                    } else {
                        if ($itemtype != "Appliance"
                            //                               && $itemtype !="Software"
//                            && $itemtype != "Printer"
                        ) {
                            $where['users_id'] = $users_id_requester;
                        }
                    }
                    //               }

                    if (is_array($objects_items_id)
                        && count($objects_items_id) > 0) {
                        $where = [];
                        $where['id'] = $objects_items_id;
                    }
                    $criteria = [
                        'FROM' => $itemtable,
                        'WHERE' => $where + getEntitiesRestrictCriteria($itemtable, '', $_SESSION["glpiactive_entity"], $item->maybeRecursive()),
                        'ORDER' => $item->getNameField()
                    ];

                    if ($item->maybeDeleted()) {
                        $criteria['WHERE']['is_deleted'] = 0;
                    }
                    if ($item->maybeTemplate()) {
                        $criteria['WHERE']['is_template'] = 0;
                    }

                    $user = new User();
                    $locations_id = 0;
                    if ($user->getFromDB($users_id_requester)) {
                        $locations_id = $user->fields['locations_id'];
                    }
                    if ($itemtype == "Printer" && $locations_id > 0) {
                        $criteria['WHERE']['locations_id'] = $locations_id;
                    }

                    if (in_array($itemtype, $CFG_GLPI["helpdesk_visible_types"]) && $itemtype != "Database") {
                        $criteria['WHERE']['is_helpdesk_visible'] = 1;
                    }

                    $iterator = $DB->request($criteria);
                    $nb = count($iterator);
                    if ($nb > 0) {
                        foreach ($iterator as $data) {
                            $items_id = $data["id"];
                            $typename = $item->getTypeName(1);
                            $type = $item->getType();
                            if ($type == "Appliance"
                                && !PluginServicecatalogApplianceLink::isApplianceAllowed($items_id)) {
                                continue;
                            }

                            $varname = "hardwareType_" . $type . "_" . $items_id;
                            echo Html::scriptBlock("hardwareType.push('$varname');");

                            $checked = "";
                            $active = "";
                            if (isset($values["items_id"]) && is_array($values["items_id"])) {
                                $arr = $values["items_id"];
                                foreach ($arr as $elttype => $arr2) {
                                    if (in_array($items_id, $arr2) && $elttype == $itemtype) {
                                        $checked = "checked";
                                        $active = "active buttonelt_color";
                                    }
                                }
                            }
                            if (is_array($objects_items_id)
                                && count($objects_items_id) == 1 && in_array($items_id, $objects_items_id)) {
                                $checked = "checked";
                                $active = "active buttonelt_color";
                            }

                            if ($values['selected_items_id'] == $items_id
                                && $values['selected_itemtype'] == $itemtype) {
                                $checked = "checked";
                                $active = "active buttonelt_color";
                            }

                            echo "<label id='$varname' class='btn buttonelt col-md-2 center $active'
                                            onclick='changeBackgroundColor(\"$varname\",\"buttonelt_color\")'>";

                            $value = $itemtype . "_" . $items_id;
                            echo "<input type='radio' name='my_items' value='$value' $checked>";

                            echo "<div class='center'>";
                            $icon = PluginServicecatalogUsercard::getIconForType($itemtype);

                            $ok = 0;
                            $obj = new $itemtype();
                            if ($obj->getFromDB($items_id)) {
                                $className = strtolower(get_class($obj));
                                $model = $className . "models";
                                if (isset($obj->fields[$model . "_id"]) && !empty($obj->fields[$model . "_id"])) {
                                    if ($itemModel = getItemForItemtype($type . 'Model')) {
                                        $itemModel->getFromDB($obj->fields[$model . "_id"]);
                                        $pictures = [];
                                        if ($itemModel->fields['pictures'] != null) {
                                            $pictures = json_decode($itemModel->fields['pictures'], true);

                                            if (isset($pictures) && is_array($pictures)) {
                                                foreach ($pictures as $picture) {
                                                    $picture_url = Toolbox::getPictureUrl($picture);
                                                    $icon = "<img class='user_picture' style='width: 50%;height: 50%;' 
                                        alt=\"" . _sn('Picture', 'Pictures', 1) . "\" src='" .
                                                        $picture_url . "'>";
                                                    $ok = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                if ($itemtype == "Appliance") {
                                    if ($obj->fields['pictures'] != null) {
                                        $pictures = json_decode($obj->fields['pictures'], true);

                                        if (isset($pictures) && is_array($pictures)) {
                                            foreach ($pictures as $picture) {
                                                $picture_url = Toolbox::getPictureUrl($picture);
                                                $icon = "<img class='user_picture' style='width: 50%;height: 50%;' 
                                        alt=\"" . _sn('Picture', 'Pictures', 1) . "\" src='" .
                                                    $picture_url . "'>";
                                                $ok = 1;
                                            }
                                        }
                                    }
                                }
                            }
                            if ($ok == 1) {
                                echo "$icon&nbsp;";
                            } else {
                                echo "<i class='$icon fa-3x mr-3'></i>&nbsp;";
                            }

                            echo "<h5 class='mt-0 mb-1 buttonelt-title'>";
                            echo $data[$item->getNameField()] . "&nbsp;";
                            $comment = "";
                            if (isset($data['serial']) && !empty($data['serial'])) {
                                $comment = __('Serial number') . " : " . $data['serial'];
                            }
                            if (!empty($comment)) {
                                echo "&nbsp;";
                                echo Html::showToolTip($comment);
                            }

                            echo "</h5><br>";
                            echo $typename;
                            echo "</div>";
                            echo "</label>";
                        }
                    }
                }

                if ($itemtype == "Other") {
                    echo Html::scriptBlock("hardwareType.push('hardwareType_0');");
                    $checked = "";
                    $active = "";
                    if (isset($elttype) && $elttype == $itemtype) {
                        $checked = "checked";
                        $active = "active buttonelt_color";
                    }

                    echo "<label id='hardwareType_0' class='btn buttonelt col-md-2 center $active'
                            onclick='changeBackgroundColor(\"hardwareType_0\",\"buttonelt_color\")'>";
                    $value = $itemtype . "_0";
                    echo "<input type='radio' name='my_items' value='$value' $checked>";
                    $icon = "fas fa-question";
                    echo "<div class='center' style='padding-top: 10px;'>";
                    echo "<i class='$icon fa-3x'></i>";
                    echo "<h5 class='mt-0 mb-1 buttonelt-title'>";
                    echo __('My equipment does not appear', 'servicecatalog');
                    echo "</h5><br>";
                    echo "</div>";

                    echo "</label>";
                }
            }
            echo "</div>";
            $active = "";
            if ($values['is_mandatory']) {
                $active = "active";
            }
            echo "<div class='alertelt $active'><div class='alertelttext'><span>";
            echo __('This field is mandatory, please select your equipment', 'servicecatalog');
            echo "</span></div></div>";

            echo "<div class='tooltipelt'><div class='tooltipelttext'><span>";
            echo __('If your equipment is not listed, thanks to add its name on ticket description', 'servicecatalog');
            echo "</span></div></div>";

            echo "</div>";
        } else {
            $ticket = new ticket();
            $params['_users_id_requester'] = $users_id_requester;
            $params['itemtype'] = 'Ticket';
            $params['_canupdate'] = true;

            Item_Ticket::itemAddForm($ticket, $params);
        }
    }


    /**
     * Display an html textarea  with extended options
     *
     * @param array $options with these keys:
     *  - name (string):              corresponding html attribute
     *  - filecontainer (string):     dom id for the upload filelist
     *  - rand (string):              random param to avoid overriding between textareas
     *  - editor_id (string):         id attribute for the textarea
     *  - value (string):             value attribute for the textarea
     *  - enable_richtext (bool):     enable tinymce for this textarea
     *  - enable_images (bool):       enable image pasting in tinymce (default: true)
     *  - enable_fileupload (bool):   enable the inline fileupload system
     *  - display (bool):             display or return the generated html
     *  - cols (int):                 textarea cols attribute (witdh)
     *  - rows (int):                 textarea rows attribute (height)
     *  - required (bool):            textarea is mandatory
     *  - uploads (array):            uploads to recover from a prevous submit
     *
     * @return mixed          the html if display paremeter is false or true
     * @since 9.2
     *
     */
    public
    static function textarea($options = [])
    {
        //default options
        $p['name'] = 'text';
        $p['filecontainer'] = 'fileupload_info';
        $p['rand'] = mt_rand();
        $p['editor_id'] = 'text' . $p['rand'];
        $p['value'] = '';
        $p['placeholder'] = '';
        $p['enable_richtext'] = false;
        $p['enable_images'] = true;
        $p['enable_fileupload'] = false;
        $p['display'] = true;
        $p['cols'] = 100;
        $p['rows'] = 15;
        $p['multiple'] = true;
        $p['required'] = false;
        $p['uploads'] = [];

        //merge default options with options parameter
        $p = array_merge($p, $options);

        $required = $p['required'] ? 'required' : '';
        $display = '';
        $display .= "<textarea class='form-control' name='" . $p['name'] . "' id='" . $p['editor_id'] . "'
                             rows='" . $p['rows'] . "' cols='" . $p['cols'] . "' $required>" .
            $p['value'] . "</textarea>";

        if ($p['enable_richtext']) {
            $display .= self::initEditorSystem($p['editor_id'], $p['rand'], false, false, $p['enable_images'], $p['placeholder']);
        }
        if (!$p['enable_fileupload'] && $p['enable_richtext'] && $p['enable_images']) {
            $p_rt = $p;
            $p_rt['display'] = false;
            $p_rt['only_uploaded_files'] = true;
            $p_rt['required'] = false;
            $display .= Html::file($p_rt);
        }

        if ($p['enable_fileupload']) {
            $p_rt = $p;
            unset($p_rt['name']);
            $p_rt['display'] = false;
            $p_rt['required'] = false;
            $display .= Html::file($p_rt);
        }

        if ($p['display']) {
            echo $display;
            return true;
        } else {
            return $display;
        }
    }

    /**
     * Init the Editor System to a textarea
     *
     * @param string $name name of the html textarea to use
     * @param string $rand rand of the html textarea to use (if empty no image paste system)(default '')
     * @param boolean $display display or get js script (true by default)
     * @param boolean $readonly editor will be readonly or not
     * @param boolean $enable_images enable image pasting in rich text
     *
     * @return void|string
     *    integer if param display=true
     *    string if param display=false (HTML code)
     **/
    public
    static function initEditorSystem($name, $rand = '', $display = true, $readonly = false, $enable_images = true, $placeholder_comment = '')
    {
        global $CFG_GLPI, $DB;

        // load tinymce lib
        Html::requireJs('tinymce');

        $language = $_SESSION['glpilanguage'];
        if (!file_exists(GLPI_ROOT . "/public/lib/tinymce-i18n/langs5/$language.js")) {
            $language = $CFG_GLPI["languages"][$_SESSION['glpilanguage']][2];
            if (!file_exists(GLPI_ROOT . "/public/lib/tinymce-i18n/langs5/$language.js")) {
                $language = "en_GB";
            }
        }
        $language_url = $CFG_GLPI['root_doc'] . '/public/lib/tinymce-i18n/langs5/' . $language . '.js';

        // Apply all GLPI styles to editor content
        $content_css = preg_replace('/^.*href="([^"]+)".*$/', '$1', Html::scss('css/palettes/' . $_SESSION['glpipalette'] ?? 'auror'))
            . ',' . preg_replace('/^.*href="([^"]+)".*$/', '$1', Html::css('public/lib/base.css'));

        $cache_suffix = '?v=' . GLPI_VERSION;
        $readonlyjs = $readonly ? 'true' : 'false';

        $invalid_elements = 'applet,canvas,embed,form,object';
        if (!$enable_images) {
            $invalid_elements .= ',img';
        }

        $plugins = [
            'autoresize',
            'code',
            'directionality',
            'fullscreen',
            'link',
            'lists',
            'quickbars',
            'searchreplace',
            'table',
        ];
        if ($enable_images) {
            $plugins[] = 'image';
            $plugins[] = 'glpi_upload_doc';
        }
        if ($DB->use_utf8mb4) {
            $plugins[] = 'emoticons';
        }
        $pluginsjs = json_encode($plugins);

        $language_opts = '';
        if ($language !== 'en_GB') {
            $language_opts = json_encode([
                'language' => $language,
                'language_url' => $language_url
            ]);
        }

        $placeholder = \Glpi\RichText\RichText::getSafeHtml($placeholder_comment);
        $placeholder = addslashes($placeholder);
        $alert = __('The description field is mandatory', 'servicecatalog');
        // init tinymce
        $js = <<<JS
         $(function() {
            var is_dark = $('html').css('--is-dark').trim() === 'true';
            var richtext_layout = "{$_SESSION['glpirichtext_layout']}";

            // init editor
            tinyMCE.init(Object.assign({
               selector: '#{$name}',

               plugins: {$pluginsjs},

               // Appearance
               skin_url: is_dark
                  ? CFG_GLPI['root_doc']+'/public/lib/tinymce/skins/ui/oxide-dark'
                  : CFG_GLPI['root_doc']+'/public/lib/tinymce/skins/ui/oxide',
               body_class: 'rich_text_container',
               content_css: '{$content_css}',

               min_height: '150px',
               resize: true,

               // disable path indicator in bottom bar
               elementpath: false,

               // inline toolbar configuration
               menubar: false,
               toolbar: richtext_layout == 'classic'
                  ? 'styleselect | bold italic | forecolor backcolor | bullist numlist outdent indent | emoticons table link image | code fullscreen'
                  : false,
               quickbars_insert_toolbar: richtext_layout == 'inline'
                  ? 'emoticons quicktable quickimage quicklink | bullist numlist | outdent indent '
                  : false,
               quickbars_selection_toolbar: richtext_layout == 'inline'
                  ? 'bold italic | styleselect | forecolor backcolor '
                  : false,
               //contextmenu: 'emoticons table image link | undo redo | code fullscreen',
               contextmenu: false,
               // Content settings
               entity_encoding: 'raw',
               invalid_elements: '{$invalid_elements}',
               paste_data_images: true,
               readonly: {$readonlyjs},
               relative_urls: false,
               remove_script_host: false,

               // Misc options
               browser_spellcheck: true,
               cache_suffix: '{$cache_suffix}',

               setup: function(editor) {
                  // "required" state handling
                  if ($('#$name').attr('required') == 'required') {
                     $('#$name').removeAttr('required'); // Necessary to bypass browser validation

                     editor.on('submit', function (e) {
                        if ($('#$name').val() == '') {
                           alert('$alert');
                           e.preventDefault();

                           // Prevent other events to run
                           // Needed to not break single submit forms
                           e.stopPropagation();
                        }
                     });
                     editor.on('keyup', function (e) {
                        editor.save();
                        if ($('#$name').val() == '') {
                           $(editor.container).addClass('required');
                        } else {
                           $(editor.container).removeClass('required');
                        }
                     });
                     editor.on('init', function (e) {
                        if (strip_tags($('#$name').val()) == '') {
                           $(editor.container).addClass('required');
                        }
                     });
                     editor.on('paste', function (e) {
                        // Remove required on paste event
                        // This is only needed when pasting with right click (context menu)
                        // Pasting with Ctrl+V is already handled by keyup event above
                        $(editor.container).removeClass('required');
                     });
                  }
                  editor.on('init', () => {
                     if ($('#$name').val() == '') {
                     editor.setContent(`
                              <div id="placeholder">
                            $placeholder
                        </div>
                          `);
                     }
                  });
                  // When the editor is clicked we monitor what is being clicked and
                  // take appropriate actions. This is how we dedect if a insert template
                  // button has been clicked. This event is triggered for every click inside
                  // TinyMCE.
                  // https://www.tiny.cloud/docs/advanced/events/
                  const placeholderManager = (e) => {
      
                     // Check if the content contains the placeholder inserted above.
                     // The get() function looks for an id attribute.
                     // https://www.tiny.cloud/docs/api/tinymce.dom/tinymce.dom.domutils/#get
                     const placeholderExists = editor.dom.get('placeholder');
                     
                     if (placeholderExists) {
      
                        // In this demo we want to start an empty document with a title.
                           // This does not force having a title for a document, it's simply
                           // a convenience feature.
                           editor.undoManager.transact(() => {
                              editor.setContent('');
                           });
                     }
                  };
      
                  // Bind the click event listener to the placeholder manager function
                  editor.once('click tap keydown', placeholderManager);
      
                  editor.on('Undo', () => {
                     // Rebind the click event listener when the editor is reverted back
                     // to the original content
                     if (!editor.undoManager.hasUndo()) {
                        editor.once('click tap keydown', placeholderManager);
                     }
                  });
                  editor.on('Change', function (e) {
                     // Nothing fancy here. Since this is only used for tracking unsaved changes,
                     // we want to keep the logic in common.js with the other form input events.
                     onTinyMCEChange(e);
                  });
                  // ctrl + enter submit the parent form
                  editor.addShortcut('ctrl+13', 'submit', function() {
                     editor.save();
                     submitparentForm($('#$name'));
                  });
                  editor.on('PreInit', () => {
                     // To prevent the placeholder to be submitted out of TinyMCE we
                     // remove it upon serialization. In this case, any <div> tag
                     // will be removed, so adapt it to your needs.
                     // https://www.tiny.cloud/docs/api/tinymce.dom/tinymce.dom.serializer/#addnodefilter
                     editor.serializer.addNodeFilter('div', nodes => {
                        nodes.forEach(node => {
                           node.remove();
                        });
                     });
                  });
               },
               content_style: `
                #placeholder {
                    color: #aaa;
                    display: flex;
                    flex-direction: column;
                    -webkit-user-select: none; /* Prevent any selections on the element */
                    user-select: none;
                }

                #placeholder * {
                    -webkit-user-select: none; /* Prevent any selections on the element */
                    user-select: none;
                }`
            }, {$language_opts}));
         });
JS;

        if ($display) {
            echo Html::scriptBlock($js);
        } else {
            return Html::scriptBlock($js);
        }
    }

    public
    static function seePluginFields($ticket, $params, $use_as_step)
    {
        if (Plugin::isPluginActive('fields')) {
            $c_id = 0;
            $functions = array_column(debug_backtrace(), 'function');

            $subtype = isset($_SESSION['glpi_tabs'][strtolower($ticket::getType())]) ? $_SESSION['glpi_tabs'][strtolower($ticket::getType())] : "";
            $type = substr($subtype, -strlen('$main')) === '$main'
            || in_array('showForm', $functions)
            || in_array('showPrimaryForm', $functions)
            || in_array('showFormHelpdesk', $functions)
                ? 'dom'
                : 'domtab';
            if ($subtype == -1) {
                $type = 'dom';
            }
            // if we are in 'dom' or 'tab' type, no need for subtype ('domtab' specific)
            if ($type != 'domtab') {
                $subtype = "";
            }

            $c_id = PluginFieldsContainer::findContainer(get_Class($ticket), $type, $subtype);

            $align = "";
            $center = "";
            if ($use_as_step == 1) {
                $align = "center w-75 mx-auto";
                $center = "w-25 mx-auto";
            }
            $config = new PluginServicecatalogConfig();
            if ($c_id > 0) {
                $loc_c = new PluginFieldsContainer;
                $loc_c->getFromDB($c_id);
                $profile = new PluginFieldsProfile();
                $found = $profile->find(['profiles_id' => $_SESSION['glpiactiveprofile']['id'],
                    'plugin_fields_containers_id' => $c_id,
                    'right' => ['>=', READ]
                ]);

                $first_found = array_shift($found);
                if (!$first_found || $first_found['right'] == null || $first_found['right'] == 0) {
                    return false;
                }

                $entities = [$loc_c->fields['entities_id']];
                if ($loc_c->fields['is_recursive']) {
                    $entities = getSonsOf(getTableForItemType('Entity'), $loc_c->fields['entities_id']);
                }
                if ($ticket->isEntityAssign()) {
                    $current_entity = $ticket->getEntityID();
                    if (in_array($current_entity, $entities)) {
                        if ($use_as_step == 1) {
                            echo "<div class='tab-sc'>";
                            echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                        } else {
                            echo "<div class=\"form-group col-md-12 $align borderpanel\">";
                        }

                        echo "<h5>";

                        $alert = "alert-secondary";
                        $style = "";
//                        if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//                            || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//                            $alert_hide = "alert-light";
//                        }
                        if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                            || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                            $style = 'style="border-radius: 1px"';
                        }
                        echo "<div class='alert $alert' role='alert' $style>";
                        $title = __('Other fields', 'servicecatalog');
                        echo $title;
                        echo "</div>";
                        echo "</h5>";
//                        echo "</div>";
                        $opt['item'] = $ticket;
                        $opt['options'] = $params;
//                        echo "<div class=\"form-group col-md-6 borderpanel\">";
                        PluginFieldsField::showForTab($opt);
                        echo "</div>";

                        if ($use_as_step == 1) {
                            echo "</div>";
                        }
                    }
                } else {
                    if ($use_as_step == 1) {
                        echo "<div class='tab-sc'>";
                        echo "<div class=\"form-group col-md-6 $align borderpanel\">";
                    } else {
                        echo "<div class=\"form-group col-md-12 $align borderpanel\">";
                    }

                    echo "<h5>";
                    $alert = "alert-secondary";
                    $style = "";
//                    if ($config->getLayout() == PluginServicecatalogConfig::WRAPPER
//                        || $config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
//                        $alert_hide = "alert-light";
//                    }
                    if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                        || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                        $style = 'style="border-radius: 1px"';
                    }
                    echo "<div class='alert $alert' role='alert' $style>";
                    $title = __('Other fields', 'servicecatalog');
                    echo $title;
                    echo "</div>";
                    echo "</h5>";
                    echo "</div>";
                    $opt['item'] = $ticket;
                    $opt['options'] = $params;
                    echo "<div class=\"form-group col-md-6 borderpanel\">";
                    PluginFieldsField::showForTab($opt);
                    echo "</div>";
                    if ($use_as_step == 1) {
                        echo "</div>";
                    }
                }
            }
        }
    }

    /**
     * @param $type
     *
     * @return mixed
     */
    public
    static function getColumnsName($type)
    {
        switch ($type) {
            case self::ID_PRIORITY:
                return __("ID and priority", "servicecatalog");
            case self::DATE:
                return __('Opening date');
            case self::REQUESTER:
                return __('Requester');
            case self::STATUS:
                return __('Status');
            case self::ITEM:
                return __('Associated element');
            case self::TITLE:
                return __('Title');
            case self::ID:
                return __("ID");
            case self::PRIORITY:
                return __("Priority");
            case self::CATEGORY:
                return __('Category');
            case self::TYPE:
                return __('Type');
            case self::ASSIGNED:
                return __('Assigned to') . " - " . __('Group');
            case self::ASSIGNED_TECH:
                return __('Assigned to') . " - " . __('Technician');
            case self::TTR:
                return __("Time to resolve");
            case self::ENTITY:
                return __('Entity');
        }
        return false;
    }

    /**
     * @return array
     */
    static function getListColumnsForTable()
    {

        $columns = [
            self::ID_PRIORITY,
            self::DATE,
            self::REQUESTER,
            self::STATUS,
            self::ITEM,
            self::TITLE,
            self::ID,
            self::PRIORITY,
            self::CATEGORY,
            self::TYPE,
            self::ASSIGNED,
            self::ASSIGNED_TECH,
            self::TTR,
            self::ENTITY
        ];
        return $columns;
    }


    /**
     * @param      $entities_id
     * @param      $type
     *
     * @param bool $showgroup
     *
     * @param int $itilcategories_id
     *
     * @return string
     * @throws \GlpitestSQLError
     */
    public
    static function getYourTicketsFromMetademands($widgetname, $as_lists, $entities_id, $type = 0, $showgroup = true, $toppage = false, $itilcategories_id = 0)
    {
        global $DB;

        $config = new PluginServicecatalogConfig();
        $config->getFromDB(1);

        $showgrouptickets = false;
        if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP)) {
            if ($showgroup) {
                $showgrouptickets = true;
            }
        }

        $title = __('Tickets opened by Metademands', 'servicecatalog');


        if (!Session::haveRightsOr(Ticket::$rightname, [CREATE, Ticket::READMY, ITILFollowup::SEEPUBLIC])) {
            if ($toppage == 1) {
                $widget = PluginServicecatalogWidget::getPageTitle($title);
            } else {
                $widget = PluginServicecatalogWidget::getWidgetTitle($title);
            }

            $widget .= "<div class='alert alert-info' role='alert'>";
            $widget .= __('No data available', 'servicecatalog');
            $widget .= "</div>";
            return $widget;
        }

        $list = "YourTicketsMeta";
        //table name
        if ($as_lists) {
            $widget = self::getTableHeader($list, $entities_id, $type, $showgroup);
        } else {
            $widget = "";
        }

        //query
        $search_users_id = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "') ";
        $search_observer = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::OBSERVER . "')";
        $search_redactor = "`glpi_tickets`.`users_id_recipient` = '" . Session::getLoginUserID() . "' ";
        $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

        if ($showgrouptickets) {

            if (count($_SESSION['glpigroups'])) {
                $groups = implode("','", $_SESSION['glpigroups']);

                $search_users_id .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::REQUESTER . "') ";

                $search_observer .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::OBSERVER . "') ";
            }
        }

        $query = "SELECT DISTINCT `glpi_tickets`.`id`
                FROM `glpi_tickets`
                LEFT JOIN `glpi_tickets_users`
                     ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`)
                RIGHT JOIN `glpi_plugin_metademands_tickets_metademands`
                     ON (`glpi_tickets`.`id` = `glpi_plugin_metademands_tickets_metademands`.`tickets_id`)";

        $query .= "WHERE $is_deleted
                             AND ( $search_users_id OR $search_observer OR $search_redactor) ";

//        if ($itilcategories_id > 0) {
//            $query .= "AND `glpi_tickets`.`itilcategories_id` = '" . $itilcategories_id . "' ";
//        }
        $dbu = new DbUtils();
        $query .= "AND `glpi_tickets`.`status` NOT IN ('" . Ticket::CLOSED . "',
                                                                         '" . Ticket::SOLVED . "') " .
            $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $query .= " ORDER BY `glpi_tickets`.`date` DESC";
        $result = $DB->query($query);
        $numrows = $DB->numrows($result);
        //forcetab

        $forcetab = '';

        $output = [];
        Session::initNavigateListItems('Ticket');

        if ($numrows > 0) {
            for ($i = 0; $i < $numrows; $i++) {
                $ID = $DB->result($result, $i, "id");
                if ($as_lists) {
                    $output[$i] = self::showVeryShort($ID, $forcetab);
                } else {
                    $output[$i] = self::showVeryShortForBubble($ID, $forcetab);
                }
                Session::addToNavigateListItems('Ticket', $ID);
            }
        }

        $class = "bt-col-md-12";
        $delclass = "";
        if (Session::haveRight("plugin_servicecatalog_view", CREATE)
            || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
            $delclass = "delclass";
        }

        //widget id
        $widget .= "<div id='$widgetname' class=\"bt-row sc-content  $delclass\">";

        $widget .= "<div class=\"bt-feature $class \">";

        if ($toppage == 1) {
            $widget .= PluginServicecatalogWidget::getPageTitle($title);
        } else {
            $widget .= PluginServicecatalogWidget::getWidgetTitle($title);
        }

        if ($numrows == 0 && $as_lists == 0) {
            $widget .= "<div class='alert alert-info' role='alert'>";
            $widget .= __('No data available', 'servicecatalog');
            $widget .= "</div>";
        }

        $widget .= "<div id=\"display-sc\" class='ticket-list' style='width: 95%;'>";

        if ($as_lists) {
            $widget .= self::getTabledisplay($list, $output, $type, $showgroup);
        } else {
            $widget .= self::getBubbledisplay($list, $output, $type, $list);
        }
        $widget .= "</div>";
        $widget .= "</div>";
        $widget .= "</div>";
        return $widget;
    }

}
