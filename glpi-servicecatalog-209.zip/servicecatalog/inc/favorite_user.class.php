<?php
/**
 * ---------------------------------------------------------------------
 * GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2015-2018 Teclib' and contributors.
 *
 * http://glpi-project.org
 *
 * based on GLPI - Gestionnaire Libre de Parc Informatique
 * Copyright (C) 2003-2014 by the INDEPNET Development Team.
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * GLPI is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLPI is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLPI. If not, see <http://www.gnu.org/licenses/>.
 * ---------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}


/**
 * Class PluginServicecatalogFavorite_User
 */
class PluginServicecatalogFavorite_User extends CommonDBRelation
{

   // From CommonDBRelation
    public static $itemtype_1 = 'PluginServicecatalogFavorite';
    public static $items_id_1 = 'favorites_id';
    public static $itemtype_2 = 'User';
    public static $items_id_2 = 'users_id';

    public static $checkItem_2_Rights = self::DONT_CHECK_ITEM_RIGHTS;
    public static $logs_for_item_2    = false;

    const REQUEST_TYPE_FAVORITES  = 1;
    const INCIDENT_TYPE_FAVORITES = 2;
    const BOTH_TYPE_FAVORITES     = 3;


   /**
    * @param $favorites_id
    *
    * @return array
    */
    static function getUsers($favorites_id)
    {
        global $DB;

        $users = [];

        $iterator = $DB->request([
                                  'FROM'  => self::getTable(),
                                  'WHERE' => [
                                     'favorites_id' => $favorites_id
                                  ]
                               ]);

        foreach ($iterator as $data) {
            $users[$data['users_id']][] = $data;
        }
        return $users;
    }

   /**
    * @param $type
    *
    * @return string
    */
    static function getTypesFavorites($type)
    {
        switch ($type) {
            case 1:
                return __('Request');
            case 2:
                return __('Incident');
            case 3:
                return __('Incident') . " / " . __('Request');
        }
    }


   /**
    * @param $user_id
    *
    * @return array
    */
    static function getFavoritesByUser($user_id)
    {
        global $DB;

        $favorites = [];
        $join      = ['`glpi_plugin_servicecatalog_favorites`' => [
         'FKEY' => [
            '`glpi_plugin_servicecatalog_favorites_users`' => '`favorites_id`',
            '`glpi_plugin_servicecatalog_favorites`'       => '`id`'
         ]
        ],
                    '`glpi_itilcategories`'                  => [
                       'FKEY' => [
                          '`glpi_plugin_servicecatalog_favorites`' => '`itilcategories_id`',
                          '`glpi_itilcategories`'                  => '`id`'
                       ]
                    ]
        ];

        $iterator = $DB->request([
                                  'SELECT'     => ['`glpi_plugin_servicecatalog_favorites_users`.`users_id`',
                                                   '`glpi_plugin_servicecatalog_favorites_users`.`favorites_id`',
                                                   '`glpi_plugin_servicecatalog_favorites_users`.`id` AS `favorites_users_id`',
                                                   '`glpi_plugin_servicecatalog_favorites_users`.`ranking_requests`',
                                                   '`glpi_plugin_servicecatalog_favorites_users`.`ranking_incidents`',
                                                   '`glpi_plugin_servicecatalog_favorites_users`.`type_favorites`',
                                                   '`glpi_plugin_servicecatalog_favorites`.`id`',
                                                   '`glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id`',
                                                   '`glpi_plugin_servicecatalog_favorites`.`itilcategories_id`',
                                                   '`glpi_itilcategories`.`completename`',
                                                   '`glpi_itilcategories`.`id`'],
                                  'FROM'       => self::getTable(),
                                  'INNER JOIN' => $join,
                                  'WHERE'      => [
                                     self::getTable() . '.users_id' => $user_id
                                  ],
                                  'ORDER'      => 'ranking_requests'
                               ]);

        foreach ($iterator as $data) {
            $favorites [] = $data;
        }
        return $favorites;
    }

   /**
    * @param $groupFavoritesIncident
    *
    * @return array
    */
    static function orderIncidentsRanking($groupFavoritesIncident)
    {
        $formatGroupFavoritesIncident = [];

        foreach ($groupFavoritesIncident as $key => $row) {
            usort($row, function ($a, $b) {
                return $a['ranking_incidents'] - $b['ranking_incidents'];
            });
            $formatGroupFavoritesIncident[$key] = $row;
        }

        return $formatGroupFavoritesIncident;
    }

   /**
    * @param $user_id
    * @param $oldRank
    * @param $newRank
    * @param $groupId
    * @param $type_ranking
    *
    * @return array
    */
    static function getGroupFavoritesByRanking($user_id, $oldRank, $newRank, $groupId, $type_ranking)
    {

        global $DB;

        $betweenRank1 = '';
        $betweenRank2 = '';

        if ($oldRank < $newRank) {
            $betweenRank1 = self::getTable() . '.' . $type_ranking . ' > ' . $oldRank;
            $betweenRank2 = self::getTable() . '.' . $type_ranking . ' <= ' . $newRank;
        } else {
            $betweenRank1 = self::getTable() . '.' . $type_ranking . ' < ' . $oldRank;
            $betweenRank2 = self::getTable() . '.' . $type_ranking . ' >= ' . $newRank;
        }

        $favorites = [];
        $join      = ['`glpi_plugin_servicecatalog_favorites`' => [
         'FKEY' => [
            '`glpi_plugin_servicecatalog_favorites_users`' => '`favorites_id`',
            '`glpi_plugin_servicecatalog_favorites`'       => '`id`'
         ]
        ]];

        $iterator = $DB->request([
                                  'SELECT'     => [self::getTable() . '.id',
                                                   self::getTable() . '.' . $type_ranking],
                                  'FROM'       => self::getTable(),
                                  'INNER JOIN' => $join,
                                  'WHERE'      => [
                                     self::getTable() . '.`users_id`'                                      => $user_id,
                                     $betweenRank1,
                                     $betweenRank2,
                                     '`glpi_plugin_servicecatalog_favorites`.`favorite_itilcategories_id`' => $groupId
                                  ]]);

        foreach ($iterator as $data) {
            $favorites [] = $data;
        }
        return $favorites;
    }


   /**
    * @param array $params
    */
    public function reorder(array $params)
    {

        $toUpdateList = [];

        if (isset($params['old_order']) && isset($params['new_order'])) {
            $type_ranking = $params['type_favorites'] == PluginServicecatalogFavorite_User::REQUEST_TYPE_FAVORITES ? 'ranking_requests' : 'ranking_incidents';

            $crit = [
            'id' => $params['favorites_users_id']
            ];

            $itemMove = new self();
            $itemMove->getFromDBByCrit($crit);

            if (isset($itemMove->fields["id"])) {
               // Reorganization of all fields
                if ($params['old_order'] < $params['new_order']) {
                    $toUpdateList = self::getGroupFavoritesByRanking($params['users_id'], $params['old_order'], $params['new_order'], $params['itil_categories_id'], $type_ranking);

                    foreach ($toUpdateList as $toUpdate) {
                        $this->update([
                                   'id'          => $toUpdate['id'],
                                   $type_ranking => $toUpdate[$type_ranking] - 1
                                ]);
                    }
                } else {
                    $toUpdateList = self::getGroupFavoritesByRanking($params['users_id'], $params['old_order'], $params['new_order'], $params['itil_categories_id'], $type_ranking);

                    foreach ($toUpdateList as $toUpdate) {
                        $this->update([
                                   'id'          => $toUpdate['id'],
                                   $type_ranking => $toUpdate[$type_ranking] + 1
                                ]);
                    }
                }

                if (isset($itemMove->fields["id"]) && $itemMove->fields['id'] > 0) {
                    $this->update([
                                'id'          => $itemMove->fields['id'],
                                $type_ranking => $params['new_order']
                             ]);
                }
            }
        }
    }
}
