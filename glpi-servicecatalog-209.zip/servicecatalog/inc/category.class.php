<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogCategory
 */
class PluginServicecatalogCategory extends CommonDBTM
{
    public static $rightname = 'plugin_servicecatalog_setup';
    public $can_be_translated = true;

    const CONFIG_PARENT = 1;

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        PluginServicecatalogMain::getTypeName();
    }

    public function post_getEmpty()
    {
        $this->fields['inherit_config'] = 1;
        $this->fields['inherit_picture'] = 1;
        $this->fields['inherit_detail'] = 1;
        $this->fields['inherit_alert'] = 1;
        $this->fields['inherit_itemtypes'] = 1;
    }

    /**
     * Display image tab for each category
     *
     * @param CommonGLPI $item
     * @param int $withtemplate
     *
     * @return array|string
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if (!$withtemplate) {
            if ($item->getType() == 'ITILCategory' && $this->canUpdate()) {
                if ($_SESSION['glpishow_count_on_tabs']) {
                    $dbu = new DbUtils();
                    return self::createTabEntry(
                        PluginServicecatalogMain::getTypeName(),
                        $dbu->countElementsInTable(
                            "glpi_plugin_servicecatalog_categories",
                            ["itilcategories_id" => $item->getField('id')]
                        )
                    );
                }
                return PluginServicecatalogMain::getTypeName();
            }
        }
        return '';
    }

    /**
     * Display tab's content for each ITILCategory
     *
     * @static
     *
     * @param CommonGLPI $item
     * @param int $tabnum
     * @param int $withtemplate
     *
     * @return bool|true
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case 'ITILCategory':
                $ID = $item->getField('id');
                $self = new self();

                if (!$self->getFromDBByCategory($ID)) {
                    $self->createAccess($ID);
                }
                $self->showForm($ID);
                break;
        }

        return true;
    }

    /**
     * Returns if category is present
     *
     * @param type $categories_id
     *
     * @return boolean
     * @global type $DB
     *
     */
    public function getFromDBByCategory($categories_id)
    {
        global $DB;

        $iterator = $DB->request([
            'FROM' => getTableForItemType(__CLASS__),
            'WHERE' => [
                'itilcategories_id' => $categories_id,
            ],
        ]);

        if (count($iterator) != 1) {
            return false;
        }
        foreach ($iterator as $data) {
            $this->fields = $data;
            if (is_array($this->fields) && count($this->fields)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    /**
     * Create the first access
     *
     * @param type $ID
     */
    public function createAccess($ID)
    {
        $this->add([
            'itilcategories_id' => $ID,
            'comment' => "",
            'simplified_name_incident' => "",
            'simplified_name_request' => "",
            'display_warning' => "",
            'use_website_url' => 0,
            'website_url' => "",
            'website_target' => 1,
            'force_validation' => 0,
            'group_visibility' => 0,
            'knowbaseitems_id' => 0,
            'inherit_picture' => 1,
            'picture' => null,
            'icon' => "",
            'background_color' => "",
            'size' => "normal",
            'glue' => 0,
            'inherit_config' => 1,
            'keywords' => "",
            'groups' => "",
            'itemtypes' => "",
            'items_id' => 0,
            'inherit_itemtypes' => 1,
            'picture_detail' => null,
            'inherit_detail' => 1,
            'inherit_alert' => 1,
            'service_detail' => "",
            'service_users' => "",
            'service_ttr' => "",
            'service_use' => "",
            'service_supervision' => "",
            'service_rules' => "",
            'service_links' => ""]);
    }


    /**
     * Dropdown Helpdesk Itemtypes
     *
     * @param $options array of possible options:
     *    - name : string / name of the select (default is profiles_id)
     *    - values : array of values
     **@since 0.84
     *
     */
    public static function dropdownHelpdeskItemtypes($options)
    {
        $p['name'] = 'itemtypes';
        $p['values'] = [];
        $p['display'] = true;

        if (is_array($options) && count($options)) {
            foreach ($options as $key => $val) {
                $p[$key] = $val;
            }
        }

        $values = self::getAllTypesForHelpdesk();

        $p['multiple'] = true;
        $p['size'] = 3;

        if (!is_array($p['values'])) {
            $p['values'] = [];
        }
        return Dropdown::showFromArray($p['name'], $values, $p);
    }

    /**
     * Get all available types to which an ITIL object can be assigned
     **/
    public static function getAllTypesForHelpdesk()
    {
        global $PLUGIN_HOOKS, $CFG_GLPI;

        /// TODO ticket_types -> itil_types

        $types = [];
        $ptypes = [];
        //Types of the plugins (keep the plugin hook for right check)
        if (isset($PLUGIN_HOOKS['assign_to_ticket'])) {
            foreach (array_keys($PLUGIN_HOOKS['assign_to_ticket']) as $plugin) {
                if (!Plugin::isPluginActive($plugin)) {
                    continue;
                }
                $ptypes = Plugin::doOneHook($plugin, 'AssignToTicket', $ptypes);
            }
        }
        asort($ptypes);
        //Types of the core (after the plugin for robustness)
        foreach ($CFG_GLPI["ticket_types"] as $itemtype) {
            if ($item = getItemForItemtype($itemtype)) {
                if (!isPluginItemType($itemtype) // No plugin here
                    //                && isset($_SESSION["glpiactiveprofile"]["helpdesk_item_type"])
                    //                && in_array($itemtype, $_SESSION["glpiactiveprofile"]["helpdesk_item_type"])
                ) {
                    $types[$itemtype] = $item->getTypeName(1);
                }
            }
        }
        asort($types); // core type first... asort could be better ?

        // Drop not available plugins
        foreach (array_keys($ptypes) as $itemtype) {
            if (!isset($_SESSION["glpiactiveprofile"]["helpdesk_item_type"])
                || !in_array($itemtype, $_SESSION["glpiactiveprofile"]["helpdesk_item_type"])) {
                unset($ptypes[$itemtype]);
            }
        }

        $types = array_merge($types, $ptypes);
        return $types;
    }

    /**
     * @param       $ID
     * @param array $options
     *
     * @return bool
     * @throws \GlpitestSQLError
     * @throws \GlpitestSQLError
     */
    public function showForm($ID, $options = [])
    {
        global $CFG_GLPI, $DB;

        $config = new PluginServicecatalogConfig();

        if (!self::canUpdate()) {
            return false;
        }

        $canUpdate = $this->can($this->getID(), UPDATE);

        $rand = mt_rand();

        echo "<form name='itilCategory_form$rand' id='itilCategory_form$rand' method='post'
            action='" . self::getFormURL() . "' enctype='multipart/form-data'>";

        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.js");
        echo $JS = <<<JAVASCRIPT
         <script type='text/javascript'>
         function accordion(id, openall) {
             if(id == undefined){
                 id  = 'accordion';
             }
             jQuery(document).ready(function () {
                 $("#"+id).accordion({
                     collapsible: true,
                     //active:[0, 1, 2, 3],
                     heightStyle: "content"
                 });
                 //if (openall) {
                     //$('#'+id +' .ui-accordion-content').show();
                 //}
             });
         };
         </script>
JAVASCRIPT;

        echo "<div id='accordion'>";


        echo "<h3 ><a href='#'>" . __('Informations for service catalog', 'servicecatalog') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr>";
        echo "<td>";
        echo __('Name for simplified interface (incident)', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        $opt = [
            'value' => $this->fields['simplified_name_incident'],
            'maxlength' => 250,
            'size' => 80,
        ];
        echo Html::input("simplified_name_incident", $opt);
        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Name for simplified interface (request)', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        $opt = [
            'value' => $this->fields['simplified_name_request'],
            'maxlength' => 250,
            'size' => 80,
        ];
        echo Html::input("simplified_name_request", $opt);
        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Display warning on the ticket creation form', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        Html::textarea(['name' => 'display_warning',
            'value' => $this->fields["display_warning"],
            'cols' => '75',
            'rows' => '7']);
        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Use this category to link a other website', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        PluginServicecatalogConfig::showSwitchField("use_website_url", $this->fields["use_website_url"]);

        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Url of the website', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        echo Html::input('website_url', ['name' => 'website_url',
            'value' => $this->fields["website_url"],
        ]);
        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Launch website on the same page', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        Dropdown::showYesNo("website_target", $this->fields["website_target"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Linked FAQ Item', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        $params = [
            'name' => 'knowbaseitems_id',
            'value' => $this->fields["knowbaseitems_id"],
            'condition' => ['is_faq' => 1]
        ];
        Dropdown::show(KnowbaseItem::class, $params);
        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Force validation of user responsible in simplified interface', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        PluginServicecatalogConfig::showSwitchField("force_validation", $this->fields["force_validation"]);

        echo "</td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>";
        echo __('Comments');
        echo "</td>";
        echo "<td colspan='2'>";
        Html::textarea(['name' => 'comment',
            'value' => $this->fields["comment"],
            'cols' => '75',
            'rows' => '7']);
        echo "</td>";
        echo "</tr>";

        if ($config->getEnableKeywords()) {
            $keyword = new PluginServicecatalogItilcategory_Keyword();
            $keywords = $keyword->getKeywords($this->fields['id']);

            echo "<tr><td>";
            echo __('Keywords', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            echo "<div class='spaced'><table class='tab_cadre_fixe' id='plugin_servicecatalog_keywords'>";
            $i = 1;
            foreach ($keywords as $data) {
                echo "<tr><td id='plugin_servicecatalog_keywords$i'>
                      <input type='text' name='keywords[]' maxlength='40' value=\"" . $data['name'] . "\">";
                echo " <a class='pointer' onclick=\"pluginServiceCatalogDelete('plugin_servicecatalog_keywords$i');\">";
                echo "&nbsp;<i style='font-size: 2em' class=\"fas fa-minus-circle\"></i></a>";
                echo "</td></tr>";
                $i += 1;
            }
            echo "<tr id='plugin_servicecatalog_add_keywords'><td>" . __('Add keyword', 'servicecatalog');
            echo " <a class='pointer' onclick=\"pluginServiceCatalogAdd('plugin_servicecatalog_add_keywords', '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/keyword.php', " . $this->fields["id"] . ");\">";
            echo "&nbsp;<i style='font-size: 2em' class=\"fas fa-plus-circle\"></i></a>";
            echo "</td></tr>";
            echo "</table></div>";
            echo "</td>";
            echo "</tr>";
        }

        // GROUPS
        if ($config->getEnableGroupRestriction()) {

            echo "<tr><td>";
            echo __('Group visibility', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            $visibility = [0 => __('Only these groups', 'servicecatalog'),
                1 => __('All groups and not these groups', 'servicecatalog')];
            Dropdown::showFromArray(
                'visibility_group',
                $visibility,
                [
                    'id' => 'visibility_group',
                    'value' => $this->fields['visibility_group']
                ]
            );
            echo "</td>";
            echo "</tr>";

            $group = new PluginServicecatalogGroup();
            $groups = $group->getGroups($this->fields['itilcategories_id'], $this->getTable());

            echo "<tr><td>";
            echo __('Limited to Groups', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            echo "<div class='spaced'><table class='tab_cadre_fixe' id='plugin_servicecatalog_groups'>";
            $i = 1;
            foreach ($groups as $data) {
                echo "<tr><td id='plugin_servicecatalog_groups$i'>";

                $rand = mt_rand();
                $params = [
                    'name' => 'group_' . $rand,
                    'value' => $data,
                    'condition' => getEntitiesRestrictCriteria(Group::getTable(), '', '', true)
                ];
                Dropdown::show(Group::class, $params);

                echo " <a class='pointer' onclick=\"pluginServiceCatalogDelete('plugin_servicecatalog_groups$i');\">";
                echo "&nbsp;<i style='font-size: 2em' class=\"fas fa-minus-circle\"></i></a>";
                echo "</td></tr>";
                $i += 1;
            }
            echo "<tr id='plugin_servicecatalog_add_groups'><td>" . __('Add group', 'servicecatalog');
            echo " <a class='pointer' onclick=\"pluginServiceCatalogAddGroup('plugin_servicecatalog_add_groups', '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/group.php', " . $this->fields["id"] . ");\">";
            echo "&nbsp;<i style='font-size: 2em' class=\"fas fa-plus-circle\"></i></a>";
            echo "</td></tr>";
            echo "</table></div>";
            echo "</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Personalization') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr><td>";
        echo __('Inherit of parent category', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        PluginServicecatalogConfig::showSwitchField("inherit_config", $this->fields["inherit_config"]);
        echo "</td>";
        echo "</tr>";

        if ($this->fields["inherit_config"] == false) {
            echo "<tr><td>";
            echo __('Icon');
            echo "</td>";
            echo "<td colspan='2'>";
            $icon_selector_id = 'icon_' . mt_rand();
            echo Html::select(
                'icon',
                [$this->fields['icon'] => $this->fields['icon']],
                [
                    'id' => $icon_selector_id,
                    'selected' => $this->fields['icon'],
                    'style' => 'width:175px;'
                ]
            );

            echo Html::script('js/Forms/FaIconSelector.js');
            echo Html::scriptBlock(
                <<<JAVASCRIPT
         $(
            function() {
               var icon_selector = new GLPI.Forms.FaIconSelector(document.getElementById('{$icon_selector_id}'));
               icon_selector.init();
            }
         );
JAVASCRIPT
            );

            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('Color', 'servicecatalog');
            echo "<br>" . __('(background for Wrapper / Logo & text for WrapperSly)', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::showColorField('background_color', ['value' => $this->fields["background_color"], 'rand' => $rand]);
            echo "</td>";
            echo "</tr>";

            echo "<tr>";
            echo "<td>" . __('Category Size', 'servicecatalog') . " (" . __('Wrapper mode', 'servicecatalog') . ")</td>";
            echo "<td colspan='2'>";
            $values = ['small' => __('Small', 'servicecatalog'),
                'normal' => __('Normal', 'servicecatalog'),
                'big' => __('Big', 'servicecatalog'),
            ];
            Dropdown::showFromArray('size', $values, ['value' => $this->fields["size"]]);
            echo "</td>";
            echo "</tr>";

            echo "<tr>";
            echo "<td>" . __('Stick with the next', 'servicecatalog') . " (" . __('Wrapper mode', 'servicecatalog') . ")</td>";
            echo "<td colspan='2'>";
            Dropdown::showYesNo("glue", $this->fields["glue"]);
            echo "</td>";
            echo "</tr>";
        } else {
            echo "<tr>";
            echo "<td></td>";
            echo "<td colspan='2'>";
            echo "<div class='badge bg-azure-lt m-1 py-3 inline'
                   title='" . __('Herited from parent category', 'servicecatalog') . "'
                   data-bs-toggle='tooltip'>
         <i class='fas fa-level-up-alt me-1'></i>";
            echo __('Herited from parent category', 'servicecatalog');
            echo "</div>";
            echo "</td>";
            echo "</tr>";


            echo "<tr><td>";
            echo __('Icon');
            echo "</td>";
            echo "<td colspan='2'>";
            $icon = self::getUsedConfig("inherit_config", $this->fields['itilcategories_id'], "icon");
            $color = self::getUsedConfig("inherit_config", $this->fields['itilcategories_id'], "background_color");
            echo "<i class='fas " . $icon . " fa-3x' style='color:$color'></i>";
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('Color', 'servicecatalog');
            echo "<br>" . __('(background for Wrapper / Logo & text for WrapperSly)', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";

            echo $color;
            echo "</td>";
            echo "</tr>";

            echo "<tr>";
            echo "<td>" . __('Category Size', 'servicecatalog') . " (" . __('Wrapper mode', 'servicecatalog') . ")</td>";
            echo "<td colspan='2'>";
            $size = self::getUsedConfig("inherit_config", $this->fields['itilcategories_id'], "size");
            echo $size;
            echo "</td>";
            echo "</tr>";

            echo "<tr>";
            echo "<td>" . __('Stick with the next', 'servicecatalog') . " (" . __('Wrapper mode', 'servicecatalog') . ")</td>";
            echo "<td colspan='2'>";
            $glue = self::getUsedConfig("inherit_config", $this->fields['itilcategories_id'], "glue");
            echo Dropdown::getYesNo($glue);
            echo "</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Logo', 'servicecatalog') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr><td>";
        echo __('Inherit of parent picture', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        PluginServicecatalogConfig::showSwitchField("inherit_picture", $this->fields["inherit_picture"]);
        echo "</td>";
        echo "</tr>";

        if ($this->fields["inherit_picture"] == false) {
            echo "<tr><td>" . __('Picture') . "</td>";
            echo "<td>";
            echo "<div style='width:145px;border-radius: 6px; border: 2px inset #969595;text-align:center;'
               id='picture$rand'>";
            echo "<img alt=\"" . __s('Picture') . "\" src='" .
                self::getThumbnailURLForPicture($this->fields['picture']) . "'>";
            echo "</div>";

            echo "</td><td>";

            echo "<input class='form-control'  type='file' name='picture' accept='image/*'>";
            echo "<input type='checkbox' name='_blank_picture'>&nbsp;" . __('Clear');
            echo "<p>" . sprintf(__('%1$s (%2$s)'), __('It is recommended to use a png file of size 145px x 75px', 'servicecatalog'), Document::getMaxUploadSize()) . "</p>";
            echo "</td>";
            echo "</tr>";
        } else {
            echo "<tr>";
            echo "<td></td>";
            echo "<td colspan='2'>";
            echo "<div class='badge bg-azure-lt m-1 py-3 inline'
                   title='" . __('Herited from parent category', 'servicecatalog') . "'
                   data-bs-toggle='tooltip'>
         <i class='fas fa-level-up-alt me-1'></i>";
            echo __('Herited from parent category', 'servicecatalog');
            echo "</div>";
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>" . __('Picture') . "</td>";
            echo "<td>";
            $picture = self::getUsedConfig("inherit_picture", $this->fields['itilcategories_id'], "picture");
            echo "<div style='width:145px;border-radius: 6px; border: 2px inset #969595;text-align:center;'
               id='picture$rand'>";
            echo "<img alt=\"" . __s('Picture') . "\" src='" .
                self::getThumbnailURLForPicture($picture) . "'>";
            echo "</div>";

            echo "</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Used itemtypes', 'servicecatalog') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr><td>";
        echo __('Inherit of parent itemtypes', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        PluginServicecatalogConfig::showSwitchField("inherit_itemtypes", $this->fields["inherit_itemtypes"]);
        echo "</td>";
        echo "</tr>";

        if ($this->fields["inherit_itemtypes"] == false) {
            $itemtypes = [];
            if (isset($this->fields["itemtypes"]) && !empty($this->fields["itemtypes"])) {
                $itemtypes = json_decode($this->fields["itemtypes"], true);
            }

            echo "<tr><td>";
            echo __('Used itemtypes', "servicecatalog");
            echo "</td>";
            echo "<td colspan='2'>";
            self::dropdownHelpdeskItemtypes(['values' => $itemtypes]);
            echo "</td>";
            echo "</tr>";

            if (is_array($itemtypes)
                && count($itemtypes) == 1) {
                echo "<tr><td>";
                echo __('Used items', "servicecatalog");
                echo "</td>";
                echo "<td colspan='2'>";
                foreach ($itemtypes as $itemtype) {
                    if (($item = getItemForItemtype($itemtype))) {
                        $itemtable = getTableForItemType($itemtype);
                        $entity_restrict = $_SESSION['glpiactiveentities'];
                        $criteria = [
                            'FROM' => $itemtable,
                            'WHERE' => getEntitiesRestrictCriteria($itemtable, '', $entity_restrict, $item->maybeRecursive()),
                            'ORDER' => $item->getNameField()
                        ];

                        if ($item->maybeDeleted()) {
                            $criteria['WHERE']['is_deleted'] = 0;
                        }
                        if ($item->maybeTemplate()) {
                            $criteria['WHERE']['is_template'] = 0;
                        }
                        if (in_array($itemtype, $CFG_GLPI["helpdesk_visible_types"])) {
                            $criteria['WHERE']['is_helpdesk_visible'] = 1;
                        }

                        $iterator = $DB->request($criteria);
                        $nb = count($iterator);

                        $items_id = [];
                        if (isset($this->fields["items_id"]) && !empty($this->fields["items_id"])) {
                            $items_id = json_decode($this->fields["items_id"], true);
                        }

                        if (!is_array($items_id)) {
                            $values = [];
                        } else {
                            $values = $items_id;
                        }

                        if ($nb > 0) {
                            foreach ($iterator as $data) {
                                $items[$data['id']] = $data['name'];
                            }

                            Dropdown::showFromArray(
                                'items_id',
                                $items,
                                ['values' => $values,
                                    'multiple' => true]
                            );
                        }
                    }
                }

                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr>";
            echo "<td></td>";
            echo "<td colspan='2'>";
            echo "<div class='badge bg-azure-lt m-1 py-3 inline'
                   title='" . __('Herited from parent category', 'servicecatalog') . "'
                   data-bs-toggle='tooltip'>
         <i class='fas fa-level-up-alt me-1'></i>";
            echo __('Herited from parent category', 'servicecatalog');
            echo "</div>";
            echo "</td>";
            echo "</tr>";

            $used_itemtypes = self::getUsedConfig("inherit_itemtypes", $this->fields['itilcategories_id'], "itemtypes");
            $itemtypes = [];
            if (isset($used_itemtypes) && !empty($used_itemtypes)) {
                $itemtypes = json_decode($used_itemtypes, true);
            }

            echo "<tr><td>";
            echo __('Used itemtypes', "servicecatalog");
            echo "</td>";
            echo "<td colspan='2'>";
            foreach ($itemtypes as $itemtype) {
                if (($item = getItemForItemtype($itemtype))) {
                    echo $item->getFieldLabel();
                    echo "<br>";
                }
                $used_items_id = self::getUsedConfig("inherit_itemtypes", $this->fields['itilcategories_id'], "items_id");
                if (isset($used_items_id) && !empty($used_items_id)) {
                    echo "<br>";
                    $items_id = json_decode($used_items_id, true);

                    foreach ($items_id as $items_id_unique) {
                        if ($item->getFromDB($items_id_unique)) {
                            echo $item->getName();
                        }
                    }
                }
            }

            //            self::dropdownHelpdeskItemtypes(['values' => $itemtypes]);
            echo "</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Mydashboard alerts', 'servicecatalog') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr><td>";
        echo __('Inherit of parent category', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        PluginServicecatalogConfig::showSwitchField("inherit_alert", $this->fields["inherit_alert"]);
        echo "</td>";
        echo "</tr>";

        if ($this->fields["inherit_alert"] == false) {
        } else {
            echo "<tr>";
            echo "<td></td>";
            echo "<td colspan='2'>";
            echo "<div class='badge bg-azure-lt m-1 py-3 inline'
                   title='" . __('Herited from parent category', 'servicecatalog') . "'
                   data-bs-toggle='tooltip'>
         <i class='fas fa-level-up-alt me-1'></i>";
            echo __('Herited from parent category', 'servicecatalog');
            echo "</div>";
            echo "</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Service details', 'servicecatalog') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr><td>";
        echo __('Inherit of parent category', "servicecatalog");
        echo "</td>";
        echo "<td colspan='2'>";
        PluginServicecatalogConfig::showSwitchField("inherit_detail", $this->fields["inherit_detail"]);
        echo "</td>";
        echo "</tr>";

        if ($this->fields["inherit_detail"] == false) {

            echo "<tr><td>" . __('Picture for display category details', 'servicecatalog') . "</td>";
            echo "<td>";
            echo "<div style='width:145px;border-radius: 6px; border: 2px inset #969595;text-align:center;'
               id='picture_detail$rand'>";
            echo "<img alt=\"" . __s('Picture') . "\" src='" .
                self::getThumbnailURLForPicture($this->fields['picture_detail']) . "'>";
            echo "</div>";

            echo "</td><td>";

            echo "<input class='form-control'  type='file' name='picture_detail' accept='image/*'>";
            echo "<input type='checkbox' name='_blank_picture_detail'>&nbsp;" . __('Clear');
            echo "<p>" . Document::getMaxUploadSize() . "</p>";
            echo "</td>";
            echo "</tr>";

            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Width of details picture', 'servicecatalog') . "</td>";
            echo "<td>";
            $optionNumber = [
                'value' => $this->fields['picture_detail_width'],
                'min'   => 50,
                'max'   => 100,
            ];
            Dropdown::showNumber('picture_detail_width', $optionNumber);
            echo " %</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('How can i use it', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::textarea(['name' => 'service_detail',
                'value' => $this->fields["service_detail"],
                'enable_richtext' => true,
                'enable_fileupload' => false,
                'enable_images' => false,
                'cols' => '75',
                'rows' => '5']);
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('Who can benefit from this service?', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::textarea(['name' => 'service_users',
                'value' => $this->fields["service_users"],
                'enable_richtext' => true,
                'enable_fileupload' => false,
                'enable_images' => false,
                'cols' => '75',
                'rows' => '5']);
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('Lead time', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::textarea(['name' => 'service_ttr',
                'value' => $this->fields["service_ttr"],
                'enable_richtext' => true,
                'enable_fileupload' => false,
                'enable_images' => false,
                'cols' => '75',
                'rows' => '5']);
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('How to obtain the software in case of request?', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::textarea(['name' => 'service_use',
                'value' => $this->fields["service_use"],
                'enable_richtext' => true,
                'enable_fileupload' => false,
                'enable_images' => false,
                'cols' => '75',
                'rows' => '5']);
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('Availability of service', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::textarea(['name' => 'service_supervision',
                'value' => $this->fields["service_supervision"],
                'enable_richtext' => true,
                'enable_fileupload' => false,
                'enable_images' => false,
                'cols' => '75',
                'rows' => '5']);
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('What are the rules to follow ?', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::textarea(['name' => 'service_rules',
                'value' => $this->fields["service_rules"],
                'enable_richtext' => true,
                'enable_fileupload' => false,
                'enable_images' => false,
                'cols' => '75',
                'rows' => '5']);
            echo "</td>";
            echo "</tr>";

            echo "<tr><td>";
            echo __('Useful links', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            Html::textarea(['name' => 'service_links',
                'value' => $this->fields["service_links"],
                'enable_richtext' => true,
                'enable_fileupload' => false,
                'enable_images' => false,
                'cols' => '75',
                'rows' => '5']);
            echo "</td>";
            echo "</tr>";
        } else {


            echo "<tr><td>" . __('Picture') . "</td>";
            echo "<td>";
            $picture = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "picture_detail");
            echo "<div style='width:145px;border-radius: 6px; border: 2px inset #969595;text-align:center;'
               id='picture_detail$rand'>";
            echo "<img alt=\"" . __s('Picture') . "\" src='" .
                self::getThumbnailURLForPicture($picture) . "'>";
            echo "</div>";

            echo "</td>";
            echo "</tr>";

            $service_detail = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "service_detail");
            echo "<tr><td>";
            echo __('How can i use it', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            if ($service_detail != null) {
                echo Glpi\RichText\RichText::getTextFromHtml($service_detail);
            }
            echo "</td>";
            echo "</tr>";

            $service_users = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "service_users");
            echo "<tr><td>";
            echo __('Who can benefit from this service?', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            if ($service_users != null) {
                echo Glpi\RichText\RichText::getTextFromHtml($service_users);
            }
            echo "</td>";
            echo "</tr>";

            $service_ttr = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "service_ttr");
            echo "<tr><td>";
            echo __('Lead time', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            if ($service_ttr != null) {
                echo Glpi\RichText\RichText::getTextFromHtml($service_ttr);
            }
            echo "</td>";
            echo "</tr>";

            $service_use = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "service_use");
            echo "<tr><td>";
            echo __('How to obtain the software in case of request?', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            if ($service_use != null) {
                echo Glpi\RichText\RichText::getTextFromHtml($service_use);
            }
            echo "</td>";
            echo "</tr>";

            $service_supervision = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "service_supervision");
            echo "<tr><td>";
            echo __('Availability of service', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            if ($service_supervision != null) {
                echo Glpi\RichText\RichText::getTextFromHtml($service_supervision);
            }
            echo "</td>";
            echo "</tr>";

            $service_rules = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "service_rules");
            echo "<tr><td>";
            echo __('What are the rules to follow ?', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            if ($service_rules != null) {
                echo Glpi\RichText\RichText::getTextFromHtml($service_rules);
            }
            echo "</td>";
            echo "</tr>";

            $service_links = self::getUsedConfig("inherit_detail", $this->fields['itilcategories_id'], "service_links");
            echo "<tr><td>";
            echo __('Useful links', 'servicecatalog');
            echo "</td>";
            echo "<td colspan='2'>";
            if ($service_links != null) {
                echo Glpi\RichText\RichText::getTextFromHtml($service_links);
            }
            echo "</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";

        echo "</div>";

        echo "<script>accordion();</script>";

        echo Html::hidden('id', ['value' => $this->fields["id"]]);

        $options['canedit'] = false;

        if ($canUpdate) {
            $options['canedit'] = true;
        }
        $options['candel'] = false;
        $this->showFormButtons($options);
    }

    /**
     * Get picture URL from picture field
     *
     * @param $picture picture field
     *
     * @return string URL to show picture
     **@since version 0.85
     *
     */
    public static function getThumbnailURLForPicture($picture)
    {
        global $CFG_GLPI;

        if (!empty($picture)) {
            $tmp = explode(".", $picture);

            if (count($tmp) == 2) {
                return PLUGIN_SERVICECATALOG_WEBDIR . "/front/document.send.php?file=_plugins/" . $tmp[0] .
                    "." . $tmp[1];
            }
        }
        return PLUGIN_SERVICECATALOG_WEBDIR . "/pics/picture.png";
    }

    /**
     * Send a file (not a document) to the navigator
     * See Document->send();
     *
     * @param $file      string: storage filename
     * @param $filename  string: file title
     *
     * @return void
     */
    public static function sendFile($file, $filename)
    {
        // Test securite : document in DOC_DIR
        $tmpfile = str_replace(GLPI_PLUGIN_DOC_DIR, "", $file);

        if (strstr($tmpfile, "../") || strstr($tmpfile, "..\\")) {
            \Glpi\Event::log(
                $file,
                "sendFile",
                1,
                "security",
                $_SESSION["glpiname"] . " try to get a non standard file."
            );
            die("Security attack!!!");
        }

        if (!file_exists($file)) {
            die("Error file $file does not exist");
        }

        $mime = "application/octetstream";

        if (preg_match('/\.(...)$/', $file, $regs)) {
            switch ($regs[1]) {
                case "sql":
                    $mime = "text/x-sql";
                    break;

                case "xml":
                    $mime = "text/xml";
                    break;

                case "csv":
                    $mime = "text/csv";
                    break;

                case "svg":
                    $mime = "image/svg+xml";
                    break;

                case "png":
                    $mime = "image/png";
                    break;
            }
        }

        // Now send the file with header() magic
        header("Expires: Mon, 26 Nov 1962 00:00:00 GMT");
        header('Pragma: private'); /// IE BUG + SSL
        header('Cache-control: private, must-revalidate'); /// IE BUG + SSL
        header("Content-disposition: filename=\"$filename\"");
        header("Content-type: " . $mime);

        readfile($file) or die("Error opening file $file");
    }

    /**
     * get list of categories in fact the type
     *
     * @param     $type
     *
     * @param int $withchild
     *
     * @return array
     * @throws \GlpitestSQLError
     */
    public static function getCategories($type, $withchild = 1)
    {
        global $DB;

//        $TIMER = new Timer();
//        $TIMER->start();

        $dbu = new DbUtils();
        $condition = [];
        if (isset($_SESSION["glpiactiveprofile"])
            && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
            $condition = ['is_helpdeskvisible' => 1];
        }
        $condition += $dbu->getEntitiesRestrictCriteria('glpi_itilcategories', '', $_SESSION["glpiactive_entity"], true);

        switch ($type) {
            case Ticket::DEMAND_TYPE:
                $condition['is_request'] = 1;
                break;
            case Ticket::INCIDENT_TYPE:
                $condition['is_incident'] = 1;
                break;
            default:
                $condition = [
                    'OR' => [
                        ['is_incident' => 1],
                        ['is_request' => 1]
                    ]
                ];
                break;
        }

        $order = ["completename"];
        $itil_category = new ITILCategory();

        $table = $itil_category->getTable();
        $SELECTNAME = new \QueryExpression("'' AS " . $DB->quoteName('transname'));
        $SELECTCOMMENT = new \QueryExpression("'' AS " . $DB->quoteName('transcomment'));
        $SELECTCOMPLETENAME = new \QueryExpression("'' AS " . $DB->quoteName('completename'));
        $JOIN = [];
        $JOINS = [];
        $WHERE = [];
        $ORDERBY = [];
        if (Session::haveTranslations(getItemTypeForTable($table), 'name')) {
            $SELECTNAME = 'namet.value AS transname';
            $JOINS['glpi_dropdowntranslations AS namet'] = [
                'ON' => [
                    'namet' => 'items_id',
                    $table => 'id', [
                        'AND' => [
                            'namet.itemtype' => getItemTypeForTable($table),
                            'namet.language' => $_SESSION['glpilanguage'],
                            'namet.field' => 'name'
                        ]
                    ]
                ]
            ];
        }
        if (Session::haveTranslations(getItemTypeForTable($table), 'completename')) {
            $SELECTCOMPLETENAME = 'namect.value AS transcompletename';
            $JOINS['glpi_dropdowntranslations AS namect'] = [
                'ON' => [
                    'namect' => 'items_id',
                    $table => 'id', [
                        'AND' => [
                            'namect.itemtype' => getItemTypeForTable($table),
                            'namect.language' => $_SESSION['glpilanguage'],
                            'namect.field' => 'completename'
                        ]
                    ]
                ]
            ];
        }
        if (Session::haveTranslations(getItemTypeForTable($table), 'comment')) {
            $SELECTCOMMENT = 'namec.value AS transcomment';
            $JOINS['glpi_dropdowntranslations AS namec'] = [
                'ON' => [
                    'namec' => 'items_id',
                    $table => 'id', [
                        'AND' => [
                            'namec.itemtype' => getItemTypeForTable($table),
                            'namec.language' => $_SESSION['glpilanguage'],
                            'namec.field' => 'comment'
                        ]
                    ]
                ]
            ];
        }

        if (count($JOINS)) {
            $JOIN = ['LEFT JOIN' => $JOINS];
        }

        if (count($condition)) {
            $WHERE = [
                'WHERE' => $condition
            ];
        }

        if (count($order)) {
            $ORDERBY = [
                'ORDERBY' => $order
            ];
        }

        $datastoadd = [];
        $config = new PluginServicecatalogConfig();
        $favorites = PluginServicecatalogFavorite::getFavorites();
        $count = 0;

        $crits = [
                'SELECT' => [
                    "$table.*",
                    $SELECTNAME,
                    $SELECTCOMPLETENAME,
                    $SELECTCOMMENT
                ],
                'FROM' => $table,
            ] + $JOIN + $WHERE + $ORDERBY;

        $iterator = $DB->request($crits);

        foreach ($iterator as $data) {
            $level = $data['level'];
            $ID = $data['id'];

            if ($config->getEnableGroupRestriction() == 1) {
                if (!self::isCategoryAllowedByUserGroups($ID)) {
                    continue;
                }
            }

            if ($level > 1) {
                if (!isset($last_level_displayed[$level - 1])
                    || (isset($last_level_displayed) && $last_level_displayed[$level - 1] != $data['itilcategories_id'])) {
                    $work_level = $level - 1;
                    $work_parentID = $data[$itil_category->getForeignKeyField()];
                    $parent_datas = [];

                    do {
                        // Get parent
                        if ($itil_category->getFromDB($work_parentID)
                            //                         && self::isCategoryAllowedByUserGroups($itil_category->fields['itilcategories_id'])
                        ) {
                            $condition = [
                                'itilcategories_id' => $itil_category->fields['id'],
                                'type' => $type];

                            $ranking = 0;
                            $order = new PluginServicecatalogCategoryorder();
                            $ranks = $order->find($condition);

                            if (count($ranks) > 0) {
                                foreach ($ranks as $rank) {
                                    $ranking = $rank['ranking'];
                                }
                            }

                            $cat = new self();
                            $comment = "";
                            $simplified_name_incident_parent = "";
                            $simplified_name_request_parent = "";
                            $warning_parent = "";
                            $keywords = null;
                            $groups = null;
                            $use_website_url = 0;
                            $website_url = "";
                            $website_target = 1;
                            if ($cat->getFromDBByCategory($itil_category->fields['id'])) {
                                $comment = self::displayField($cat, 'comment');
                                $keyword = new PluginServicecatalogItilcategory_Keyword();
                                $keywords = $keyword->getKeywordsInString($cat->fields['id']);
                                $simplified_name_incident_parent = self::displayField($cat, 'simplified_name_incident');
                                $simplified_name_request_parent = self::displayField($cat, 'simplified_name_request');
                                $warning_parent = self::displayField($cat, 'display_warning');
                                $use_website_url = $cat->fields['use_website_url'];
                                $website_url = $cat->fields['website_url'];
                                $website_target = $cat->fields['website_target'];
                            }

                            $icon = self::getUsedConfig("inherit_config", $itil_category->fields['id'], 'icon');
                            $default_icon = "fas fa-network-wired";
                            if (!empty($config->fields['default_icon'])) {
                                $default_icon = $config->fields['default_icon'];
                            }
                            $icon = (!empty($icon) ? $icon : $default_icon);
                            $picture = self::getUsedConfig("inherit_picture", $itil_category->fields['id'], "picture");
                            $picture = (!empty($picture) ? $picture : "");
                            $background_color = self::getUsedConfig("inherit_config", $itil_category->fields['id'], "background_color");
                            $background_color = (!empty($background_color) ? $background_color : $config->getGeneralColor());
                            $size = self::getUsedConfig("inherit_config", $itil_category->fields['id'], "size");
                            $size = (!empty($size) ? $size : "normal");
                            $glue = self::getUsedConfig("inherit_config", $itil_category->fields['id'], "glue");
                            $glue = ($glue > 0 ? "stick" : "");

                            if (empty($name_parent = DropdownTranslation::getTranslatedValue(
                                $itil_category->fields['id'],
                                ITILCategory::class,
                                'name',
                                $_SESSION['glpilanguage']
                            ))) {
                                $name_parent = $itil_category->fields['name'];
                            }

                            if (empty($comment)) {
                                $comment = DropdownTranslation::getTranslatedValue($itil_category->fields['id'], 'ITILCategory', 'comment', $_SESSION['glpilanguage']);
                                if (empty($comment)) {
                                    $comment = $itil_category->fields['comment'];
                                }
                            }

                            if (empty($completename = DropdownTranslation::getTranslatedValue(
                                $itil_category->fields['id'],
                                ITILCategory::class,
                                'completename',
                                $_SESSION['glpilanguage']
                            ))) {
                                $completename = $itil_category->fields['completename'];
                            }
                            $disabled = 0;
                            if ($config->getEnableGroupRestriction() == 1) {
                                $disabled = (self::isCategoryAllowedByUserGroups($itil_category->fields['id']) ? 0 : 1);
                                $disabled_parent = (self::isCategoryAllowedByUserGroups($itil_category->fields['itilcategories_id']) ? 0 : 1);
                                if ($disabled_parent == 1) {
                                    $disabled = 1;
                                }
                            }
                            $sons = count(self::getSons($itil_category->fields['id'], $type));

                            $favorite = 0;
                            $favorite_itilcategories_id = 0;
                            $users_id = 0;
                            $ranking_incidents = 0;
                            $ranking_requests = 0;
                            if (Session::haveRight('plugin_servicecatalog_favorites', READ)
                                && in_array($itil_category->fields['id'], $favorites)) {
                                $favorite = 1;
                                $fav = new PluginServicecatalogFavorite();
                                $fav_users = new PluginServicecatalogFavorite_User();
                                if ($fav->getFromDBByCategory($itil_category->fields['id'])) {
                                    $favorite_itilcategories_id = $fav->fields['favorite_itilcategories_id'];
                                    if ($fav_users->getFromDBByCrit(['favorites_id' => $fav->getField('id')])) {
                                        $users_id = $fav_users->fields['users_id'];
                                        $ranking_requests = $fav_users->fields['ranking_requests'];
                                        $ranking_incidents = $fav_users->fields['ranking_incidents'];
                                    }
                                }
                            }

                            $temp = [
                                'id' => $itil_category->fields['id'],
                                'name' => $name_parent,
                                'simplified_name_incident' => $simplified_name_incident_parent,
                                'simplified_name_request' => $simplified_name_request_parent,
                                'display_warning' => $warning_parent,
                                'completename' => $completename,
                                'level' => $work_level,
                                'ranking' => $ranking,
                                'itilcategories_id' => $itil_category->fields['itilcategories_id'],
                                'knowbaseitemcategories_id' => $itil_category->fields['knowbaseitemcategories_id'],
                                'is_request' => $itil_category->fields['is_request'],
                                'is_incident' => $itil_category->fields['is_incident'],
                                'comment' => $comment,
                                'keywords' => $keywords,
                                //                           'groups'                    => $groups,
                                'disabled' => $disabled,
                                'favorite' => $favorite,
                                'icon' => $icon,
                                'picture' => $picture,
                                'use_website_url' => $use_website_url,
                                'website_target' => $website_target,
                                'website_url' => $website_url,
                                'background_color' => $background_color,
                                'size' => $size,
                                'glue' => $glue,
                                'favorite_itilcategories_id' => $favorite_itilcategories_id,
                                'favorite_users_id' => $users_id,
                                'ranking_requests' => $ranking_requests,
                                'ranking_incidents' => $ranking_incidents,
                                'have_sons' => $sons
                            ];

                            array_unshift($parent_datas, $temp);

                            $last_level_displayed[$work_level] = $itil_category->fields['id'];
                            $work_level--;
                            $work_parentID = $itil_category->fields[$itil_category->getForeignKeyField()];
                        } else { // Error getting item : stop
                            $work_level = -1;
                        }
                    } while (($work_level >= 1)
                    && (!isset($last_level_displayed[$work_level])
                        || ($last_level_displayed[$work_level] != $work_parentID)));

                    // Add parents
                    foreach ($parent_datas as $val) {
                        array_push($datastoadd, $val);
                    }
                }
            }

            $last_level_displayed[$level] = $data['id'];

            $ranking = 0;
            //display categories without childs
            $condition = ['itilcategories_id' => $data['id'],
                'type' => $type,
                'level' => $level];
            $order = new PluginServicecatalogCategoryorder();
            $ranks = $order->find($condition, "ranking");

            if (count($ranks) > 0) {
                foreach ($ranks as $rank) {
                    $ranking = $rank['ranking'];
                }
            }

            $cat = new self();

            $comment = "";
            $simplified_name_incident = "";
            $simplified_name_request = "";
            $warning = "";
            $keywords = null;
            $groups = null;
            $use_website_url = 0;
            $website_url = "";
            $website_target = 0;
            if ($cat->getFromDBByCategory($ID)) {
                $keyword = new PluginServicecatalogItilcategory_Keyword();
                $keywords = $keyword->getKeywordsInString($cat->fields['id']);
                $comment = self::displayField($cat, 'comment');
                $simplified_name_incident = self::displayField($cat, 'simplified_name_incident');
                $simplified_name_request = self::displayField($cat, 'simplified_name_request');
                $warning = self::displayField($cat, 'display_warning');
                $use_website_url = $cat->fields['use_website_url'];
                $website_url = $cat->fields['website_url'];
                $website_target = $cat->fields['website_target'];
            }
            $config = new PluginServicecatalogConfig();
            $icon_sons = self::getUsedConfig("inherit_config", $data['id'], 'icon');
            $default_icon = "fas fa-network-wired";
            if (!empty($config->fields['default_icon'])) {
                $default_icon = $config->fields['default_icon'];
            }
            $icon_sons = (!empty($icon_sons) ? $icon_sons : $default_icon);
            $picture_sons = self::getUsedConfig("inherit_picture", $data['id'], "picture");
            $picture_sons = (!empty($picture_sons) ? $picture_sons : "");
            $background_color_sons = self::getUsedConfig("inherit_config", $data['id'], "background_color");
            $background_color_sons = (!empty($background_color_sons) ? $background_color_sons : $config->getGeneralColor());
            //            $size_sons             = self::getUsedConfig("inherit_config", $data['id'], "size");
            //            $size_sons             = (!empty($size_sons) ? $size_sons : "normal");
            //            $glue_sons             = self::getUsedConfig("inherit_config", $data['id'], "glue");
            //            $glue_sons             = ($glue_sons > 0 ? "stick" : "");

            if (!empty($data['transname'])) {
                $name = $data['transname'];
            } else {
                $name = $data['name'];
            }

            if (!empty($data['transcomment'])) {
                $comment = $data['transcomment'];
            } else {
                $comment = $data['comment'];
            }

            if (!empty($data['transcompletename'])) {
                $completename = $data['transcompletename'];
            } else {
                $completename = $data['completename'];
            }

            //check parent
            $disabled_sons = 0;
            if ($config->getEnableGroupRestriction() == 1) {
                $disabled_sons = (self::isCategoryAllowedByUserGroups($ID) ? 0 : 1);
                $disabled_parent = (self::isCategoryAllowedByUserGroups($data['itilcategories_id']) ? 0 : 1);
                if ($disabled_parent == 1) {
                    $disabled_sons = 1;
                }
            }
            $sons = count(self::getSons($ID, $type));

            $favorite = 0;
            $favorite_itilcategories_id = 0;
            $users_id = 0;
            $ranking_incidents = 0;
            $ranking_requests = 0;
            if (Session::haveRight('plugin_servicecatalog_favorites', READ)
                && in_array($ID, $favorites)) {
                $favorite = 1;
                $fav = new PluginServicecatalogFavorite();
                $fav_users = new PluginServicecatalogFavorite_User();
                if ($fav->getFromDBByCategory($ID)) {
                    $favorite_itilcategories_id = $fav->fields['favorite_itilcategories_id'];
                    if ($fav_users->getFromDBByCrit(['favorites_id' => $fav->getField('id')])) {
                        $users_id = $fav_users->fields['users_id'];
                        $ranking_requests = $fav_users->fields['ranking_requests'];
                        $ranking_incidents = $fav_users->fields['ranking_incidents'];
                    }
                }
            }

            $item = [
                'id' => $ID,
                'name' => $name,
                'simplified_name_incident' => $simplified_name_incident,
                'simplified_name_request' => $simplified_name_request,
                'display_warning' => $warning,
                'completename' => $completename,
                'level' => $level,
                'ranking' => $ranking,
                'itilcategories_id' => $data['itilcategories_id'],
                'knowbaseitemcategories_id' => $data['knowbaseitemcategories_id'],
                'is_request' => $data['is_request'],
                'is_incident' => $data['is_incident'],
                'comment' => $comment,
                'keywords' => $keywords,
                //                           'groups'                    => $groups,
                'disabled' => $disabled_sons,
                'favorite' => $favorite,
                'icon' => $icon_sons,
                'picture' => $picture_sons,
                'use_website_url' => $use_website_url,
                'website_url' => $website_url,
                'website_target' => $website_target,
                'background_color' => $background_color_sons,
                'size' => "normal",
                'glue' => "",
                'favorite_itilcategories_id' => $favorite_itilcategories_id,
                'favorite_users_id' => $users_id,
                'ranking_requests' => $ranking_requests,
                'ranking_incidents' => $ranking_incidents,
                'have_sons' => $sons
            ];

            array_push($datastoadd, $item);
            $count++;
        }

        $ID_levelOne = -1;
        $categories = [];

        foreach ($datastoadd as $id => $values) {
            if ($values['level'] == 1) {
                $categories[$values['id']] = $values;
                $ID_levelOne = $values['id'];
            } else {
                if ($withchild == 1) {
                    $categories[$ID_levelOne]['subcategories'][$values['id']] = $values;
                }
            }
        }

        $new = array();
        foreach ($datastoadd as $a) {
            $new[$a['itilcategories_id']][] = $a;
        }
        $self = new self();
        if (isset($new[0])) {
            $categories = $self->createTree($new, $new[0]); // changed
        }

        //      Toolbox::logWarning($categories);
//        $TIME = $TIMER->getTime();
        //      Toolbox::logWarning("getCategories");
        //      Toolbox::logWarning($TIME);
        return $categories;
    }

    /**
     * @param $list
     * @param $parent
     *
     * @return array
     */
    public function createTree(&$list, $parent)
    {
        $tree = array();
        foreach ($parent as $k => $l) {
            if (isset($list[$l['id']])) {
                $l['subcategories'] = $this->createTree($list, $list[$l['id']]);
            }
            $tree[$l['id']] = $l;
        }
        return $tree;
    }

    /**
     * @param $needle
     * @param $haystack
     *
     * @return bool
     */
    public function findCategory($needle, $haystack)
    {
        if (is_array($haystack)) {
            foreach ($haystack as $key => $value) {
                if ($key === $needle) {
                    return $value;
                } elseif (is_array($value)) {
                    $result = $this->findCategory($needle, $value);
                    if ($result !== false) {
                        return $result;
                    }
                }
            }
        }


        return false;
    }

    /**
     * @param $array
     *
     * @return array|array[]
     */
    public function findChildsCategories($array)
    {
        if (empty($array)) {
            return [];
        }
        return array_merge(
            [array_column($array, 'id')],
            $this->findChildsCategories(array_column($array, 'subcategories'))
        );
    }

    /**
     * @param int $type
     *
     * @throws \GlpitestSQLError
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public static function setCategoriesCache($type = 0)
    {
        global $GLPI_CACHE;

        //Toolbox::logwarning('set');
        //      if (Toolbox::useCache()) {
        $cat = new self();
        if ($type > 0) {
            $datas = self::getCategoriesCache($type);
            if (!is_array($datas) || count($datas) == 0) {
                $ckey = 'sc_cache_' . md5($cat->getTable() . $type);
                $categories = self::getCategories($type);
                foreach ($categories as $k => $cats) {
                    if ($cats['disabled'] == 1) {
                        unset($categories[$k]);
                    }
                }
                $GLPI_CACHE->set($ckey, $categories);
                //Toolbox::logwarning('setandload');
            }
        } else {
            $types = [Ticket::INCIDENT_TYPE, Ticket::DEMAND_TYPE];
            foreach ($types as $type) {
                $datas = self::getCategoriesCache($type);
                if (!is_array($datas) || count($datas) == 0) {
                    $ckey = 'sc_cache_' . md5($cat->getTable() . $type);
                    $categories = self::getCategories($type);
                    foreach ($categories as $k => $cats) {
                        if ($cats['disabled'] == 1) {
                            unset($categories[$k]);
                        }
                    }
                    $GLPI_CACHE->set($ckey, $categories);
                    //Toolbox::logwarning('setandloadall');
                }
            }
        }
        //      } else {
        //         $categories                                                                                                                                                       = self::getCategories($type);
        //         $_SESSION["glpi_plugin_servicecatalog_categories"][$_SESSION['glpilanguage']][$_SESSION["glpiactiveprofile"]["interface"]][$_SESSION["glpiactive_entity"]][$type] = $categories;
        //      }
    }

    /**
     * @param $type
     *
     * @return mixed|null
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public static function getCategoriesCache($type)
    {
        global $GLPI_CACHE;

        //$TIMER = new Timer();
        //$TIMER->start();
        //      if (Toolbox::useCache()) {
        $cat = new self();
        $ckey = 'sc_cache_' . md5($cat->getTable() . $type);
        $datas = $GLPI_CACHE->get($ckey);
        if (!is_array($datas) || count($datas) == 0) {
            $ckey = 'sc_cache_' . md5($cat->getTable() . $type);
            $datas = self::getCategories($type);
            foreach ($datas as $k => $cats) {
                if ($cats['disabled'] == 1) {
                    unset($datas[$k]);
                }
            }

            $GLPI_CACHE->set($ckey, $datas);
            //Toolbox::logwarning('setandload');
        }
        //      Toolbox::logWarning("getCategoriesCache");


        //      } else {
        //         if (isset($_SESSION["glpi_plugin_servicecatalog_categories"]) && is_array($_SESSION["glpi_plugin_servicecatalog_categories"])) {
        //            return $_SESSION["glpi_plugin_servicecatalog_categories"][$_SESSION['glpilanguage']][$_SESSION["glpiactiveprofile"]["interface"]][$_SESSION["glpiactive_entity"]][$type];
        //         }
        //      }
        //$TIME = $TIMER->getTime();
        //Toolbox::logWarning($TIME);
        //      return [];
        //      return $GLPI_CACHE->get($ckey);
        return $datas;
    }

    /**
     * Check if user can see the category using group restriction and group restriction recursive
     *
     * @param $category_id
     *
     * @return bool
     * @throws \GlpitestSQLError
     */
    public static function isCategoryAllowedByUserGroups($category_id)
    {
        $config = new PluginServicecatalogConfig();
        if ($config->getEnableGroupRestriction() == 1) {
            $user_groups = Group_User::getUserGroups($_SESSION['glpiID']);

            $pluginServicecatalogGroup = new PluginServicecatalogGroup();

            $current_result = false;

            $allowedGroups = $pluginServicecatalogGroup->getGroups($category_id, self::getTable());

            $self = new self();
            $visibility = 0;

            if($self->getFromDBByCategory($category_id) && $self->fields['visibility_group'] == 1) {
                $visibility = 1;
            }

            if ($visibility == 0) {
                if (empty($allowedGroups)) {
                    $current_result = true;
                } else {
                    foreach ($allowedGroups as $allowed_group) {
                        foreach ($user_groups as $user_group) {
                            if ($user_group['id'] == $allowed_group) {
                                $current_result = true;
                            }
                        }

                        if ($config->getEnableGroupRestrictionRecursive() == 1 && !$current_result) {
                            foreach ($user_groups as $user_group) {
                                if (self::findGroupInGroupAncestors($user_group['id'], $allowed_group)) {
                                    $current_result = true;
                                }
                            }
                        }
                    }
                }
                if (!$current_result) {
                    return false;
                } else {
                    return true;
                }
            } else {
                if (empty($allowedGroups)) {
                    return true;
                } else {
                    foreach ($allowedGroups as $allowed_group) {
                        foreach ($user_groups as $user_group) {
                            if ($user_group['id'] == $allowed_group) {
                                return false;
                            }
                        }

                        if ($config->getEnableGroupRestrictionRecursive() == 1 && !$current_result) {
                            foreach ($user_groups as $user_group) {
                                if (self::findGroupInGroupAncestors($user_group['id'], $allowed_group)) {
                                    return false;
                                }
                            }
                        }
                    }
                }
                return true;
            }

        }

    }


    /**
     * @param $type
     * @param $category_id
     *
     * @return int|mixed
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public static function getDisabledCategory($type, $category_id)
    {
        $disabled = 0;

        $datas = self::getCategoriesCache($type);

        $categories = [];

        while (!empty($datas)) {
            $temp = [];
            foreach ($datas as $k => $v) {
                if (isset($v["subcategories"])) {
                    $temp = array_merge($temp, $v['subcategories']);
                } else {
                    $categories[] = $v;
                }
            }
            $categories = array_merge($categories, $temp);
            $datas = $temp;
        }

        foreach ($categories as $k => $v) {
            if ($v['id'] == $category_id) {
                $disabled = $v['disabled'];
            }
        }

        return $disabled;
    }


    /**
     * Find group in ancestors of group
     * Look for ancestors until no ancestors or group found
     *
     * @param $group_id
     * @param $group_id_to_find
     *
     * @return bool
     */
    private static function findGroupInGroupAncestors($group_id, $group_id_to_find)
    {
        $result = false;
        $stack = [];
        $stack[] = $group_id;

        while (count($stack) > 0) {
            $group_id = array_pop($stack);

            if ($group_id == $group_id_to_find) {
                $result = true;
                break;
            }

            $dbu = new DBUtils();
            $ancestors = $dbu->getAncestorsOf(Group::getTable(), $group_id);

            foreach ($ancestors as $ancestor) {
                if ($ancestor !== $group_id) {
                    $stack[] = $ancestor;
                }
            }
        }

        return $result;
    }

    /**
     * Returns the translation of the field
     *
     * @param type $item
     * @param type $field
     *
     * @return type
     * @global type $DB
     *
     */
    public static function displayField($item, $field)
    {
        global $DB;

        // Make new database object and fill variables
        $table = $item->getTable();
        $dbu = new DbUtils();
        $iterator = $DB->request([
            'FROM' => 'glpi_plugin_servicecatalog_categorytranslations',
            'WHERE' => [
                'itemtype' => $dbu->getItemTypeForTable($table),
                'items_id' => $item->getID(),
                'field' => $field,
                'language' => $_SESSION['glpilanguage']
            ]]);

        if (count($iterator)) {
            foreach ($iterator as $data) {
                return $data['value'];
            }
        }
        return $item->fields[$field] ?? "";
    }


    /**
     * Get the Search options for the given Type
     *
     * This should be overloaded in Class
     *
     * @return array an *indexed* array of search options
     *
     * @see https://glpi-developer-documentation.rtfd.io/en/master/devapi/search.html
     **/
    public function rawSearchOptions()
    {
        $tab = [];

        $tab[] = [
            'id' => 'common',
            'name' => __('Characteristics')
        ];

        $tab[] = [
            'id' => '1',
            'table' => $this->getTable(),
            'field' => 'comment',
            'name' => __('Comments'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '2',
            'table' => $this->getTable(),
            'field' => 'service_detail',
            'name' => __('How can i use it', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '3',
            'table' => $this->getTable(),
            'field' => 'service_users',
            'name' => __('Who can benefit from this service?', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '4',
            'table' => $this->getTable(),
            'field' => 'service_ttr',
            'name' => __('Lead time', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '5',
            'table' => $this->getTable(),
            'field' => 'service_use',
            'name' => __('How to obtain the software in case of request?', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '6',
            'table' => $this->getTable(),
            'field' => 'service_supervision',
            'name' => __('Availability of service', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '7',
            'table' => $this->getTable(),
            'field' => 'service_rules',
            'name' => __('What are the rules to follow ?', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '8',
            'table' => $this->getTable(),
            'field' => 'service_links',
            'name' => __('Useful links', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];
        $tab[] = [
            'id' => '9',
            'table' => $this->getTable(),
            'field' => 'icon',
            'name' => __('Icon'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];
        $tab[] = [
            'id' => '10',
            'table' => $this->getTable(),
            'field' => 'background_color',
            'name' => __('Color', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];
        $tab[] = [
            'id' => '11',
            'table' => $this->getTable(),
            'field' => 'size',
            'name' => __('Size', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];
        $tab[] = [
            'id' => '12',
            'table' => $this->getTable(),
            'field' => 'glue',
            'name' => __('Stick with the next', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'bool'
        ];
        $tab[] = [
            'id' => '13',
            'table' => $this->getTable(),
            'field' => 'inherit_config',
            'name' => __('Inherit of parent category', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'bool'
        ];
        $tab[] = [
            'id' => '14',
            'table' => $this->getTable(),
            'field' => 'inherit_detail',
            'name' => __('Service details', 'servicecatalog') . " " . __('Inherit of parent category', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'bool'
        ];
        $tab[] = [
            'id' => '15',
            'table' => $this->getTable(),
            'field' => 'inherit_alert',
            'name' => __('Mydashboard alerts', 'servicecatalog') . " " . __('Inherit of parent category', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'bool'
        ];
        $tab[] = [
            'id' => '16',
            'table' => $this->getTable(),
            'field' => 'inherit_picture',
            'name' => __('Inherit of parent picture', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'bool'
        ];
        $tab[] = [
            'id' => '17',
            'table' => $this->getTable(),
            'field' => 'simplified_name_incident',
            'name' => __('Name for simplified interface (incident)', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];
        $tab[] = [
            'id' => '18',
            'table' => $this->getTable(),
            'field' => 'simplified_name_request',
            'name' => __('Name for simplified interface (request)', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];
        $tab[] = [
            'id' => '19',
            'table' => $this->getTable(),
            'field' => 'inherit_itemtypes',
            'name' => __('Inherit of parent itemtypes', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'bool'
        ];
        $tab[] = [
            'id' => '20',
            'table' => $this->getTable(),
            'field' => 'display_warning',
            'name' => __('Display warning on the ticket creation form', "servicecatalog"),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];
        $tab[] = [
            'id' => '21',
            'table' => $this->getTable(),
            'field' => 'force_validation',
            'name' => __('Force validation of user responsible in simplified interface', "servicecatalog"),
            'searchtype' => 'equals',
            'datatype' => 'bool'
        ];
        return $tab;
    }

    /**
     * @param $datas
     *
     * @return bool
     */
    public function showDetails($datas, $style = "")
    {
        $itil_category = new ITILCategory();
        $dbu = new DbUtils();
        $config = new PluginServicecatalogConfig();

        if (isset($datas['category']) && $itil_category->getFromDB($datas['category'])) {
            $cat = new self();
            if (!$cat->getFromDBByCategory($itil_category->getID())) {
                return false;
            }

            if ($cat->fields['comment'] ||
                $cat->fields['service_detail'] != null ||
                $cat->fields['service_users'] ||
                $cat->fields['service_ttr'] ||
                $cat->fields['service_use'] ||
                $cat->fields['service_supervision'] ||
                $cat->fields['service_rules'] ||
                $cat->fields['service_links']) {

                echo "<div id='content' class='details' style='$style'>";
                echo "<div class=''>";
                echo "<div class='bt-block bt-features'>";

                $style = "";
                $class = "";
                if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
                    || $config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    $style = "style='border-radius: 0;margin: 0px;'";
                    $class = "alert-bootstrapped";
                }
                if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL
                    || $config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                    $style = "style='border-radius: 0;margin: 0px;'";
                }
                echo "<h5><div class='alert alert-secondary $class' role='alert' $style>";
                echo __('Service details', 'servicecatalog');
                echo "</div></h5>";

                echo "<div class=\"widgetrow\">";

                echo "<div class=\"bt-row\">";

                echo "<div class='media'>";

                echo "<span style='padding-right: 20px;'>";
                $opt['display'] = true;
                $opt['withlink'] = false;
                $opt['id_cat'] = $datas['category'];
                $opt['first'] = 1;

                if ($config->getLayout() == PluginServicecatalogConfig::SLY) {
                    $opt['details'] = 1;
                    PluginServicecatalogSly::showCategoryLogo($cat, $opt);
                } elseif ($config->getLayout() == PluginServicecatalogConfig::WRAPPER) {
                    $opt['details'] = 1;
                    PluginServicecatalogWrapper::showCategoryLogo($cat, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
                    PluginServicecatalogWrappersly::showCategoryLogo($cat, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL) {
                    PluginServicecatalogThumbnail::showCategoryLogo($cat, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
                    $opt['details'] = 1;
                    PluginServicecatalogThumbnailwrapper::showCategoryLogo($cat, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED) {
                    PluginServicecatalogBootstrapped::showCategoryLogo($cat, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
                    PluginServicecatalogBootstrappedcolor::showCategoryLogo($cat, $opt);
                } else if ($config->getLayout() == PluginServicecatalogConfig::SHOPER) {
                    PluginServicecatalogShoper::showCategoryLogo($cat, $opt);
                }
                echo "</span>";
                echo "<div class='media-body'>";
                echo "<h5 class='mt-0 mb-1 full_glpi_policy'>";//
                echo $itil_category->fields['completename'];
                echo "</h5>";

                echo "<span style='font-style: italic;'>";
                echo $cat->fields['comment'];
                echo "</span>";
                echo "</div>";

                echo "</div>";


                if ($config->getEnableKeywords()) {
                    $keyword = new PluginServicecatalogItilcategory_Keyword();
                    $keywords = $keyword->getKeywords($cat->getID());
                    $count = count($keywords);
                    if ($count > 0) {
                        echo "<div class=\"form-group\">";
                        echo "<label class=\"bt-col-md-5 control-label\">";

                        //               echo "</br></br>";
                        echo __('Keywords', 'servicecatalog');
                        echo "&nbsp;";
                        $rand = mt_rand();
                        $viewId = "tag$rand";
                        $style = 'style="display: block;"';
                        if ($count > 20) {
                            echo "<a href=\"javascript:showHideDiv('$viewId',
                                                'more$rand','fas fa-search-plus',
                                                'fas fa-search-minus')\">";
                            echo "<i id='more$rand' style='color:black' class='fas fa-search-plus'></i>";
                            echo "</a>";
                            $style = 'style="display: none;"';
                        }
                        echo "<div id='" . $viewId . "' $style >";
                        $url = PLUGIN_SERVICECATALOG_WEBDIR . "/pics/tag.png";
                        foreach ($keywords as $data) {
                            echo "<div class='sc-tag' style='background: url($url) no-repeat;'>";
                            echo $data['name'];
                            echo "</div>";
                            echo "&nbsp;";
                        }
                        echo "</div>";
                        echo "</label>";
                        echo "</div>";
                    }
                }

                echo "</div>";

                if ($itil_category->fields["groups_id"] || $itil_category->fields["users_id"]) {
                    echo "<div class=\"bt-row\">";

                    if ($itil_category->fields["groups_id"]) {
                        echo "<div class=\"form-group\">";
                        echo "<label class=\"bt-col-md-4 control-label\">";
                        echo "<h5>";
                        echo "<div class='alert alert-light' role='alert'>";
                        echo __('Group in charge of the hardware');
                        echo "</div>";
                        echo "</h5>";
                        echo "<div id='display-sc'>";
                        echo Dropdown::getDropdownName("glpi_groups", $itil_category->fields["groups_id"]);
                        echo "</div>";
                        echo "</label>";
                        echo "</div>";
                    }
                    if ($itil_category->fields["users_id"]) {
                        echo "<div class=\"form-group\">";
                        echo "<label class=\"bt-col-md-5 control-label\">";
                        echo "<h5>";
                        echo "<div class='alert alert-light' role='alert'>";
                        echo __('Technician in charge of the hardware');
                        echo "</div>";
                        echo "</h5>";
                        echo "<div id='display-sc'>";
                        echo $dbu->getUserName($itil_category->fields['users_id']);
                        echo "</div>";
                        echo "</label>";
                        echo "</div>";
                    }
                    echo "</div>";
                }
                if ($cat->fields['service_detail'] != null) {
                    echo "</br>";
                    echo "<div class=\"bt-row\">";

                    echo "<div class=\"form-group\">";
                    echo "<label class=\"bt-col-md-11 control-label\">";
                    echo "<h5>";
                    echo "<div class='alert alert-light' role='alert'>";
                    echo __('How can i use it', 'servicecatalog');
                    echo "</div>";
                    echo "</h5>";
                    echo "<div id='display-sc'>";
                    echo htmlspecialchars_decode(stripslashes($cat->fields['service_detail']));
                    echo "</div>";
                    echo "</label>";
                    echo "</div>";

                    echo "</div>";
                }

                if ($cat->fields['service_users'] != null) {
                    echo "</br>";
                    echo "<div class=\"bt-row\">";

                    echo "<div class=\"form-group\">";
                    echo "<label class=\"bt-col-md-11 control-label\">";
                    echo "<h5>";
                    echo "<div class='alert alert-light' role='alert'>";
                    echo __('Who can benefit from this service?', 'servicecatalog');
                    echo "</div>";
                    echo "</h5>";
                    echo "<div id='display-sc'>";
                    echo htmlspecialchars_decode(stripslashes($cat->fields['service_users']));
                    echo "</div>";
                    echo "</label>";
                    echo "</div>";

                    echo "</div>";
                }

                if ($cat->fields['service_ttr'] != null) {
                    echo "</br>";
                    echo "<div class=\"bt-row\">";

                    echo "<div class=\"form-group\">";
                    echo "<label class=\"bt-col-md-11 control-label\">";
                    echo "<h5>";
                    echo "<div class='alert alert-light' role='alert'>";
                    echo __('Lead time', 'servicecatalog');
                    echo "</div>";
                    echo "</h5>";
                    echo "<div id='display-sc'>";
                    echo htmlspecialchars_decode(stripslashes($cat->fields['service_ttr']));
                    echo "</div>";
                    echo "</label>";
                    echo "</div>";

                    echo "</div>";
                }

                if ($cat->fields['service_use'] != null) {
                    echo "</br>";
                    echo "<div class=\"bt-row\">";

                    echo "<div class=\"form-group\">";
                    echo "<label class=\"bt-col-md-11 control-label\">";
                    echo "<h5>";
                    echo "<div class='alert alert-light' role='alert'>";
                    echo __('How to obtain the software in case of request?', 'servicecatalog');
                    echo "</div>";
                    echo "</h5>";
                    echo "<div id='display-sc'>";
                    echo htmlspecialchars_decode(stripslashes($cat->fields['service_use']));
                    echo "</div>";
                    echo "</label>";
                    echo "</div>";

                    echo "</div>";
                }

                if ($cat->fields['service_supervision'] != null) {
                    echo "</br>";
                    echo "<div class=\"bt-row\">";

                    echo "<div class=\"form-group\">";
                    echo "<label class=\"bt-col-md-11 control-label\">";
                    echo "<h5>";
                    echo "<div class='alert alert-light' role='alert'>";
                    echo __('Availability of service', 'servicecatalog');
                    echo "</div>";
                    echo "</h5>";
                    echo "<div id='display-sc'>";
                    echo htmlspecialchars_decode(stripslashes($cat->fields['service_supervision']));
                    echo "</div>";
                    echo "</label>";
                    echo "</div>";

                    echo "</div>";
                }

                if ($cat->fields['service_rules'] != null) {
                    echo "</br>";
                    echo "<div class=\"bt-row\">";

                    echo "<div class=\"form-group\">";
                    echo "<label class=\"bt-col-md-11 control-label\">";
                    echo "<h5>";
                    echo "<div class='alert alert-light' role='alert'>";
                    echo __('What are the rules to follow ?', 'servicecatalog');
                    echo "</div>";
                    echo "</h5>";
                    echo "<div id='display-sc'>";
                    echo htmlspecialchars_decode(stripslashes($cat->fields['service_rules']));
                    echo "</div>";
                    echo "</label>";
                    echo "</div>";

                    echo "</div>";
                }
                if ($cat->fields['service_links'] != null) {
                    echo "</br>";
                    echo "<div class=\"bt-row\">";
                    echo "<div class=\"form-group\">";
                    echo "<label class=\"bt-col-md-11 control-label\">";
                    echo "<h5>";
                    echo "<div class='alert alert-light' role='alert'>";
                    echo __('Useful links', 'servicecatalog');
                    echo "</div>";
                    echo "</h5>";
                    echo "<div id='display-sc'>";
                    echo htmlspecialchars_decode(stripslashes($cat->fields['service_links']));
                    echo "</div>";
                    echo "</label>";
                    echo "</div>";

                    echo "</div>";
                }
                $config = new PluginServicecatalogConfig();
                if ($config->getLayout() != PluginServicecatalogConfig::SHOPER) {
                    echo "<br>";
                }

                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        }
    }

    /**
     * @param datas $input
     *
     * @return bool|datas
     */
    public function prepareInputForAdd($input)
    {
        if (isset($input['itemtypes'])) {
            $input['itemtypes'] = json_encode($input['itemtypes']);
        }
        if (isset($input['items_id'])) {
            $input['items_id'] = json_encode($input['items_id']);
        }

        return $input;
    }

    /**
     * @param datas $input
     *
     * @return bool|datas
     */
    public function prepareInputForUpdate($input)
    {
        //picture manually uploaded by category
        if (isset($input["_blank_picture"]) && $input["_blank_picture"]) {
            self::dropPictureFiles($this->fields['picture']);
            $input['picture'] = 'NULL';
        } else {
            if (isset($_FILES['picture'])) {
                if (!count($_FILES['picture'])
                    || empty($_FILES['picture']['name'])
                    || !is_file($_FILES['picture']['tmp_name'])
                ) {
                    switch ($_FILES['picture']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            Session::addMessageAfterRedirect(
                                __('File too large to be added.'),
                                false,
                                ERROR
                            );
                            return false;
                            break;

                        case UPLOAD_ERR_NO_FILE:
                            unset($input['picture']);
                            //                     Session::addMessageAfterRedirect(__('No file specified.'), false, ERROR);
                            //                     return false;
                            break;
                    }
                } else {
                    if (Toolbox::getMime($_FILES['picture']['tmp_name'], 'image')) {
                        // Unlink old picture (clean on changing format)
                        self::dropPictureFiles($this->fields['picture']);
                        // Move uploaded file
                        $filename = uniqid($this->fields['id'] . '_');
                        $tmp = explode(".", $_FILES['picture']['name']);
                        $extension = array_pop($tmp);
                        $picture_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";
                        self::dropPictureFiles($filename . "." . $extension);

                        if (in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'bmp', 'gif'])
                            && Document::renameForce($_FILES['picture']['tmp_name'], $picture_path)
                        ) {
                            Session::addMessageAfterRedirect(__('The file is valid. Upload is successful.'));
                            // For display
                            $input['picture'] = "servicecatalog/{$filename}_min.$extension";

                            //prepare a thumbnail
                            $thumb_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}_min.$extension";

                            $img_infos = getimagesize($picture_path);
                            if ($img_infos[2] == IMAGETYPE_PNG) {
                                self::resizePicture($picture_path, $thumb_path, $img_infos, 145, 75);
                            } else {
                                Toolbox::resizePicture($picture_path, $thumb_path, 145, 75);
                            }
                        } else {
                            Session::addMessageAfterRedirect(
                                __('Potential upload attack or file too large. Moving temporary file failed.'),
                                false,
                                ERROR
                            );
                            return false;
                        }
                    } else {
                        Session::addMessageAfterRedirect(
                            __('The file is not an image file.'),
                            false,
                            ERROR
                        );
                        return false;
                    }
                }
            } else {
                unset($input['picture']);
            }
        }

        if (isset($input["_blank_picture_detail"]) && $input["_blank_picture_detail"]) {
            self::dropPictureFiles($this->fields['picture_detail']);
            $input['picture_detail'] = 'NULL';
        } else {
            if (isset($_FILES['picture_detail'])) {
                if (!count($_FILES['picture_detail'])
                    || empty($_FILES['picture_detail']['name'])
                    || !is_file($_FILES['picture_detail']['tmp_name'])
                ) {
                    switch ($_FILES['picture_detail']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            Session::addMessageAfterRedirect(
                                __('File too large to be added.'),
                                false,
                                ERROR
                            );
                            return false;
                            break;

                        case UPLOAD_ERR_NO_FILE:
                            unset($input['picture_detail']);
                            //                     Session::addMessageAfterRedirect(__('No file specified.'), false, ERROR);
                            //                     return false;
                            break;
                    }
                } else {
                    if (Toolbox::getMime($_FILES['picture_detail']['tmp_name'], 'image')) {
                        // Unlink old picture (clean on changing format)
                        self::dropPictureFiles($this->fields['picture_detail']);
                        // Move uploaded file
                        $filename = uniqid($this->fields['id'] . '_');
                        $tmp = explode(".", $_FILES['picture_detail']['name']);
                        $extension = array_pop($tmp);
                        $picture_path = GLPI_PLUGIN_DOC_DIR . "/servicecatalog/{$filename}.$extension";
                        self::dropPictureFiles($filename . "." . $extension);

                        if (in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'bmp', 'gif'])
                            && Document::renameForce($_FILES['picture_detail']['tmp_name'], $picture_path)
                        ) {
                            Session::addMessageAfterRedirect(__('The file is valid. Upload is successful.'));
                            // For display
                            $input['picture_detail'] = "servicecatalog/{$filename}.$extension";

                        } else {
                            Session::addMessageAfterRedirect(
                                __('Potential upload attack or file too large. Moving temporary file failed.'),
                                false,
                                ERROR
                            );
                            return false;
                        }
                    } else {
                        Session::addMessageAfterRedirect(
                            __('The file is not an image file.'),
                            false,
                            ERROR
                        );
                        return false;
                    }
                }
            } else {
                unset($input['picture_detail']);
            }
        }

        //keywords
        $keyword = new PluginServicecatalogItilcategory_Keyword();
        if (isset($input['keywords'])) {
            $keyword->updateKeywords($input['keywords'], $input['id']);
            unset($input['keywords']);
        } else {
            $keyword->cleanKeywords($input['id']);
        }

        //groups
        $group = new PluginServicecatalogGroup();
        if (isset($input['groups'])) {
            $group->updateGroups($input['groups'], $input['id']);
            unset($input['groups']);
        } else {
            $group->cleanGroups($input['id']);
        }

        if (isset($input['itemtypes'])) {
            $input['itemtypes'] = json_encode($input['itemtypes']);
        } else {
            $input['itemtypes'] = json_encode([]);
        }

        if (isset($input['items_id'])) {
            $input['items_id'] = json_encode($input['items_id']);
        }

        return $input;
    }

    /**
     * Drop existing files for category picture
     *
     * @param $picture picture field
     *
     * @return void
     * @since version 0.85
     *
     */
    public static function dropPictureFiles($picture)
    {
        if (!empty($picture)) {
            // unlink main file
            if (file_exists(GLPI_PLUGIN_DOC_DIR . "/servicecatalog/$picture")) {
                @unlink(GLPI_PLUGIN_DOC_DIR . "/servicecatalog/$picture");
            }
            // unlink Thunmnail
            $tmp = explode(".", $picture);
            if (count($tmp) == 2) {
                if (file_exists(GLPI_PLUGIN_DOC_DIR . "/servicecatalog/" . $tmp[0] . "_min." . $tmp[1])) {
                    @unlink(GLPI_PLUGIN_DOC_DIR . "/servicecatalog/" . $tmp[0] . "_min." . $tmp[1]);
                }
            }
        }
    }

    /**
     * Resize a picture to the new size
     * Method to avoid black background
     *
     * @param type $picture_path
     * @param type $thumb_path
     * @param type $img_infos
     * @param type $new_width
     * @param type $new_height
     */
    public static function resizePicture($picture_path, $thumb_path, $img_infos, $new_width, $new_height)
    {
        //get img informations (dimensions and extension)
        if (empty($img_width)) {
            $img_width = $img_infos[0];
        }
        if (empty($img_height)) {
            $img_height = $img_infos[1];
        }
        if (empty($new_width)) {
            $new_width = $img_infos[0];
        }
        if (empty($new_height)) {
            $new_height = $img_infos[1];
        }

        //Create a new image
        $source_res = imagecreatefrompng($picture_path);
        //Create a new true color image
        $img_new = imagecreatetruecolor($new_width, $new_height);
        //Modifies blending mode of an image
        imagealphablending($img_new, false);
        //Configures the recording of full alpha channel information when saving PNG images
        imagesavealpha($img_new, true);
        //Allocates a color to an image
        $transparent = imagecolorallocatealpha($img_new, 255, 255, 255, 127);
        imagefilledrectangle($img_new, 0, 0, $new_width, $new_height, $transparent);
        //Copy, resize, resample an image
        imagecopyresampled($img_new, $source_res, 0, 0, 0, 0, $new_width, $new_height, $img_width, $img_height);
        imagepng($img_new, $thumb_path);
    }

    /**
     *
     * List of sons with check if visible simplified interface
     * and if category request or incident following type passed in parameter.
     *
     * @param $itilcategories_id
     *
     * @param $type
     *
     * @return array
     */
    public static function getSons($itilcategories_id, $type)
    {
        global $DB, $GLPI_CACHE;

        $dbu = new DbUtils();

        ////*Fix childs*//////
//        $itilcat = new ITILCategory();
//        $ckey = 'sons_cache_' . $itilcat->getTable() . '_' . $itilcategories_id;
//        $sons = [];
//        $GLPI_CACHE->set($ckey, $sons);
//
//        $DB->update(
//            $itilcat->getTable(),
//            [
//                'sons_cache' => NULL
//            ],
//            [
//                'id' => $itilcategories_id
//            ]
//        );

        $sons = $dbu->getSonsOf("glpi_itilcategories", $itilcategories_id);
        ////* end Fix childs*//////

        unset($sons[$itilcategories_id]);

        switch ($type) {
            case Ticket::DEMAND_TYPE:
                $field_type = 'is_request';
                break;

            default: // Ticket::INCIDENT_TYPE :
                $field_type = 'is_incident';
        }

        foreach ($sons as $son) {
            $itilcategory = new ITILCategory();
            $itilcategory->getFromDB($son);

            //         if (!self::isCategoryAllowedByUserGroups($son)) {
            //            continue;
            //         }

            if (isset($_SESSION['glpiactiveentities'])) {
                if (!in_array($itilcategory->getField('entities_id'), $_SESSION['glpiactiveentities'])
                    && $itilcategory->getField('is_recursive') == 0) {
                    unset($sons[$son]);
                }
            }
            if (isset($_SESSION["glpiactiveprofile"])
                && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
                if (!$itilcategory->getField('is_helpdeskvisible') || !$itilcategory->getField($field_type)) {
                    unset($sons[$son]);
                }
            }
        }

        return $sons;
    }

    /**
     * Retrieve data of current category or parent category
     *
     * @param     $fieldref        string   name of the referent field to know if we look at parent entity
     * @param     $category_id
     * @param     $fieldval        string   name of the field that we want value (default '')
     * @param int $default_value value to return (default -2)
     **@return int|mixed|\value
     *
     * @return int|mixed|\value
     *
     * @since 0.84 (before in entitydata.class)
     */
    public static function getUsedConfig($fieldref, $category_id, $fieldval = '', $default_value = -1)
    {
        // for calendar
        if (empty($fieldval)) {
            $fieldval = $fieldref;
        }
        $ITILCategory = new ITILCategory();
        $ITILCategory->getFromDB($category_id);
        //      $entity = new self();
        $category = new self();
        // Search in entity data of the current entity
        if ($category->getFromDBByCategory($category_id)) {
            // Value is defined : use it
            if (isset($category->fields[$fieldref])) {
                // Numerical value
                $test = is_numeric($default_value);
                if ($test
                    && ($category->fields[$fieldref] != self::CONFIG_PARENT)) {
                    return $category->fields[$fieldval];
                }
                // String value
                if (!is_numeric($default_value)
                    && $category->fields[$fieldref]) {
                    return $category->fields[$fieldval];
                }
            }
        }

        //      $ITILCategory = new ITILCategory();
        //      $ITILCategory->getFromDB($category->fields['itilcategories_id']);
        // Entity data not found or not defined : search in parent one
        if (isset($ITILCategory->fields['itilcategories_id'])
            && $ITILCategory->fields['itilcategories_id'] > 0) {
            return self::getUsedConfig(
                $fieldref,
                $ITILCategory->fields['itilcategories_id'],
                $fieldval,
                $default_value
            );
        }
    }

    /**
     * @param \MassiveAction $ma
     *
     * @return bool
     */
    public static function showMassiveActionsSubForm(MassiveAction $ma)
    {
        switch ($ma->getAction()) {
            case 'UpdateInherit':
                echo __('Inherit of parent category', 'servicecatalog');
                echo "&nbsp;";
                echo Dropdown::showYesNo("inherit_config", 0, -1, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateInheritItemtypes':
                echo __('Inherit of parent itemtypes', 'servicecatalog');
                echo "&nbsp;";
                echo Dropdown::showYesNo("inherit_itemtypes", 0, -1, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateInheritPicture':
                echo __('Inherit of parent picture', 'servicecatalog');
                echo "&nbsp;";
                echo Dropdown::showYesNo("inherit_picture", 0, -1, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateInheritDetail':
                echo __('Mydashboard alerts', 'servicecatalog') . " " . __('Inherit of parent category', 'servicecatalog');
                echo "&nbsp;";
                echo Dropdown::showYesNo("inherit_alert", 0, -1, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateInheritAlert':
                echo __('Service details', 'servicecatalog') . " " . __('Inherit of parent category', 'servicecatalog');
                echo "&nbsp;";
                echo Dropdown::showYesNo("inherit_detail", 0, -1, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateGlue':
                echo __('Stick with the next', 'servicecatalog');
                echo "&nbsp;";
                echo Dropdown::showYesNo("glue", 0, -1, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateIcon':
                echo __("Icon");
                echo "&nbsp;";
                echo Html::input('icon');
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateBackground':
                //            echo Html::script('/lib/jqueryplugins/spectrum-colorpicker/spectrum.js');
                //            echo Html::css('lib/jqueryplugins/spectrum-colorpicker/spectrum.min.css');
                echo __('Color', 'servicecatalog');
                echo "&nbsp;";
                echo Html::showColorField('background_color', ['display' => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;

            case 'UpdateSize':
                echo __('Size', 'servicecatalog');
                echo "&nbsp;";
                $values = ['small' => __('Small', 'servicecatalog'),
                    'normal' => __('Normal', 'servicecatalog'),
                    'big' => __('Big', 'servicecatalog'),
                ];
                echo Dropdown::showFromArray("size", $values, ["display" => false]);
                echo "<br>";
                echo Html::submit(_sx('button', 'Post'), ['name' => 'massiveaction', 'class' => 'btn btn-primary']) . "</span>";

                return true;
        }
        return parent::showMassiveActionsSubForm($ma);
    }

    /**
     * @param $input
     * @param $id
     *
     * @return bool
     */
    public function UpdateInfo($input, $id)
    {
        if ($this->getFromDBByCrit(["itilcategories_id" => $id])) {
            $input["id"] = $this->getID();
            $input["itilcategories_id"] = $id;
            if ($this->update($input)) {
                return true;
            }
        } else {
            $input["itilcategories_id"] = $id;
            if ($this->add($input)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param \MassiveAction $ma
     * @param \CommonDBTM $item
     * @param array $ids
     */
    public static function processMassiveActionsForOneItemtype(
        MassiveAction $ma,
        CommonDBTM    $item,
        array         $ids
    )
    {
        switch ($ma->getAction()) {
            case 'UpdateInherit':
            case 'UpdateInheritItemtypes':
            case 'UpdateInheritPicture':
            case 'UpdateInheritDetail':
            case 'UpdateGlue':
            case 'UpdateIcon':
            case 'UpdateBackground':
            case 'UpdateSize':
            case 'UpdateInheritAlert':
                $input = $ma->getInput();

                foreach ($ids as $id) {
                    $category = new self();
                    if ($item->getFromDB($id)
                        && $category->UpdateInfo($input, $id)) {
                        $ma->itemDone($item->getType(), $id, MassiveAction::ACTION_OK);
                    } else {
                        $ma->itemDone($item->getType(), $id, MassiveAction::ACTION_KO);
                        $ma->addMessage(__("Something went wrong"));
                    }
                }
                return;
        }
        parent::processMassiveActionsForOneItemtype($ma, $item, $ids);
    }

    /**
     * @param \ITILCategory $itilCategory
     *
     * @return bool
     */
    /**
     * @param \ITILCategory $itilCategory
     *
     * @return bool
     */
    public static function pre_delete_category(ITILCategory $itilCategory)
    {
        $cat = new self();
        $cat->deleteByCriteria(["itilcategories_id" => $itilCategory->getID()], 1);

        $catOrd = new PluginServicecatalogCategoryorder();
        $catOrd->deleteByCriteria(["itilcategories_id" => $itilCategory->getID()], 1);

        $form = new PluginServicecatalogFormcreator();
        $form->deleteByCriteria(["itilcategories_id" => $itilCategory->getID()], 1);

        $fav = new PluginServicecatalogFavorite();
        $fav->deleteByCriteria(["itilcategories_id" => $itilCategory->getID()], 1);

        return true;
    }

    public function cleanDBonPurge()
    {
        $cat = new PluginServicecatalogCategoryTranslation();
        $cat->deleteByCriteria(["items_id" => $this->getID(), "itemtype" => self::getType()], 1);

        $group = new PluginServicecatalogGroup();
        $group->deleteByCriteria(["plugin_servicecatalog_categories_id" => $this->getID()], 1);

        $key = new PluginServicecatalogItilcategory_Keyword();
        $key->deleteByCriteria(["plugin_servicecatalog_categories_id" => $this->getID()], 1);
    }

    /**
     * @param $name
     * @param $type
     * @return void
     */
    public static function fuzzySearchForm($name, $type)
    {
        $config = new PluginServicecatalogConfig();
        if ($type == Ticket::INCIDENT_TYPE) {
            $title = PluginServicecatalogConfig::displayField($config, 'title_searchbar_incident');
            if (empty($title)) {
                $title = __("Start typing to find a category", "servicecatalog");
            }
        } elseif ($type == Ticket::DEMAND_TYPE) {
            $title = PluginServicecatalogConfig::displayField($config, 'title_searchbar_request');
            if (empty($title)) {
                $title = __("Start typing to find a category", "servicecatalog");
            }
        } else {
            $title = __("Start typing to find a category", "servicecatalog");
        }
        $strict_search = $config->useStrictSearch();
        $modal_header = __('Search');
        $modal_help = __('Help');

        $help = "";
        if ($strict_search == 0) {
            $modal_help_details = __("You can use ' character for search a word of the sentence (Example : 'incident)", "servicecatalog") . "</br>";
            $modal_help_details .= __("You can use the ^ character to search for the first word of the sentence (Example: ^incident)", "servicecatalog") . "</br>";
            $modal_help_details .= __("You can use the $ character to search for the last word of the sentence (Example: incident$)", "servicecatalog") . "</br>";
            $help = self::showToolTip(
                $modal_help_details,
                ['display' => false, 'autoclose' => true]
            );
        }
        $style = "";
        if ($name == 'sc-home-trigger-fuzzy') {
            $style = "style='display:none;'";
        }
        echo "<div tabindex='-1' id='fuzzysearch' $style>";
        if ($strict_search == 0) {
            echo "<div class='modal-header' >";
//        echo "<h5 class='modal-title'>";
//        echo "<i class='fas fa-arrow-right me-2'></i>";
//        echo $modal_header;
//        echo "</h5>";
            echo $help;
            echo "</div>";
        }
        echo "<div class='modal-content'>";
        echo "<div class='modal-body' style='padding: unset;'>";
        echo "<div class='input-group'>";
        echo "<div class='input-group-prepend'>";
        echo "<span class='input-group-text' style='padding: 10px;'><i class='fas fa-search'></i></span>";
        echo "</div>";
        echo "<input type='text' class='$name form-control' placeholder='" . $title . "'>";
        if ($name == 'sc-trigger-fuzzy' || $name == 'sc-home-trigger-fuzzy') {
            echo "<input type='hidden' name='fuzzy-strict' id='fuzzy-strict' value='" . $strict_search . "'/>";
        } else {
            echo "<input type='hidden' name='type' id='type' value='" . $type . "'/>";
            echo "<input type='hidden' name='categoryload' id='categoryload' value='0'/>";
        }


        echo "</div>";
        echo "<ul class='results list-group mt-2 mb-2' style='background: #FFF;border: 1px solid #d9dbde;'></ul>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo Html::scriptBlock("$(document).ready(function() {
                                        $('#fuzzysearch').show();
                                    });");
    }

    /**
     * Manage events from js/fuzzysearch.js
     *
     * @param string $action action to switch (should be actually 'getHtml' or 'getList')
     *
     * @return string
     * @since 9.2
     *
     */
    public static function fuzzySearch($action = '', $searchtype = 0, $category = 0)
    {
        $config = new PluginServicecatalogConfig();
        if ($searchtype == Ticket::INCIDENT_TYPE) {
            $title = PluginServicecatalogConfig::displayField($config, 'title_searchbar_incident');
            if (empty($title)) {
                $title = __("Start typing to find a category", "servicecatalog");
            }
        } elseif ($searchtype == Ticket::DEMAND_TYPE) {
            $title = PluginServicecatalogConfig::displayField($config, 'title_searchbar_request');
            if (empty($title)) {
                $title = __("Start typing to find a category", "servicecatalog");
            }
        } else {
            $title = __("Start typing to find a category", "servicecatalog");
        }
        $searchcat = $category;
        $strict_search = $config->useStrictSearch();
        switch ($action) {
            case 'getModalHtml':
                $modal_header = __('Search');
                $placeholder = $title;
                $alert = "";
                //            $alert        = sprintf(
                //               __("Tip: You can call this modal with %s keys combination"),
                //               "<kbd><kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>G</kbd></kbd>"
                //            )
                $html = <<<HTML
               <div class="modal" tabindex="-1" id="fuzzysearch">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">
                              <i class="fas fa-arrow-right me-2"></i>
                              {$modal_header}
                           </h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                           <input type="text" class="form-control" placeholder="{$placeholder}">
                           <input type="hidden" id="fuzzy-strict" value="{$strict_search}">
                           <ul class="results list-group mt-2"></ul>
                        </div>
                     </div>
                  </div>
               </div>

HTML;

                return $html;
                break;

            default:
                $fuzzy_entries = [];
                if ($searchtype > 0) {
                    $types = [$searchtype];
                } else {
                    $types = [];
                    $widget = new PluginServicecatalogWidget();
                    if (Session::haveRight('plugin_servicecatalog_incidents', READ)
                        && $widget->fields['display_incident'] == 1) {
                        $types[] = Ticket::INCIDENT_TYPE;
                    }
                    if (Session::haveRight('plugin_servicecatalog_requests', READ)
                        && $widget->fields['display_request'] == 1) {
                        $types[] = Ticket::DEMAND_TYPE;
                    }
                }
                foreach ($types as $type) {
                    $cat = new self();
                    $datas = self::getCategoriesCache($type);

                    $categories = [];

                    while (!empty($datas)) {
                        $temp = [];
                        foreach ($datas as $k => $v) {
                            if (isset($v["subcategories"])) {
                                $temp = array_merge($temp, $v['subcategories']);
                            } else {
                                $categories[] = $v;
                            }
                        }
                        $categories = array_merge($categories, $temp);
                        $datas = $temp;
                    }

                    if ($searchcat > 0) {
                        $newcats = [];
                        foreach ($categories as $k => $v) {
                            if ($v['itilcategories_id'] == $searchcat) {
                                $newcats[] = $v;
                            }
                        }
                        $newcats = array_map("unserialize", array_unique(array_map("serialize", $newcats)));
                        $categories = $newcats;
                    }

                    $cats = [];

                    foreach ($categories as $k => $v) {
                        if (isset($v['subcategories'])) {
                            $cats[] = $cat->findChildsCategories($v['subcategories']);
                        } else {
                            $cats[] = [0 => [$v["id"]]];
                        }
                    }

                    $single = [];
                    if (is_array($cats) & count($cats) > 0) {
                        $single = call_user_func_array('array_merge', $cats);
                        if (is_array($single) & count($single) > 0) {
                            $single = call_user_func_array('array_merge', $single);
                        }
                    }
                    $single = array_unique($single);


                    //                    if ($k == $searchcat) {

                    foreach ($single as $id => $catid) {
                        if ($config->getEnableGroupRestriction() == 1) {
                            $disabled = self::getDisabledCategory($type, $catid);
                            if ($disabled == 1) {
                                continue;
                            }
                        }

                        $itilcat = new self();
                        $keywords = "";
                        $comment = "";
                        if ($itilcat->getFromDBByCategory($catid)) {

                            if (Ticket::INCIDENT_TYPE == $type) {
                                $name = self::displayField($itilcat, 'simplified_name_incident');
                            } else {
                                $name = self::displayField($itilcat, 'simplified_name_request');
                            }
                            $itil_category = new ITILCategory();
                            $itil_category->getFromDB($catid);
                            if (empty($name)) {

                                if (empty($name = DropdownTranslation::getTranslatedValue(
                                    $catid,
                                    ITILCategory::class,
                                    'completename',
                                    $_SESSION['glpilanguage']
                                ))) {
                                    $name = $itil_category->fields['completename'];
                                }
                            }
                            $comment = DropdownTranslation::getTranslatedValue($catid, 'ITILCategory', 'comment', $_SESSION['glpilanguage']);
                            if (empty($comment)) {
                                $comment = $itil_category->fields['comment'];
                            }

                            if (isset($itilcat->fields['id'])) {
                                $keyword = new PluginServicecatalogItilcategory_Keyword();
                                $keywords = $keyword->getKeywordsInString($itilcat->fields['id']);
                            }

                        } else {
                            $itil_category = new ITILCategory();
                            $itil_category->getFromDB($catid);

                            $comment = DropdownTranslation::getTranslatedValue($catid, 'ITILCategory', 'comment', $_SESSION['glpilanguage']);
                            if (empty($comment)) {
                                $comment = $itil_category->fields['comment'];
                            }

                            if (empty($name = DropdownTranslation::getTranslatedValue(
                                $itil_category->fields['id'],
                                ITILCategory::class,
                                'completename',
                                $_SESSION['glpilanguage']
                            ))) {
                                $name = $itil_category->fields['completename'];
                            }
                        }

                        $icon = self::getUsedConfig("inherit_config", $catid, 'icon');
                        $default_icon = "fas fa-network-wired";
                        if (!empty($config->fields['default_icon'])) {
                            $default_icon = $config->fields['default_icon'];
                        }
                        $icon = (!empty($icon) ? $icon : $default_icon);

                        $use_website_url = $itilcat->fields['use_website_url'] ?? 0;
                        $website_url = $itilcat->fields['website_url'] ?? '';
                        $target = '';
                        if ($use_website_url && !empty($website_url)) {
                            if ($itilcat->fields['website_target'] == 0) {
                                $target = 'target="_blank"';
                            }
                            $url = $website_url;
                        } else {
                            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/newticket.form.php?type=" . $type . "&category_id=" . $catid;
                        }

                        $fuzzy_entries[] = [
                            'url' => $url,
                            'title' => $name,
                            'comment' => ($comment != null) ? Html::resume_text(Glpi\RichText\RichText::getTextFromHtml($comment), "200") : "",
                            'type' => Ticket::getTicketTypeName($type),
                            'order' => "1",
                            'keywords' => $keywords,
                            'background' => $config->getSearchTicketsColor(),
                            'icon' => $icon,
                            'target' => $target
                        ];
                    }
                }
                if ($searchcat == 0 && Session::haveRight('knowbase', KnowbaseItem::READFAQ)) {
                    $kbitems = PluginServicecatalogKnowbase::getKbItems();
                    if (count($kbitems) > 0) {
                        foreach ($kbitems as $kbitem) {
                            $kbarticle = new KnowbaseItem();
                            $kbarticle->getFromDB($kbitem['id']);
                            if (KnowbaseItemTranslation::canBeTranslated($kbarticle)) {
                                $name = KnowbaseItemTranslation::getTranslatedValue($kbarticle, 'name');
                                $answer = KnowbaseItemTranslation::getTranslatedValue($kbarticle, 'answer');
                            } else {
                                $name = $kbarticle->fields["name"];
                                $answer = $kbarticle->fields["answer"];
                            }
                            $keyword = new PluginServicecatalogKnowbaseitem_Keyword();
                            $keywords = $keyword->getKeywordsInString($kbitem['id']);
                            $widget = new PluginServicecatalogWidget();
                            $identity = __('FAQ');
                            $fuzzy_entries[] = [
                                'url' => PLUGIN_SERVICECATALOG_WEBDIR . "/front/faq.php?id=" . $kbitem['id'],
                                'title' => $name, //. " ".Glpi\RichText\RichText::getTextFromHtml($answer)
                                'comment' => ($answer != null) ? Html::resume_text(Glpi\RichText\RichText::getTextFromHtml($answer), "200") : "",
                                'keywords' => $keywords,
                                'icon' => $widget->fields['fa_faq'],
                                'background' => $config->getSearchKbColor(),
                                'type' => $identity,
                                'order' => "2",
                                'target' => ''
                            ];
                        }
                    }
                }

                $fuzzy_entries = PluginServicecatalogApiclient::getArticles($fuzzy_entries);

                // return the entries to ajax call
                return json_encode($fuzzy_entries);
                break;
        }
    }

    /**
     * Display tree categories for navigation / fil ariane
     *
     * @param $type
     * @param $category_id
     *
     * @return array
     */
    public static function getTreeCategoryFriendlyName($type, $category_id, $where = 0, $link = true, $first = false)
    {
        $name = "";
//        $script     = "";

        $script = "\"";
        if ($category_id > 0) {
            $widget = new PluginServicecatalogWidget();
            $config = new PluginServicecatalogConfig();
            $rootname = "";
            if (Ticket::INCIDENT_TYPE == $type) {
                $rootname = PluginServicecatalogConfig::displayField($widget, 'title_incident');
            } else {
                $rootname = PluginServicecatalogConfig::displayField($widget, 'title_request');
            }
//            $class = "";
//            if ($link) {
                $class = "class='launchrootype'";
//            }
            $name .= "<span id='launchrootype$type' $class >" . $rootname . "</span>";
            $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=1";
            $script .= "$('#launchrootype$type').click(function() {  window.location = '$url';  });";

            if ($config->getBypassCategories() == 0) {
                if ($first == false) {
                    $name .= "<i class='ti ti-caret-right' style='vertical-align: text-top;'></i>";
                }

                $dbu = new DbUtils();
                $ancestors = $dbu->getAncestorsOf("glpi_itilcategories", $category_id);

                $cpt = count($ancestors);

                foreach ($ancestors as $k => $ancestor) {
                    $cpt--;
                    $itilcat = new ITILCategory();
                    if ($itilcat->getFromDB($ancestor)) {
//                $id_parent = $itilcat->getID();

                        $cat = new self();
                        $cat->getFromDBByCategory($ancestor);

                        if ($type == Ticket::INCIDENT_TYPE) {
                            $displayname = self::displayField($cat, 'simplified_name_incident');
                        } else {
                            $displayname = self::displayField($cat, 'simplified_name_request');
                        }
                        if (empty($displayname)) {
                            $displayname = $itilcat->fields['name'];
                        }
                        $level = $itilcat->fields['level'];
                        $id_parent = $itilcat->fields['itilcategories_id'];
                        $name .= "<span id='launchparentcat$id_parent'  $class >" . $displayname . "</span>";//"-". $level."-".$ancestor."-".$id_parent.

                        $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$ancestor&choose_category=$id_parent";
                        $script .= "$('#launchparentcat$id_parent').click(function() {  window.location = '$url';  });";


                        if ($cpt >= 0) {
                            $name .= "<i class='ti ti-caret-right' style='vertical-align: text-top;'></i>";
                        }
                    }
                }
                if ($first == true) {
                    $name .= "<i class='ti ti-caret-right' style='vertical-align: text-top;'></i>";
                }
                //      $name    .= " > ";
                $itilcat = new ITILCategory();
                $itilcat->getFromDB($category_id);

                $cat = new self();
                $cat->getFromDBByCategory($category_id);

                if ($type == Ticket::INCIDENT_TYPE) {
                    $displayname = self::displayField($cat, 'simplified_name_incident');
                } else {
                    $displayname = self::displayField($cat, 'simplified_name_request');
                }
                if (empty($displayname)) {
                    $displayname = $itilcat->fields['name'];
                }
                $class = "class='last-cat'";
                if ($link) {
                    $class = "class='last-cat launchchildcat'";
                }
                $id_parent = $itilcat->fields['itilcategories_id'];
                $level = $itilcat->fields['level'];
                $name .= "<span id='launchchildcat$category_id'  $class >" . $displayname . "</span>"; //."-". $level."-".$category_id."-".$id_parent
                //for Debug
                //      $name .= $where;
//            $script .= "$('#launchcat$category_id').click(function() { $('ul.events li').hide(); $('#displaycat$category_id').show(); $('span[id^=launchparentcat]').css('font-weight', 'normal'); $('#launchcat$category_id').css('font-weight', 'bold'); });";


                if (count(self::getSons($category_id, $type))) {
                    $url = PLUGIN_SERVICECATALOG_WEBDIR . "/front/choosecategory.form.php?type=" . $type . "&level=$level&category_id=$category_id&choose_category=$id_parent";
                    $script .= "$('#launchchildcat$category_id').click(function() {  window.location = '$url';  });";
                }
            }
        }
        $script .= "\"";


        return ['name' => $name, 'script' => json_encode($script)];
    }

    /**
     * Show a tooltip on an item
     *
     * @param $content   string   data to put in the tooltip
     * @param $options   array    of possible options:
     *   - applyto : string / id of the item to apply tooltip (default empty).
     *                  If not set display an icon
     *   - title : string / title to display (default empty)
     *   - contentid : string / id for the content html container (default auto generated) (used for ajax)
     *   - link : string / link to put on displayed image if contentid is empty
     *   - linkid : string / html id to put to the link link (used for ajax)
     *   - linktarget : string / target for the link
     *   - popup : string / popup action : link not needed to use it
     *   - img : string / url of a specific img to use
     *   - display : boolean / display the item : false return the datas
     *   - autoclose : boolean / autoclose the item : default true (false permit to scroll)
     *
     * @return void|string
     *    void if option display=true
     *    string if option display=false (HTML code)
     **/
    public static function showToolTip($content, $options = [])
    {
        $param = [
            'applyto' => '',
            'title' => '',
            'contentid' => '',
            'link' => '',
            'linkid' => '',
            'linktarget' => '',
            'awesome-class' => 'fa-info',
            'popup' => '',
            'ajax' => '',
            'display' => true,
            'autoclose' => true,
            'onclick' => false,
            'link_class' => '',
        ];

        if (is_array($options) && count($options)) {
            foreach ($options as $key => $val) {
                $param[$key] = $val;
            }
        }

        // No empty content to have a clean display
        if (empty($content)) {
            $content = "&nbsp;";
        }
        $rand = mt_rand();
        $out = '';

        // Force link for popup
        if (!empty($param['popup'])) {
            $param['link'] = '#';
        }

        if (empty($param['applyto'])) {
            if (!empty($param['link'])) {
                $out .= "<a id='" . (!empty($param['linkid']) ? $param['linkid'] : "tooltiplink$rand") . "'
                        class='dropdown_tooltip {$param['link_class']}'";

                if (!empty($param['linktarget'])) {
                    $out .= " target='" . $param['linktarget'] . "' ";
                }
                $out .= " href='" . $param['link'] . "'";

                if (!empty($param['popup'])) {
                    $out .= " data-bs-toggle='modal' data-bs-target='#tooltippopup$rand' ";
                }
                $out .= '>';
            }
            if (isset($param['img'])) {
                //for compatibility. Use fontawesome instead.
                $out .= "<img id='tooltip$rand' src='" . $param['img'] . "'>";
            } else {
                $out .= "<span id='tooltip$rand' class='fas {$param['awesome-class']} fa-fw'></span>";
            }

            if (!empty($param['link'])) {
                $out .= "</a>";
            }

            $param['applyto'] = (!empty($param['link']) && !empty($param['linkid'])) ? $param['linkid'] : "tooltip$rand";
        }

        if (empty($param['contentid'])) {
            $param['contentid'] = "content" . $param['applyto'];
        }

        $out .= "<div id='" . $param['contentid'] . "' class='tooltip-invisible'>$content</div>";
        if (!empty($param['popup'])) {
            $out .= Ajax::createIframeModalWindow(
                'tooltippopup' . $rand,
                $param['popup'],
                ['display' => false,
                    'width' => 600,
                    'height' => 300
                ]
            );
        }
        $js = "$(function(){";
        $js .= Html::jsGetElementbyID($param['applyto']) . ".qtip({
         position: { viewport: $(window) },
         content: {text: " . Html::jsGetElementbyID($param['contentid']);
        if (!$param['autoclose']) {
            $js .= ", title: {text: ' ',button: true}";
        }
        $js .= "}, style: { classes: 'qtip-shadow qtip-bootstrap'}, hide: {
                  fixed: true,
                  delay: 200,
                  leave: false,
                  when: { event: 'unfocus' }
                }";
        if ($param['onclick']) {
            $js .= ",show: 'click', hide: false,";
        }
        // else if (!$param['autoclose']) {
        $js .= ",show: {
                        solo: true, // ...and hide all other tooltips...
                        when: false, // Don't specify a show event
                        ready: true // Show the tooltip when ready
                        },
                ";
        //        }
        $js .= "});";
        $js .= "});";
        $out .= Html::scriptBlock($js);

        if ($param['display']) {
            echo $out;
        } else {
            return $out;
        }
    }
}
