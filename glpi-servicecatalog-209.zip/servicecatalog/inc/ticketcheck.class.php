<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogTicketcheck
 */
class PluginServicecatalogTicketcheck extends CommonDBTM
{
    public static $rightname = 'plugin_servicecatalog_checkticket';

    /**
     * @param string $interface
     *
     * @return array
     */
    public function getRights($interface = 'central')
    {
        $values = parent::getRights();

        unset($values[READ], $values[UPDATE], $values[DELETE], $values[PURGE]);
        return $values;
    }

   /**
    * @param $params
    *
    * @return bool
    */
    public static function checkCategory($params)
    {
        global $CFG_GLPI;

        if (!Session::haveRight("plugin_servicecatalog_checkticket", CREATE)) {
            return false;
        }

        $item = $params['item'];
       //      $rand = mt_rand();

        if (!is_array($item)
            && $item != null
          && $item::getType() == "Ticket"
          && $item->getID()
          && isset($item->fields['is_deleted'])
          && $item->fields['is_deleted']) {
            return false;
        }

        if (!is_array($item)
            && $item != null
          && $item::getType() == "Ticket"
          && $item->getID()) {
            $restrict = ["tickets_id" => $item->getID()];
            $dbu      = new DbUtils();
            $checks   = $dbu->getAllDataFromTable("glpi_plugin_servicecatalog_ticketchecks", $restrict);
            if (!empty($checks)) {
                return false;
            }
        }
        if (!is_array($item)
            && $item != null
          && $item::getType() == "Ticket"
          && $item->getID()
          && Session::getCurrentInterface() == 'central'
          && isset($item->fields["status"])
          && !in_array($item->fields["status"], $item->getSolvedStatusArray())
          && !in_array($item->fields["status"], $item->getClosedStatusArray())) {
           //
           //         $rootdoc    = $CFG_GLPI["root_doc"];
           //         $error_cat  = __('Error : Category is mandatory', 'servicecatalog');
           //         $error      = __('Error : Cannot modify ticket', 'servicecatalog');
           //         $csrf_token = json_encode(Session::getNewCSRFToken());

            if (!isset($_SESSION["glpi_plugin_servicecatalog_ticketckeck"])
                               || $_SESSION["glpi_plugin_servicecatalog_ticketckeck"] != $item->fields['id']) {
                echo Ajax::createIframeModalWindow(
                    'ticketcheck',
                    PLUGIN_SERVICECATALOG_WEBDIR . '/front/ticketcheck.form.php?tickets_id=' . $item->fields['id'],
                    ['title'         => __('Ticket verification', 'servicecatalog'),
                             'display'       => false,
                             //                                             'width'         => 200,
                             //                                             'height'        => 600,
                             'reloadonclose' => true,
                             'autoopen'      => true]
                );
            }
        }
    }

   /**
    * @param $item
    */
    public static function showModalForm($params)
    {
        global $CFG_GLPI;
        //For fix auto reload
        $_SESSION["glpi_plugin_servicecatalog_ticketckeck"] = $params['tickets_id'];
        $item                                               = new Ticket();
        $item->getFromDB($params['tickets_id']);

        echo Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/bootstrap/sc_bootstrap_new.scss");
        //verification
        echo "<form name='form' method='post' action='" . self::getFormURL() . "'>";
        echo "<div class='container'>";

        $tt = $item->getITILTemplateToUse(0, $item->fields["type"], $item->fields["itilcategories_id"], $item->fields["entities_id"]);

        $contract_ticket  = new Ticket_Contract();
        $nb               = 0;
        $ticket_contracts = $contract_ticket->find(['tickets_id' => $item->fields["id"]]);
        if (is_array($ticket_contracts) && count($ticket_contracts) > 0) {
            $nb++;
        }
        echo "<div class=\"row\">";
        $col = "col-md-10";
        if ($tt->isMandatoryField('_contracts_id') && $nb == 0) {
            $col = "col-md-6";
            echo "<div class=\"form-group col-md-5\" style='display:table-cell; vertical-align:middle'>";
            echo "<label class=\"control-label center\" style='color: red'><i class='fas fa-exclamation-triangle fa-2x'></i>&nbsp;";
            echo __('Please define a contract for this ticket', 'servicecatalog');
            echo "</label>&nbsp;";
            Contract::dropdown(['entity'  => $item->getEntityID(),
                            ]);
            echo "</div>";
            echo Html::hidden('contracts_id_mandatory', ['id'    => 'contracts_id_mandatory',
                                                      'value' => 1]);
        }
        echo "<br>";
        echo "<div class=\"form-group $col\" style='display:table-cell; vertical-align:middle'>";
        echo "<label class=\"control-label center\">";

        echo __('This is the good type and category ?', 'servicecatalog');
        echo "</label>";
       //      echo "<div class=\"selectContainer center\">";

        $ok = "<button type='submit' class='submit btn btn-success _buttons_on' id='close' name='validate_ticket'>" . __s('Yes') . "</button>";
        if ($tt->isMandatoryField('itilcategories_id') && empty($item->fields["itilcategories_id"])) {
            echo "&nbsp;";
        } else {
            echo "&nbsp;";
            echo $ok;
        }
        echo "&nbsp;";
        echo "<button type='submit' form='' class='submit btn btn-danger _buttons_off addcat' name='no'>" . __s('No') . "</button>";
        echo "</div>";

        echo "<script type='text/javascript'>
            $(document).ready(function(){
               $('#flipcat').click(function(){
                  $('.panel').toggle();
               });
               $('.addcat').click(function(){
                  $('.params').toggle();
               });
            });
         </script>";

        echo "<div class='params' style='display: none;'>";
        //new type
        echo "<br>";
        echo "<h5 style='margin-top: 2px;'>
                     <div class='alert alert-secondary' role='alert'>";
        echo __('Select the new type and category', 'servicecatalog');
        echo "</div>
               </h5>";

        echo "<div class=\"form-group\">";
        echo "<label class=\"bt-col-md-4 control-label \">";
        echo sprintf(__('%1$s%2$s'), __('New type ?', 'servicecatalog'), $tt->getMandatoryMark('type'));
        echo "</label>";
        echo "<div class=\"bt-col-md-6 selectContainer \">";

        $mrand = Ticket::dropdownType('plugin_servicecatalog_type', ['value'     => $item->fields["type"],
                                                                   'on_change' => 'plugin_servicecatalog_reloadcat()'
        ]);
        echo "<script type='text/javascript'>";
        echo "function plugin_servicecatalog_reloadcat(){";
        $params = ['action'            => 'reloadCat',
                 'type'              => '__VALUE__',
                 'itilcategories_id' => $item->fields["itilcategories_id"],
                 'entity'            => $item->fields["entities_id"],
        ];
        Ajax::updateItemJsCode(
            'plugin_servicecatalog_category',
            PLUGIN_SERVICECATALOG_WEBDIR . '/ajax/reloadcat.php',
            $params,
            'dropdown_plugin_servicecatalog_type' . $mrand
        );
        echo "};";
        echo "</script>";
        echo "</div>";
        echo "</div>";

        //new category
        echo "<div class=\"form-group\">";
        echo "<label class=\"bt-col-md-4 control-label \">";
        echo sprintf(__('%1$s%2$s'), __('New category ?', 'servicecatalog'), $tt->getMandatoryMark('itilcategories_id'));

        if ($tt->isMandatoryField('itilcategories_id')) {
            echo Html::hidden('itilcategories_mandatory', ['id'    => 'itilcategories_mandatory',
                                                        'value' => 1]);
        } else {
            echo Html::hidden('itilcategories_mandatory', ['id'    => 'itilcategories_mandatory',
                                                        'value' => 0]);
        }
        echo "</label>";
        echo "<div id='plugin_servicecatalog_category' class=\"bt-col-md-6 selectContainer \">";
        self::displayCategory($item->fields["type"], $item->fields["entities_id"], $item->fields["itilcategories_id"]);
        echo "</div>";
        echo "</div>";

        if ($CFG_GLPI['urgency_mask'] != (1 << 3)) {
            if (!$tt->isHiddenField('urgency')) {
                echo "<div class=\"form-group\">";
                echo "<label class=\"bt-col-md-4 control-label \">";
                echo __('Urgency');
                echo "</label>";
                echo "<div class=\"bt-col-md-6 selectContainer \" data-toggle='buttons'>";
                $urgencies = [];
                if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 1)) {
                    $urgencies[1] = Ticket::getUrgencyName(1);
                }
                if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 2)) {
                    $urgencies[2] = Ticket::getUrgencyName(2);
                }
                $urgencies[3] = Ticket::getUrgencyName(3);
                if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 4)) {
                    $urgencies[4] = Ticket::getUrgencyName(4);
                }
                if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 5)) {
                    $urgencies[5] = Ticket::getUrgencyName(5);
                }

               //            echo "<div class='$class' data-toggle='buttons'>";
                $persoColor = "";
                echo Html::scriptBlock("var urgencies = [];");
                foreach ($urgencies as $k => $v) {
                    echo Html::scriptBlock("urgencies.push('urgency_$k');");
                    $persoColor .= PluginServicecatalogTicket::setPersonalStyle('urgency', $k);

                    echo "<label id='urgency_$k' class='submit btn btn-default " .
                    (($k == $item->fields["urgency"]) ? "active urgency_color_" . $k : "") . "'
                         onclick='changeColor(\"urgency_$k\",\"urgency_color_$k\",\"urgencies\")'>";

                    if ($k == $item->fields["urgency"]) {
                        $checked = "checked";
                    } else {
                        $checked = "";
                    }
                    echo "<input type='radio' name='urgency' value='$k' $checked>";
                    echo $v;
                    echo "</label>";
                }
                echo $persoColor;
                echo "</div>";
                echo "</div>";
            }
        }

        if ($CFG_GLPI['impact_mask'] != (1 << 3)) {
            if (!$tt->isHiddenField('impact')) {
                echo "<div class=\"form-group\">";
                echo "<label class=\"bt-col-md-4 control-label \">";
                echo __('Impact');
                echo "</label>";
                echo "<div class=\"bt-col-md-6 selectContainer \" data-toggle='buttons'>";

                $impacts = [];
                if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 1)) {
                    $impacts[1] = Ticket::getImpactName(1);
                }
                if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 2)) {
                    $impacts[2] = Ticket::getImpactName(2);
                }
                $impacts[3] = Ticket::getImpactName(3);
                if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 4)) {
                    $impacts[4] = Ticket::getImpactName(4);
                }
                if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 5)) {
                    $impacts[5] = Ticket::getImpactName(5);
                }
                $persoColor = "";
                echo Html::scriptBlock("var impacts = [];");
                foreach ($impacts as $k => $v) {
                    echo Html::scriptBlock("impacts.push('impact_$k');");
                    $persoColor .= PluginServicecatalogTicket::setPersonalStyle('impact', $k);

                    echo "<label id='impact_$k' class='submit btn btn-default " .
                    (($k == $item->fields["impact"]) ? "active impact_color_" . $k : "") . "'
                         onclick='changeColor(\"impact_$k\",\"impact_color_$k\",\"impacts\")'>";

                    if ($k == $item->fields["impact"]) {
                        $checked = "checked";
                    } else {
                        $checked = "";
                    }
                    echo "<input type='radio' name='impact' value='$k' $checked>";
                    echo $v;
                    echo "</label>";
                }
                echo $persoColor;
                echo "</div>";
                echo "</div>";
            }
        }

        echo Html::scriptBlock("function changeColor(idLabel,newCss,itemType){
                                      if(itemType == 'urgencies'){
                                         urgencies.forEach(function(item, index, array) {
                                            document.getElementById(item).className='btn btn-default';
                                         });
                                      }
                                      if(itemType == 'impacts'){
                                         impacts.forEach(function(item, index, array) {
                                            document.getElementById(item).className='btn btn-default';
                                         });
                                      }
                                      document.getElementById(idLabel).className='btn btn-default '+newCss;
                                   }");

        echo "<label class=\"bt-col-md-3 control-label\">";
        echo "</label>";
        echo "<div class=\"bt-col-md-8 selectContainer \">";
        echo Html::hidden('tickets_id', ['id'    => 'tickets_id',
                                       'value' => $item->getID()]);
        echo Html::submit(_sx('button', 'Save'), ['name'  => 'update_ticket',
                                                'id'    => 'formsubmit',
                                                'class' => 'btn btn-primary']);
        echo "</div>";


        echo "</div>";
        echo "</div>";

        echo "<div class='container' id='seeticket'>";

        echo "<h5 style='margin-top: 15px;'>
                  <div class='alert alert-secondary' role='alert'>";
        echo __('Ticket informations', 'servicecatalog');
        echo "</div>
            </h5>";

        //type
        echo "<div class=\"row\">";

        echo "<div class=\"form-group col-md-5\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Type');
        echo "</label>";
        echo "<div>";
        echo Ticket::getTicketTypeName($item->fields['type']);
        echo "</div>";
        echo "</div>";

        //category
        echo "<div class=\"form-group col-md-5\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Category');
        echo "</label>";
        echo "<div>";
        if (!empty($item->fields["itilcategories_id"])) {
            echo Dropdown::getDropdownName("glpi_itilcategories", $item->fields["itilcategories_id"]);
        } else {
            echo "<span class='b red'>" . __('There is no category', 'servicecatalog') . "</span>";
        }
        echo "</div>";
        echo "</div>";

        echo "</div>";

        //title
        echo "<div class=\"row\">";

        echo "<div class=\"form-group col-md-10\">";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Title');
        echo "</label>";
        echo "<div>";
        echo $item->fields["name"];
        echo "</div>";
        echo "</div>";

        echo "</div>";

        //content

        echo "<div class=\"row\">";
        echo "<div class=\"form-group col-md-10\">";
        echo "<div id='flipcat'>";
        echo "<label class=\"b col-form-label col-form-label-xd\">";
        echo __('Description');

        echo "&nbsp;<i class=\"fas fa-2x fa-angle-right\" aria-hidden=\"true\" style=\"vertical-align: middle;\"></i>";
        echo "</label>";
        echo "</div>";
        echo "</div>";

        echo "<div class=\"form-group col-md-10\">";
        echo "<div class='panel' style='display: inline;'>";
        $rand      = mt_rand();
        $rand_text = mt_rand();
        Html::initEditorSystem("content" . $rand, $rand, true, true);
        if (!isset($item->fields['content'])) {
            $item->fields['content'] = '';
        }
        Html::textarea(['name'            => 'content',
                      'value'           => stripslashes($item->fields["content"]),
                      'editor_id'       => 'content' . $rand,
                      'rows'            => 3,
                      'enable_richtext' => false]);
        echo "</div>";
        echo "</div>";

        echo "</div>";
        //container
        echo "</div>";
        Html::closeform();
    }

   /**
    * Display drop-down list of the category and ticket templates
    *
    * @param $type
    * @param $entities_id
    * @param $itilcategories_id
    */
    public static function displayCategory($type, $entities_id, $itilcategories_id)
    {
        switch ($type) {
            case Ticket::DEMAND_TYPE:
                $condition = ['is_request' => 1];
                break;

            default: // self::INCIDENT_TYPE :
                $condition = ['is_incident' => 1];
        }

        $opt = ['entity'    => $entities_id,
              'condition' => $condition,
              'display'   => false,
              'value'     => $itilcategories_id,
              'name'      => 'plugin_servicecatalog_category_id'
        ];

        $opt['display_emptychoice'] = false;

        echo ITILCategory::dropdown($opt);
    }
}
