<?php
/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

/**
 *
 */
class PluginServicecatalogTools extends CommonDBTM
{

    static $rightname = 'plugin_servicecatalog_setup';
    private $table = "";

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    static function getTypeName($nb = 0)
    {
        return __('Tools', 'servicecatalog');
    }

    public static function getTable($classname = null)
    {
        return "glpi_plugin_servicecatalog_configs";
    }

    /**
     * @param \CommonGLPI $item
     * @param int $withtemplate
     *
     * @return string
     * @see CommonGLPI::getTabNameForItem()
     */
    function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {

        if ($item->getType() == 'PluginServicecatalogConfig') {
            return self::getTypeName();
        }
        return '';
    }

    /**
     * @param \CommonGLPI $item
     * @param int $tabnum
     * @param int $withtemplate
     *
     * @return bool
     * @see CommonGLPI::displayTabContentForItem()
     */
    static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {

        if ($item->getType() == 'PluginServicecatalogConfig') {
            $self = new self();
            $self->showTools();
        }
        return true;
    }


    public static function showTools()
    {
        global $DB, $CFG_GLPI;

        echo "<br><div align='center'>";
        echo "<table class='tab_cadre_fixe'>";
        echo "<tr class='tab_bg_2'>";
        echo "<th class='center' colspan='2'>";
        echo __('Tools', 'servicecatalog');
        echo "</th>";
        echo "</tr>";
        echo "<tr class='tab_bg_2'>";
        echo "<td class='center'>";
        echo "<a class='btn btn-primary submit' href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/tools.form.php?renewtree=1'>";
        echo __('Regenerate tree of tickets categories', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "</tr>";

//duplicates
        $query = "SELECT COUNT(*) AS nbr_doublon, `itilcategories_id` 
                    FROM `glpi_plugin_servicecatalog_categories` 
                    GROUP BY `itilcategories_id` 
                     HAVING COUNT(*) > 1";

        $result = $DB->query($query);
        if ($DB->numrows($result) > 0) {
            echo "<tr class='tab_bg_2'>";
            echo "<td class='center'>";
            echo __('Duplicates of categories', 'servicecatalog');
            echo "</td>";
            echo "</tr>";

            echo "<tr class='tab_bg_2'>";
            echo "<td class='center'>";

            while ($array = $DB->fetchAssoc($result)) {

                echo "<table class='tab_cadre_fixe'>";
                echo "<tr class='tab_bg_2'>";
                echo "<th class='center'>";
                echo __('Category');
                echo "</th>";
                echo "<th class='center'>";
                echo __('Number of duplicates', 'servicecatalog');
                echo "</th>";
                echo "<th class='center'>";
                echo "</th>";
                echo "</tr>";
                echo "<tr class='tab_bg_2'>";
                echo "<td class='center'>";
                echo "<a href='" . $CFG_GLPI["root_doc"] . "/front/itilcategory.form.php?id=" . $array['itilcategories_id'] . "'>";
                echo $array['itilcategories_id'];
                echo "</a>";
                echo "</td>";
                echo "<td class='center'>";
                echo $array['nbr_doublon'];
                echo "</td>";
                echo "<td class='center'>";
                echo Html::getSimpleForm(
                    PluginServicecatalogTools::getFormURL(),
                    'purge_duplicates',
                    _x('button', 'Delete permanently'),
                    ['itilcategories_id' => $array['itilcategories_id']],
                    'fa-times-circle'
                );
                echo "</td>";
                echo "</tr>";
                echo "</table>";
            }
        }



        $query = "SELECT COUNT(*) AS nbr_doublon, `entities_id` 
                    FROM `glpi_plugin_servicecatalog_dashboards`
                    WHERE `users_id` = 0 AND `profiles_id` = 0
                    GROUP BY `entities_id` 
                     HAVING COUNT(*) > 1";

        $result = $DB->query($query);
        $form = Toolbox::getItemTypeFormURL('PluginServicecatalogEntity');
        if ($DB->numrows($result) > 0) {
            echo "<tr class='tab_bg_2'>";
            echo "<td class='center'>";
            echo __('Duplicates of default dashboards', 'servicecatalog');
            echo "</td>";
            echo "</tr>";

            echo "<tr class='tab_bg_2'>";
            echo "<td class='center'>";

            while ($array = $DB->fetchAssoc($result)) {

                echo "<table class='tab_cadre_fixe'>";
                echo "<tr class='tab_bg_2'>";
                echo "<th class='center'>";
                echo __('Entity');
                echo "</th>";
                echo "<th class='center'>";
                echo __('Number of duplicates', 'servicecatalog');
                echo "</th>";
                echo "<th class='center'>";
                echo "</th>";
                echo "</tr>";
                echo "<tr class='tab_bg_2'>";
                echo "<td class='center'>";
                echo Dropdown::getDropdownName("glpi_entities", $array['entities_id']);
                echo "</a>";
                echo "</td>";
                echo "<td class='center'>";
                echo $array['nbr_doublon'];
                echo "</td>";
                echo "<td class='center'>";
                echo Html::getSimpleForm(
                    $form,
                    'delete_entity',
                    "",
                    ["entities_id" => $array['entities_id']],
                    "fa-times-circle fa-1x",
                    "class='submit btn btn-default'",
                    __('Are you sure you want to delete this default dashboard ?', 'servicecatalog')
                );
                echo "</td>";
                echo "</tr>";
                echo "</table>";
            }
        }

        echo "</table></div>";
    }
}
