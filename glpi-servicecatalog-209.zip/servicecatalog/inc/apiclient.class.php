<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

define('SC_API_RESULT_OK', 'ok');
define('SC_API_RESULT_ERROR', 'ko');

/**
 * Class PluginServicecatalogApiclient
 */
class PluginServicecatalogApiclient extends CommonDBTM
{
    public static $rightname         = "plugin_servicecatalog_api";

    /**
     * functions mandatory
     * getTypeName(), canCreate(), canView()
     *
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        return __('API clients', 'servicecatalog');
    }

    /**
     * get menu content
     *
     * @return array array for menu
     **@since version 0.85
     *
     */
    public static function getMenuContent()
    {
        $menu = [];

        $menu['title']           = self::getMenuName();
        $menu['page']            = self::getSearchURL(false);
        $menu['links']['search'] = self::getSearchURL(false);
        if (self::canCreate()) {
            $menu['links']['add'] = self::getFormURL(false);
        }
        $menu['icon'] = self::getIcon();

        return $menu;
    }

    /**
     * @return string
     */
    public static function getIcon()
    {
        return "ti ti-world-download";
    }

    /**
     * @param array $options
     *
     * @return array
     * @see CommonGLPI::defineTabs()
     */
    public function defineTabs($options = [])
    {
        $ong = [];
        $this->addDefaultFormTab($ong);
        return $ong;
    }

    /**
     * @param \CommonGLPI $item
     * @param int         $withtemplate
     *
     * @return string
     * @see CommonGLPI::getTabNameForItem()
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item->getType() == 'PluginServicecatalogConfig') {
            return self::getTypeName(2);
        }
        return '';
    }

    /**
     * @param \CommonGLPI $item
     * @param int         $tabnum
     * @param int         $withtemplate
     *
     * @return bool
     * @see CommonGLPI::displayTabContentForItem()
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if ($item->getType() == 'PluginServicecatalogConfig') {
            $self = new self();
            $self->showMenu();
        }
        return true;
    }


    /**
     * @return void
     */
    public static function showMenu()
    {
        echo "<div class='display-4 center' style='margin: 15px;'>";
        echo "<h4>";
        $icon = self::getIcon();
        echo "<i class='ti $icon'></i>&nbsp;";
        echo self::getTypeName(2);
        echo "</h4>";
        echo "</div><hr style='margin: 1.2rem 0;'>";

        echo "<div align='center'>";
        echo "<table class='tab_cadre_fixe'>";
        echo "<tr>";
        echo "<td class='center'>";
        echo "<i class='ti ti-world'></i><br>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/apiclient.php'>";
        echo __('API client list', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<td class='center'>";
        echo "<i class='ti ti-world-upload'></i><br>";
        echo "<a href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/apiclient.form.php'>";
        echo __('Add API client', 'servicecatalog');
        echo "</a>";
        echo "</td>";
        echo "<tr>";
        echo "</table></div>";
    }



    /**
     * @param       $ID
     * @param array $options
     */
    public function showForm($ID, $options = [])
    {
        $this->initForm($ID, $options);
        $this->showFormHeader($options);

        echo "<tr class='tab_bg_1'><td>" . __('Active') . "</td>";
        echo "<td>";
        Dropdown::showYesNo("is_active", $this->fields['is_active']);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Name') . "</td>";
        echo "<td colspan='3'>";
        echo Html::input('name', ['value' => $this->fields['name'], 'size' => 40]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Login') . "</td>";
        echo "<td colspan='3'>";
        echo Html::input('login', ['value' => $this->fields['login'], 'size' => 40]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Password') . "</td>";
        echo "<td><input type='password' size='40' id='password' name='password' value='' autocomplete='new-password' class='form-control'>";
        if ($ID) {
            echo "<input type='checkbox' name='_blank_passwd' id='_blank_passwd'>&nbsp;"
            . "<label for='_blank_passwd'>" . __('Clear') . "</label>";
        }
        echo "</td></tr>";


        echo "<tr class='tab_bg_1'><td>" . __('Api Json url', 'service catalog') . "</td>";
        echo "<td colspan='3'>";
        echo Html::input('url', ['value' => $this->fields['url'], 'size' => 84]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Article url', 'service catalog') . "</td>";
        echo "<td colspan='3'>";
        echo Html::input('url_article', ['value' => $this->fields['url_article'], 'size' => 84]);
        echo "</td></tr>";

        if ($ID > 0 && $this->fields['is_active'] == 1) {
            $test = self::APICall($ID, true);

            echo "<tr class='tab_bg_1'><td>" . __('Connection test', 'service catalog') . "</td>";
            echo "<td colspan='3'>";
            if ($test == 200) {
                echo "<i style='color:forestgreen' class='fas fa-check-circle fa-1x'></i>";
            } else {
                echo "<i style='color:darkred' class='fas fa-times-circle fa-1x'></i>";
                echo "<br>".$test." Error";
            }
            echo "</td></tr>";
        }
        $this->showFormButtons($options);

        Html::closeForm();
    }

    public function prepareInputForAdd($input)
    {
        if (isset($input["password"]) && !empty($input["password"])) {
            $input["password"] = (new GLPIKey())->encrypt($input["password"]);
        }

        return $input;
    }

    public function prepareInputForUpdate($input)
    {
        if (isset($input["password"])) {
            if (empty($input["password"])) {
                unset($input["password"]);
            } else {
                $input["password"] = (new GLPIKey())->encrypt($input["password"]);
            }
        }

        if (isset($input["_blank_passwd"]) && $input["_blank_passwd"]) {
            $input['password'] = '';
        }

        return $input;
    }

    /**
     * Get the Search options for the given Type
     *
     * This should be overloaded in Class
     *
     * @return array an *indexed* array of search options
     *
     * @see https://glpi-developer-documentation.rtfd.io/en/master/devapi/search.html
     **/
    public function rawSearchOptions()
    {
        $tab = [];

        $tab[] = [
            'id'   => 'common',
            'name' => __('Characteristics')
        ];

        $tab[] = [
            'id'            => '1',
            'table'         => $this->getTable(),
            'field'         => 'name',
            'name'          => __('Name'),
            'datatype'      => 'itemlink',
            'massiveaction' => false
        ];

        $tab[] = [
            'id'            => '2',
            'table'         => $this->getTable(),
            'field'         => 'id',
            'name'          => __('ID'),
            'massiveaction' => false,
            'datatype'      => 'number'
        ];

        $tab[] = [
            'id'       => '3',
            'table'    => $this->getTable(),
            'field'    => 'url',
            'name'     => __('Api Json url', 'servicecatalog'),
            'datatype' => 'string'
        ];

        $tab[] = [
            'id'       => '4',
            'table'    => $this->getTable(),
            'field'    => 'url_article',
            'name'     => __('Article url', 'servicecatalog'),
            'datatype' => 'string'
        ];

        $tab[] = [
            'id'       => '5',
            'table'    => $this->getTable(),
            'field'    => 'login',
            'name'     => __('Login'),
            'datatype' => 'string'
        ];

//        $tab[] = [
//            'id'       => '18',
//            'table'    => $this->getTable(),
//            'field'    => 'is_recursive',
//            'name'     => __('Child entities'),
//            'datatype' => 'bool'
//        ];


//        $tab[] = [
//            'id'       => '80',
//            'table'    => 'glpi_entities',
//            'field'    => 'completename',
//            'name'     => __('Entity'),
//            'datatype' => 'dropdown'
//        ];

        return $tab;
    }


    /**
     * @return array
     */
    public static function getArticles($fuzzy_entries)
    {
        $apiclient = new self();
        $config = new PluginServicecatalogConfig();

        foreach ($apiclient->find(["is_active" => 1]) as $data) {
            $url_article = $data['url_article'];

            $drupal_articles = self::APICall($data['id']);

            if (is_array($drupal_articles) && count($drupal_articles) > 0) {
                foreach ($drupal_articles as $drupal_article) {
                    $name = $drupal_article["title"];
                    $resume = $drupal_article["field_resume"];
                    $keywords = $drupal_article["field_mots_cles"];
                    $targets = $drupal_article["field_public_cible"];

                    if(str_contains($targets,",") !== false){
                        $targets = "";
                    }
                    $url_link = $url_article . $drupal_article["search_api_url"];
                    $identity = __('FAQ');

                    $entries[] = [
                        'url' => $url_link,
                        'title' => $name,
                        'keywords' => $keywords,
                        'targets' => $targets,
                        'comment' => ($resume != null) ? Html::resume_text(Glpi\RichText\RichText::getTextFromHtml($resume), "200") : "",
                        'icon' => 'fa-book-open',
                        'background' => $config->getSearchApiColor(),
                        'type' => $identity,
                        'order'     => "3",
                        'target' => '_blank'
                    ];
                }
                $fuzzy_entries = array_merge($fuzzy_entries, $entries);
            }
        }

        return $fuzzy_entries;
    }


    /**
     * Curl call to create element
     *
     * @param String $url
     * @param $login
     * @param $password
     * @return mixed
     */
    public static function APICall($id, $test = false)
    {
        global $CFG_GLPI;

        $self = new self();
        if ($self->getFromDB($id)) {
            $url = $self->fields['url'];
            $login = $self->fields['login'];
            $password = (new GLPIKey())->decrypt($self->fields['password']);

            if (!function_exists('curl_init')) {
                return __('Curl PHP package not installed', 'servicecatalog') . "\n";
            }
            $proxy_host  = !empty($CFG_GLPI["proxy_name"]) ? ($CFG_GLPI["proxy_name"] . ":" . $CFG_GLPI["proxy_port"]) : false; // host:port
            $proxy_ident = !empty($CFG_GLPI["proxy_user"]) ? ($CFG_GLPI["proxy_user"] . ":" .
                (new GLPIKey())->decrypt($CFG_GLPI["proxy_passwd"])) : false; // username:password


            $ch = curl_init();

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//        curl_setopt($ch, CURLOPT_TIMEOUT, 5000);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
//        curl_setopt($ch, CURLOPT_VERBOSE, 1);
//         Activation de l'utilisation d'un serveur proxy
            if (!empty($CFG_GLPI["proxy_name"])) {
                // Définition de l'adresse du proxy
                curl_setopt($ch, CURLOPT_PROXY, $proxy_host);

                // Définition des identifiants si le proxy requiert une identification
                if ($proxy_ident) {
                    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy_ident);
                }
            }
            if (preg_match('`^https://`i', $url)) {
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            }

            curl_setopt($ch, CURLOPT_URL, $url);
            // Set authentication details.

//        $basic_auth = base64_encode($login.':'.$password);
            $headers = ['Accept: application/json'];
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, "$login:$password");
            // Fetch the results.
            $result = curl_exec($ch);
            $infos = curl_getinfo($ch);
            $response = $infos['http_code'];

            curl_close($ch);

            if ($response != 200 || $test) {
                Toolbox::logInfo($response);
                if ($test) {
                    return $response;
                } else {
                    return [];
                }
            } else {
                return json_decode($result, 1);
            }
        }
        return false;
    }
}
