<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogIndicator
 */
class PluginServicecatalogIndicator extends CommonDBTM
{

   /**
    * @param $left
    * @param $criteria
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryAllTickets($left, $criteria)
    {
        global $DB;

        //all tickets
        $dbu     = new DbUtils();
        $sql_all = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        AND `glpi_tickets`.`status` NOT IN (" . Ticket::SOLVED . ", " . Ticket::CLOSED . ") ";
        $sql_all .= $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $result_all = $DB->query($sql_all);
        $total_all  = $DB->result($result_all, 0, 'total');

        return $total_all;
    }


   /**
    * @param $left
    * @param $criteria
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryNewTickets($left, $criteria, $search_assign)
    {
        global $DB;

        //New tickets
        $dbu     = new DbUtils();
        $sql_new = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        
                        AND `glpi_tickets`.`status` = " . Ticket::INCOMING . " " .
                 $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");//AND ($search_assign)

        $result_new = $DB->query($sql_new);
        $total_new  = $DB->result($result_new, 0, 'total');

        return $total_new;
    }

   /**
    * @param $left
    * @param $criteria
    * @param $search_assign
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryDueTickets($left, $criteria, $search_assign)
    {
        global $DB;

        $dbu     = new DbUtils();
        $sql_due = "SELECT COUNT(DISTINCT glpi_tickets.id) AS due
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        AND ($search_assign)
                        AND `glpi_tickets`.`status` NOT IN (" . Ticket::WAITING . "," . Ticket::SOLVED . ", " . Ticket::CLOSED . ")
                        AND `glpi_tickets`.`time_to_resolve` IS NOT NULL
                        AND `glpi_tickets`.`time_to_resolve` < NOW() ";
        $sql_due .= $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $result_due = $DB->query($sql_due);
        $total_due  = $DB->result($result_due, 0, 'due');

        return $total_due;
    }

   /**
    * @param $left
    * @param $criteria
    * @param $search_assign
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryPendingTickets($left, $criteria, $search_assign)
    {
        global $DB;

        $dbu      = new DbUtils();
        $sql_pend = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        AND ($search_assign)
                        AND `glpi_tickets`.`status` = " . Ticket::WAITING . " " .
                  $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $result_pend = $DB->query($sql_pend);
        $total_pend  = $DB->result($result_pend, 0, 'total');

        return $total_pend;
    }


   /**
    * @param $left
    * @param $criteria
    * @param $search_assign
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryIncidentTickets($left, $criteria, $search_assign)
    {
        global $DB;

        $dbu      = new DbUtils();
        $statuses = [Ticket::SOLVED, Ticket::CLOSED, Ticket::WAITING, Ticket::INCOMING];
        if (Session::getCurrentInterface() == 'helpdesk') {
            $statuses = [Ticket::SOLVED, Ticket::CLOSED];
        }

        $sql_incpro    = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        AND ($search_assign)
                        AND `glpi_tickets`.`type` = '" . Ticket::INCIDENT_TYPE . "'
                        AND `glpi_tickets`.`status` NOT IN (" . implode(",", $statuses) . ") ";
        $sql_incpro    .= $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");
        $result_incpro = $DB->query($sql_incpro);
        $total_incpro  = $DB->result($result_incpro, 0, 'total');
        return $total_incpro;
    }

   /**
    * @param     $type
    * @param     $left
    * @param     $is_deleted
    * @param     $search_assign
    *
    * @param int $itilcategories_id
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryGroupUserTickets($type, $left, $is_deleted, $search_assign, $itilcategories_id = 0)
    {
        global $DB;

        $dbu      = new DbUtils();
        $addwhere = "";
        if ($itilcategories_id > 0) {
            $addwhere = "AND `glpi_tickets`.`itilcategories_id` = '" . $itilcategories_id . "'";
        }
        $sql    = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $is_deleted
                        AND ($search_assign)
                        AND `glpi_tickets`.`type` = '" . $type . "'
                        $addwhere
                        AND `glpi_tickets`.`status` NOT IN (" . Ticket::SOLVED . ", " . Ticket::CLOSED . ") ";
        $sql    .= $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");
        $result = $DB->query($sql);

        $total = $DB->result($result, 0, 'total');

        return $total;
    }

   /**
    * @param $left
    * @param $criteria
    * @param $search_assign
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryRequestTickets($left, $criteria, $search_assign)
    {
        global $DB;

        $dbu = new DbUtils();

        $statuses = [Ticket::SOLVED, Ticket::CLOSED, Ticket::WAITING, Ticket::INCOMING];
        if (Session::getCurrentInterface() == 'helpdesk') {
            $statuses = [Ticket::SOLVED, Ticket::CLOSED];
        }

        $sql_dempro    = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        AND ($search_assign)
                        AND `glpi_tickets`.`type` = '" . Ticket::DEMAND_TYPE . "'
                        AND `glpi_tickets`.`status` NOT IN (" . implode(",", $statuses) . ") ";
        $sql_dempro    .= $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");
        $result_dempro = $DB->query($sql_dempro);
        $total_dempro  = $DB->result($result_dempro, 0, 'total');

        return $total_dempro;
    }

   /**
    * @param $left
    * @param $criteria
    * @param $search_assign
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryValidateTickets($left, $criteria, $search_assign)
    {
        global $DB;

        $dbu     = new DbUtils();
        $sql_val = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                      FROM `glpi_tickets`
                      LEFT JOIN `glpi_tickets_users`
                           ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`)
                      LEFT JOIN `glpi_groups_tickets`
                           ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`)
                      LEFT JOIN `glpi_ticketvalidations`
                                 ON (`glpi_tickets`.`id` = `glpi_ticketvalidations`.`tickets_id`)
                              WHERE `glpi_tickets`.`is_deleted` = 0
                                    AND `users_id_validate` = '" . Session::getLoginUserID() . "'
                                    AND `glpi_ticketvalidations`.`status` = '" . CommonITILValidation::WAITING . "'
                                    AND `glpi_tickets`.`global_validation` = '" . CommonITILValidation::WAITING . "'
                                    AND `glpi_tickets`.`status` NOT IN ('" . Ticket::CLOSED . "',
                                                                         '" . Ticket::SOLVED . "') ";
        $sql_val .= $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");
        $sql_val .= " ORDER BY `glpi_tickets`.`date_mod` DESC";

        $result_val = $DB->query($sql_val);
        $total_val  = $DB->result($result_val, 0, 'total');

        return $total_val;
    }


   /**
    * @param $left
    * @param $criteria
    * @param $search_assign
    *
    * @return mixed|\Value
    * @throws \GlpitestSQLError
    */
    public static function queryResolvedTickets($left, $criteria, $search_assign)
    {
        global $DB;

        $dbu     = new DbUtils();
        $sql_res = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        AND ($search_assign)
                        AND `glpi_tickets`.`status` = " . Ticket::SOLVED . " " .
                 $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $result_res = $DB->query($sql_res);
        $total_res  = $DB->result($result_res, 0, 'total');

        return $total_res;
    }


    /**
     * @param $left
     * @param $criteria
     * @param $search_assign
     *
     * @return mixed|\Value
     * @throws \GlpitestSQLError
     */
    public static function queryClosedTickets($left, $criteria, $search_assign)
    {
        global $DB;

        $dbu     = new DbUtils();
        $sql_res = "SELECT COUNT(DISTINCT glpi_tickets.id) as total
                  FROM glpi_tickets
                  $left
                  WHERE $criteria
                        AND ($search_assign)
                        AND `glpi_tickets`.`status` = " . Ticket::CLOSED . " " .
            $dbu->getEntitiesRestrictRequest("AND", "glpi_tickets");

        $result_res = $DB->query($sql_res);
        $total_res  = $DB->result($result_res, 0, 'total');

        return $total_res;
    }

   /**
    * @param       $id
    * @param array $params
    * @param bool  $iswidget
    *
    * @return bool
    * @throws \GlpitestSQLError
    */
    public static function displayIndicator($id, $params = [], $iswidget = false, $mygroups = false)
    {
        global $CFG_GLPI;

        if ($mygroups && !Session::haveRightsOr("ticket", [Ticket::READGROUP])) {
            return false;
        }

        if ($mygroups == false && !Session::haveRightsOr("ticket", [Ticket::READMY, Ticket::READALL])) {
            return false;
        }

        $seeown = false;
        if (Session::getCurrentInterface() == 'helpdesk') {
            $seeown = true;
        }

        if ($seeown == false) {
            if ($iswidget == true) {
                if (Plugin::isPluginActive("Mydashboard")) {
                    $preference = new PluginMydashboardPreference();
                    if (!$preference->getFromDB(Session::getLoginUserID())) {
                        $preference->initPreferences(Session::getLoginUserID());
                    }
                    $preference->getFromDB(Session::getLoginUserID());
                    $preferences = $preference->fields;
                    if (isset($preferences['prefered_group'])) {
                        $technicians_groups_id = json_decode($preferences['prefered_group'], true);
                        if (is_array($technicians_groups_id)
                        && count($technicians_groups_id) > 0
                        && count($params) < 1) {
                            $params['technicians_groups_id'] = $technicians_groups_id;
                        }
                    }
                }

                if (isset($params['technicians_groups_id'])) {
                    $params['technicians_groups_id'] = (is_array($params['technicians_groups_id']) ? $params['technicians_groups_id'] : [$params['technicians_groups_id']]);
                }
            } else {
                if (count($_SESSION['glpigroups']) && $iswidget == false) {
                    $groups = [];
                    foreach ($_SESSION['glpigroups'] as $groups_id) {
                        $group = new Group;
                        $group->getFromDB($groups_id);
                        if (isset($group->fields['is_assign'])
                        && $group->fields['is_assign'] == 1) {
                            $groups[] = $groups_id;
                        }
                    }
                    $params['technicians_groups_id'] = $groups;
                }
            }
        }

        $search_assign = "1=1";
        $left          = "LEFT JOIN glpi_entities 
                  ON (`glpi_tickets`.`entities_id` = `glpi_entities`.`id`) ";
        $is_deleted    = " `glpi_tickets`.`is_deleted` = 0 ";
        //if (Session::haveRight("ticket", Ticket::READMY)) {
        //   $left          .= "LEFT JOIN `glpi_tickets_users`
       //            ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`) ";
        //   $search_assign .= " AND (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
       //                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::ASSIGN . "')";
        //}

        if ($seeown == false) {
            if (isset($params['technicians_groups_id']) && count($params['technicians_groups_id']) > 0) {
                $left                  .= "LEFT JOIN `glpi_groups_tickets`
                  ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`) ";
                $technicians_groups_id = $params['technicians_groups_id'];
                $search_assign         .= " AND (`glpi_groups_tickets`.`groups_id` IN (" . implode(",", $technicians_groups_id) . ")
                                AND `glpi_groups_tickets`.`type` = '" . CommonITILActor::ASSIGN . "')";
            } elseif (count($_SESSION['glpigroups']) && $iswidget == false) {
                $groups = [];
                $groups_assign = [];
                foreach ($_SESSION['glpigroups'] as $groups_id) {
                    $group = new Group;
                    $group->getFromDB($groups_id);
                    if (isset($group->fields['is_assign'])
                        && $group->fields['is_assign'] == 1) {
                        $groups[] = $groups_id;
                    }
                }

                $left          .= "LEFT JOIN `glpi_groups_tickets`
                  ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`) ";
                if (count($groups) > 0) {
                    $groups_assign = implode("','", $groups);
                }
                if (count($groups_assign) > 0) {
                    $search_assign .= " AND (`glpi_groups_tickets`.`groups_id` IN ('" . $groups_assign . "')
                                AND `glpi_groups_tickets`.`type` = '" . CommonITILActor::ASSIGN . "')";
                }
            }
        } else {
            if ($mygroups && count($_SESSION['glpigroups'])) {
                $groups = [];
                foreach ($_SESSION['glpigroups'] as $groups_id) {
                    $group = new Group;
                    $group->getFromDB($groups_id);
                    if (isset($group->fields['is_requester'])
                        && $group->fields['is_requester'] == 1) {
                        $groups[] = $groups_id;
                    }
                }

                if (count($groups) > 0) {
                    $left .= "LEFT JOIN `glpi_groups_tickets`
                  ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`) ";
                    $groups_requester = implode("','", $groups);
                    $search_assign .= " AND ((`glpi_groups_tickets`.`groups_id` IN ('" . $groups_requester . "')
                                AND `glpi_groups_tickets`.`type` = '" . CommonITILActor::REQUESTER . "')";


                    $search_assign .= " OR (`glpi_groups_tickets`.`groups_id` IN ('$groups_requester')
                                     AND `glpi_groups_tickets`.`type`
                                           = '" . CommonITILActor::OBSERVER . "')) ";
                }

            } else {
                $left          .= "LEFT JOIN `glpi_tickets_users`
                  ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`) ";
                $search_assign .= " AND (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                                AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "')";
                $search_assign .= " OR (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            AND `glpi_tickets_users`.`type` = '" . CommonITILActor::OBSERVER . "')";
                $search_assign .= " OR `glpi_tickets`.`users_id_recipient` = '" . Session::getLoginUserID() . "' ";
            }

        }
        //New tickets
        $total_new = self::queryNewTickets($left, $is_deleted, $search_assign);
        //Late tickets
        $total_due = self::queryDueTickets($left, $is_deleted, $search_assign);
        //Waiting tickets
        $total_pend = self::queryPendingTickets($left, $is_deleted, $search_assign);
        //Processing incidents
        $total_incpro = self::queryIncidentTickets($left, $is_deleted, $search_assign);
        //Processing requests
        $total_dempro = self::queryRequestTickets($left, $is_deleted, $search_assign);
        //Validate tickets
        $total_validate = self::queryValidateTickets($left, $is_deleted, $search_assign);
        //Resolved tickets
        $total_resolved = self::queryResolvedTickets($left, $is_deleted, $search_assign);

        $size = "";
        $span = "";
        if ($iswidget == true) {
            $size = "font-size:18px";
            $span = "ind-link";
        }

        $target = "";
        if ($iswidget == true) {
            $target = "target = '_blank'";
        }

        // Reset criterias
        $options_new['reset'][] = 'reset';

        $options_new['criteria'][] = [
         'field'      => 12,//status
         'searchtype' => 'equals',
         'value'      => Ticket::INCOMING,
         'link'       => 'AND'
        ];

//        if (isset($params['technicians_groups_id'])
//            && count($params['technicians_groups_id']) > 0) {
//            $groups = $params['technicians_groups_id'];
//            $nb     = 0;
//            foreach ($groups as $group) {
//                $criterias['criteria'][$nb] = [
//                    'field'      => 8, // groups_id_assign
//                    'searchtype' => 'equals',
//                    'value'      => $group,
//                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
//                ];
//                $nb++;
//            }
//            $options_new['criteria'][] = $criterias;
//        }


        $href_new = "<a $target style='color:#D9534F !important;$size' title='" . __('New tickets', 'servicecatalog') . "' \
href='" . $CFG_GLPI["root_doc"] . '/front/ticket.php?' .
                  Toolbox::append_params($options_new, '&amp;') . "' ><span class='$span'>" .
                  $total_new . "</span></a>";

        //$href_due
        // Reset criterias
        $options_due['reset'][] = 'reset';

        $options_due['criteria'][] = [
         'field'      => 12,//status
         'searchtype' => 'equals',
         'value'      => 'notold',
         'link'       => 'AND'
        ];

        if (isset($params['technicians_groups_id'])
          && count($params['technicians_groups_id']) > 0) {
            $groups = $params['technicians_groups_id'];
            $nb     = 0;
            foreach ($groups as $group) {
                $criterias['criteria'][$nb] = [
                'field'      => 8, // groups_id_assign
                'searchtype' => 'equals',
                'value'      => $group,
                'link'       => (($nb == 0) ? 'AND' : 'OR'),
                ];
                $nb++;
            }
            $options_due['criteria'][] = $criterias;
        }

        $options_due['criteria'][] = [
         'field'      => 82,//due date
         'searchtype' => 'equals',
         'value'      => 1,
         'link'       => 'AND'
        ];


        $href_due = "<a $target style='$size' title='" . __('Tickets late', 'servicecatalog') . "' \
href='" . $CFG_GLPI["root_doc"] . '/front/ticket.php?' .
                  Toolbox::append_params($options_due, '&amp;') . "' ><span class='$span'>" .
                  $total_due . "</span></a>";

        //$href_pend
        // Reset criterias
        $options_pend['reset'][] = 'reset';

        $options_pend['criteria'][] = [
         'field'      => 12,//status
         'searchtype' => 'equals',
         'value'      => Ticket::WAITING,
         'link'       => 'AND'
        ];

        if (isset($params['technicians_groups_id'])
          && count($params['technicians_groups_id']) > 0) {
            $groups = $params['technicians_groups_id'];
            $nb     = 0;
            foreach ($groups as $group) {
                $criterias['criteria'][$nb] = [
                'field'      => 8, // groups_id_assign
                'searchtype' => 'equals',
                'value'      => $group,
                'link'       => (($nb == 0) ? 'AND' : 'OR'),
                ];
                $nb++;
            }
            $options_pend['criteria'][] = $criterias;
        }

        $href_pend = "<a $target style='$size' title='" . __('Pending tickets', 'servicecatalog') . "' \
href='" . $CFG_GLPI["root_doc"] . '/front/ticket.php?' .
                   Toolbox::append_params($options_pend, '&amp;') . "' ><span class='$span'>" .
                   $total_pend . "</span></a>";

        //$href_incpro
        // Reset criterias
        $options_incpro['reset'][] = 'reset';

        if ($seeown == false) {
            $options_incpro['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => 'process',
            'link'       => 'AND'
            ];
        } else {
            $options_incpro['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => 'notold',
            'link'       => 'AND'
            ];
        }

        $options_incpro['criteria'][] = [
         'field'      => 14, // type
         'searchtype' => 'equals',
         'value'      => Ticket::INCIDENT_TYPE,
         'link'       => 'AND',
        ];

        if ($seeown == false) {
            if (isset($params['technicians_groups_id'])
             && count($params['technicians_groups_id']) > 0) {
                $groups = $params['technicians_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 8, // groups_id_assign
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options_incpro['criteria'][] = $criterias;
            }
        }
        if ($mygroups == false) {
            $mygroups = 0;
        }
        if (Session::getCurrentInterface() != 'central') {
            $href_incpro = "<a style='$size' title='" . __('Incidents in progress', 'servicecatalog') . "' \
href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php?type=" . Ticket::INCIDENT_TYPE . "&mygroups=$mygroups'><span class='$span'>" .
                        $total_incpro . "</span></a>";
        } else {
            $href_incpro = "<a $target style='$size' title='" . __('Incidents in progress', 'servicecatalog') . "' \
href='" . $CFG_GLPI["root_doc"] . '/front/ticket.php?' .
                        Toolbox::append_params($options_incpro, '&amp;') . "' ><span class='$span'>" .
                        $total_incpro . "</span></a>";
        }
        //$href_dempro
        // Reset criterias
        $options_dempro['reset'][] = 'reset';

        if ($seeown == false) {
            $options_dempro['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => 'process',
            'link'       => 'AND'
            ];
        } else {
            $options_dempro['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => 'notold',
            'link'       => 'AND'
            ];
        }

        $options_dempro['criteria'][] = [
         'field'      => 14, // type
         'searchtype' => 'equals',
         'value'      => Ticket::DEMAND_TYPE,
         'link'       => 'AND',
        ];

        if ($seeown == false) {
            if (isset($params['technicians_groups_id'])
             && count($params['technicians_groups_id']) > 0) {
                $groups = $params['technicians_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 8, // groups_id_assign
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options_dempro['criteria'][] = $criterias;
            }
        }
        if ($mygroups == false) {
            $mygroups = 0;
        }
        if (Session::getCurrentInterface() != 'central') {
            $href_dempro = "<a style='$size' title='" . __('Requests in progress', 'servicecatalog') . "' \
href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php?type=" . Ticket::DEMAND_TYPE . "&mygroups=$mygroups'><span class='$span'>" .
                        $total_dempro . "</span></a>";
        } else {
            $href_dempro = "<a $target style='$size' title='" . __('Requests in progress', 'servicecatalog') . "' \
href='" . $CFG_GLPI["root_doc"] . '/front/ticket.php?' .
                        Toolbox::append_params($options_dempro, '&amp;') . "' ><span class='$span'>" .
                        $total_dempro . "</span></a>";
        }

        if ($seeown == true) {
            $config = new PluginServicecatalogConfig();

            if (Session::getCurrentInterface() != 'central') {
                $href_validate = "<a style='$size' title='" . __('Your tickets to validate') . "' \
href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket_validate.php'><span class='$span'>" .
                             $total_validate . "</span></a>";
            } else {
                //Reset criterias
                $options_validate['reset'][] = 'reset';

                $options_validate['criteria'][] = [
                'field'      => 12,//status
                'searchtype' => 'equals',
                'value'      => 'notold',
                'link'       => 'AND'
                ];

                $options_validate['criteria'][] = [
                'field'      => 55,//validation status
                'searchtype' => 'equals',
                'value'      => TicketValidation::WAITING,
                'link'       => 'AND'
                ];

                $options_validate['criteria'][] = [
                'field'      => 59,//validation aprobator
                'searchtype' => 'equals',
                'value'      => Session::getLoginUserID(),
                'link'       => 'AND'
                ];

                $options_validate['criteria'][] = [
                'field'      => 52,//global validation status
                'searchtype' => 'equals',
                'value'      => CommonITILValidation::WAITING,
                'link'       => 'AND'
                ];

                $href_validate = "<a style='$size' title='" . __('Your tickets to validate') . "' \
            href='" . $CFG_GLPI["root_doc"] . '/front/ticket.php?' .
                             Toolbox::append_params($options_validate, '&amp;') . "' ><span class='$span'>" .
                             $total_validate . "</span></a>";
            }

            if (Session::getCurrentInterface() != 'central') {
                $widget   = new PluginServicecatalogWidget();
                $titleres = __('Your tickets to close', 'servicecatalog');
                if (Session::haveRight('plugin_servicecatalog_requests', READ)
                && $widget->fields['display_request'] == 1
                && $widget->fields["display_incident"] != 1) {
                    $titleres = __('Your requests to close', 'servicecatalog');
                }
                if (Session::haveRight('plugin_servicecatalog_incidents', READ)
                && $widget->fields['display_incident'] == 1
                && $widget->fields["display_request"] != 1) {
                    $titleres = __('Your incidents to close', 'servicecatalog');
                }
                $href_res = "<a style='$size' title='" . $titleres . "' \
href='" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/resolved_ticket.php'><span class='$span'>" .
                        $total_resolved . "</span></a>";
            } else {
                //Reset criterias
                $options_resolved['reset'][] = 'reset';

                $options_resolved['criteria'][] = [
                'field'      => 12,//status
                'searchtype' => 'equals',
                'value'      => 'solved',
                'link'       => 'AND'
                ];

                $options_resolved['criteria'][] = [
                'field'      => 4,//user
                'searchtype' => 'equals',
                'value'      => Session::getLoginUserID(),
                'link'       => 'AND'
                ];

                $href_res = "<a style='$size' title='" . __('Your tickets to close', 'servicecatalog') . "' \
            href='" . $CFG_GLPI["root_doc"] . '/front/ticket.php?' .
                        Toolbox::append_params($options_resolved, '&amp;') . "' ><span class='$span'>" .
                        $total_resolved . "</span></a>";
            }
        }

        if ($iswidget == false) {
           //         echo "<li>";
            echo "<table id='indicators' class='indicators'><tr>";

            echo "<td class='ind-new'>";
            echo $href_new;
            echo "</td>";

            echo "<td class='ind-late'>";
            echo $href_due;
            echo "</td>";

            echo "<td class='ind-pending'>";
            echo $href_pend;
            echo "</td>";

            echo "<td class='ind-process'>";
            echo $href_incpro;
            echo "</td>";

            echo "<td class='dem-process'>";
            echo $href_dempro;
            echo "</td>";

            echo "</tr></table>";
           //         echo "</li>";
        } else {
           //         $graph = "<table id='indicators' class='indicators'><tr>";

            $stats = "";
            if ($iswidget == true
             && Session::haveRightsOr("ticket", [Ticket::READALL, Ticket::READGROUP])
             && Session::getCurrentInterface() == 'central') {
                $criterias     = ['technicians_groups_id'];
                $params_header = ["widgetId"  => "PluginServicecatalogIndicator3",
                              "name"      => 'PluginServicecatalogIndicator3',
                              "onsubmit"  => true,
                              "opt"       => $params,
                              "criterias" => $criterias,
                              "export"    => false,
                              "canvas"    => false,
                              "nb"        => 1];
                if (Plugin::isPluginActive("Mydashboard")) {
                    $stats .= PluginMydashboardHelper::getGraphHeader($params_header);
                }
            }

            if ($seeown == true) {
                $delclass = "";
                $class    = "bt-col-md-12";
                if (Session::haveRight("plugin_servicecatalog_view", CREATE)
                || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
                    $delclass = "delclass";
                }
                $stats .= "<div id='".$id."' class=\"bt-row $delclass\">";
                $stats .= "<div class=\"bt-feature $class \">";
                $title_widget = __("Global indicators", "servicecatalog");
                if ($id == "gs20") {
                    $title_widget = __("Global indicators (personal)", "servicecatalog");
                } else if ($id == "gs21") {
                    $title_widget = __("Global indicators (my groups)", "servicecatalog");
                }

                $stats .= PluginServicecatalogWidget::getWidgetTitle($title_widget);
            }

            $stats .= "<div id='indicators' class='tickets-sc-ind full_glpi_policy' style='text-align: center;'>";
           //         $stats .= "<div class='circle'>";

            if ($seeown == false) {
                $stats .= "<div class='nb ind-widget-new'>";
                $stats .= $href_new;
                $stats .= "<br><br>";
                $stats .= __('New tickets', 'servicecatalog');
                $stats .= "</div>";

                $stats .= "<div class='nb ind-widget-late'>";
                $stats .= $href_due;
                $stats .= "<br><br>";
                $stats .= __('Tickets late', 'servicecatalog');
                $stats .= "</div>";

                $stats .= "<div class='nb ind-widget-pending'>";
                $stats .= $href_pend;
                $stats .= "<br><br>";
                $stats .= __('Pending tickets', 'servicecatalog');
                $stats .= "</div>";

                $stats .= "<div class='nb ind-widget-process'>";
                $stats .= $href_incpro;
                $stats .= "<br><br>";
                $stats .= __('Incidents in progress', 'servicecatalog');
                $stats .= "</div>";

                $stats .= "<div class='nb dem-widget-process'>";
                $stats .= $href_dempro;
                $stats .= "<br><br>";
                $stats .= __('Requests in progress', 'servicecatalog');
                $stats .= "</div>";
            } else {
                $widget = new PluginServicecatalogWidget();
                if ($widget->fields['display_incident'] == 1) {
                    $stats .= "<div class='nb ind-widget-process'>";
                    $stats .= $href_incpro;
                    $stats .= "<br><br>";
                    $stats .= __('Incidents in progress', 'servicecatalog');
                    $stats .= "</div>";
                }

                $widget = new PluginServicecatalogWidget();
                if ($widget->fields['display_request'] == 1) {
                    $stats .= "<div class='nb dem-widget-process'>";
                    $stats .= $href_dempro;
                    $stats .= "<br><br>";
                    $stats .= __('Requests in progress', 'servicecatalog');
                    $stats .= "</div>";
                }
                if (Session::haveRightsOr('ticketvalidation', TicketValidation::getValidateRights())) {
                    $stats .= "<div class='nb ind-widget-validate'>";
                    $stats .= $href_validate;
                    $stats .= "<br><br>";
                    $stats .= __('Your tickets to validate');
                    $stats .= "</div>";
                }

                $autoclose_value = Entity::getUsedConfig(
                    'autoclose_delay',
                    $_SESSION['glpiactive_entity'],
                    '',
                    Entity::CONFIG_NEVER
                );
                if ($autoclose_value) {
                    $widget   = new PluginServicecatalogWidget();
                    $titleres = __('Your tickets to close', 'servicecatalog');
                    if (Session::haveRight('plugin_servicecatalog_requests', READ)
                    && $widget->fields['display_request'] == 1
                    && $widget->fields["display_incident"] != 1) {
                        $titleres = __('Your requests to close', 'servicecatalog');
                    }
                    if (Session::haveRight('plugin_servicecatalog_incidents', READ)
                    && $widget->fields['display_incident'] == 1
                    && $widget->fields["display_request"] != 1) {
                        $titleres = __('Your incidents to close', 'servicecatalog');
                    }

                    $stats .= "<div class='nb ind-widget-solved'>";
                    $stats .= $href_res;
                    $stats .= "<br><br>";
                    $stats .= $titleres;
                    $stats .= "</div>";
                }
            }
           //         $stats .= "</div>";
            $stats .= "</div>";
           //         $stats .= "</tr></table>";

            if ($seeown == true) {
                if ($iswidget == false) {
                    $stats .= "</div>";
                    $stats .= "</div>";
                }
            }

            return $stats;
        }
    }

   /**
    * @param $type
    *
    * @throws \GlpitestSQLError
    * @throws \GlpitestSQLError
    */
    public static function displayGroupUserTickets($type)
    {
        global $CFG_GLPI;

        if (Session::haveRight(Ticket::$rightname, Ticket::READGROUP) && count($_SESSION['glpigroups'])) {
            $left       = "LEFT JOIN glpi_entities 
                  ON (`glpi_tickets`.`entities_id` = `glpi_entities`.`id`) ";
            $is_deleted = " `glpi_tickets`.`is_deleted` = 0 ";

            $search_request = " 1 = 1 ";

            if (count($_SESSION['glpigroups'])) {
                $left           .= "LEFT JOIN `glpi_groups_tickets`
                  ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`) ";
                $groups         = implode("','", $_SESSION['glpigroups']);
                $search_request .= " AND (`glpi_groups_tickets`.`groups_id` IN ('" . $groups . "')
                                AND `glpi_groups_tickets`.`type` = '" . CommonITILActor::REQUESTER . "')";
            }
            //not resolved incidents
            $total_tickets = self::queryGroupUserTickets($type, $left, $is_deleted, $search_request);
            $warnings      = "";

            if ($total_tickets > 0) {
                $warnings = sprintf(__('Yours groups has already opened %s', 'servicecatalog'), $total_tickets);
                if (Ticket::INCIDENT_TYPE == $type) {
                    $warnings .= " " . strtolower(_n('Incident', 'Incidents', $total_tickets, 'servicecatalog'));
                } else {
                    $warnings .= " " . strtolower(_n('Request', 'Requests', $total_tickets, 'servicecatalog'));
                }
                $warnings .= " - " . __('Do you want to see them ?', 'servicecatalog');
   //            echo "<table class='tab_cadre_central' style='width: 95%;'>";
   //            echo "<tr><th colspan='2'>";
                echo "<div class='alert alert-sc alert-warning alert-dismissible fade show' role='alert'>";
                echo "<a href='#' class='close' data-bs-dismiss='alert' aria-label='close'>&times;</a>";
                echo "<div class='d-flex'>";
                echo "<div class='me-2'>";
                echo "<i class='fas fa-exclamation-triangle fa-3x'></i>";
                echo "</div>";
                $options['reset'] = 'reset';

                $options['criteria'][] = [
                'field'      => 12,//status
                'searchtype' => 'equals',
                'value'      => 'notold',
                'link'       => 'AND'
                ];

                $options['criteria'][] = [
                'field'      => 14, // type
                'searchtype' => 'equals',
                'value'      => $type,
                'link'       => 'AND',
                ];

                if (count($_SESSION['glpigroups'])) {
                    $options['criteria'][] = [
                    'field'      => 71, // groups_id_request
                    'searchtype' => 'equals',
                    'value'      => 'mygroups',
                    'link'       => 'AND',
                    ];
                }

                echo "<div><h4 class='alert-title'>";
                echo $warnings;
                echo "</h4>";
                echo "<div class='text-muted'>";
                if (Session::getCurrentInterface() != 'central') {
                    echo "<a target='_blank' href=\"" . PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.php?" .
                         Toolbox::append_params($options, '&amp;') . "\">";
                } else {
                    echo "<a target='_blank' href=\"" . $CFG_GLPI["root_doc"] . "/front/ticket.php?" .
                         Toolbox::append_params($options, '&amp;') . "\">";
                }
                echo __('Tickets list', 'servicecatalog');
                echo "</a>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
   //            echo "</th></tr>";
   //            echo "</table>";
//                echo "<br>";
            }
        }
    }

   /**
    * @param       $id
    * @param       $class
    * @param array $params
    * @param bool  $iswidget
    *
    * @return string
    * @throws \GlpitestSQLError
    */
    public static function getWidgetStats($id, $class, $params = [], $iswidget = false)
    {
        global $CFG_GLPI, $DB;

        $canedit = false;
        if (Session::haveRightsOr("ticket", [Ticket::READASSIGN, Ticket::READALL])) {
            $canedit = true;
        }

        $preference = new PluginMydashboardPreference();
        if (!$preference->getFromDB(Session::getLoginUserID())) {
            $preference->initPreferences(Session::getLoginUserID());
        }
        $preference->getFromDB(Session::getLoginUserID());
        $prefs = $preference->fields;
       //      $params = [];

        $technicians_groups_id           = PluginMydashboardHelper::getGroup($prefs['prefered_group'], $params);
        $params['technicians_groups_id'] = $technicians_groups_id;

        $user = new User();
        if (!isset($params['locations_id'])
          && Session::getCurrentInterface() == 'helpdesk'
          && $user->getFromDB(Session::getLoginUserID())) {
            $params['locations_id'] = $user->fields['locations_id'];
        }

        if (isset($_POST) && !empty($_POST) && !isset($_POST['requesters_groups_id'])) {
            $params['requesters_groups_id'] = [];
        }

        $requesters_groups_id           = PluginMydashboardHelper::getRequesterGroup($prefs['requester_prefered_group'], $params, $_SESSION['glpiactive_entity'], Session::getLoginUserID(), []);
        $params['requesters_groups_id'] = $requesters_groups_id;

        $stats = "";

        if (isset($_SESSION['glpiactiveprofile']['interface'])
          && Session::getCurrentInterface() != 'central') {
            $criterias = ['requesters_groups_id', 'locations_id'];
        }
        if ($iswidget == true
          && Session::haveRightsOr("ticket", [Ticket::READALL, Ticket::READGROUP])) {
            $criterias = ['requesters_groups_id', 'locations_id', 'technicians_groups_id'];
        }
        if ($iswidget == true) {
            $params_header = ["widgetId"  => "PluginServicecatalogIndicator1",
                           "name"      => 'PluginServicecatalogIndicator1',
                           "onsubmit"  => true,
                           "opt"       => $params,
                           "criterias" => $criterias,
                           "export"    => false,
                           "canvas"    => false,
                           "nb"        => 1];
            $stats         .= PluginMydashboardHelper::getGraphHeader($params_header);
        }
        if ($iswidget == false) {
            $delclass = "";
            if (Session::haveRight("plugin_servicecatalog_view", CREATE)
             || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
                $delclass = "delclass";
            }
            $stats .= "<div id='$id' class=\"bt-row $delclass\">";
            $stats .= "<div class=\"bt-feature $class \">";

            $title = __('Global statistics', 'servicecatalog');
            $stats .= PluginServicecatalogWidget::getWidgetTitle($title);

            $stats .= "<div class='left small-comments'>" . __('Ticket followup', 'servicecatalog');
            if (count($params['requesters_groups_id']) > 0) {
                $stats .= "&nbsp;/&nbsp;" . _n('Requester group', 'Requester groups', count($params['requesters_groups_id'])) . "&nbsp;:&nbsp;";
                foreach ($params['requesters_groups_id'] as $k => $v) {
                    $stats .= Dropdown::getDropdownName('glpi_groups', $v);
                    if (count($params['requesters_groups_id']) > 1) {
                        $stats .= "&nbsp;-&nbsp;";
                    }
                }
            }

            if (isset($params['locations_id']) && $params['locations_id'] > 0) {
                $stats .= "&nbsp;/&nbsp;" . __('Location') . "&nbsp;:&nbsp;";
                $stats .= Dropdown::getDropdownName('glpi_locations', $params['locations_id']);
            }

            $stats .= "</div>";
            $stats .= "<div id='display-sc' style='width: 95%;'>";
        }
        $stats .= "<div class='total-stats' style='text-align: center;'>";

        $stats .= "<div class='circle'>";
        if ($canedit) {
            //$href_new
            $options['reset'] = 'reset';

            $options['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => Ticket::INCOMING,
            'link'       => 'AND'
            ];

            if (isset($params['requesters_groups_id'])
             && count($params['requesters_groups_id']) > 0) {
                $groups = $params['requesters_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 71, // requester_group
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options['criteria'][] = $criterias;
            }

            $stats .= "<a style='color:#000;' target='_blank' title='" . __('New tickets', 'servicecatalog') . "' 
                  href=\"" . $CFG_GLPI["root_doc"] . "/front/ticket.php?" .
                   Toolbox::append_params($options, '&amp;') . "\">";
        }
        $stats .= "<div id='circles-1'></div>";
        $stats .= "<div class='source-semibold text-center chart-title'>" . __('New tickets', 'servicecatalog') . "</div>";
        if ($canedit) {
            $stats .= "</a>";
        }
        $stats .= "</div>";

        $stats .= "<div class='circle'>";
        //href_incpro
        if ($canedit) {
            unset($options);
            $options['reset'] = 'reset';

            $options['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => 'process',
            'link'       => 'AND'
            ];

            $options['criteria'][] = [
            'field'      => 14, // type
            'searchtype' => 'equals',
            'value'      => Ticket::INCIDENT_TYPE,
            'link'       => 'AND',
            ];

            if (isset($params['technicians_groups_id'])
             && count($params['technicians_groups_id']) > 0) {
                $groups = $params['technicians_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 8, // groups_id_assign
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options['criteria'][] = $criterias;
            }

            if (isset($params['requesters_groups_id'])
             && count($params['requesters_groups_id']) > 0) {
                $groups = $params['requesters_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 71, // requester_group
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options['criteria'][] = $criterias;
            }

            $stats .= "<a style='color:#000;' target='_blank' title='" . __('Incidents in progress', 'servicecatalog') . "' 
                  href=\"" . $CFG_GLPI["root_doc"] . "/front/ticket.php?" .
                   Toolbox::append_params($options, '&amp;') . "\">";
        }
        $stats .= "<div id='circles-2'></div>";
        $stats .= "<div class='source-semibold text-center chart-title'>" . __('Incidents in progress', 'servicecatalog') . "</div>";
        if ($canedit) {
            $stats .= "</a>";
        }
        $stats .= "</div>";

        $stats .= "<div class='circle'>";
        //href_incpro
        if ($canedit) {
            unset($options);
            $options['reset'] = 'reset';

            $options['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => 'process',
            'link'       => 'AND'
            ];

            $options['criteria'][] = [
            'field'      => 14, // type
            'searchtype' => 'equals',
            'value'      => Ticket::DEMAND_TYPE,
            'link'       => 'AND',
            ];

            if (isset($params['technicians_groups_id'])
             && count($params['technicians_groups_id']) > 0) {
                $groups = $params['technicians_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 8, // groups_id_assign
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options['criteria'][] = $criterias;
            }

            if (isset($params['requesters_groups_id'])
             && count($params['requesters_groups_id']) > 0) {
                $groups = $params['requesters_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 71, // requester_group
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options['criteria'][] = $criterias;
            }

            $stats .= "<a style='color:#000;' target='_blank' title='" . __('Requests in progress', 'servicecatalog') . "' 
                  href=\"" . $CFG_GLPI["root_doc"] . "/front/ticket.php?" .
                   Toolbox::append_params($options, '&amp;') . "\">";
        }
        $stats .= "<div id='circles-3'></div>";
        $stats .= "<div class='source-semibold text-center chart-title'>" . __('Requests in progress', 'servicecatalog') . "</div>";
        if ($canedit) {
            $stats .= "</a>";
        }
        $stats .= "</div>";
        $stats .= "<div class='circle'>";

        //$href_pend
        if ($canedit) {
            unset($options);

            $options['reset'] = 'reset';

            $options['criteria'][] = [
            'field'      => 12,//status
            'searchtype' => 'equals',
            'value'      => Ticket::WAITING,
            'link'       => 'AND'
            ];

            if (isset($params['technicians_groups_id'])
             && count($params['technicians_groups_id']) > 0) {
                $groups = $params['technicians_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 8, // groups_id_assign
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options['criteria'][] = $criterias;
            }

            if (isset($params['requesters_groups_id'])
             && count($params['requesters_groups_id']) > 0) {
                $groups = $params['requesters_groups_id'];
                $nb     = 0;
                foreach ($groups as $group) {
                    $criterias['criteria'][$nb] = [
                    'field'      => 71, // requester_group
                    'searchtype' => 'equals',
                    'value'      => $group,
                    'link'       => (($nb == 0) ? 'AND' : 'OR'),
                    ];
                    $nb++;
                }
                $options['criteria'][] = $criterias;
            }

            $stats .= "<a style='color:#000;' target='_blank' title='" . __('Pending tickets', 'servicecatalog') . "' 
                  href=\"" . $CFG_GLPI["root_doc"] . "/front/ticket.php?" .
                   Toolbox::append_params($options, '&amp;') . "\">";
        }

        $stats .= "<div id='circles-4'></div>";
        $stats .= "<div class='source-semibold text-center chart-title'>" . __('Pending tickets', 'servicecatalog') . "</div>";
        if ($canedit) {
            $stats .= "</a>";
        }
        $stats .= "</div>";
        $stats .= "<br>";
        $stats .= "<br>";

        /*SQl Queries for stats display*/

        $left = "LEFT JOIN glpi_entities
                        ON (`glpi_tickets`.`entities_id` = `glpi_entities`.`id`) ";

        $search_assign = "1=1";
        if ($canedit && isset($params['technicians_groups_id']) && count($params['technicians_groups_id']) > 0) {
           //            $left          .= "LEFT JOIN `glpi_tickets_users`
           //                  ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`) ";
           //            $search_assign .= " AND (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
           //                                  AND `glpi_tickets_users`.`type` = '" . CommonITILActor::ASSIGN . "')";

            $left          .= "LEFT JOIN `glpi_groups_tickets`
                     ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`) ";
            $search_assign .= " AND (`glpi_groups_tickets`.`groups_id` IN (" . implode(",", $technicians_groups_id) . ")
                                 AND `glpi_groups_tickets`.`type` = '" . CommonITILActor::ASSIGN . "') ";
        }

        $criteria = " `glpi_tickets`.`is_deleted` = 0 ";

        if (isset($params['locations_id']) && $params['locations_id'] > 0) {
            $criteria .= " AND `glpi_tickets`.`locations_id` = '" . $params['locations_id'] . "' ";
        }
        if (isset($params['requesters_groups_id']) && count($params['requesters_groups_id']) > 0) {
            $criteria .= " AND `glpi_tickets`.`id` IN (SELECT `tickets_id` AS id FROM `glpi_groups_tickets`
            WHERE `type` = " . CommonITILActor::REQUESTER . " 
            AND `groups_id` IN (" . implode(",", $params['requesters_groups_id']) . "))";
        }

        //total tickets
        $total_tickets = self::queryAllTickets($left, $criteria);
        //New tickets
        $total_new = self::queryNewTickets($left, $criteria, $search_assign);
        //Late tickets
        $total_due = self::queryDueTickets($left, $criteria, $search_assign);
        //Waiting tickets
        $total_pend = self::queryPendingTickets($left, $criteria, $search_assign);
        //Processing incidents
        $total_incpro = self::queryIncidentTickets($left, $criteria, $search_assign);
        //Processing requests
        $total_dempro = self::queryRequestTickets($left, $criteria, $search_assign);
        /*END SQl Queries for stats display*/

        $stats .= "<div align='center' class='total-progress'>";
        $stats .= "<div class='media' style='margin: 0 auto;width: 250px;'>";

        $stats .= "<div class='media-left bt-col-xs-3'>";
        $stats .= _n('Ticket', 'Tickets', 2);
        $stats .= "</div>";

        $stats .= "<div class='media-body bt-col-xs-2'>";
        $stats .= "<div class='bt-progress ticket-progressbar '>";
        $stats .= "<div class='bt-progress-bar'></div>";
        $stats .= "</div>";
        $stats .= "</div>";

        $stats          .= "<div class='media-right bt-col-xs-4'>";
        $stats          .= $total_tickets;
        $nbStockTickets = 0;
        if (Plugin::isPluginActive("mydashboard")) {
            $entities = " `entities_id` = " . $_SESSION['glpiactive_entity'] . " ";
            $query    = "SELECT SUM(nbStockTickets) AS nbStockTickets 
                        FROM `glpi_plugin_mydashboard_stocktickets` 
                        WHERE " . $entities . " 
                        AND YEAR(date) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH)
                        AND MONTH(date) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH)";
            $result   = $DB->query($query);
            while ($data = $DB->fetchArray($result)) {
                $nbStockTickets = $data["nbStockTickets"];
            }
        }
        if ($nbStockTickets > 0
          && $nbStockTickets > $total_tickets) {
            $stats .= "<i class=\"fas fa-arrow-down sc-fa-arrow\"></i>";
        } else {
            $stats .= "<i class=\"fas fa-arrow-up sc-fa-arrow\"></i>";
        }

        $stats .= "</div>";

        $stats .= "</div>";
        $stats .= "</div>";

        if ($iswidget == false) {
            $stats .= "</div>";
            $stats .= "</div>";
            $stats .= "</div>";
        }
        $stats .= "<script type='text/javascript'>
//        setTimeout(function () { 
        /*Stats Circle*/
        var colors = [
                     ['#dfe3e7', '#1f77b4'], 
                     ['#dfe3e7', '#aec7e8'],
                     ['#dfe3e7', '#aec7e8'], 
                     ['#dfe3e7', '#aec7e8']
                  ], circles = [];
      
                  for (var i = 1; i <= 4; i++) {
                     var child = document.getElementById('circles-' + i);
                     total_tickets = $total_tickets;
                     total_new = $total_new;
                     total_incpro = $total_incpro;
                     total_due = $total_due;
                     total_dempro = $total_dempro;
                     total_pend = $total_pend;
                     warn = Math.round((total_tickets / 2));
                     red = Math.round(((total_tickets / 4)*3));
      
                     if (i == 1){
                         mycolor = colors[i - 1];
                         if (total_new > red){
                             mycolor = ['#dfe3e7', '#d62728'];
                         }
                         if (total_new > warn & total_new < red){
                             mycolor = ['#dfe3e7', '#ff7f0e'];
                         }
                     circles.push(Circles.create({
                        id:         child.id,
                        value:   total_new,
                        maxValue:     total_tickets,
                        radius:     50,
                        width:      15,
                        colors:     mycolor,
                        textClass:           'circles-text',
                        styleText:           true
                     }))
                     }
                     if (i == 2){
                         mycolor = colors[i - 1];
                         if (total_incpro > red){
                             mycolor = ['#dfe3e7', '#d62728'];
                         }
                         if (total_incpro > warn & total_incpro < red){
                             mycolor = ['#dfe3e7', '#ff7f0e'];
                         }
                         circles.push(Circles.create({
                        id:         child.id,
                        value:   total_incpro,
                        maxValue:     total_tickets,
                        radius:     50,
                        width:      15,
                        colors:     mycolor,
                        textClass:           'circles-text',
                        styleText:           true
                     }))
                     }
                     if (i == 3){
                         mycolor = colors[i - 1];
                         if (total_dempro > red){
                             mycolor = ['#dfe3e7', '#d62728'];
                         }
                         if (total_dempro > warn & total_dempro < red){
                             mycolor = ['#dfe3e7', '#ff7f0e'];
                         }
                         circles.push(Circles.create({
                        id:         child.id,
                        value:   total_dempro,
                        maxValue:     total_tickets,
                        radius:     50,
                        width:      15,
                        colors:     mycolor,
                        textClass:           'circles-text',
                        styleText:           true
                     }))
                     }
                    if (i == 4){
                         mycolor = ['#dfe3e7', '#ff7f0e'];
                         circles.push(Circles.create({
                        id:         child.id,
                        value:   total_pend,
                        maxValue:     total_tickets,
                        radius:     50,
                        width:      15,
                        colors:     mycolor,
                        textClass:           'circles-text',
                        styleText:           true
                     }))
                     }
                     ;
                  }
                  
        
         function progress() {
               var el = $('.ticket-progressbar');
               var progressBarWidth = 100 * el.width() / 100;
               el.find('.bt-progress-bar').animate({width: progressBarWidth}, 500);
           }
           progress();
           // progress(100, $('.user-progressbar'));
//           }, 1000);
       </script>";

        return $stats;
    }


   /**
    * @param       $class
    * @param array $params
    * @param bool  $iswidget
    *
    * @return string
    * @throws \GlpitestSQLError
    */
    public static function getTicketsByStatusPieChart($id, $class, $params = [], $iswidget = false)
    {
        global $DB;

        if ($iswidget == true) {
            $preference = new PluginMydashboardPreference();
            if (!$preference->getFromDB(Session::getLoginUserID())) {
                $preference->initPreferences(Session::getLoginUserID());
            }
            $preference->getFromDB(Session::getLoginUserID());
            $preferences = $preference->fields;
            if (isset($preferences['prefered_group'])) {
                $technicians_groups_id = json_decode($preferences['prefered_group'], true);
                if (count($technicians_groups_id) > 0
                && count($params) < 1) {
                    $params['technicians_groups_id'] = $technicians_groups_id;
                }
            }
            if (isset($params['technicians_groups_id'])) {
                $params['technicians_groups_id'] = (is_array($params['technicians_groups_id']) ? $params['technicians_groups_id'] : [$params['technicians_groups_id']]);
            }
        }
        $name            = 'TicketsByStatusPieChart';
        $datas           = [];
        $states          = [];
        $name_status     = [];
        $search_users_id = " 1 = 1 ";
        $search_assign   = " ";
        if ($iswidget == false) {
            $search_users_id = " (`glpi_tickets_users`.`users_id` = '" . Session::getLoginUserID() . "'
                            OR `glpi_tickets`.users_id_recipient = '" . Session::getLoginUserID() . "')  ";
        }
        $query = "SELECT DISTINCT
                           `glpi_tickets`.`status`,
                           COUNT(`glpi_tickets`.`id`) AS nb
                        FROM `glpi_tickets` ";
        if ($iswidget == false) {
            $query .= "LEFT JOIN `glpi_tickets_users`
                               ON (`glpi_tickets`.`id` = `glpi_tickets_users`.`tickets_id`  AND `glpi_tickets_users`.`type` = '" . CommonITILActor::REQUESTER . "') ";
        }
        if (isset($params['technicians_groups_id']) && $params['technicians_groups_id'] > 0) {
            $query         .= "LEFT JOIN `glpi_groups_tickets`
                  ON (`glpi_tickets`.`id` = `glpi_groups_tickets`.`tickets_id`  AND `glpi_groups_tickets`.`type` = '" . CommonITILActor::ASSIGN . "') ";
            $search_assign = " AND (`glpi_groups_tickets`.`groups_id` IN (" . implode(",", $technicians_groups_id) . ")) ";
        }
        $query .= "WHERE $search_users_id  $search_assign AND `glpi_tickets`.`is_deleted` = '0' ";
        if ($iswidget == false) {
            $query .= "AND `glpi_tickets`.`status` NOT IN ('" . Ticket::CLOSED . "') ";
        } else {
            $query .= "AND `glpi_tickets`.`status` NOT IN ('" . Ticket::SOLVED . "', '" . Ticket::CLOSED . "') ";
        }
        $dbu   = new DbUtils();
        $query .= $dbu->getEntitiesRestrictRequest("AND", Ticket::getTable())
                . " GROUP BY `status` ORDER BY `status` ASC";

        $result = $DB->query($query);
        $nb     = $DB->numrows($result);
        if ($nb) {
            while ($data = $DB->fetchArray($result)) {
                $name_status[] = Ticket::getStatus($data['status']);
//                $datas[]       = $data['nb'];
                $states[]      = $data['status'];

                $datas[] = ['value' => $data['nb'],
                            'name' => Ticket::getStatus($data['status'])];
            }
        }
        $title = __("Opened tickets by status", "servicecatalog");
        $comment = "";
        if ($iswidget == false) {
            $colors = ["#a2cc51", "#729ed7", "#C41825", "#FFA830", "#24A830"];
        } else {
            $colors = ["#a2cc51", "#729ed7", "#FFA830", "#C41825"];
        }
        $dataPieset         = json_encode($datas);
        $stateset           = json_encode($states);
        $backgroundPieColor = json_encode($colors);
        $labelsPie          = json_encode($name_status);

        $graph_datas = ['title'           => $title,
                        'comment'         => $comment,
                        'name'            => $name,
                      'ids'             => $stateset,
                      'data'            => $dataPieset,
                      'labels'          => $labelsPie,
                      'label'           => $title,
                      'backgroundColor' => $backgroundPieColor];


        $graph = PluginMydashboardPieChart::launchPieGraph($graph_datas, []);

        if ($iswidget == false) {
            $delclass = "";
            if (Session::haveRight("plugin_servicecatalog_view", CREATE)
             || Session::haveRight("plugin_servicecatalog_defaultview", CREATE)) {
                $delclass = "delclass";
            }
            $graph .= "<div id='".$id."' class=\"bt-row $delclass\">";
            $graph .= "<div class=\"bt-feature $class \">";

            $graph .= PluginServicecatalogWidget::getWidgetTitle($title);

           //      $stats .= "<small>" . __('Ticket followup') . "</small>";
        }
        $graph .= "<div id='display-sc' style='width: 95%;'>";
        if ($iswidget == true
          && Session::haveRightsOr("ticket", [Ticket::READALL, Ticket::READGROUP])) {
            $criterias     = ['technicians_groups_id'];
            $params_header = ["widgetId"  => "PluginServicecatalogIndicator2",
                           "name"      => $name,
                           "onsubmit"  => true,
                           "opt"       => $params,
                           "criterias" => $criterias,
                           "export"    => true,
                           "canvas"    => false,
                           "nb"        => 1];
            $graph         .= PluginMydashboardHelper::getGraphHeader($params_header);
        }

        $graph .= "<div id=\"chart-container\" class=\"chart-container\">"; // style="position: relative; height:45vh; width:45vw"
        $graph .= "<div id=\"$name\" style='width: 100%; height: 400px;'></div>";
        $graph .= "</div>";
        $graph .= "</div>";

        if ($iswidget == false) {
            $graph .= "</div>";
            $graph .= "</div>";
        }
        return $graph;
    }

   /**
    * @return array
    */
    public function getWidgetsForItem()
    {
        $widgets = [
            PluginMydashboardMenu::$HELPDESK => [

                $this->getType() . "1" => ["title"   => __('Global statistics', "servicecatalog"),
                                           "type"    => PluginMydashboardWidget::$KPI,
                                           "comment" => __("Global statistics of tickets activity", "servicecatalog")],
                $this->getType() . "3" => ["title"   => __("Global indicators", "servicecatalog"),
                                           "type"    => PluginMydashboardWidget::$KPI,
                                           "comment" => ""],
                $this->getType() . "2" => ["title"   => __("Opened tickets by status", "servicecatalog"),
                                           "type"    => PluginMydashboardWidget::$PIE,
                                           "comment" => ""],
            ],
        ];

        return $widgets;
    }

   /**
    * @param       $widgetId
    *
    * @param array $opt
    *
    * @return PluginMydashboardDatatable
    * @throws \GlpitestSQLError
    */
    public function getWidgetContentForItem($widgetId, $opt = [])
    {
        switch ($widgetId) {
            case $this->getType() . "1":
                $class  = "bt-col-md-12";
                $widget = new PluginMydashboardHtml();
                $widget->setWidgetTitle(__('Global statistics', "servicecatalog"));
                $widget->setWidgetComment(__("Global statistics of tickets activity", "servicecatalog"));
                $graph = self::getWidgetStats($widgetId, $class, $opt, true);
                $widget->setWidgetHtmlContent(
                    $graph
                );
                $widget->toggleWidgetRefresh();
                return $widget;
                break;

            case $this->getType() . "2":
                $class  = "bt-col-md-12";
                $plugin = new Plugin();
                if (Plugin::isPluginActive('mydashboard')
                    && ($plugin->getInfo('mydashboard')["version"] >= "2.0.5")) {
                    $widget = new PluginMydashboardHtml();
                    $widget->setWidgetTitle(__("Opened tickets by status", "servicecatalog"));
                    $graph = self::getTicketsByStatusPieChart($widgetId, $class, $opt, true);
                    $widget->setWidgetHtmlContent(
                        $graph
                    );
                    $widget->toggleWidgetRefresh();
                    return $widget;
                } else {
                    return __('Please install version >= 2.0.5 of Mydashboard', 'servicecatalog');
                }
                break;

//            case $this->getType() . "3":
//                $widget = new PluginMydashboardHtml();
//                $widget->setWidgetTitle(__("Global indicators", "servicecatalog"));
//                $graph = self::displayIndicator($widgetId, $opt, true);
//                $widget->setWidgetHtmlContent(
//                    $graph
//                );
//                $widget->toggleWidgetRefresh();
//                return $widget;
//                break;
        }
    }
}
