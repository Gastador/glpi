<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogUsercard
 */
class PluginServicecatalogUsercard extends CommonDBTM
{
    public static $rightname = 'plugin_servicecatalog';
    public static $types     = ['Computer', 'Monitor', 'Peripheral', 'Phone', 'Printer',
                         'SoftwareLicense', 'Item_DeviceSimcard', 'PluginBadgesBadge'];


    public static function getTable($classname = null)
    {
        return "glpi_plugin_servicecatalog_dashboards";
    }

    /**
     * @param string $interface
     *
     * @return array
     */
    public function getRights($interface = 'central')
    {
        $values = parent::getRights();

        unset($values[CREATE], $values[UPDATE], $values[DELETE], $values[PURGE]);
        return $values;
    }

    public static function getIconForType($type)
    {
        switch ($type) {
            case 'Computer':
                return 'fas fa-laptop';
                break;
            case 'Monitor':
                return 'fas fa-desktop';
                break;
            case 'Peripheral':
                return 'fab fa-usb';
                break;
            case 'Phone':
                return 'fas fa-mobile-alt';
                break;
            case 'Printer':
                return 'fas fa-print';
                break;
            case 'Certificate':
                return 'fas fa-certificate';
                break;
            case 'Appliance':
                $applink = new PluginServicecatalogApplianceLink();
                $icon    = $applink::getIcon();
                $config  = new PluginServicecatalogConfig();
                if (!empty($config->fields['fa_myappliances_menu'])) {
                    $icon = $config->fields['fa_myappliances_menu'];
                }
                return 'fas ' . $icon;
                break;
            case 'Software':
                return 'fas fa-cube';
                break;
            case 'NetworkEquipment':
                return 'fas fa-network-wired';
                break;
            case 'SoftwareLicense':
                return 'fas fa-key';
                break;
            case 'Item_DeviceSimcard':
                return 'fas fa-sim-card';
                break;
            case 'PluginBadgesBadge':
                return 'fas fa-id-badge';
                break;
            case 'PluginAccountsAccount':
                return 'fas fa-lock';
                break;
            case 'PluginResourcesResource':
                return 'fas fa-users';
                break;
            case 'PluginCmdbOperationprocess':
                return 'fas fa-sitemap';
                break;
            default:
                return 'far fa-question-circle';
                break;
        }
    }

    /**
     * @param $ID
     *
     * @throws \GlpitestSQLError
     */
    public static function showItems($ID, $toppage = false)
    {
        global $DB, $CFG_GLPI;

        $config = new PluginServicecatalogConfig();

        $widget = new PluginServicecatalogWidget();

        $display = PluginServicecatalogConfig::loadForLayout(false);
        $display .= "<div class='bt-row sc-content'>";
        $display .= "<div class='bt-feature bt-col-md-12'>";
        $title   = PluginServicecatalogConfig::displayField($config, 'title_myelements_menu');
        if ($toppage == 1) {
            $display .= PluginServicecatalogWidget::getPageTitle($title);
        } else {
            $display .= PluginServicecatalogWidget::getWidgetTitle($title);
        }

        $type_user = $CFG_GLPI['linkuser_types'];

        $inv   = false;
        $datas = [];
        $dbu   = new DbUtils();

        foreach ($type_user as $itemtype) {
            if (!($item = $dbu->getItemForItemtype($itemtype))
                || !in_array($itemtype, $type_user)
                || $itemtype == "PluginResourcesResource"
                || $itemtype == "PluginAccountsAccount"
                || $itemtype == "PluginOrderOrder"
                || $itemtype == "PluginConnectionsConnection"
                || $itemtype == "PluginTasklistsTask"
                || $itemtype == "PluginIdeaboxIdeabox"
                //         ||  strpos($itemtype, "PluginGenericobject") === false
            ) {
                continue;
            }
            $i         = 0;
            $itemtable = $dbu->getTableForItemType($itemtype);
            $query     = "SELECT *
                      FROM `$itemtable`
                      WHERE `users_id` = '$ID'";

            if ($item->maybeTemplate()) {
                $query .= " AND `is_template` = 0 ";
            }
            if ($item->maybeDeleted()) {
                $query .= " AND `is_deleted` = 0 ";
            }

            $states = isset($widget->fields['item_states']) ? json_decode($widget->fields['item_states']): [];
            if (count($states) > 0 && in_array($itemtype, $CFG_GLPI["state_types"])) {
                $states_sql     = implode("','", $states);
                $query .= " AND `states_id` NOT IN ('" . $states_sql . "') ";
            }

            $query  .= $dbu->getEntitiesRestrictRequest('AND', $itemtable, '', $_SESSION['glpiactiveentities'], $item->maybeRecursive());
            $result = $DB->query($query);

            if ($DB->numrows($result) > 0) {
                $inv = true;
                while ($data = $DB->fetchAssoc($result)) {
                    $datas[$itemtype][$i] = $data;

                    $i++;
                }
            }
        }
        $numOfCols         = 2;
        $rowCount          = 0;
        $bootstrapColWidth = (12 / $numOfCols) - 1;

        if ($inv == true) {
            $style = "";
            if ($toppage == false) {
                $style = "style='margin-left: 20px;'";
            }
            $display .= "<div class='row'>";//margin for widget view
            foreach ($datas as $type => $table) {
                $obj       = new $type();
                $count     = count($table);
                $type_name = $obj->getTypeName($count);

                $display .= "<div $style class='h-50 col-md-$bootstrapColWidth itemsdisplay'>";

                $display .= PluginServicecatalogWidget::getWidgetTitle($type_name);

                $display .= "<ul class='list-unstyled'>";
                foreach ($table as $k => $values) {
                    $i      = 1;
                    $cansee = $obj->can($values["id"], READ);
                    $link   = isset($values["name"]) ? $values["name"] : "";
                    if ($type == "Item_DeviceSimcard") {
                        $link = $type_name;
                    }

                    //            if ($cansee && Session::getCurrentInterface() == 'central') {
                    //               $link_item = Toolbox::getItemTypeFormURL($type);
                    //               if ($_SESSION["glpiis_ids_visible"] || empty($link)) {
                    //                  $link = sprintf(__('%1$s (%2$s)'), $link, $values["id"]);
                    //               }
                    //               $link = "<a href='" . $link_item . "?id=" . $values["id"] . "'>" . $link . "</a>";
                    //            }

                    $display .= "<li class='media my-3' style='min-height: 130px;'>";

                    $className = strtolower(get_class($obj));
                    $model     = $className . "models";

                    $icon = self::getIconForType($type);
                    $ok = 0;
                    if (isset($values[$model . "_id"]) && !empty($values[$model . "_id"])) {
                        if ($itemModel = getItemForItemtype($type . 'Model')) {
                            $itemModel->getFromDB($values[$model . "_id"]);
                            $pictures = [];
                            if ($itemModel->fields['pictures'] != null) {
                                $pictures = json_decode($itemModel->fields['pictures'], true);

                                if (isset($pictures) && is_array($pictures)) {
                                    foreach ($pictures as $picture) {
                                        $picture_url = Toolbox::getPictureUrl($picture);
                                        $icon = "<img class='user_picture' style='width: 20%;height: 20%;' 
                                        alt=\"" . _sn('Picture', 'Pictures', 1) . "\" src='" .
                                            $picture_url . "'>";
                                        $ok = 1;
                                    }
                                }
                            }
                        }
                    }
                    if ($ok == 1) {
                        $display .= "$icon&nbsp;";
                    } else {
                        $display .= "<i class='$icon fa-3x mr-3'></i>&nbsp;";
                    }


                    $display .= "<div class='media-body left'>";

                    $display .= "<h6 class='mt-0 mb-1 full_glpi_policy'>";
                    $display .= $link;
                    $display .= "</h6>";


                    //            if (Session::isMultiEntitiesMode()) {
                    //               $display .= Dropdown::getDropdownName("glpi_entities", $values["entities_id"]) . "</br>";
                    //            }

                    if (isset($values[$model . "_id"]) && !empty($values[$model . "_id"])) {
                        $display .= Dropdown::getDropdownName("glpi_$model", $values[$model . "_id"]) . "</br>";
                    }
                    $typeItem = $className . "types";
                    if (isset($values[$typeItem . "_id"]) && !empty($values[$typeItem . "_id"])) {
                        $display .= Dropdown::getDropdownName("glpi_$typeItem", $values[$typeItem . "_id"]) . "</br>";
                    }
                    if (isset($values["locations_id"]) && !empty($values["locations_id"])) {
                        $display .= Dropdown::getDropdownName("glpi_locations", $values["locations_id"]) . "</br>";
                    }
                    if (isset($values["groups_id"]) && !empty($values["groups_id"])) {
                        $display .= Dropdown::getDropdownName("glpi_groups", $values["groups_id"]) . "</br>";
                    }
                    if (isset($values["serial"]) && !empty($values["serial"])) {
                        $display .= __('Serial number') . " " . $values["serial"];
                        $display .= "</br>";
                    }
                    if (isset($values["otherserial"]) && !empty($values["otherserial"])) {
                        $display .= __('Inventory number') . " " . $values["otherserial"];
                        $display .= "</br>";
                    }
                    if (isset($values["states_id"]) && !empty($values["states_id"])) {
                        $display .= Dropdown::getDropdownName("glpi_states", $values["states_id"]);
                        $display .= "</br>";
                    }
                    if (isset($values["date_expiration"]) && !empty($values["date_expiration"])) {
                        if (
                            $values["date_expiration"] <= date('Y-m-d')
                            && !empty($values["date_expiration"])
                        ) {
                            $display .= "<td class='center'>";
                            $display .= "<div class='deleted'>" . Html::convDate($values["date_expiration"]) . "</div>";
                            $display .= "</td>";
                        } elseif (empty($values["date_expiration"])) {
                            $display .= "<td class='center'>" . __('Does not expire') . "</td>";
                        } else {
                            $display .= "<td class='center'>" . Html::convDate($values["date_expiration"]) . "</td>";
                        }
                        $display .= "</br>";
                    }



                    $display .= "</div>";

                    // Load ticket template if available :
                    if ($config->showAssetButtonUpdate() > 0) {
                        $display .= "<div class='right'>";

                        $form    = PLUGIN_SERVICECATALOG_WEBDIR . "/front/usercard.php?dropitem=1";
                        $display .= Html::getSimpleForm(
                            $form,
                            'dropitem',
                            "",
                            ["itemtype" => $type,
                             "items_id" => $values["id"]],
                            "fa-times-circle fa-2x",
                            "class='submit btn btn-default'",
                            __('Are you sure you want to declare this material as not belonging to you ?', 'servicecatalog')
                        );
                        $display .= "</div>";
                    }
                    $display .= "</li>";
                }
                $display .= "</ul>";

                $display .= "</div>";
                $rowCount++;
                if ($rowCount % $numOfCols == 0) {
                    $display .= '</div><div class="row">';
                }
            }

            $display .= "</div>";
        }
        if ($inv == false) {
            $display .= "<div class='center alert alert-info show' role='alert'>";
            $display .= "<b>" . __('No item found') . "</b></div>";
        }

        $display .= "</div>";
        $display .= "</div>";

        return $display;
    }


    /**
     * @param $input
     */
    public static function createTicket($input)
    {
        $ticket = new Ticket();

        $name    = __('This equipment is not to me', 'servicecatalog');
        $dbu     = new DbUtils();
        $display = "";

        $config = new PluginServicecatalogConfig();
        // Load ticket template if available :
        if ($config->getTicketTemplateAssociatedToUserAssetsUpdate() > 0) {
            $ticket_template = $config->getTicketTemplateAssociatedToUserAssetsUpdate();
            $tt              = $ticket->getITILTemplateToUse(
                $ticket_template,
                "",
                "",
                $_SESSION["glpiactive_entity"]
            );
        }

        if (isset($tt->predefined) && count($tt->predefined)) {
            foreach ($tt->predefined as $predeffield => $predefvalue) {
                // Load template data
                $ticket_inputs[$predeffield] = Toolbox::addslashes_deep($predefvalue);
            }
        }

        $ticket_inputs["entities_id"] = $_SESSION['glpiactive_entity'];

        if ($item = $dbu->getItemForItemtype($input['itemtype'])) {
            if ($item->getFromDB($input['items_id'])) {
                if (!empty($ticket_inputs["content"])) {
                    $input['content'] = Glpi\RichText\RichText::getSafeHtml($ticket_inputs["content"]);
                } else {
                    $input['content'] = $name;
                }

                $input['content'] .= "<br><table style='width: 100%;'>"; // class='mticket'
                $input['content'] .= "<tr><td style='background-color: #ccc;'>" . __('Itemtype') . "</td><td>" . $item->getTypeName(1) . "</td></tr>";
                $input['content'] .= "<tr><td style='background-color: #ccc;'>" . __('Item') . "</td><td>" . $item->getName() . "</td></tr>";

                $input['content'] .= "<tr><td style='background-color: #ccc;'>" . __('Details', 'servicecatalog') . "</td><td>";

                if (isset($item->fields["locations_id"])
                    && !empty($item->fields["locations_id"])) {
                    $input['content'] .= Dropdown::getDropdownName("glpi_locations", $item->fields["locations_id"]) . "<br>";
                }
                if (isset($item->fields["groups_id"])
                    && !empty($values["groups_id"])) {
                    $input['content'] .= Dropdown::getDropdownName("glpi_groups", $item->fields["groups_id"]) . "<br>";
                }
                if (isset($item->fields["serial"])
                    && !empty($item->fields["serial"])) {
                    $input['content'] .= __('Serial number') . " " . $item->fields["serial"];
                    $input['content'] .= "<br>";
                }
                if (isset($item->fields["otherserial"])
                    && !empty($item->fields["otherserial"])) {
                    $input['content'] .= __('Inventory number') . " " . $item->fields["otherserial"];
                }

                $input['content'] .= "</td></tr>";
                $input['content'] .= "</table>";

                $ticket_inputs["entities_id"]  = $item->fields["entities_id"];
                $ticket_inputs["locations_id"] = $item->fields["locations_id"];
            }
        }

        $ticket_inputs["_users_id_requester"] = Session::getLoginUserID();
        $ticket_inputs['items_id']            = [$input['itemtype'] => [$input['items_id']]];
        if (empty($ticket_inputs["name"])) {
            $ticket_inputs["name"] = addslashes($name);
        }
        $ticket_inputs["content"] = Glpi\Toolbox\Sanitizer::sanitize($input['content']);

        $ticket->add($ticket_inputs);
    }

    public static function detectBrowser($input)
    {
        $u_agent  = $_SERVER['HTTP_USER_AGENT'];
        $bname    = __('Unknown', 'servicecatalog');
        $ub       = __('Unknown', 'servicecatalog');
        $version  = "";
        $platform = __('Unknown', 'servicecatalog');

        $deviceType = __('Desktop', 'servicecatalog');

        if (preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $u_agent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($u_agent, 0, 4))) {
            $deviceType = __('Mobile', 'servicecatalog');
        }

        if ($_SERVER['HTTP_USER_AGENT'] == 'Mozilla/5.0(iPad; U; CPU iPhone OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B314 Safari/531.21.10') {
            $deviceType = __('Tablet', 'servicecatalog');
        }

        if (stristr($_SERVER['HTTP_USER_AGENT'], 'Mozilla/5.0(iPad;')) {
            $deviceType = __('Tablet', 'servicecatalog');
        }

        //First get the platform?
        //      if (preg_match('/linux/i', $u_agent)) {
        //         $platform = 'Linux';
        //
        //      } elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        //         $platform = 'Mac';
        //
        //      } elseif (preg_match('/windows|win32/i', $u_agent)) {
        //         $platform = 'Windows';
        //      }

        $os_array = [
            '/windows nt 11/i'      => 'Windows 11',
            '/windows nt 10/i'      => 'Windows 10',
            '/windows nt 6.3/i'     => 'Windows 8.1',
            '/windows nt 6.2/i'     => 'Windows 8',
            '/windows nt 6.1/i'     => 'Windows 7',
            '/windows nt 6.0/i'     => 'Windows Vista',
            '/windows nt 5.2/i'     => 'Windows Server 2003/XP x64',
            '/windows nt 5.1/i'     => 'Windows XP',
            '/windows xp/i'         => 'Windows XP',
            '/windows nt 5.0/i'     => 'Windows 2000',
            '/windows me/i'         => 'Windows ME',
            '/win98/i'              => 'Windows 98',
            '/win95/i'              => 'Windows 95',
            '/win16/i'              => 'Windows 3.11',
            '/macintosh|mac os x/i' => 'Mac OS X',
            '/mac_powerpc/i'        => 'Mac OS 9',
            '/linux/i'              => 'Linux',
            '/ubuntu/i'             => 'Ubuntu',
            '/iphone/i'             => 'iPhone',
            '/ipod/i'               => 'iPod',
            '/ipad/i'               => 'iPad',
            '/android/i'            => 'Android',
            '/blackberry/i'         => 'BlackBerry',
            '/webos/i'              => 'Mobile'
        ];
        foreach ($os_array as $regex => $value) {
            if (preg_match($regex, $u_agent)) {
                $platform = $value;
            }
        }


        // Next get the name of the user agent yes seperately and for good reason
        if (preg_match('/MSIE/i', $u_agent) && !preg_match('/Opera/i', $u_agent)) {
            $bname = 'IE';
            $ub    = "MSIE";
        } elseif (preg_match('/Firefox/i', $u_agent)) {
            $bname = 'Mozilla Firefox';
            $ub    = "Firefox";
        } elseif (preg_match('/Chrome/i', $u_agent) && (!preg_match('/Opera/i', $u_agent) && !preg_match('/OPR/i', $u_agent))) {
            $bname = 'Chrome';
            $ub    = "Chrome";
        } elseif (preg_match('/Safari/i', $u_agent) && (!preg_match('/Opera/i', $u_agent) && !preg_match('/OPR/i', $u_agent))) {
            $bname = 'Safari';
            $ub    = "Safari";
        } elseif (preg_match('/Opera/i', $u_agent) || preg_match('/OPR/i', $u_agent)) {
            $bname = 'Opera';
            $ub    = "Opera";
        } elseif (preg_match('/Netscape/i', $u_agent)) {
            $bname = 'Netscape';
            $ub    = "Netscape";
        } elseif ((isset($u_agent) && (strpos($u_agent, 'Trident') !== false || strpos($u_agent, 'MSIE') !== false))) {
            $bname = 'Internet Explorer';
            $ub    = 'Internet Explorer';
        }


        // finally get the correct version number
        $known   = array('Version', $ub, 'other');
        $pattern = '#(?<browser>' . join('|', $known) . ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';

        if (!preg_match_all($pattern, $u_agent, $matches)) {
            // we have no matching number just continue
        }

        // see how many we have
        $i = count($matches['browser']);
        if ($i != 1) {
            //we will have two since we are not using 'other' argument yet
            //see if version is before or after the name
            if (strripos($u_agent, "Version") < strripos($u_agent, $ub)) {
                $version = $matches['version'][0];
            } else {
                $version = @$matches['version'][1];
            }
        } else {
            $version = $matches['version'][0];
        }

        // check if we have a number
        if ($version == null || $version == "") {
            $version = "?";
        }

        $browser = [
            'user_agent'      => $u_agent,
            'browser'         => $bname,
            'browser_version' => $version,
            'os_platform'     => $platform,
            'pattern'         => $pattern,
            'device'          => $deviceType
        ];

        $content = "<tr><td style='text-align: center;' colspan='2'>";
        $content .= _n('Information', 'Informations', 2);
        $content .= "</td></tr>";

        $content .= "<tr><td width='50%'>";
        $content .= __('Browser', 'servicecatalog');
        $content .= "</td>";
        $content .= "<td>";
        $content .= $browser['browser'];
        $content .= "</td></tr>";

        $content .= "<tr><td width='50%'>";
        $content .= __('Browser version', 'servicecatalog');
        $content .= "</td>";
        $content .= "<td>";
        $content .= $browser['browser_version'];
        $content .= "</td></tr>";

        $content .= "<tr><td width='50%'>";
        $content .= __('OS', 'servicecatalog');
        $content .= "</td>";
        $content .= "<td>";
        $content .= $browser['os_platform'];
        $content .= "</td></tr>";

        $content .= "<tr><td width='50%'>";
        $content .= __('Type');
        $content .= "</td>";
        $content .= "<td>";
        $content .= $browser['device'];
        $content .= "</td></tr>";

        return $content;
    }
}
