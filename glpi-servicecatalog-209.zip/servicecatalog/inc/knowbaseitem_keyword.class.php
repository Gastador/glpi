<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogKnowbaseitem_Keyword
 */
class PluginServicecatalogKnowbaseitem_Keyword extends CommonDBTM
{
    public static $rightname = "plugin_servicecatalog_setup";
    
    /**
     * Display image tab for each Knowbaseitem
     *
     * @param CommonGLPI $item
     * @param int        $withtemplate
     *
     * @return array|string
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if (!$withtemplate) {
            if ($item->getType() == 'KnowbaseItem' && $this->canUpdate()) {
                if ($_SESSION['glpishow_count_on_tabs']) {
                    $dbu = new DbUtils();
                    return self::createTabEntry(
                        PluginServicecatalogMain::getTypeName(),
                        $dbu->countElementsInTable(
                            "glpi_plugin_servicecatalog_knowbaseitems_keywords",
                            ["knowbaseitems_id" => $item->getField('id')]
                        )
                    );
                }
                return PluginServicecatalogMain::getTypeName();
            }
        }
        return '';
    }

    /**
     * Display tab's content for each KnowbaseItem
     *
     * @static
     *
     * @param CommonGLPI $item
     * @param int        $tabnum
     * @param int        $withtemplate
     *
     * @return bool|true
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        switch ($item->getType()) {
            case 'KnowbaseItem':
                $ID   = $item->getField('id');
                $self = new self();
                $self->showForm($ID);
                break;
        }

        return true;
    }



    /**
     * Get keywords in string separated by ,
     *
     * @param $knowbaseitems_id
     *
     * @return all|array
     */
    public function getKeywordsInString($knowbaseitems_id)
    {
        $tab = [];
        $keywords = $this->find(['knowbaseitems_id' => $knowbaseitems_id], "id");
        foreach ($keywords as $keyword) {
            $tab[] = $keyword['name'];
        }
        return implode(", ", $tab);
    }


    /**
     * @param       $ID
     * @param array $options
     *
     * @return bool
     * @throws \GlpitestSQLError
     */
    public function showForm($ID, $options = [])
    {
        if (!self::canUpdate()) {
            return false;
        }

        $canUpdate = $this->can($this->getID(), UPDATE);

        $rand = mt_rand();

        echo "<div>";

        echo "<form name='knowbaseitem_form$rand' id='knowbaseitem_form$rand' method='post'
            action='" . self::getFormURL() . "' enctype='multipart/form-data'>";

        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr><th>";
        echo __('Keywords', 'servicecatalog');
        echo "</th></tr>";
        echo "<tr><td>";
        echo "<div class='spaced'><table class='tab_cadre_fixe' id='plugin_servicecatalog_keywords'>";
        $i = 1;
        $keywords = $this->find(['knowbaseitems_id' => $ID], "id");
        foreach ($keywords as $data) {
            echo "<tr><td id='plugin_servicecatalog_keywords$i'>
                      <input type='text' name='keywords[]' maxlength='40' value=\"" . $data['name'] . "\">";
            echo " <a class='pointer' onclick=\"pluginServiceCatalogDelete('plugin_servicecatalog_keywords$i');\">";
            echo "&nbsp;<i style='font-size: 2em' class=\"fas fa-minus-circle\"></i></a>";
            echo "</td></tr>";
            $i += 1;
        }
        echo "<tr id='plugin_servicecatalog_add_keywords'><td>" . __('Add keyword', 'servicecatalog');
        echo " <a class='pointer' onclick=\"pluginServiceCatalogKnowbaseItemAdd('plugin_servicecatalog_add_keywords', '" . PLUGIN_SERVICECATALOG_WEBDIR . "/ajax/keyword.php', " . $this->fields["id"] . ");\">";
        echo "&nbsp;<i style='font-size: 2em' class=\"fas fa-plus-circle\"></i></a>";
        echo "</td></tr>";

        echo Html::hidden('knowbaseitems_id', ['value' => $ID]);

        $options['canedit'] = false;

        if ($canUpdate) {
            $options['canedit'] = true;
        }
        $options['candel'] = false;
        $this->showFormButtons($options);
    }

    /**
     * Clean keywords
     *
     * @param type $knowbaseitems_id
     */
    public function cleanKeywords($knowbaseitems_id)
    {
        $this->deleteByCriteria(['knowbaseitems_id' => $knowbaseitems_id], 1);
    }
}
