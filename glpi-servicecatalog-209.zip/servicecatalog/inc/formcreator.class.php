<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogFormcreator
 */
class PluginServicecatalogFormcreator extends CommonDBTM
{

    static $rightname = 'plugin_servicecatalog_setup';

   /**
    * functions mandatory
    * getTypeName(), canCreate(), canView()
    *
    * @param int $nb
    *
    * @return string
    */
    static function getTypeName($nb = 0)
    {
        return PluginServicecatalogMain::getTypeName();
    }

   /**
    * Get Tab Name used for itemtype
    *
    * NB : Only called for existing object
    *      Must check right on what will be displayed + template
    *
    * @param CommonGLPI $item Item on which the tab need to be displayed
    * @param int        $withtemplate is a template object ? (default 0)
    *
    * @return string tab name
    * @since version 0.83
    *
    */
    function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {

        if (!$withtemplate) {
            if ($item->getType() == 'PluginFormcreatorForm' && $this->canUpdate()) {
                return self::getTypeName();
            }
        }
        return '';
    }

   /**
    * show Tab content
    *
    * @param CommonGLPI $item Item on which the tab need to be displayed
    * @param integer    $tabnum tab number (default 1)
    * @param int        $withtemplate is a template object ? (default 0)
    *
    * @return boolean
    * @since version 0.83
    *
    */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {

        switch ($item->getType()) {
            case 'PluginFormcreatorForm':
                $form = new self();
                $form->showSetup($item->getID());

                break;
        }

        return true;
    }

   /**
    * Configuring
    *
    * @param $ID
    */
    static function showSetup($ID)
    {
        global $DB;

        $formcreator = new PluginFormcreatorForm();
        $formcreator->getFromDB($ID);

        $form = new self();
        if (!$form->getFromDBByCrit(['plugin_formcreator_forms_id' => $ID])) {
            $form->getEmpty();
        }

        echo "<form name='form' method='post' action='" . self::getFormURL() . "' enctype='multipart/form-data'>";

        echo "<div align='center'><table class='tab_cadre_fixe'>";

        echo "<tr><th colspan='3'>" . __('Redirection to the form if linked to a ticket category', 'servicecatalog') . "</th></tr>";
        echo "<tr><td colspan='3'><div class='alert alert-warning' role='alert'>" .
           __('Be careful, you can assign a category to several forms only if the language of the form is different.', 'servicecatalog') . "\n" .
           __('Otherwise, the form will not be displayed with the service catalog plugin.', 'servicecatalog') . "</div></td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Linking the form with a ticket category', 'servicecatalog') . "</td>";
        echo "<td colspan='2'>";

        $opt = ['value'       => $form->getField('itilcategories_id'),
              'entity'      => $formcreator->getEntityID(),
              'entity_sons' => $formcreator->isRecursive()];
        ITILCategory::dropdown($opt);
        echo "</td>";
        echo "</tr>";

        if ($form->getField('itilcategories_id') > 0) {
            $iterator = $DB->request(['SELECT'     => 'glpi_plugin_formcreator_forms.id',
                                   'FROM'       => 'glpi_plugin_servicecatalog_formcreators',
                                   'INNER JOIN' => [
                                      'glpi_plugin_formcreator_forms' => [
                                         'FKEY' => [
                                            'glpi_plugin_servicecatalog_formcreators' => 'plugin_formcreator_forms_id',
                                            'glpi_plugin_formcreator_forms'           => 'id'
                                         ]
                                      ]
                                   ],
                                   'WHERE'      => ['itilcategories_id' => $form->getField('itilcategories_id'),
                                                    'is_active'         => 1,
                                                    'is_deleted'        => 0,
                                                    'NOT'               => ['plugin_formcreator_forms_id' => $ID]]
                                  ]);

            if (count($iterator) > 0) {
                echo "<tr><th colspan='3'>" . sprintf(
                    __('Forms linked to the category : %s', 'servicecatalog'),
                    Dropdown::getDropdownName(
                        'glpi_itilcategories',
                        $form->getField('itilcategories_id')
                    )
                ) . "</th></tr>";
                 echo "<tr><th colspan='2'>" . PluginFormcreatorForm::getTypeName() . "</th>";
                 echo "<th>" . __('Language') . "</th></tr>";
                foreach ($iterator as $row) {
                    if ($formcreator->getFromDB($row['id'])) {
                        echo "<tr><td colspan='2'>";
                        echo $formcreator->getLink();
                        echo "</td><td>";
                        echo Dropdown::getLanguageName($formcreator->getField('language'));
                        echo "</td></tr>";
                    }
                }
            }
        }

        echo Html::hidden('plugin_formcreator_forms_id', ['value' => $ID]);
        echo "<tr class='tab_bg_1'><td class='center' colspan='3'>";
        echo Html::submit(_sx('button', 'Save'), ['name' => 'update', 'class' => 'btn btn-primary']);
        echo "</td></tr>";

        echo "</table></div>";

        Html::closeForm();
    }

   /**
    * @param array $input
    *
    * @return array
    */
    function prepareInputForAdd($input)
    {
        if ($input['itilcategories_id'] == 0) {
            unset($input);
        }
        return $input;
    }

   /**
    * @param array $input
    *
    * @return array
    */
    function prepareInputForUpdate($input)
    {
        return self::prepareInputForAdd($input);
    }
}
