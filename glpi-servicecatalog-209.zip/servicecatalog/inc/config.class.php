<?php

/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access directly to this file");
}

/**
 * Class PluginServicecatalogConfig
 */
class PluginServicecatalogConfig extends CommonDBTM
{
    const SLY = 0;
    const WRAPPER = 1;
    const WRAPPERSLY = 2;
    const THUMBNAIL = 3;
    const THUMBNAIL_WRAPPER = 4;
    const BOOTSTRAPPED = 5;
    const BOOTSTRAPPED_COLOR = 6;
    const SHOPER = 7;
    const NO_COLOR = 0;
    const DEFAULT_COLOR = 1;
    const BLUE_COLOR = 2;
    const MALLOW_COLOR = 3;
    const BLACK_COLOR = 4;

    public static $rightname = "plugin_servicecatalog_setup";
    public $can_be_translated = true;

    /**
     * PluginServicecatalogConfig constructor.
     */
    public function __construct()
    {
        global $DB;

        if ($DB->tableExists($this->getTable())) {
            $this->getFromDB(1);
        }
    }


    /**
     * Have I the global right to "view" the Object
     *
     * Default is true and check entity if the objet is entity assign
     *
     * May be overloaded if needed
     *
     * @return bool|int
     */
    public static function canView()
    {
        return (Session::haveRight(self::$rightname, UPDATE));
    }

    /**
     * Have I the global right to "create" the Object
     * May be overloaded if needed (ex KnowbaseItem)
     *
     * @return bool|int
     */
    public static function canCreate()
    {
        return (Session::haveRight(self::$rightname, CREATE));
    }

    /**
     * @param CommonGLPI $item
     * @param int $tabnum
     * @param int $withtemplate
     *
     * @return bool
     */
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if ($item->getType() == __CLASS__) {
            switch ($tabnum) {
                case 1:
                    $item->showGlobalForm($item->getID());
                    break;

                case 2:
                    $widget = new PluginServicecatalogWidget();
                    $widget->showWidgetsForm($item->getID());
                    break;
            }
        }
        return true;
    }

    /**
     * @param array $input
     *
     * @return array|bool
     */

    /**
     * @param bool $update
     *
     * @return null|PluginServicecatalogConfig
     */
    public static function getConfig($update = false)
    {
        static $config = null;

        if (is_null($config)) {
            $config = new self();
        }
        if ($update) {
            $config->getFromDB(1);
        }

        return $config;
    }

    /**
     * Returns the translation of the field
     *
     * @param type $item
     * @param type $field
     *
     * @return type
     * @global type $DB
     *
     */
    public static function displayField($item, $field, $withclean = true)
    {
        global $DB;

        // Make new database object and fill variables
        $iterator = $DB->request([
            'FROM' => 'glpi_plugin_servicecatalog_configtranslations',
            'WHERE' => [
                'itemtype' => 'PluginServicecatalogConfig',
                'items_id' => '1',
                'field' => $field,
                'language' => $_SESSION['glpilanguage']
            ]]);

        if (count($iterator)) {
            foreach ($iterator as $data) {
                //            if ($withclean == true) {
                return Glpi\RichText\RichText::getTextFromHtml($data['value']);
                //            } else {
                //               return $data['value'];
                //            }
            }
        }
        if ($withclean == true && isset($item->fields[$field])) {
            return Glpi\RichText\RichText::getTextFromHtml($item->fields[$field]);
        } elseif (isset($item->fields[$field])) {
            return $item->fields[$field];
        }
    }


    /**
     * @param CommonGLPI $item
     * @param int $withtemplate
     *
     * @return string
     */
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if (!$withtemplate) {
            $ong[1] = __('Setup', 'servicecatalog');
            $ong[2] = __('Widgets', 'servicecatalog');
            return $ong;
        }
        return '';
    }

    /**
     * @param array $options
     *
     * @return array
     * @see CommonGLPI::defineTabs()
     */
    public function defineTabs($options = [])
    {
        $ong = [];
        //      $this->addDefaultFormTab($ong);
        $this->addStandardTab(__CLASS__, $ong, $options);
        $this->addStandardTab('PluginServicecatalogDashboard', $ong, $options);
        $this->addStandardTab('PluginServicecatalogCategoryorder', $ong, $options);
        $this->addStandardTab('PluginServicecatalogFieldorder', $ong, $options);
        $this->addStandardTab('PluginServicecatalogWidgetbuttonorder', $ong, $options);
        $this->addStandardTab('PluginServicecatalogConfigTranslation', $ong, $options);
        $this->addStandardTab('PluginServicecatalogLink', $ong, $options);
        $this->addStandardTab('PluginServicecatalogApiclient', $ong, $options);
        $this->addStandardTab('PluginServicecatalogTools', $ong, $options);
        $this->addStandardTab('PluginServicecatalogCheckSchema', $ong, $options);
        return $ong;
    }

    /**
     * @param string $interface
     *
     * @return array
     */
    public function getRights($interface = 'central')
    {
        $values = parent::getRights();

        unset($values[READ], $values[DELETE]);
        return $values;
    }

    /**
     * Get the Search options for the given Type
     *
     * This should be overloaded in Class
     *
     * @return array an *indexed* array of search options
     *
     * @see https://glpi-developer-documentation.rtfd.io/en/master/devapi/search.html
     **/
    public function rawSearchOptions()
    {
        $tab = [];

        $tab[] = [
            'id' => 'common',
            'name' => self::getTypeName(2)
        ];

        $tab[] = [
            'id' => '1',
            'table' => $this->getTable(),
            'field' => 'comment',
            'name' => __('Comments'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '2',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_incident',
            'name' => __('Comment for incident ticket', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '3',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_request',
            'name' => __('Comment for request ticket', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '4',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_tickets',
            'name' => __('Comment for tickets list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '5',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_validation',
            'name' => __('Comment for ticket validation', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '6',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_faq',
            'name' => __('Comment for faq access', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '7',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_database',
            'name' => __('Comment for document database', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '8',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_links',
            'name' => __('Comment for useful links', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '9',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_message',
            'name' => __('Title of the message', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '10',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_message',
            'name' => __('Comment of the message', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '11',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_incidents_list',
            'name' => __('Comment for incidents list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '12',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_requests_list',
            'name' => __('Comment for requests list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '13',
            'table' => $this->getTable(),
            'field' => 'title_searchbar_incident',
            'name' => __('Title of the search bar for incidents', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '14',
            'table' => $this->getTable(),
            'field' => 'title_searchbar_request',
            'name' => __('Title of the search bar for requests', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '15',
            'table' => $this->getTable(),
            'field' => 'comment_reservation',
            'name' => __('Comment for reservation', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '16',
            'table' => $this->getTable(),
            'field' => 'title_your_open_incidents',
            'name' => __('Title of your opened incidents', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '17',
            'table' => $this->getTable(),
            'field' => 'title_your_and_group_open_incidents',
            'name' => __('Title of your and your group opened incidents', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '18',
            'table' => $this->getTable(),
            'field' => 'title_your_open_requests',
            'name' => __('Title of your opened requests', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '19',
            'table' => $this->getTable(),
            'field' => 'title_your_and_group_open_requests',
            'name' => __('Title of your and your group opened requests', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '20',
            'table' => $this->getTable(),
            'field' => 'title_watchers_dropdown',
            'name' => __('Title of watchers dropdown', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '21',
            'table' => $this->getTable(),
            'field' => 'title_submit_message_button',
            'name' => __('Title of submit message button', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '22',
            'table' => $this->getTable(),
            'field' => 'comment',
            'name' => __('Comments on the home page', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '23',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_entity',
            'name' => __('Comment for the context of the ticket', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '24',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_incident',
            'name' => __('Title for incident ticket', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '25',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_request',
            'name' => __('Title for request ticket', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '26',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_requests_list',
            'name' => __('Title for requests list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '27',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_validation',
            'name' => __('Title for ticket validation', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '28',
            'table' => $this->getTable(),
            'field' => 'title_searchbar_kb',
            'name' => __('Title of the search bar for knowbase items', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '29',
            'table' => $this->getTable(),
            'field' => 'select_title_incident_category',
            'name' => __('Select incident category', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '30',
            'table' => $this->getTable(),
            'field' => 'select_title_request_category',
            'name' => __('Select request category', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];


        $tab[] = [
            'id' => '31',
            'table' => $this->getTable(),
            'field' => 'title_favorites_category',
            'name' => __('Favorite categories', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '32',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_personalinfo',
            'name' => __('Title for personal informations', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '33',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_links',
            'name' => __('Title for useful links', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '34',
            'table' => $this->getTable(),
            'field' => 'title_ticket',
            'name' => __('Title of the ticket', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '35',
            'table' => $this->getTable(),
            'field' => 'title_description_ticket',
            'name' => __('Title for the ticket description', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '36',
            'table' => $this->getTable(),
            'field' => 'select_title_faq_article',
            'name' => __('Linked FAQ items', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '37',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_entity',
            'name' => __('Title for ticket context', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '38',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_database',
            'name' => __('Title for document database', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '39',
            'table' => $this->getTable(),
            'field' => 'title',
            'name' => __('Title on the home page', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '40',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_entity_list',
            'name' => __('Title of entities list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '41',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_entity_list',
            'name' => __('Comment of entities list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '42',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_tickets_list',
            'name' => __('Title for tickets list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '43',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_faq',
            'name' => __('Title for faq', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '44',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_incidents_list',
            'name' => __('Title for incidents list', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '45',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'comment_personalinfo',
            'name' => __('Comment for personal informations', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '46',
            'table' => "glpi_plugin_servicecatalog_widgets",
            'field' => 'title_reservation',
            'name' => __('Title for the reservation', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '47',
            'table' => $this->getTable(),
            'field' => 'title_phone_number',
            'name' => __('Title of phone number field', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '48',
            'table' => $this->getTable(),
            'field' => 'title_your_open_tickets',
            'name' => __('Title of your opened tickets', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '49',
            'table' => $this->getTable(),
            'field' => 'title_your_resolved_tickets',
            'name' => __('Title of your tickets to close', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '50',
            'table' => $this->getTable(),
            'field' => 'title_your_tickets_to_validate',
            'name' => __('Title of your tickets to validate', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '51',
            'table' => $this->getTable(),
            'field' => 'title_myelements_menu',
            'name' => __('Title of My elements menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '52',
            'table' => $this->getTable(),
            'field' => 'title_closedtickets_menu',
            'name' => __('Title of closed tickets menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '53',
            'table' => $this->getTable(),
            'field' => 'title_items_dropdown',
            'name' => __('Title of linked items dropdown', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '54',
            'table' => $this->getTable(),
            'field' => 'title_others_infos',
            'name' => __('Title of others informations', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '55',
            'table' => $this->getTable(),
            'field' => 'title_tickets_menu',
            'name' => __('Title of tickets menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '56',
            'table' => $this->getTable(),
            'field' => 'title_incidents_menu',
            'name' => __('Title of incidents menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '57',
            'table' => $this->getTable(),
            'field' => 'title_requests_menu',
            'name' => __('Title of requests menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '58',
            'table' => $this->getTable(),
            'field' => 'title_urgency',
            'name' => __('Title of urgency', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '59',
            'table' => $this->getTable(),
            'field' => 'title_impact',
            'name' => __('Title of impact', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '60',
            'table' => $this->getTable(),
            'field' => 'title_time_to_resolve',
            'name' => __('Title of TTR date', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '61',
            'table' => $this->getTable(),
            'field' => 'title_add_validation',
            'name' => __('Title of adding validation', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '62',
            'table' => $this->getTable(),
            'field' => 'title_inform_me',
            'name' => __('Title of email followup', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '63',
            'table' => $this->getTable(),
            'field' => 'title_location',
            'name' => __('Title of ticket location', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '64',
            'table' => $this->getTable(),
            'field' => 'title_delegation',
            'name' => __('Title of ticket delegation', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '65',
            'table' => $this->getTable(),
            'field' => 'title_category',
            'name' => __('Title of category selection', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '66',
            'table' => $this->getTable(),
            'field' => 'title_preferences',
            'name' => __('Title of preferences menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '67',
            'table' => $this->getTable(),
            'field' => 'placeholder_description_ticket',
            'name' => __('Title for the placeholder of ticket description', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '68',
            'table' => $this->getTable(),
            'field' => 'title_help_menu',
            'name' => __('Title of help menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '69',
            'table' => $this->getTable(),
            'field' => 'title_others_menu',
            'name' => __('Title of others menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '70',
            'table' => $this->getTable(),
            'field' => 'title_myappliances_menu',
            'name' => __('Title of My appliances menu', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '71',
            'table' => $this->getTable(),
            'field' => 'comment_urgency',
            'name' => __('Comment for urgency', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        $tab[] = [
            'id' => '72',
            'table' => $this->getTable(),
            'field' => 'comment_impact',
            'name' => __('Comment for impact', 'servicecatalog'),
            'searchtype' => 'equals',
            'datatype' => 'text'
        ];

        return $tab;
    }

    /**
     * @param int $nb
     *
     * @return string
     */
    public static function getTypeName($nb = 0)
    {
        return __('Plugin setup', 'servicecatalog');
    }


    /**
     * @return array
     */
    //    public function getPalettes()
    //    {
    //        $themes_files = scandir(GLPI_ROOT . PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/" . $this->getCatSize() . "/palettes/");
    //        $themes       = [];
    //        foreach ($themes_files as $file) {
    //            if (strpos($file, ".css") !== false) {
    //                $name = substr($file, 0, -4);
    //                if (strpos($name, '.min') !== false) {
    //                    $name = substr($name, 0, -4);
    //                    if (isset($themes[$name])) {
    //                        continue;
    //                    }
    //                }
    //                $themes[$name] = ucfirst($name);
    //            }
    //        }
    //        return $themes;
    //    }

    /**
     * @return mixed
     */
    public function getCatSize()
    {
        return $this->fields['cat_size'];
    }

    /**
     * @param $name
     * @param $value
     */
    public static function showSwitchField($name, $value)
    {
        echo Html::hidden($name, ['id' => $name,
            'value' => $value]);
        echo Html::scriptBlock("(function(){
                             var toggleButton = $('.$name');
                             toggleButton.click(function() {
                             if ($(this).hasClass('fa-toggle-on')) {
                                   toggleButton.removeClass('fa-toggle-on');
                                   toggleButton.addClass('fa-toggle-off');
                                   toggleButton.removeClass('enabled');
                                   toggleButton.addClass('disabled');
                                   document.getElementById('$name').value = '0';
                                 } else {
                                   toggleButton.removeClass('fa-toggle-off');
                                   toggleButton.addClass('fa-toggle-on');
                                   toggleButton.removeClass('disabled');
                                   toggleButton.addClass('enabled');
                                   document.getElementById('$name').value = '1';
                                 }
                             });
                           })();");
        if ($value == 1) {
            echo "<a class=\"button\"><i class=\"$name fa-fw fas fa-2x fa-toggle-on enabled\"></i></a>";
        } else {
            echo "<a class=\"button\"><i class=\"$name fa-fw fas fa-2x fa-toggle-off disabled\"></i></a>";
        }
    }


    /**
     * @param datas $input
     *
     * @return datas
     */
    public function prepareInputForAdd($input)
    {
        if (isset($input['fields_more_informations'])) {
            $input['fields_more_informations'] = json_encode($input['fields_more_informations']);
        }

        if (isset($input['columns_for_table'])) {
            $input['columns_for_table'] = json_encode($input['columns_for_table']);
        }

        return $input;
    }

    /**
     * @param datas $input
     *
     * @return datas
     */
    public function prepareInputForUpdate($input)
    {
        if (isset($input['fields_more_informations'])) {
            $input['fields_more_informations'] = json_encode($input['fields_more_informations']);
        } else {
            $input['fields_more_informations'] = json_encode([]);
        }

        if (isset($input['columns_for_table'])) {
            $input['columns_for_table'] = json_encode($input['columns_for_table']);
        } else {
            $input['columns_for_table'] = json_encode([]);
        }

        return $input;
    }
    //----------------- Getters and setters -------------------//

    /**
     * @param       $ID
     * @param array $options
     */
    public function showGlobalForm($ID, $options = [])
    {
        global $CFG_GLPI;

        echo "<form name='form' id='form' method='post'  enctype='multipart/form-data' action='" . Toolbox::getItemTypeFormURL('PluginServicecatalogConfig') . "'>";
        echo Html::hidden('deleteImg', ['id' => 'deleteImg', 'value' => 1]);
        echo "<table class='tab_cadre_fixe'>\n";
        echo "<tr class='tab_bg_2'>\n";
        echo "<td class='top'>\n";
        echo Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.css");
        echo Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.js");
        echo $JS = <<<JAVASCRIPT
         <script type='text/javascript'>
         function accordion(id, openall) {
             if(id == undefined){
                 id  = 'accordion';
             }
             jQuery(document).ready(function () {
                 $("#"+id).accordion({
                     collapsible: true,
                     //active:[0, 1, 2, 3],
                     heightStyle: "content"
                 });
                 //if (openall) {
                     //$('#'+id +' .ui-accordion-content').show();
                 //}
             });
         };
         </script>
JAVASCRIPT;

        echo "<div id='accordion'>";

        echo "<h3 ><a href='#'>" . __('Display setup', 'servicecatalog') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";


        echo "<tr class='tab_bg_1'>";
        echo "<td><label for='theme-selector'>" . __("Layout for categories", 'servicecatalog') . "</label></td><td>";

        $layout = [0 => 'sly',
            1 => 'wrapper',
            2 => 'wrappersly',
            3 => 'thumbnail',
            4 => 'thumbnail_wrapper',
            5 => 'bootstrapped',
            6 => 'bootstrapped_color',
            7 => 'shoper'];
        Dropdown::showFromArray(
            'layout',
            $layout,
            [
                'id' => 'layout',
                'value' => $this->fields['layout']
            ]
        );


        echo "</td>";
        echo "</tr>";

        //      echo "<tr class='tab_bg_1'>";
        //      echo "<td><label for='theme-selector'>" . __("Color palette") . "</label></td><td>";
        //      echo Html::select(
        //         'palette',
        //         $this->getPalettes(),
        //         [
        //            'id'       => 'theme-selector',
        //            'selected' => $this->fields['palette']
        //         ]
        //      );
        //      echo Html::scriptBlock("
        //         function formatThemes(theme) {
        //             if (!theme.id) {
        //                return theme.text;
        //             }
        //             var size = '" . $this->getCatSize() . "';
        //             return $('<span></span>').html('<img src=\'../css/previews/' + theme.text.toLowerCase() + '.png\'/>'
        //                      + '&nbsp;' + theme.text);
        //         }
        //         $(\"#theme-selector\").select2({
        //             templateResult: formatThemes,
        //             templateSelection: formatThemes,
        //             width: '100%',
        //             escapeMarkup: function(m) { return m; }
        //         });
        //         $('label[for=theme-selector]').on('click', function(){ $('#theme-selector').select2('open'); });
        //      ");
        //      echo "</td>";
        //      echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __("Use own colors", 'servicecatalog');
        Html::showToolTip(__("Use plugin colors or use CSS customization from core", 'servicecatalog'));
        echo "</td><td>";
        self::showSwitchField('use_own_colors', $this->fields['use_own_colors']);
        echo "</td>";
        echo "</tr>";

        if ($this->fields['use_own_colors'] == 1) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('General color', 'servicecatalog') . "</td>";
            echo "<td colspan='3'>";
            $rand = mt_rand();
            Html::showColorField('general_color', ['value' => $this->fields["general_color"], 'rand' => $rand]);

            echo "</td></tr>";

            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('General secondary color (hover)', 'servicecatalog') . "</td>";
            echo "<td colspan='3'>";
            $rand = mt_rand();
            Html::showColorField('general_hover_color', ['value' => $this->fields["general_hover_color"], 'rand' => $rand]);

            echo "</td></tr>";

            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Nav bar color', 'servicecatalog') . "</td>";
            echo "<td colspan='3'>";
            $rand = mt_rand();
            Html::showColorField('navbar-palette', ['value' => $this->fields["navbar-palette"], 'rand' => $rand]);

            echo "</td></tr>";

            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Titles font color', 'servicecatalog') . "</td>";
            echo "<td colspan='3'>";
            $rand = mt_rand();
            Html::showColorField('title_color', ['value' => $this->fields["title_color"], 'rand' => $rand]);

            echo "</td></tr>";

            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Titles background color', 'servicecatalog') . "</td>";
            echo "<td colspan='3'>";
            $rand = mt_rand();
            Html::showColorField('title_background_color', ['value' => $this->fields["title_background_color"], 'rand' => $rand]);

            echo "</td></tr>";

            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Force background color for title', 'servicecatalog') . "</td>";
            echo "<td colspan='3'>";
            self::showSwitchField('force_background_title', $this->fields['force_background_title']);
            echo "</td></tr>";
        }


        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Categories Size', 'servicecatalog') . "</td>";
        echo "<td>";
        $values = ['verysmall' => __('Very small', 'servicecatalog'),
            'small' => __('Small', 'servicecatalog'),
            'normal' => __('Normal', 'servicecatalog'),
            /*'big' => __('Big', 'servicecatalog')*/];
        Dropdown::showFromArray('cat_size', $values, ['value' => $this->fields["cat_size"]]);
        echo "</td>";
        echo "</tr>";

        $menus = [

            ["title_menuname" => "see_widgets_border",
                "title_menufield" => __('Display widgets border', 'servicecatalog'),
            ],
            ["title_menuname" => "radius_border",
                "title_menufield" => __('Rounded edges for the border', 'servicecatalog'),
            ],
            ["title_menuname" => "drop_helpdesk_menu",
                "title_menufield" => __('Drop helpdesk menu', 'servicecatalog'),
            ],
            //         ["title_menuname"  => "drop_helpdesk_footer",
            //          "title_menufield" => __('Drop helpdesk footer', 'servicecatalog'),
            //         ],
            ["title_menuname" => "drop_home_button",
                "title_menufield" => __('Redirect home button to Service Catalog', 'servicecatalog'),
            ],
            ["title_menuname" => "drop_languages_button",
                "title_menufield" => __('Drop helpdesk\'s languages button ', 'servicecatalog'),
            ],
            ["title_menuname" => "drop_help_button",
                "title_menufield" => __('Drop helpdesk\'s help button', 'servicecatalog'),
            ],
            ["title_menuname" => "drop_savedsearchs_button",
                "title_menufield" => __('Drop helpdesk\'s saved searchs button', 'servicecatalog'),
            ],
            ["title_menuname" => "drop_preferences_button",
                "title_menufield" => __('Drop helpdesk\'s preferences button', 'servicecatalog'),
            ],
            ["title_menuname" => "drop_logout_button",
                "title_menufield" => __('Drop helpdesk\'s logout button', 'servicecatalog'),
            ],
            ["title_menuname" => "see_faq_articles",
                "title_menufield" => __('Display linked FAQ articles', 'servicecatalog'),
            ],
            ["title_menuname" => "see_category_details",
                "title_menufield" => __('Display category details link', 'servicecatalog'),
            ],
            ["title_menuname" => "display_logo_category_detail",
                "title_menufield" => __('Display the logo in category details', 'servicecatalog'),
            ],
            ["title_menuname" => "show_indicators",
                "title_menufield" => __('Show indicators into complete interface', 'servicecatalog'),
            ],
        ];

        foreach ($menus as $k => $v) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . $v['title_menufield'] . "</td>";
            echo "<td>";
            self::showSwitchField($v['title_menuname'], $this->fields[$v['title_menuname']]);
            echo "</td>";
            echo "</tr>";
        }

        echo "<tr class='tab_bg_1'><td>";
        echo __('Default icon for categories', 'servicecatalog');
        echo "</td>";
        echo "<td colspan='2'>";
        $icon_selector_id = 'icon_' . mt_rand();
        echo Html::select(
            'default_icon',
            [$this->fields['default_icon'] => $this->fields['default_icon']],
            [
                'id' => $icon_selector_id,
                'selected' => $this->fields['default_icon'],
                'style' => 'width:175px;'
            ]
        );

        echo Html::script('js/Forms/FaIconSelector.js');
        echo Html::scriptBlock(
            <<<JAVASCRIPT
         $(
            function() {
               var icon_selector = new GLPI.Forms.FaIconSelector(document.getElementById('{$icon_selector_id}'));
               icon_selector.init();
            }
         );
JAVASCRIPT
        );

        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('See tickets lists as table', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("use_table_lists", $this->fields["use_table_lists"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Used columns for tables', 'servicecatalog') . "</td>";
        echo "<td>";

        $loadedcolumns = [];
        if (isset($this->fields["columns_for_table"])
            && !empty($this->fields["columns_for_table"])) {
            $loadedcolumns = json_decode($this->fields["columns_for_table"], true);
        }
        $listcolumns = PluginServicecatalogTicket::getListColumnsForTable();
        foreach ($listcolumns as $k => $data) {
            $columns[$data] = PluginServicecatalogTicket::getColumnsName($data);
        }

        if (!is_array($loadedcolumns)) {
            $values = [];
        } else {
            $values = $loadedcolumns;
        }

        Dropdown::showFromArray(
            'columns_for_table',
            $columns,
            ['values' => $values,
                'multiple' => true]
        );
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Number of rows displayed by default on tickets lists', 'servicecatalog') . "</td>";
        echo "<td>";
        $nbrows = [0 => '3',
            1 => '5',
            2 => '10',
            3 => '25',
            4 => '50',
            5 => '100'
        ];

        Dropdown::showFromArray(
            'default_number_rows',
            $nbrows,
            [
                'id' => 'default_number_rows',
                'value' => $this->fields['default_number_rows']
            ]
        );
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __("Demo mode", 'servicecatalog') . "</td><td>";
        self::showSwitchField('demo_mode', $this->fields['demo_mode']);
        echo "</td>";
        echo "</tr>";

        //      echo "<tr class='tab_bg_1'><td>";
        //      echo __('Back icon', 'servicecatalog');
        //      echo "<br>" . __('Example : ', 'servicecatalog') . "fas fa-chevron-circle-left";
        //      echo "</td>";
        //      echo "<td colspan='2'>";
        //      $opt = [
        //         'value'     => $this->fields['fa_back'],
        //         'maxlength' => 250,
        //         'size'      => 80,
        //      ];
        //      echo Html::input('fa_back', $opt);
        //      if (isset($this->fields['fa_back'])
        //          && !empty($this->fields['fa_back'])) {
        //         $icon = $this->fields['fa_back'];
        //         echo "<br><br><i class='fas-sc sc-fa-color $icon fa-3x' ></i>";
        //      }
        //      echo "</td>";
        //      echo "</tr>";

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Plugin setup', 'servicecatalog') . "</a></h3>";

        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Enable keywords', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("keywords", $this->fields["keywords"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Enable group restriction', 'servicecatalog');
        echo "<p style='font-size:x-small;margin-left:2%'>";
        echo __("When a category is restricted to specific groups all children categories are restricted.", 'servicecatalog');
        echo "</p>";
        echo "</td>";
        echo "<td>";
        self::showSwitchField("groups_restriction", $this->fields["groups_restriction"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Enable group restriction recursivity', 'servicecatalog');
        echo "<p style='font-size:x-small;margin-left:2%'>";
        echo __("Restriction to specific groups include children groups.", 'servicecatalog');
        echo "</p>";
        echo "</td>";
        echo "<td>";
        self::showSwitchField("groups_restriction_recursive", $this->fields["groups_restriction_recursive"]);
        echo "</td>";
        echo "</tr>";

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Plugin dashboard', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        $titles = [
            ["title_titlename" => "title",
                "title_titlefield" => __('Title on the home page', 'servicecatalog'),
            ],
            ["title_titlename" => "comment",
                "title_titlefield" => __('Comments on the home page', 'servicecatalog'),
            ],
            ["title_titlename" => "title_your_open_tickets",
                "title_titlefield" => __('Title of your opened tickets', 'servicecatalog'),
            ],
            ["title_titlename" => "title_your_open_incidents",
                "title_titlefield" => __('Title of your opened incidents', 'servicecatalog'),
            ],
            ["title_titlename" => "title_your_and_group_open_incidents",
                "title_titlefield" => __('Title of your and your group opened incidents', 'servicecatalog'),
            ],
            ["title_titlename" => "title_your_open_requests",
                "title_titlefield" => __('Title of your opened requests', 'servicecatalog'),
            ],
            ["title_titlename" => "title_your_and_group_open_requests",
                "title_titlefield" => __('Title of your and your group opened requests', 'servicecatalog'),
            ],
            ["title_titlename" => "title_your_resolved_tickets",
                "title_titlefield" => __('Title of your tickets to close', 'servicecatalog'),
            ],
            ["title_titlename" => "title_your_tickets_to_validate",
                "title_titlefield" => __('Title of your tickets to validate', 'servicecatalog'),
            ],
            ["title_titlename" => "select_title_incident_category",
                "title_titlefield" => __('Select incident category', 'servicecatalog'),
            ],
            ["title_titlename" => "select_title_request_category",
                "title_titlefield" => __('Select request category', 'servicecatalog'),
            ],
            ["title_titlename" => "title_favorites_category",
                "title_titlefield" => __('Favorite categories', 'servicecatalog'),
            ],
            ["title_titlename" => "select_title_faq_article",
                "title_titlefield" => __('Linked FAQ items', 'servicecatalog'),
            ],
        ];

        foreach ($titles as $k => $v) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . $v['title_titlefield'] . "</td>";
            echo "<td>";
            Html::textarea(['name' => $v['title_titlename'],
                'value' => $this->fields[$v['title_titlename']],
                'enable_richtext' => false,
                'cols' => 80,
                'rows' => 3]);
            echo "</td>";
            echo "</tr>";
        }

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Level of categories to show', 'servicecatalog') . "</td>";
        echo "<td>";
        $itilCat = new ITILCategory();
        $itilCategories = $itilCat->find([1 => 1]);
        $levelsCat = [];
        foreach ($itilCategories as $categorie) {
            $levelsCat[$categorie['level']] = $categorie['level'];
        }
        ksort($levelsCat);
        Dropdown::showFromArray('levelCat', $levelsCat, ['value' => $this->fields["levelCat"]]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Show Top incidents / Top requests', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("seetop", $this->fields["seetop"]);
        echo "</td>";
        echo "</tr>";

        echo "</table>";
        echo "</div>";
        echo "<h3 ><a href='#'>" . __('Plugin search bars', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Use integrated search bar', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("use_integrated_search", $this->fields["use_integrated_search"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Use strict search', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("use_strict_search", $this->fields["use_strict_search"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Search tickets color', 'servicecatalog') . "</td>";
        echo "<td colspan='3'>";
        $rand = mt_rand();
        Html::showColorField('search_ticket_color', ['value' => $this->fields["search_ticket_color"], 'rand' => $rand]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Search KB articles color', 'servicecatalog') . "</td>";
        echo "<td colspan='3'>";
        $rand = mt_rand();
        Html::showColorField('search_kb_color', ['value' => $this->fields["search_kb_color"], 'rand' => $rand]);
        echo "</td></tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Search API color', 'servicecatalog') . "</td>";
        echo "<td colspan='3'>";
        $rand = mt_rand();
        Html::showColorField('search_api_color', ['value' => $this->fields["search_api_color"], 'rand' => $rand]);
        echo "</td></tr>";


        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of the search bar for incidents', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_searchbar_incident',
            'value' => $this->fields['title_searchbar_incident'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of the search bar for requests', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_searchbar_request',
            'value' => $this->fields['title_searchbar_request'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of the search bar for knowbase items', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_searchbar_kb',
            'value' => $this->fields['title_searchbar_kb'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Navigation bar', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of tickets menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_tickets_menu',
            'value' => $this->fields['title_tickets_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of incidents menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_incidents_menu',
            'value' => $this->fields['title_incidents_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of requests menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_requests_menu',
            'value' => $this->fields['title_requests_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of help menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_help_menu',
            'value' => $this->fields['title_help_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of others menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_others_menu',
            'value' => $this->fields['title_others_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('See My elements menu', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("display_myelements_menu", $this->fields["display_myelements_menu"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of My elements menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_myelements_menu',
            'value' => $this->fields['title_myelements_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Icon of My elements menu', 'servicecatalog');
        echo "</td>";
        echo "<td colspan='2'>";
        $icon_selector_id = 'icon_' . mt_rand();
        echo Html::select(
            'fa_myelements_menu',
            [$this->fields['fa_myelements_menu'] => $this->fields['fa_myelements_menu']],
            [
                'id' => $icon_selector_id,
                'selected' => $this->fields['fa_myelements_menu'],
                'style' => 'width:175px;'
            ]
        );

        echo Html::script('js/Forms/FaIconSelector.js');
        echo Html::scriptBlock(
            <<<JAVASCRIPT
         $(
            function() {
               var icon_selector = new GLPI.Forms.FaIconSelector(document.getElementById('{$icon_selector_id}'));
               icon_selector.init();
            }
         );
JAVASCRIPT
        );

        echo "</td>";
        echo "</tr>";


        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('See My appliances menu', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("display_myappliances_menu", $this->fields["display_myappliances_menu"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of My appliances menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_myappliances_menu',
            'value' => $this->fields['title_myappliances_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Icon of My appliances menu', 'servicecatalog');
        echo "</td>";
        echo "<td colspan='2'>";
        $icon_selector_id = 'icon_' . mt_rand();
        echo Html::select(
            'fa_myappliances_menu',
            [$this->fields['fa_myappliances_menu'] => $this->fields['fa_myappliances_menu']],
            [
                'id' => $icon_selector_id,
                'selected' => $this->fields['fa_myappliances_menu'],
                'style' => 'width:175px;'
            ]
        );

        echo Html::script('js/Forms/FaIconSelector.js');
        echo Html::scriptBlock(
            <<<JAVASCRIPT
         $(
            function() {
               var icon_selector = new GLPI.Forms.FaIconSelector(document.getElementById('{$icon_selector_id}'));
               icon_selector.init();
            }
         );
JAVASCRIPT
        );

        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('See closed tickets menu', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("display_closedtickets_menu", $this->fields["display_closedtickets_menu"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of closed tickets menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_closedtickets_menu',
            'value' => $this->fields['title_closedtickets_menu'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>";
        echo __('Icon of closed tickets menu', 'servicecatalog');
        echo "</td>";
        echo "<td colspan='2'>";

        $icon_selector_id = 'icon_' . mt_rand();
        echo Html::select(
            'fa_closedtickets_menu',
            [$this->fields['fa_closedtickets_menu'] => $this->fields['fa_closedtickets_menu']],
            [
                'id' => $icon_selector_id,
                'selected' => $this->fields['fa_closedtickets_menu'],
                'style' => 'width:175px;'
            ]
        );

        echo Html::script('js/Forms/FaIconSelector.js');
        echo Html::scriptBlock(
            <<<JAVASCRIPT
         $(
            function() {
               var icon_selector = new GLPI.Forms.FaIconSelector(document.getElementById('{$icon_selector_id}'));
               icon_selector.init();
            }
         );
JAVASCRIPT
        );

        echo "</td>";
        echo "</tr>";


        echo "</table>";
        echo "</div>";


        echo "<h3 ><a href='#'>" . __('Ticket form', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";
        $rand = mt_rand();

        echo "<tr class='tab_bg_1'><td>" . __('Bypass categories selection', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("bypass_categories_selection", $this->fields["bypass_categories_selection"]);
        echo "</td>\n";
        echo "</tr>";

        if ($this->fields["bypass_categories_selection"] == 1) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Title of category selection', 'servicecatalog') . "</td>";
            echo "<td>";
            Html::textarea(['name' => 'title_category',
                'value' => $this->fields['title_category'],
                'enable_richtext' => false,
                'cols' => 80,
                'rows' => 3]);
            echo "</td>";
            echo "</tr>";
        }

//        echo "<tr class='tab_bg_1'>";
//        echo "<td>" . __("Load new page to launch create ticket form with all layouts", 'servicecatalog') . "</td><td>";
//        self::showSwitchField('new_page_to_create', $this->fields['new_page_to_create']);
//        echo "</td>";
//        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Use ticket creation form as wizard (with steps)', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("use_as_step", $this->fields["use_as_step"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Redirect user to category detail before ticket creation', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("use_detail_before_creation", $this->fields["use_detail_before_creation"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Width of helpdesk creation form', 'servicecatalog') . "</td>";
        echo "<td>";
        $optionNumber = [
            'value' => $this->fields['helpdesk_form_percent'],
            'min'   => 70,
            'max'   => 100,
        ];
        Dropdown::showNumber('helpdesk_form_percent', $optionNumber);
        echo " %</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Default ticket template for incidents', 'servicecatalog') . "</td>\n<td>";
        TicketTemplate::dropdown([
            'name' => 'template_ticket_incident',
            'value' => $this->fields["template_ticket_incident"]]);
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Default ticket template for requests', 'servicecatalog') . "</td>\n<td>";
        TicketTemplate::dropdown([
            'name' => 'template_ticket_request',
            'value' => $this->fields["template_ticket_request"]]);
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of urgency', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_urgency',
            'value' => $this->fields['title_urgency'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Comment for urgency', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'comment_urgency',
            'value' => $this->fields['comment_urgency'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Urgency colors', 'servicecatalog') . "</td>";
        echo "<td colspan='3'>";

        echo "<table><tr>";
        if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 1)) {
            echo "<td align='center'><label for='dropdown_urgency_1$rand'>" . Ticket::getUrgencyName(1) . "</label><br />";
            Html::showColorField('urgency_1', ['value' => $this->fields["urgency_1"], 'rand' => $rand]);
            echo "</td>";
        }
        if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 2)) {
            echo "<td align='center'><label for='dropdown_urgency_2$rand'>" . Ticket::getUrgencyName(2) . "</label><br />";
            Html::showColorField('urgency_2', ['value' => $this->fields["urgency_2"], 'rand' => $rand]);
            echo "</td>";
        }
        echo "<td align='center'><label for='dropdown_urgency_3$rand'>" . Ticket::getUrgencyName(3) . "</label><br />";
        Html::showColorField('urgency_3', ['value' => $this->fields["urgency_3"], 'rand' => $rand]);
        echo "</td>";
        if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 4)) {
            echo "<td align='center'><label for='dropdown_urgency_4$rand'>" . Ticket::getUrgencyName(4) . "</label><br />";
            Html::showColorField('urgency_4', ['value' => $this->fields["urgency_4"], 'rand' => $rand]);
            echo "</td>";
        }
        if ($CFG_GLPI[Ticket::URGENCY_MASK_FIELD] & (1 << 5)) {
            echo "<td align='center'><label for='dropdown_urgency_5$rand'>" . Ticket::getUrgencyName(5) . "</label><br />";
            Html::showColorField('urgency_5', ['value' => $this->fields["urgency_5"], 'rand' => $rand]);
            echo "</td>";
        }
        echo "</tr></table>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of impact', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_impact',
            'value' => $this->fields['title_impact'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Comment for impact', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'comment_impact',
            'value' => $this->fields['comment_impact'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Impact colors', 'servicecatalog') . "</td>";
        echo "<td colspan='3'>";

        echo "<table><tr>";
        if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 1)) {
            echo "<td align='center'><label for='dropdown_impact_1$rand'>" . Ticket::getImpactName(1) . "</label><br />";
            Html::showColorField('impact_1', ['value' => $this->fields["impact_1"], 'rand' => $rand]);
            echo "</td>";
        }
        if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 2)) {
            echo "<td align='center'><label for='dropdown_impact_2$rand'>" . Ticket::getImpactName(2) . "</label><br />";
            Html::showColorField('impact_2', ['value' => $this->fields["impact_2"], 'rand' => $rand]);
            echo "</td>";
        }
        echo "<td align='center'><label for='dropdown_impact_3$rand'>" . Ticket::getImpactName(3) . "</label><br />";
        Html::showColorField('impact_3', ['value' => $this->fields["impact_3"], 'rand' => $rand]);
        echo "</td>";
        if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 4)) {
            echo "<td align='center'><label for='dropdown_impact_4$rand'>" . Ticket::getImpactName(4) . "</label><br />";
            Html::showColorField('impact_4', ['value' => $this->fields["impact_4"], 'rand' => $rand]);
            echo "</td>";
        }
        if ($CFG_GLPI[Ticket::IMPACT_MASK_FIELD] & (1 << 5)) {
            echo "<td align='center'><label for='dropdown_impact_5$rand'>" . Ticket::getImpactName(5) . "</label><br />";
            Html::showColorField('impact_5', ['value' => $this->fields["impact_5"], 'rand' => $rand]);
            echo "</td>";
        }
        echo "</tr></table>";

        echo "</td></tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Display more informations options by default on create ticket', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("see_more_informations", $this->fields["see_more_informations"]);
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of others informations', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_others_infos',
            'value' => $this->fields['title_others_infos'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Used fields into more informations block', 'servicecatalog') . "</td>\n<td>";
        $fieldsOrder = new PluginServicecatalogFieldorder();
        $condition = [1 => 1];
        if ($this->getBypassCategories() == 0) {
            $condition = ['NOT' => ['name' => 'itilcategories']];
        }
        $fields_ordered = $fieldsOrder->find($condition, "ranking");
        $fields = [];
        if (isset($this->fields["fields_more_informations"])
            && !empty($this->fields["fields_more_informations"])) {
            $fields = json_decode($this->fields["fields_more_informations"], true);
        }

        if (!is_array($fields)) {
            $values = [];
        } else {
            $values = $fields;
        }

        foreach ($fields_ordered as $data) {
            $fields[$data['id']] = PluginServicecatalogFieldorder::getFullNameField($data['name']);
        }

        Dropdown::showFromArray(
            'fields_more_informations',
            $fields,
            ['values' => $values,
                'multiple' => true]
        );
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Allow opening tickets for all others users', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("force_delegating", $this->fields["force_delegating"]);
        echo "</td>\n";
        echo "</tr>";

        if ($this->fields["force_delegating"] == 1) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Opening tickets for these users', 'servicecatalog') . "</td>";
            echo "<td>";
            $restrictions = [0 => __('All users', 'servicecatalog'),
                1 => __('Only users of user groups', 'servicecatalog')
            ];

            Dropdown::showFromArray(
                'force_delegating_restriction',
                $restrictions,
                [
                    'id' => 'force_delegating_restriction',
                    'value' => $this->fields['force_delegating_restriction']
                ]
            );
            echo "</td>";
            echo "</tr>";

            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Title of ticket delegation', 'servicecatalog') . "</td>";
            echo "<td>";
            Html::textarea(['name' => 'title_delegation',
                'value' => $this->fields['title_delegation'],
                'enable_richtext' => false,
                'cols' => 80,
                'rows' => 3]);
            echo "</td>";
            echo "</tr>";
        }

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of preferences menu', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_preferences',
            'value' => $this->fields['title_preferences'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Display requester group field on create ticket', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("display_requester_group", $this->fields["display_requester_group"]);
        echo "</td>\n";
        echo "</tr>";

        if ($this->fields["display_requester_group"] == 1) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Title of requester group field', 'servicecatalog') . "</td>";
            echo "<td>";
            Html::textarea(['name' => 'title_requester_group',
                'value' => $this->fields['title_requester_group'],
                'enable_richtext' => false,
                'cols' => 80,
                'rows' => 3]);
            echo "</td>";
            echo "</tr>";
        }

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of watchers dropdown', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_watchers_dropdown',
            'value' => $this->fields['title_watchers_dropdown'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of TTR date', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_time_to_resolve',
            'value' => $this->fields['title_time_to_resolve'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of adding validation', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_add_validation',
            'value' => $this->fields['title_add_validation'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Display linked items with icons', 'servicecatalog') . "</td><td>";
        self::showSwitchField("use_itemtypes_display", $this->fields["use_itemtypes_display"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of linked items dropdown', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_items_dropdown',
            'value' => $this->fields['title_items_dropdown'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of ticket location', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_location',
            'value' => $this->fields['title_location'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Display phone number field on create ticket', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("display_phone_number", $this->fields["display_phone_number"]);
        echo "</td>\n";
        echo "</tr>";

        if ($this->fields["display_phone_number"] == 1) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Title of phone number field', 'servicecatalog') . "</td>";
            echo "<td>";
            Html::textarea(['name' => 'title_phone_number',
                'value' => $this->fields['title_phone_number'],
                'enable_richtext' => false,
                'cols' => 80,
                'rows' => 3]);
            echo "</td>";
            echo "</tr>";
        }

        echo "<tr class='tab_bg_1'><td>" . __('Phone field is mandatory', 'servicecatalog') . "</td><td>";
        self::showSwitchField("phone_mandatory", $this->fields["phone_mandatory"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Display browser informations after ticket creation', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("display_browser_infos", $this->fields["display_browser_infos"]);
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of the ticket', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_ticket',
            'value' => $this->fields['title_ticket'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title for the ticket description', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_description_ticket',
            'value' => $this->fields['title_description_ticket'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title for the placeholder of ticket description', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'placeholder_description_ticket',
            'value' => $this->fields['placeholder_description_ticket'],
            'enable_fileupload' => false,
            'enable_richtext' => true,
            'enable_images' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Title of submit message button', 'servicecatalog') . "</td>";
        echo "<td>";
        Html::textarea(['name' => 'title_submit_message_button',
            'value' => $this->fields['title_submit_message_button'],
            'enable_richtext' => false,
            'cols' => 80,
            'rows' => 3]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Hide mail followup', 'servicecatalog') . "</td><td>";
        self::showSwitchField("hide_mail_followup", $this->fields["hide_mail_followup"]);
        echo "</td>\n";
        echo "</tr>";

        if ($this->fields["hide_mail_followup"] == 0) {
            echo "<tr class='tab_bg_1'>";
            echo "<td>" . __('Title of email followup', 'servicecatalog') . "</td>";
            echo "<td>";
            Html::textarea(['name' => 'title_inform_me',
                'value' => $this->fields['title_inform_me'],
                'enable_richtext' => false,
                'cols' => 80,
                'rows' => 3]);
            echo "</td>";
            echo "</tr>";
        }

        echo "<tr class='tab_bg_1'><td>" . __('Permission to add requesters on a ticket', 'servicecatalog') . "</td><td>";
        self::showSwitchField("add_requesters_from_tickets", $this->fields["add_requesters_from_tickets"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Permission to add observers on a ticket', 'servicecatalog') . "</td><td>";
        self::showSwitchField("add_observers_from_tickets", $this->fields["add_observers_from_tickets"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Users listed for add requesters or add watchers', 'servicecatalog') . "</td>";
        echo "<td>";
        $restrictions = [0 => __('All users', 'servicecatalog'),
            1 => __('Only users of user groups', 'servicecatalog')
        ];

        Dropdown::showFromArray(
            'actors_restriction',
            $restrictions,
            [
                'id' => 'actors_restriction',
                'value' => $this->fields['actors_restriction']
            ]
        );
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'>";
        echo "<td>" . __('Redirection to entity selection after ticket creation', 'servicecatalog') . "</td>";
        echo "<td>";
        self::showSwitchField("multi_entity_redirection", $this->fields["multi_entity_redirection"]);
        echo "</td>";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Use all tab by default', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("use_all_tab_default", $this->fields["use_all_tab_default"]);
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Show linked tickets', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("show_linked_tickets_simplifiedform", $this->fields["show_linked_tickets_simplifiedform"]);
        echo "</td>\n";
        echo "</tr>";

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Configuration for update user assets', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr class='tab_bg_1'><td>" . __('Show asset update button', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("show_asset_update_button", $this->fields["show_asset_update_button"]);
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Ticket template associated for the update of user\'s assets', 'servicecatalog') . "</td>\n<td>";
        TicketTemplate::dropdown([
            'name' => 'template_ticket_assets_user_update',
            'value' => $this->fields["template_ticket_assets_user_update"]]);
        echo "</td>\n";
        echo "</tr>";

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Configuration for update user', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr class='tab_bg_1'><td>" . __('Use service catalog preferences form', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("switch_prefs", $this->fields["switch_prefs"]);
        echo "</td>\n";
        echo "</tr>";

        echo "<tr class='tab_bg_1'><td>" . __('Ticket template associated for the update of user\'s personal information', 'servicecatalog') . "</td>\n<td>";
        TicketTemplate::dropdown([
            'name' => 'template_ticket_user_update',
            'value' => $this->fields["template_ticket_user_update"]]);
        echo "</td>\n";
        echo "</tr>";

        echo "</table>";
        echo "</div>";

        echo "<h3 ><a href='#'>" . __('Configuration for cancel ticket', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr class='tab_bg_1'><td>" . __('Solution template associated for cancel ticket', 'servicecatalog') . "</td>\n<td>";
        SolutionTemplate::dropdown([
            'name' => 'template_cancel_ticket',
            'value' => $this->fields["template_cancel_ticket"]]);
        echo "</td>\n";
        echo "</tr>";

        echo "</table>";
        echo "</div>";


        echo "<h3 ><a href='#'>" . __('Configuration for reservations', 'servicecatalog') . "</a></h3>";
        echo "<div>";
        echo "<table class='tab_cadre' width='100%'>";

        echo "<tr class='tab_bg_1'><td>" . __('Create request for reservation', 'servicecatalog') . "</td>\n<td>";
        self::showSwitchField("create_ticket_reservation", $this->fields["create_ticket_reservation"]);
        echo "</td>\n";
        echo "</tr>";


        echo "<tr class='tab_bg_1'><td>" . __('Ticket template associated for the creation of the ticket for reservations', 'servicecatalog') . "</td>\n<td>";
        TicketTemplate::dropdown([
            'name' => 'template_ticket_reservation',
            'value' => $this->fields["template_ticket_reservation"]]);
        echo "</td>\n";
        echo "</tr>";

        echo "</table>";
        echo "</div>";

        echo "</div>";

        echo "<script>accordion();</script>";

        echo "</td></tr>\n";
        if (Session::haveRight("plugin_servicecatalog_setup", UPDATE)) {
            echo Html::hidden('id', ['value' => 1]);
            echo "<tr class='tab_bg_1'><td class='center' colspan='2'>";
            echo Html::submit(_sx('button', 'Save'), ['name' => 'update', 'class' => 'btn btn-primary']);
            echo "</td></tr>";
        }
        echo "</table>\n";
        Html::closeForm();
        echo "</div>\n";
    }


    /**
     * @return void
     */
    public function showLayoutSelector()
    {
        $this->getFromDB(1);
        echo "<form name='form' method='post' action='" .
            Toolbox::getItemTypeFormURL('PluginServicecatalogConfig') . "'>";

        echo 'DEMO : ' . __("Layout for categories", 'servicecatalog') . "&nbsp;";
        $layout = [0 => 'sly',
            1 => 'wrapper',
            2 => 'wrappersly',
            3 => 'thumbnail',
            4 => 'thumbnail_wrapper',
            5 => 'bootstrapped',
            6 => 'bootstrapped_color',
            7 => 'shoper'
        ];
        $selected = $this->fields['layout'];
        if (isset($_SESSION["glpi_plugin_servicecatalog_demolayout"])) {
            $selected = $_SESSION["glpi_plugin_servicecatalog_demolayout"];
        }
        echo "&nbsp;";
        Dropdown::showFromArray(
            'layout',
            $layout,
            [
                'id' => 'layout',
                'value' => $selected
            ]
        );
        echo "&nbsp;";
        echo Html::hidden('id', ['value' => 1]);
        echo Html::submit(_sx('button', 'Change'), ['name' => 'update_demo_layout',
            'class' => 'btn btn-info btn-xs']);
        Html::closeForm();
    }


    /**
     * @return void
     */
    public function showColorSelector()
    {
        if (!isset($_SESSION["glpi_plugin_servicecatalog_color"])) {
            $_SESSION["glpi_plugin_servicecatalog_color"] = self::NO_COLOR;
        }

        $this->getFromDB(1);
        echo "<form name='form' method='post' action='" .
            Toolbox::getItemTypeFormURL('PluginServicecatalogConfig') . "'>";

        echo 'DEMO : ' . __("Theme") . "&nbsp;";
        $theme = [self::DEFAULT_COLOR => 'Default color theme',
            self::BLUE_COLOR => 'Blue theme',
            self::MALLOW_COLOR => 'Mallow theme',
            self::BLACK_COLOR => 'Black theme',
            self::NO_COLOR => 'GLPI theme',
        ];
        $selected = $_SESSION["glpi_plugin_servicecatalog_color"];

        echo "&nbsp;";
        Dropdown::showFromArray(
            'theme',
            $theme,
            [
                'id' => 'theme',
                'value' => $selected
            ]
        );
        echo "&nbsp;";
        echo Html::hidden('id', ['value' => 1]);
        echo Html::submit(_sx('button', 'Change'), ['name' => 'update_demo_theme',
            'class' => 'btn btn-info btn-xs']);
        Html::closeForm();
    }

    /**
     * @return void
     */
    public function showTicketWizardSelector()
    {
        $this->getFromDB(1);
        echo "<form name='form' method='post' action='" .
            Toolbox::getItemTypeFormURL('PluginServicecatalogConfig') . "'>";

        echo 'DEMO : ' . __('Ticket mode', 'servicecatalog') . "&nbsp;";
        $layout = [0 => __('Use ticket creation form as one form', 'servicecatalog'),
            1 => __('Use ticket creation form as wizard (with steps)', 'servicecatalog')
        ];
        $selected = $this->fields['use_as_step'];
        if (isset($_SESSION["glpi_plugin_servicecatalog_demowizard"])) {
            $selected = $_SESSION["glpi_plugin_servicecatalog_demowizard"];
        }
        echo "&nbsp;";
        Dropdown::showFromArray(
            'use_as_step',
            $layout,
            [
                'id' => 'use_as_step',
                'value' => $selected
            ]
        );
        echo "&nbsp;";
        echo Html::hidden('id', ['value' => 1]);
        echo Html::submit(_sx('button', 'Change'), ['name' => 'update_demo_wizard',
            'class' => 'btn btn-info btn-xs']);
        Html::closeForm();
    }


    /**
     * @return void
     */
    public function showSearchEngineSelector()
    {
        $this->getFromDB(1);
        echo "<form name='form' method='post' action='" .
            Toolbox::getItemTypeFormURL('PluginServicecatalogConfig') . "'>";

        echo 'DEMO : ' . __('Search engine mode', 'servicecatalog') . "&nbsp;";
        $search = [0 => __('Use search engine from header', 'servicecatalog'),
            1 => __('Use integrated search engine', 'servicecatalog')
        ];
        $selected = $this->fields['use_integrated_search'];
        if (isset($_SESSION["glpi_plugin_servicecatalog_demosearch"])) {
            $selected = $_SESSION["glpi_plugin_servicecatalog_demosearch"];
        }
        echo "&nbsp;";
        Dropdown::showFromArray(
            'use_integrated_search',
            $search,
            [
                'id' => 'use_integrated_search',
                'value' => $selected
            ]
        );
        echo "&nbsp;";
        echo Html::hidden('id', ['value' => 1]);
        echo Html::submit(_sx('button', 'Change'), ['name' => 'update_demo_search',
            'class' => 'btn btn-info btn-xs']);
        Html::closeForm();
    }

    /**
     * @return mixed
     */
    public function useStrictSearch()
    {
        $use_strict_search = $this->fields['use_strict_search'];
        return $use_strict_search;
    }


    /**
     * @return void
     */
    public function showDisplayAsTableSelector()
    {
        $this->getFromDB(1);
        echo "<form name='form' method='post' action='" .
            Toolbox::getItemTypeFormURL('PluginServicecatalogConfig') . "'>";

        echo 'DEMO : ' . __('Widget lists display', 'servicecatalog') . "&nbsp;";
        $search = [1 => __('Show as list', 'servicecatalog'),
            0 => __('Show as bubble', 'servicecatalog')
        ];
        $selected = $this->fields['use_table_lists'];
        if (isset($_SESSION["glpi_plugin_servicecatalog_demotablelist"])) {
            $selected = $_SESSION["glpi_plugin_servicecatalog_demotablelist"];
        }
        echo "&nbsp;";
        Dropdown::showFromArray(
            'use_table_lists',
            $search,
            [
                'id' => 'use_table_lists',
                'value' => $selected
            ]
        );
        echo "&nbsp;";
        echo Html::hidden('id', ['value' => 1]);
        echo Html::submit(_sx('button', 'Change'), ['name' => 'update_demo_tablelist',
            'class' => 'btn btn-info btn-xs']);
        Html::closeForm();
    }

    /**
     * get general_color
     * @return mixed
     */
    public function getGeneralColor()
    {
        return $this->fields['general_color'];
    }

    /**
     * get general_hover_color
     * @return mixed
     */
    public function getGeneralHoverColor()
    {
        return $this->fields['general_hover_color'];
    }

    /**
     * get getSearchTicketsColor
     * @return mixed
     */
    public function getSearchTicketsColor()
    {
        return $this->fields['search_ticket_color'];
    }

    /**
     * get getSearchKbColor
     * @return mixed
     */
    public function getSearchKbColor()
    {
        return $this->fields['search_kb_color'];
    }

    /**
     * get getSearchApiColor
     * @return mixed
     */
    public function getSearchApiColor()
    {
        return $this->fields['search_api_color'];
    }

    /**
     * @return string
     */
    public function getTheme(): string
    {
        //        $js = "$(function() {
        //             if($('html').css('--is-dark').trim() === 'true') {
        //                return '#FFFFFF!important;';
        /*                var x = '<?php echo $x; ?>';*/
        //            }";
        //        $theme = Html::scriptBlock($js);
        //

        if (str_contains($_SESSION['glpipalette'], 'darker') == true
            || str_contains($_SESSION['glpipalette'], 'midnight') == true) {
            return '';
        } else {
            return '#FFFFFF!important;';
        }
    }


    /**
     * get nav bar color
     * @return mixed
     */
    public function getNavBarColor()
    {
        return $this->fields['navbar-palette'];
    }

    /**
     * get alert title font color
     * @return mixed
     */
    public function getTitleColor()
    {
        return $this->fields['title_color'];
    }

    /**
     * get alert title background color
     * @return mixed
     */
    public function getTitleBackgroundColor()
    {
        return $this->fields['title_background_color'];
    }

    /**
     * get alert force background color
     * @return mixed
     */
    public function getforceBackgroundColor()
    {
        return $this->fields['force_background_title'];
    }

    /**
     * get getBypassCategories
     * @return mixed
     */
    public function getBypassCategories()
    {
        return $this->fields['bypass_categories_selection'];
    }

    /**
     * get getDefaultIncidentTemplate
     * @return mixed
     */
    public function getDefaultIncidentTemplate()
    {
        return $this->fields['template_ticket_incident'];
    }

    /**
     * get getDefaultRequestTemplate
     * @return mixed
     */
    public function getDefaultRequestTemplate()
    {
        return $this->fields['template_ticket_request'];
    }

    /**
     * get getDropHelpdeskMenu
     * @return mixed
     */
    public function getDropHelpdeskMenu()
    {
        return $this->fields['drop_helpdesk_menu'];
    }

    /**
     * get getDropHelpdeskMenu
     * @return mixed
     */
    public function getDropHelpdeskFooter()
    {
        return $this->fields['drop_helpdesk_footer'];
    }

    /**
     * get getDropHomeButton
     * @return mixed
     */
    public function getDropHomeButton()
    {
        return $this->fields['drop_home_button'];
    }

    /**
     * get getDropHomeButton
     * @return mixed
     */
    public function getDropLanguagesButton()
    {
        return $this->fields['drop_languages_button'];
    }

    /**
     * get getDropHomeButton
     * @return mixed
     */
    public function getDropHelpButton()
    {
        return $this->fields['drop_help_button'];
    }

    /**
     * get getDropHomeButton
     * @return mixed
     */
    public function getDropSavedsearchsButton()
    {
        return $this->fields['drop_savedsearchs_button'];
    }

    /**
     * get getDropHomeButton
     * @return mixed
     */
    public function getDropPreferencesButton()
    {
        return $this->fields['drop_preferences_button'];
    }

    /**
     * get getDropHomeButton
     * @return mixed
     */
    public function getDropLogoutButton()
    {
        return $this->fields['drop_logout_button'];
    }

    /**
     * @return mixed
     */
    public function seeMore()
    {
        return $this->fields['see_more_informations'];
    }

    /**
     * @return array
     */
    public function getFieldsMoreInformations()
    {
        global $CFG_GLPI;
        $fields_id = json_decode($this->fields["fields_more_informations"], true);

        $fieldsOrder = new PluginServicecatalogFieldorder();
        $condition = [1 => 1];
        if ($this->getBypassCategories() == 0) {
            $condition = ['NOT' => ['name' => 'itilcategories']];
        }
        if ($CFG_GLPI['notifications_mailing'] == 0) {
            $condition[] = ['NOT' => ['name' => 'InformMe']];
        }
        $fields = $fieldsOrder->find($condition, "ranking");

        $list_fields = [];
        if (is_array($fields_id) && count($fields_id) > 0) {
            foreach ($fields_id as $field) {
                foreach ($fields as $fieldinfo) {
                    if ($field == $fieldinfo["id"]) {
                        $list_fields[] = $fieldinfo["name"];
                    }
                }
            }
        }
        return $list_fields;
    }

    /**
     * @return mixed
     */
    public function seeFAQ()
    {
        return $this->fields['see_faq_articles'];
    }

    /**
     * @return mixed
     */
    public function seeCategoryDetails()
    {
        return $this->fields['see_category_details'];
    }

    /**
     * @return mixed
     */
    public function getDisplayLogoCategoryDetail()
    {
        return $this->fields['display_logo_category_detail'];
    }

    /**
     * @return mixed
     */
    public function getEnableKeywords()
    {
        return $this->fields['keywords'];
    }

    /**
     * @return mixed
     */
    public function getEnableGroupRestriction()
    {
        return $this->fields['groups_restriction'];
    }

    /**
     * @return mixed
     */
    public function getEnableGroupRestrictionRecursive()
    {
        return $this->fields['groups_restriction_recursive'];
    }

    /**
     * @return mixed
     */
    public function getMultiEntityRedirection()
    {
        return $this->fields['multi_entity_redirection'];
    }

    /**
     * @return mixed
     */
    public function getUseOwnColors()
    {
        return $this->fields['use_own_colors'];
    }

    /**
     * @return mixed
     */
    public function getLayout()
    {
        $layout = self::SLY;

        if ($this->getDemoMode() == 1) {
            if (isset($_SESSION["glpi_plugin_servicecatalog_demolayout"])) {
                $layout = $_SESSION["glpi_plugin_servicecatalog_demolayout"];
                return $layout;
            } else {
                $_SESSION["glpi_plugin_servicecatalog_demolayout"] = self::BOOTSTRAPPED_COLOR;
                return $layout;
            }
        }
        if ($this->fields['layout']
            && !empty($this->fields['layout'])) {
            $layout = $this->fields['layout'];
        }

        $layout_entities = PluginServicecatalogEntity::getUsedConfig($layout);
        if ($layout_entities !== false) {
            $layout = $layout_entities;
        }
        return $layout;
    }

    /**
     * @param $type
     * @param $i
     *
     * @return mixed
     */
    public function getColor($type, $i)
    {
        return $this->getField($type . '_' . $i);
    }

    /**
     * @return mixed
     */
    public function hideMailFollowup()
    {
        return $this->fields['hide_mail_followup'];
    }


    /**
     * @return mixed
     */
    public function useItemtypesDisplay()
    {
        return $this->fields['use_itemtypes_display'];
    }

    /**
     * @return mixed
     */
    public function addRequestersFromTickets()
    {
        return $this->fields['add_requesters_from_tickets'];
    }

    /**
     * @return mixed
     */
    public function addObserversFromTickets()
    {
        return $this->fields['add_observers_from_tickets'];
    }

    /**
     * @return mixed
     */
    //    function useAllTabDefault()
    //    {
    //        return $this->fields['use_all_tab_default'];
    //    }

    /**
     * @return mixed
     */
    public function getDisplayPhoneNumber()
    {
        return $this->fields['display_phone_number'];
    }


    /**
     * @return mixed
     */
    public function IsPhoneNumberMandatory()
    {
        return $this->fields['phone_mandatory'];
    }


    /**
     * @return mixed
     */
    public function getTitleRequesterGroup()
    {
        return $this->fields['title_requester_group'];
    }

    /**
     * @return mixed
     */
    public function getDisplayRequesterGroup()
    {
        return $this->fields['display_requester_group'];
    }

    /**
     * @return mixed
     */
    public function getTitlePhoneNumber()
    {
        return $this->fields['title_phone_number'];
    }

    //   /**
    //    * @return mixed
    //    */
    //   public function getDisplayTopMenu() {
    //      return $this->fields['display_topmenu'];
    //
    //   }

    /**
     * @return mixed
     */
    public function seeWidgetsBorder()
    {
        return $this->fields['see_widgets_border'];
    }

    /**
     * @return mixed
     */
    public function useRadiusBorder()
    {
        return $this->fields['radius_border'];
    }

    /**
     * @return mixed
     */
    public function getDisplayBrowserInformations()
    {
        return $this->fields['display_browser_infos'];
    }

    /**
     * @return mixed
     */
    public function getTitleFavoritesCategory()
    {
        return $this->fields['title_favorites_category'];
    }

    /**
     * @return mixed
     */
    public function getTicketTemplateAssociatedToUserInformationUpdate()
    {
        return $this->fields['template_ticket_user_update'];
    }

    /**
     * @return mixed
     */
    public function getTicketTemplateAssociatedToCancelTicket()
    {
        return $this->fields['template_cancel_ticket'];
    }


    /**
     * @return mixed
     */
    public function showAssetButtonUpdate()
    {
        return $this->fields['show_asset_update_button'];
    }

    /**
     * @return mixed
     */
    public function getTicketTemplateAssociatedToUserAssetsUpdate()
    {
        return $this->fields['template_ticket_assets_user_update'];
    }

    /**
     * @return mixed
     */
    public function getTicketTemplateAssociatedToTicketReservationCreation()
    {
        return $this->fields['template_ticket_reservation'];
    }

    /**
     * @return mixed
     */
    public function seetop()
    {
        return $this->fields['seetop'];
    }

    /**
     * @return mixed
     */
    public function see_myelements_menu()
    {
        return $this->fields['display_myelements_menu'];
    }

    /**
     * @return mixed
     */
    public function see_myappliances_menu()
    {
        return $this->fields['display_myappliances_menu'];
    }

    /**
     * @return mixed
     */
    public function see_closedtickets_menu()
    {
        return $this->fields['display_closedtickets_menu'];
    }

    /**
     * @return mixed
     */
    public function forceDelegating()
    {
        return $this->fields['force_delegating'];
    }

    /**
     * @return mixed
     */
    public function forceDelegatingUsers()
    {
        return $this->fields['force_delegating_restriction'];
    }

    /**
     * @return mixed
     */
    public function getActorUsers()
    {
        return $this->fields['actors_restriction'];
    }

    /**
     * @return mixed
     */
    public function createTicketReservation()
    {
        return $this->fields['create_ticket_reservation'];
    }

    /**
     * @return mixed
     */
    public function getDemoMode()
    {
        return $this->fields['demo_mode'];
    }

    /**
     * @return mixed
     */
    public function getDetailBeforeFormRedirect()
    {
        return $this->fields['use_detail_before_creation'] ?? 0;
    }

    /**
     * @return mixed
     */
    public function getFormDisplayAsStep()
    {
        $use_as_step = $this->fields['use_as_step'];
        if (isset($_SESSION["glpi_plugin_servicecatalog_demowizard"])
            && $this->getDemoMode() == 1) {
            $use_as_step = $_SESSION["glpi_plugin_servicecatalog_demowizard"];
        }
        return $use_as_step;
    }

    /**
     * @return mixed
     */
    public function switchpreferences()
    {
        return $this->fields['switch_prefs'];
    }

    /**
     * @return mixed
     */
    public function showIndicators()
    {
        return $this->fields['show_indicators'];
    }

    /**
     * @return mixed
     */
    public function showLinkedTicketsSimplifiedform()
    {
        return $this->fields['show_linked_tickets_simplifiedform'];
    }

    /**
     * @return mixed
     */
    public function useIntegratedSearch()
    {
        $use_integrated_search = $this->fields['use_integrated_search'];
        if (isset($_SESSION["glpi_plugin_servicecatalog_demosearch"]) && $this->getDemoMode() == 1) {
            $use_integrated_search = $_SESSION["glpi_plugin_servicecatalog_demosearch"];
        }
        return $use_integrated_search;
    }


    /**
     * @return mixed
     */
    public function useTableforlists()
    {
        $use_table_lists = $this->fields['use_table_lists'];
        if (isset($_SESSION["glpi_plugin_servicecatalog_demotablelist"]) && $this->getDemoMode() == 1) {
            $use_table_lists = $_SESSION["glpi_plugin_servicecatalog_demotablelist"];
        }
        return $use_table_lists;
    }

    /**
     * @return mixed
     */
    public function getDefaultNumberRows()
    {
        switch ($this->fields['default_number_rows']) {
            case 0:
                return '3';
            case 1:
                return '5';
            case 2:
                return '10';
            case 3:
                return '25';
            case 4:
                return '50';
            case 5:
                return '100';
        }
        return 5;
    }

    /**
     * @param $display
     *
     * @return string|void
     */
    public static function loadForLayout($display = true)
    {
        $self = new self();
        if ($self->getLayout() == PluginServicecatalogConfig::WRAPPER) {
            $css = Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/wrapper.css.php");
        } elseif ($self->getLayout() == PluginServicecatalogConfig::WRAPPERSLY) {
            $css = Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/wrappersly.css.php");
        } elseif ($self->getLayout() == PluginServicecatalogConfig::THUMBNAIL) {
            $css = Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/thumbnail_common.scss");
            $css .= Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/thumbnail.css.php");
        } elseif ($self->getLayout() == PluginServicecatalogConfig::THUMBNAIL_WRAPPER) {
            $css = Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/thumbnail_common.scss");
            $css .= Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/thumbnail_wrapper.css.php");
        } elseif ($self->getLayout() == PluginServicecatalogConfig::SLY) {
            $css = Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/slyonly.css.php");
            $css .= Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.css");
            $css .= Html::script(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/lib/jquery-ui/jquery-ui.min.js");
        } elseif ($self->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED
            || $self->getLayout() == PluginServicecatalogConfig::BOOTSTRAPPED_COLOR) {
            $css = Html::scss(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/bootstrapped_common.scss");
            $css .= Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/bootstrapped.css.php");
        } else if ($self->getLayout() == PluginServicecatalogConfig::SHOPER) {
            $css = Html::css(PLUGIN_SERVICECATALOG_NOTFULL_DIR . "/css/layout/shoper.css.php");
        }
        if ($display == true) {
            echo $css;
        } else {
            return $css;
        }
    }
}
