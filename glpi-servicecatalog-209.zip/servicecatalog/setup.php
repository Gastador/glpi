<?php
/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

define('PLUGIN_SERVICECATALOG_VERSION', '2.0.9');

if (!defined("PLUGIN_SERVICECATALOG_DIR")) {
    define("PLUGIN_SERVICECATALOG_DIR", Plugin::getPhpDir("servicecatalog"));
    define("PLUGIN_SERVICECATALOG_NOTFULL_DIR", Plugin::getPhpDir("servicecatalog", false));
    define("PLUGIN_SERVICECATALOG_WEBDIR", Plugin::getWebDir("servicecatalog"));
}

// Init the hooks of the plugins -Needed
function plugin_init_servicecatalog()
{
    global $PLUGIN_HOOKS, $CFG_GLPI;

    $PLUGIN_HOOKS['csrf_compliant']['servicecatalog'] = true;
    $PLUGIN_HOOKS['change_profile']['servicecatalog'] = ['PluginServicecatalogProfile', 'changeProfile'];
    $PLUGIN_HOOKS['change_entity']['servicecatalog']  = ['PluginServicecatalogEntity', 'changeEntity'];

    if ($CFG_GLPI["use_public_faq"]) {
        $PLUGIN_HOOKS['display_login']['servicecatalog'] = "plugin_servicecatalog_replace_faq";
    }

    $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'lib/fuze.js';
    $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'lib/fuzzysearch.js.php';

    if (Session::getLoginUserID()) {
        $PLUGIN_HOOKS['customtabs']['servicecatalog'] = ['PluginServicecatalogTicket', 'customtabs'];

        Plugin::registerClass('PluginServicecatalogProfile', ['addtabon' => 'Profile']);
        Plugin::registerClass('PluginServicecatalogLinkgroup', ['addtabon' => 'PluginServicecatalogLink']);
        Plugin::registerClass('PluginServicecatalogApplianceLink', ['addtabon' => 'Appliance']);
        Plugin::registerClass('PluginServicecatalogTicketAppointment', ['notificationtemplates_types' => true]);

        if (Session::haveRight('plugin_servicecatalog_links', CREATE)) {
            $PLUGIN_HOOKS["menu_toadd"]['servicecatalog']
            = ['plugins' => 'PluginServicecatalogLink'];

        }
        if (Session::haveRight('plugin_servicecatalog_shortcuts', CREATE)) {
            $PLUGIN_HOOKS['menu_toadd']['servicecatalog']['tools'] = 'PluginServicecatalogShortcut';
        }

        // Display a menu entry
        if (Session::haveRight("plugin_servicecatalog_setup", UPDATE)) {
            $PLUGIN_HOOKS['use_massive_action']['servicecatalog'] = 1;
            $PLUGIN_HOOKS['config_page']['servicecatalog']        = 'front/config.form.php';

            Plugin::registerClass('PluginServicecatalogCategory', ['addtabon' => 'ITILCategory']);
            Plugin::registerClass('PluginServicecatalogCategoryTranslation', ['addtabon' => 'ITILCategory']);
            Plugin::registerClass('PluginServicecatalogEntity', ['addtabon' => 'Entity']);
            Plugin::registerClass('PluginServicecatalogDashboard', ['addtabon' => 'Entity']);
            Plugin::registerClass('PluginServicecatalogTicketTemplate', ['addtabon' => 'TicketTemplate']);
            Plugin::registerClass('PluginServicecatalogKnowbaseitem_Keyword', ['addtabon' => 'KnowbaseItem']);
        }

        if (Session::haveRight("plugin_servicecatalog_favorites", UPDATE)) {
            Plugin::registerClass('PluginServicecatalogFavorite', ['addtabon' => 'ITILCategory']);
        }
        if (Plugin::isPluginActive('servicecatalog')) { // only if plugin activated
            $PLUGIN_HOOKS['plugin_datainjection_populate']['servicecatalog'] = 'plugin_datainjection_populate_servicecatalog';
        }

        $PLUGIN_HOOKS['pre_item_purge']['servicecatalog'] = ['ITILCategory' =>
                                                              ['PluginServicecatalogCategory', 'pre_delete_category']];
        if (Plugin::isPluginActive("servicecatalog")) {
            if (Session::haveRight('plugin_servicecatalog', READ)
             && Session::getCurrentInterface() == "helpdesk") {
                $PLUGIN_HOOKS['redefine_menus']['servicecatalog'] = ['PluginServicecatalogMain',
                                                                 'getNavBarMenu'];
            }
            $PLUGIN_HOOKS['item_empty']['servicecatalog'] = ['Ticket' =>
                                                             ['PluginServicecatalogTicket', 'emptyTicket']];

            if (Session::haveRight('plugin_servicecatalog_checkticket', CREATE)) {
                $PLUGIN_HOOKS['pre_show_item']['servicecatalog'] = ['PluginServicecatalogTicketcheck',
                                                                'checkCategory'];

               //            $PLUGIN_HOOKS['pre_item_add']['servicecatalog'] = ['PluginServicecatalogTicket',
               //                                                               'checkAdditionalFields'];
            }

            $config = new PluginServicecatalogConfig();

            if (strpos($_SERVER['PHP_SELF'], 'ticket') > 0
             && $_SESSION['glpiactiveprofile']['interface'] != 'central'
             && Session::haveRight('plugin_servicecatalog', READ)) {
                $PLUGIN_HOOKS['add_javascript']['servicecatalog'][] = 'scripts/replace_tabs_update_ticket_form.js.php';
            }
            if ((isset($_SESSION["glpiactiveprofile"])
              && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") &&
             (strpos($_SERVER['REQUEST_URI'], "ticket.form.php") !== false)) {
                $PLUGIN_HOOKS['post_item_form']['servicecatalog'] = ['PluginServicecatalogTicket',
                                                                 'showTicketForm'];
            }

            if (Session::haveRight("plugin_servicecatalog", READ)) {
                $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'scripts/replace_menu_postonly.js.php';

                if(isset($_GET['ignore_redirect'])){
                    $_SESSION["glpi_plugin_servicecatalog_loaded"] = 1;
                }

                if (isset($_SERVER['HTTP_REFERER'])
                && strpos($_SERVER['HTTP_REFERER'], 'redirect') !== false) {
                    $_SESSION["glpi_plugin_servicecatalog_loaded"] = 1;
                }

                if (strpos($_SERVER['REQUEST_URI'], 'apirest.php') === false) {
                    if (isset($_SESSION["glpi_plugin_servicecatalog_loaded"])
                    && $_SESSION["glpi_plugin_servicecatalog_loaded"] == 0) {
                        $_SESSION["glpi_plugin_servicecatalog_loaded"] = 1;
                        Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
                    }
                }
                if (strpos($_SERVER['REQUEST_URI'], 'helpdesk.public.php') !== false
                && isset($_SESSION["glpi_plugin_servicecatalog_loaded"])
                && $_SESSION["glpi_plugin_servicecatalog_loaded"] == 0) {
                    $_SESSION["glpi_plugin_servicecatalog_loaded"] = 1;
                    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/main.form.php");
                }
                //redirect for addMessageAfterRedirect inks
                if (isset($_SESSION["glpiactiveprofile"])
                && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk"
                && strpos($_SERVER['REQUEST_URI'], "servicecatalog") == false
                && strpos($_SERVER['REQUEST_URI'], 'ticket.form.php?id') !== false) {
                    $id = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
                    $id = ltrim($id, "id=");
                    Html::redirect(PLUGIN_SERVICECATALOG_WEBDIR . "/front/ticket.form.php?id=$id");
                }
                //modify links for complete interface
                if (Session::haveRight("ticket", CREATE)) {
                    $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'scripts/replace_links.js.php';
                }

                if ($config->getDropHomeButton()
                && isset($_SESSION["glpiactiveprofile"]["interface"])
                && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
                    $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'scripts/drop_home_button.js.php';
                }
            }


            if (isset($_SESSION["glpiactiveprofile"])
                && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk") {
                $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'scripts/servicecatalog_helpdesk.js.php';
            } else {
                $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'scripts/servicecatalog_central.js.php';
            }



           //         if (isset($_SERVER['REQUEST_URI'])
           //             && (strpos($_SERVER['REQUEST_URI'], "main.form.php") !== false
           //                 || strpos($_SERVER['REQUEST_URI'], "newticket.form.php") !== false)) {
           //            $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'scripts/servicecatalog_search.js.php';
           //            $PLUGIN_HOOKS["add_javascript"]['servicecatalog'][] = 'scripts/servicecatalog_back.js.php';
           //         }
            $PLUGIN_HOOKS['add_javascript']['servicecatalog'][] = "lib/redips/redips-drag-min.js";
            $PLUGIN_HOOKS['add_javascript']['servicecatalog'][] = "scripts/plugin_servicecatalog_drag-field-row.js";


           //         if ((isset($_SESSION["glpiactiveprofile"])
           //              && $_SESSION["glpiactiveprofile"]["interface"] == "central") &&
           //             (strpos($_SERVER['REQUEST_URI'], "ticket.form.php") !== false
           //              || strpos($_SERVER['REQUEST_URI'], "main.form.php") !== false)) {
           //            $PLUGIN_HOOKS["add_css"]['servicecatalog'][] = 'css/servicecatalog_interface.css.php';
           //         }

            if (isset($_SESSION["glpiactiveprofile"])
             && $_SESSION["glpiactiveprofile"]["interface"] == "helpdesk"
             && $config->getDropHelpdeskFooter()) {
                $PLUGIN_HOOKS['add_css']['servicecatalog'][] = "css/footer.css";
            }
            //Add another actions after answer
            $PLUGIN_HOOKS['timeline_actions']['servicecatalog'] = ['PluginServicecatalogTicketAction',
                                                                'showActionsForm'];
            //Add another actions into answer
            $PLUGIN_HOOKS['timeline_answer_actions']['servicecatalog'] = ['PluginServicecatalogTicketaction',
                                                                       'addToTimeline'];

           //         //Need to add Plugin::doHook('add_timeline', ['item' => $this, 'timeline' => &$timeline]); at the end
           //         //of getTimelineItems function of commonitilobject.class.php
            $PLUGIN_HOOKS['show_in_timeline']['servicecatalog'] = ['PluginServicecatalogTicketAppointment',
                                                                'addToTimeline'];

            $PLUGIN_HOOKS['mydashboard']['servicecatalog'] = ["PluginServicecatalogIndicator"];

            if (Plugin::isPluginActive("formcreator")) {
                $PLUGIN_HOOKS['servicecatalog']['formcreator'] = ["PluginFormcreatorServicecatalog"];
                Plugin::registerClass('PluginServicecatalogFormcreator', ['addtabon' => 'PluginFormcreatorForm']);
            }
        }
    }
    $PLUGIN_HOOKS["add_css"]['servicecatalog'][] = 'css/servicecatalog.scss';
}

/**
 * Get the name and the version of the plugin - Needed
 *
 * @return array
 */
function plugin_version_servicecatalog()
{
    return [
      'name'         => __('Service catalog', 'servicecatalog'),
      'version'      => PLUGIN_SERVICECATALOG_VERSION,
      'license'      => 'GPLv2+',
      'author'       => "<a href='http://infotel.com/services/expertise-technique/glpi/'>Infotel</a>, Amandine Manceau",
      'homepage'     => '',
      'requirements' => [
         'glpi' => [
            'min' => '10.0.1',
            'max' => '11.0.0',
            'dev' => false
         ]
      ]
    ];
}
