<?php
header("Content-type: text/css; charset: UTF-8");
include('../../../../inc/includes.php');
$config = new PluginServicecatalogConfig();
$navbarcolor  = $config->getNavBarColor();
$titlecolor  = $config->getTitleColor();
$titlebackgroundcolor  = $config->getTitleBackgroundColor();
$color  = $config->getGeneralColor();
$hover  = $config->getGeneralHoverColor();
?>

#sidebar-container, .navbar-vertical {
    background-color: <?php echo $navbarcolor; ?>;
    padding: 0;
    /* flex: unset; */
}

a.bg-dark-sc:hover, a.bg-dark-sc:focus,
button.bg-dark-sc:hover,
button.bg-dark-sc:focus {
    background-color: <?php echo $navbarcolor; ?>;
}

.bg-dark-sc {
    background-color: <?php echo $navbarcolor; ?>!important;
    /*background-color: unset!important;*/
    box-sizing: border-box;
}

#sidebar-container .list-group a.is_active {
   background-color: <?php echo $navbarcolor; ?>!important;
   cursor:pointer;
   background: rgba(0, 0, 0, 0.08) !important;
}

#sidebar-container .list-group a:hover,
#sidebar-container .list-group a:active,
#sidebar-container .list-group a:focus {
   background-color: <?php echo $navbarcolor; ?>!important;
   cursor:pointer;
   background: rgba(0, 0, 0, 0.08) !important;
}

.alert-secondary {
    color: <?php echo $titlecolor; ?>!important;
    background-color: <?php echo $titlebackgroundcolor; ?>!important;
    opacity: 0.9;
    border-color: <?php echo $titlebackgroundcolor; ?>!important;
   font-family: var(--tblr-body-font-family);
   font-size: var(--tblr-body-font-size);
   font-weight: var(--tblr-body-font-weight);
   line-height: var(--tblr-body-line-height);
}

.sc-color,
.sc-hover,
.fa-back,
.topnav a,
.sc-search {
    color: <?php echo $titlecolor; ?>!important;
}

.sc-color:hover,
.sc-hover:hover,
.fa-back:hover,
.topnav:hover a,
.sc-search:hover {
    color: <?php echo $titlecolor; ?>!important;
}

.title-cat {
    color: <?php echo $titlecolor; ?>!important;
}

.btn-back {
color: #ffffff;
background-color: <?php echo $color; ?> !important;
border-color: <?php echo $color; ?> !important;
}

.btn-primary {
color: #ffffff;
background-color: <?php echo $color; ?> !important;
border-color: <?php echo $color; ?> !important;
}

.btn-primary:focus,
.btn-primary.focus {
color: #ffffff;
background-color: <?php echo $color; ?> !important;
border-color: <?php echo $color; ?> !important;
}

.btn-primary:hover {
color: #ffffff;
background-color: <?php echo $hover; ?> !important;
border-color: <?php echo $hover; ?> !important;
}


.buttonelt:hover,
.buttonelt:focus,
.buttonelt:active {
background-color: <?php echo $color; ?> !important;
color:white;
}

.buttonelt_color {
background-color: <?php echo $color; ?> !important;
color:white;
}
