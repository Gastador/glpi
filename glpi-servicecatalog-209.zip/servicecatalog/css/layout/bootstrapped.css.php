<?php
header("Content-type: text/css; charset: UTF-8");
include('../../../../inc/includes.php');
$config = new PluginServicecatalogConfig();
$color  = $config->getGeneralColor();
$hover  = $config->getGeneralHoverColor();
$colortheme = $config->getTheme();
?>

.widgetrow,
.itemsdisplay {
    background-color: <?php echo $colortheme; ?>;
}

.grid-stack > .grid-stack-item > .grid-stack-item-content,
div[class^="mostsc"],
div[class^="menusc"],
div[class^="linksc"],
div[class^="favsc"] {
    background-color: <?php echo $colortheme; ?>;
}

div[class^="menusc"]:hover,
li[class^="first-btnsc"]:hover,
div[class^="btnsc"]:hover,
div[class^="btnsc"]:active,
div[class^="favsc"]:hover,
div[class^="searchsc"]:hover,
div[class^="mostsc"]:active,
div[class^="mostsc"]:hover,
div[class^="linksc"]:hover,
visitedbg,
faqrow {
    background-color: #cccccc1f !important;
}

table.dataTable tbody tr {
    background-color: <?php echo $colortheme; ?>;
}


div[class^="menusc"] {
    float: left;
    list-style-type: none;
    padding: 4px 15px 15px 15px;
    overflow: auto;
    margin: 10px;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    border: solid #CCC 1px;
    background-color: <?php echo $colortheme; ?>;
}

.events_list,
.search_list,
.cats_list,
.cats_firstlist {
    background-color: <?php echo $colortheme; ?>;
    border: #E6E6E6 1px solid;
}

@media only screen and (min-width: 768px) {
    .cd-faq-content {
        background-color: <?php echo $colortheme; ?>;
    }
}

.subcats_list {
    display: grid;
    display: -ms-grid;
}


/*
@media (max-width: 380px) {
#faq {
width: 240px;
}
}

@media (min-width: 380px) and (max-width: 768px) {
#faq {
width: 280px;
margin-left: 15px;
}
}

@media (min-width: 768px) and (max-width: 1367px) {
#faq {
width: 290px;
}
}

@media (min-width: 1367px) and (max-width: 1500px) {
#faq {
width: 310px;
}
}

@media  (min-width: 1500px) and (max-width: 1600px) {
#faq {
width: 310px;
}
}
*/


ul.ul_comment {
    list-style-type: initial;
    margin-left: 20px;
}

.tooltip-details {
    font-size: 11px;
}

@media screen and (max-width: 900px) {
    .details {
        font-size: 12px;

    }
}

@media (min-width: 900px) and (max-width: 1366px) {
    .details {
        font-size: 12px;

    }
}

@media only screen and (min-width: 1367px) and (max-width: 1600px) {
    .details {
        font-size: 12px;

    }
}

@media (min-width: 1601px) {
    .details {
        font-size: 12px;

    }
}

.css_ticket {
    border: solid #CCC 1px;
    padding: 15px;
}

/*
div#launch_ticket {
margin: 10px;
}

.sc-row-ticket {
background-color: #FFF!important;
}
*/


.visitedchildbg {
    background-color: <?php echo $colortheme; ?>;
}

.sc-title-divider {
    background: none !important;
}

.sc-title-divider span {
    background: none !important;
}


.menusc-entity-normal {
    width: 300px !important;
    min-height: 250px;
}

.img-entity {
    /*margin: 10px 5px 15px 0;*/
    float: left;
}

a.thumbnail {
    margin: 0 15px 15px 0;
    font-size: inherit;
    width: 15%;
}

img.bt-img-responsive {
    background-size: auto !important;
    width: 50% !important;
}

img.bt-img-fav {
    background-size: initial !important;
    width: 15%;
    border: none;
}

img.bt-img-responsive-details {
    width: 25% !important;
}

img.bt-img-link-responsive {
    width: 50% !important;
}

.bt-features .bt-feature img:hover {
    background-image: none;
    background-repeat: no-repeat;
    background-color: <?php echo $colortheme; ?>;
}

i.thumbnail {
    float: left;
    margin: 20px 15px 60px 0;
}

.sc-buttons {
    margin: 30px 15px 0px 0;
}

i.thumbnail_child {
    float: left;
    margin: 20px 15px 15px 0;
}

.btnsc-big {
    width: 300px;
}

.btnsc-normal {
    width: 250px;
}

.btnsc-small {
    width: 120px;
}

/*.stick {*/
/*   margin-right: 0 !important;*/
/*}*/

/*.Start{*/
/*   color: white;*/
/*   font: normal 50px 'Yanone Kaffeesatz', sans-serif;*/
/*   margin-bottom: 20px;*/
/*   cursor: pointer;*/
/*   user-select: none;*/
/*   transition: all .3s ease;*/
/*}*/
/*.Start:hover{*/
/*   text-shadow: 0 0 4px white;*/
/*}*/
.space {
    margin-bottom: 110px;
}

.sc-fa-color {
    color: <?php echo $color; ?> !important;
    vertical-align: middle;
}


.label_firsttitle {
    color: <?php echo $color; ?>;
    font-size: 13px;
    margin-left: 5px;
    background-color: unset !important;
    border: none !important;
}

.label_firsttitle:hover,
.label_firsttitle: * {
    color: <?php echo $color; ?>;
    font-size: 13px;
    margin-left: 5px;
    background-color: unset !important;
    box-shadow: unset !important;
    border: none !important;
}

.label_favtitle {
    position: relative;
    margin-right: 10px;
    margin-bottom: 10px;
    margin-left: 5px;
    margin-top: 10px;
    display: inline-block;
    font-size: 12px;
    font-family: inherit;
    font-weight: normal;
}

.fav-btn-i {
    padding: 10px;
    color: #FFFFFF !important;
}


.label_title {
    color: <?php echo $color; ?>;
    font-size: 12px;
    display: inline-flex;
}

.label {
    color: <?php echo $hover; ?>;
    font-size: 11px;
    left: 10px;
    text-align: left;
}

.bottom {
    bottom: 5px;
    margin-left: 20px;
}

.top {
    top: 5px;
}

.plugin_servicecatalog_formTitlekb {
    margin: 5px 5px 5px 5px;
    width: 250px;
    display: inline-block;
    vertical-align: top;
    text-align: left;
    overflow: hidden;
    cursor: pointer;
    border-radius: 0px;
    -moz-border-radius: 0px;
    -webkit-border-radius: 0px;
    padding: 10px;
    background-color: <?php echo $colortheme; ?>;
}

.red-folder,
.blue-folder,
.orange-folder,
.green-folder,
.purple-folder,
.red-light-folder,
.marroon-folder,
.turquoise-folder,
.gray-folder,
.gray2-folder,
.green-bright-folder,
.blue-nav-folder,
.redish-folder,
.lagoon-folder {
    background: rgba(245, 245, 245, 1);
}

.red
.blue,
.orange,
.green,
.purple,
.red-light,
.marroon,
.turquoise,
.gray,
.gray2,
.green-bright,
.blue-nav,
.redish,
.lagoon {
    background: rgb(255, 255, 255);
}

.grayback {
    background: rgba(245, 245, 245, 1);
}

.keywords {
    font-size: 11px;
    font-family: inherit;
    font-style: italic;
    /*margin:0 0 0 1em;  indentation */
    font-weight: normal;
    padding: 0;
    list-style: none;
    /*color: #000 !important;*/
    left: 10px;
}

.keywords_founded {
    font-size: 11px;
    position: absolute;
    bottom: 5px;
    left: 5px;
    color: #CCC;
    font-weight: normal;
}

@keyframes fade {
    0% {
        opacity: 0;
    }
    10% {
        opacity: 1;
    }
    50% {
        opacity: 1;
    }
    60% {
        opacity: 0;
    }
}

.fa-white {
    color: #FFFFFF;
}

.fa-gray {
    color: #000000 !important;
}

.background_title {
    background-image: linear-gradient(to bottom, #fafafa 0px, #ebebeb 100%);
}

.fa-back {
    color: <?php echo $color; ?>;
}

.fas-sc {
    margin-top: 20px;
}

.fas-sc-small {
    margin-top: 10px;
}

.far-sc {
    margin-top: 20px !important;
}

.fa-menu-sc {
    margin-top: 20px;
    margin-bottom: 20px;
}
.sc-tag,
.label {
    font-size: 11px;
}

.tags {
    position: relative;
}

.tags:hover:after {
    margin-left: 10px;
    content: attr(data-title);
    padding: 10px;
    background: #9b9797;
    border-radius: 2px;
}

.tags:hover::after {
    display: inline-table;
}
