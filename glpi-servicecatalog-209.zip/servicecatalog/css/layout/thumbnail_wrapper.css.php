<?php
header("Content-type: text/css; charset: UTF-8");
include('../../../../inc/includes.php');
$config = new PluginServicecatalogConfig();
$color  = $config->getGeneralColor();
$hover  = $config->getGeneralHoverColor();
$colortheme = $config->getTheme();
?>

.grid-stack > .grid-stack-item > .grid-stack-item-content,
div[class^="favsc"],
.itemsdisplay {
    background-color: <?php echo $colortheme; ?>;
    border: solid #CCC 1px;
}

div[class^="menusc"] {
    float: left;
    list-style-type: none;
    padding: 4px 15px 15px 15px;
    overflow: auto;
    margin: 10px;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    border: solid #CCC 1px;
    background-color: <?php echo $colortheme; ?>;
}


.itemsdisplay {
    background-color: <?php echo $colortheme; ?>;
}

@media (max-width: 380px) {
    .subcats_list {
        border: solid #CCC 1px;
    }
}

@media (min-width: 380px) and (max-width: 768px) {
    .subcats_list {
        width: 280px;
        margin-left: 15px;
    }
}

@media (min-width: 768px) and (max-width: 1367px) {
    .subcats_list {
        width: 290px;
    }
}

@media (min-width: 1367px) and (max-width: 1500px) {
    .subcats_list {
        width: 310px;
    }
}

@media (min-width: 1500px) and (max-width: 1600px) {
    .subcats_list {
        width: 310px;
    }
}

@media (min-width: 1600px) {
    .subcats_list {
        width: 650px;
    }
}

@media (max-width: 380px) {
    #faq {
        width: 240px;
    }
}

@media (min-width: 380px) and (max-width: 768px) {
    #faq {
        width: 280px;
        margin-left: 15px;
    }
}

@media (min-width: 768px) and (max-width: 1367px) {
    #faq {
        width: 290px;
    }
}

@media (min-width: 1367px) and (max-width: 1500px) {
    #faq {
        width: 310px;
    }
}

@media (min-width: 1500px) and (max-width: 1600px) {
    #faq {
        width: 310px;
    }
}

@media (min-width: 1600px) {
    #faq {
        width: unset;
    }
}


@media (max-width: 380px) {
    .favorites_list {
        display: none !important;
        float: right;
        margin-top: 10px;
        border: solid #CCC 1px;
        padding: 15px;
        margin-bottom: 15px;
        width: 250px;
    }
}

.favorites_list {
    background-color: #FFF
}

@media (min-width: 380px) and (max-width: 1366px) {
    .favorites_list {
        display: none !important;
        float: right;
        margin-top: 10px;
        border: solid #CCC 1px;
        padding: 15px;
        margin-bottom: 15px;
        width: 250px;
    }
}

@media (min-width: 1367px) and (max-width: 1440px) {
    .favorites_list {
        display: none !important;
        float: right;
        margin-top: 10px;
        border: solid #CCC 1px;
        padding: 15px;
        margin-bottom: 15px;
        width: 250px;
    }
}

@media (min-width: 1440px) {
    .favorites_list {
        float: right;
        margin-top: 10px;
        border: solid #CCC 1px;
        padding: 15px;
        margin-bottom: 15px;
    }
}


@media (min-width: 1367px) and (max-width: 1500px) {
    .ticket_description {
        width: 450px;
    }
}

@media (min-width: 1500px) {
    .ticket_description {
        width: 560px;
    }
}


.details {
    /*background-color: */<?php //echo $colortheme; ?>/*;*/
}

@media (max-width: 380px) {
    .launch_details {
        width: 250px;
    }
}

@media (min-width: 380px) and (max-width: 1600px) {
    .launch_details {
        width: 350px;
    }
}

.tooltip-details {
    font-size: 11px;
}

@media screen and (max-width: 900px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 450px;
    }
}

@media (min-width: 900px) and (max-width: 1366px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 500px;
    }
}

@media only screen and (min-width: 1367px) and (max-width: 1500px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 750px;
        min-width: 500px;
    }
}

@media (min-width: 1500px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 1000px;
        min-width: 500px;
    }
}

.events li {
    display: grid;
    display: -ms-grid;
}


@media (max-width: 1366px) {
    .thumbnail_grid {
        display: grid;
        grid-template-columns: 1fr;
        -ms-grid-columns: 1fr;
        display: -ms-grid;
    }
}

@media only screen and (min-width: 1367px) and (max-width: 1600px) {
    .thumbnail_grid {
        display: grid;
        display: -ms-grid;
        grid-template-columns: 1fr;
        -ms-grid-columns: 1fr;
    }
}

@media (min-width: 1600px) {
    .thumbnail_grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        column-gap: 10px;
        display: -ms-grid;
        -ms-grid-columns: 2fr 1fr;
    }
}

.css_ticket {
    border: solid #CCC 1px;
    padding: 15px;
}

/*
div#launch_ticket {
margin: 10px;
}

.sc-row-ticket {
background-color: #FFF!important;
}
*/
div[class^="btnsc"] {
    list-style-type: none;
    padding: 4px 15px 15px 15px;
    overflow: auto;
    margin-bottom: 10px;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    border: solid #CCC 1px;
    transform: scale(.98, .98);
}

.visitedchildbg {
    transform: scale(.98, .98);
}

.sc-title-divider {
    background: none !important;
}

.sc-title-divider span {
    background: none !important;
}


.menusc-entity-normal {
    width: 300px !important;
    min-height: 250px;
}

.img-entity {
    /*margin: 10px 5px 15px 0;*/
    float: left;
}


img.bt-img-responsive {
    /*float: left;*/
    /*margin: 20px 15px 15px 0;*/
    background-size: auto !important;
    /*width: 30%;*/
    height: auto;
    max-width: 35%;
    margin: 15px;
}

img.bt-img-responsive-details {
    width: 25% !important;
}

img.bt-img-fav {
    background-size: initial !important;
    width: 15%;
    border: none;
}

.bt-features .bt-feature img:hover {
    background-image: none;
    background-repeat: no-repeat;
    background-color: <?php echo $colortheme; ?>;
}

.sc-buttons {
    margin: 30px 15px 0px 0;
}

i.thumbnail_child {
    float: left;
    margin: 20px 15px 15px 0;
}

/*.stick {*/
/*   margin-right: 0 !important;*/
/*}*/

/*.Start{*/
/*   color: white;*/
/*   font: normal 50px 'Yanone Kaffeesatz', sans-serif;*/
/*   margin-bottom: 20px;*/
/*   cursor: pointer;*/
/*   user-select: none;*/
/*   transition: all .3s ease;*/
/*}*/
/*.Start:hover{*/
/*   text-shadow: 0 0 4px white;*/
/*}*/
.space {
    margin-bottom: 110px;
}

/*.bottom_title{margin-top: 120px;}*/
.bottom {
    bottom: 5px;
    margin-left: 20px;
    display: block;
}

.top {
    top: 5px;
}

.plugin_servicecatalog_formTitlekb {
    margin: 5px 5px 5px 5px;
    width: 250px;
    display: inline-block;
    vertical-align: top;
    text-align: left;
    overflow: hidden;
    cursor: pointer;
    border-radius: 0px;
    -moz-border-radius: 0px;
    -webkit-border-radius: 0px;
    padding: 10px;
    background-color: <?php echo $colortheme; ?>;
}

.red-folder,
.blue-folder,
.orange-folder,
.green-folder,
.purple-folder,
.red-light-folder,
.marroon-folder,
.turquoise-folder,
.gray-folder,
.gray2-folder,
.green-bright-folder,
.blue-nav-folder,
.redish-folder,
.lagoon-folder {
    background: rgba(245, 245, 245, 1);
}

.red
.blue,
.orange,
.green,
.purple,
.red-light,
.marroon,
.turquoise,
.gray,
.gray2,
.green-bright,
.blue-nav,
.redish,
.lagoon {
    background: rgb(255, 255, 255);
}

.grayback {
    background: rgba(245, 245, 245, 1);
}

/*::-webkit-scrollbar{*/
/*   width: 10px;*/
/*   height: 10px;*/
/*   cursor: pointer;*/
/*}*/
/*::-webkit-scrollbar-track {*/
/*   -webkit-box-shadow: inset 0 0 6px 2px rgba(0,0,0,0.3);*/
/*   background: #007491;*/
/*}*/
/*::-webkit-scrollbar-thumb {*/
/*   background: #002f3b;*/
/*   -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5);*/
/*   cursor: pointer;*/
/*}*/
/*::selection{*/
/*   background: mintcream;*/
/*}*/

/*@keyframes flip {*/
/*   0% {*/
/*      transform: rotateX(0deg);*/
/*   }*/
/*   15% {*/
/*      transform: rotateX(360deg);*/
/*   }*/
/*   100% {*/
/*      transform: rotateX(360deg);*/
/*   }*/
/*}*/

/*.photo img {*/
/*   top: -4px;*/
/*   left: -4px;*/
/*   position: absolute;*/
/*   opacity: 0;*/
/*   animation: fade 8s ease-in-out infinite 8s;*/
/*   z-index: 0;*/
/*   border: solid 2px transparent;*/
/*   transition: all .3s ease;*/
/*}*/

/*.photo img:hover {*/
/*   border: solid 2px mintcream;*/
/*}*/

@keyframes fade {
    0% {
        opacity: 0;
    }
    10% {
        opacity: 1;
    }
    50% {
        opacity: 1;
    }
    60% {
        opacity: 0;
    }
}

.fa-white {
    color: #FFFFFF;
}

.fa-gray {
    color: #000000 !important;
}

.sc-fa-color {
    color: <?php echo $color; ?> !important;
    vertical-align: middle;
}

.background_title {
    background-image: linear-gradient(to bottom, #fafafa 0px, #ebebeb 100%);
}

.fa-back {
    color: <?php echo $color; ?>;
}

.fas-sc {
    margin-top: 20px;
}

.fas-sc-small {
    margin-top: 10px;
}


.far-sc {
    margin-top: 20px !important;
}

.fa-menu-sc {
    margin-top: 20px;
}

.sc-tag {
    font-size: 11px;
}

.tags {
    position: relative;
}

.tags:hover:after {
    margin-left: 10px;
    content: attr(data-title);
    padding: 10px;
    background: #9b9797;
    border-radius: 2px;
}

.tags:hover::after {
    display: inline-table;
}

.fa-white {
    color: #FFFFFF;
}

.keywords {
    font-size: 11px;
    font-family: inherit;
    /*font-style: italic;
    margin:0 0 0 1em;  indentation */
    font-weight: normal;
    padding: 0;
    list-style: none;
    color: #fff !important;
}

.keywords_founded {
    font-size: 11px;
    position: absolute;
    bottom: 5px;
    left: 5px;
    color: #CCC;
    font-weight: normal;
}


div[class^="btnsc"]:hover {
    opacity: 0.7;
}

div[class^="btnsc"]:active {
    transform: scale(.98, .98);
}

<!--
.btnsc-big {
--> <!-- width: 350 px;
--> <!--
}

-->
<!--
-->
<!--
.btnsc-normal {
--> <!-- width: 200 px;
--> <!--
}

-->
<!--
-->
<!--
.btnsc-small {
--> <!-- width: 120 px;
--> <!--
}

-->

i.thumbnail {
    float: left;
    margin: 20px 15px 60px 0;
}

.bt-features .bt-feature img:hover {
    background-image: unset;
    background-repeat: unset;
    background-color: <?php echo $colortheme; ?>;
}

.stick {
    margin-right: 0 !important;
}

/*.Start{*/
/*   color: white;*/
/*   font: normal 50px 'Yanone Kaffeesatz', sans-serif;*/
/*   margin-bottom: 20px;*/
/*   cursor: pointer;*/
/*   user-select: none;*/
/*   transition: all .3s ease;*/
/*}*/
/*.Start:hover{*/
/*   text-shadow: 0 0 4px white;*/
/*}*/
.space {
    margin-bottom: 110px;
}

.label_firsttitle {
    /*position: absolute;*/
    color: white;
    font-size: 12px;
    font-family: inherit;
    margin-left: 20px;
}

.label_favtitle {
    position: relative;
    color: white;
    margin-right: 10px;
    margin-bottom: 10px;
    margin-left: 5px;
    margin-top: 10px;
    display: inline-block;
    font-size: 12px;
    font-family: inherit;
    font-weight: normal;
}

.label_title {
    color: white;
    font-size: 12px;
    font-family: inherit;
}

.label {
    color: white;
    font-size: 12px;
    left: 10px;
    text-align: left;
}

.bottom {
    bottom: 5px;
}

.top {
    top: 5px;
}

.red,
.red-folder {
    border: none !important;
}

.blue,
.blue-folder {
    background: #00a9ec;
    border: none !important;
}

.orange,
.orange-folder {
    background: #ff9000;
    border: none !important;
}

.green,
.green-folder {
    background: #4a9a4e;
    border: none !important;
}

.purple,
.purple-folder {
    background: rgba(139, 1, 137, 0.52);
    border: none !important;
}

.red-light,
.red-light-folder {
    background: #ce4e4e;
    border: none !important;
}

.marroon,
.marroon-folder {
    background: #53150b;
    border: none !important;
}

.turquoise,
.turquoise-folder {
    background: #007491;
    border: none !important;
}

.gray,
.gray-folder {
    background: rgba(61, 61, 61, 0.32);
    border: none !important;
    /*animation: flip 6s linear infinite;*/
    /*transform: rotateX(0deg);*/
}

.grayback {
    background: rgba(61, 61, 61, 0.32);
    border: none !important;
    /*animation: flip 6s linear infinite;*/
    /*transform: rotateX(0deg);*/
}

.gray2,
.gray2-folder {
    background: rgba(61, 61, 61, 0.49);
    border: none !important;
    /*animation: flip 6s linear infinite;*/
    /*transform: rotateX(0deg);*/
}

.green-bright,
.green-bright-folder {
    background: #78d204;
    border: none !important;
}

.blue-nav,
.blue-nav-folder {
    background: #004f91;
    border: none !important;
}

.redish,
.redish-folder {
    background: #fe677d;
    border: none !important;
}

.lagoon,
.lagoon-folder {
    background: rgba(74, 171, 255, 0.64);
    border: none !important;
}

/*::-webkit-scrollbar{*/
/*   width: 10px;*/
/*   height: 10px;*/
/*   cursor: pointer;*/
/*}*/
/*::-webkit-scrollbar-track {*/
/*   -webkit-box-shadow: inset 0 0 6px 2px rgba(0,0,0,0.3);*/
/*   background: #007491;*/
/*}*/
/*::-webkit-scrollbar-thumb {*/
/*   background: #002f3b;*/
/*   -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5);*/
/*   cursor: pointer;*/
/*}*/
/*::selection{*/
/*   background: mintcream;*/
/*}*/

@keyframes flip {
    0% {
        transform: rotateX(0deg);
    }
    15% {
        transform: rotateX(360deg);
    }
    100% {
        transform: rotateX(360deg);
    }
}

/*.photo img {*/
/*   top: -4px;*/
/*   left: -4px;*/
/*   position: absolute;*/
/*   opacity: 0;*/
/*   animation: fade 8s ease-in-out infinite 8s;*/
/*   z-index: 0;*/
/*   border: solid 2px transparent;*/
/*   transition: all .3s ease;*/
/*}*/

/*.photo img:hover {*/
/*   border: solid 2px mintcream;*/
/*}*/

/*@keyframes fade {*/
/*   0% {*/
/*      opacity: 0;*/
/*   }*/
/*   10% {*/
/*      opacity: 1;*/
/*   }*/
/*   50% {*/
/*      opacity: 1;*/
/*   }*/
/*   60% {*/
/*      opacity: 0;*/
/*   }*/
/*}*/

.fa-gray {
    color: #eeeeee !important;
}

.fas-sc {
    color: white;
    margin-top: 20px;
}

.fas-sc-small {
    color: white;
    margin-top: 10px;
}

.far-sc {
    color: white !important;
    margin-top: 20px !important;
}

.sc-fa-color {
    color: white !important;
    vertical-align: middle;
}

.fa-menu-sc {
    margin-top: 20px;
}
