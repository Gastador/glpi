<?php
header("Content-type: text/css; charset: UTF-8");
include('../../../../inc/includes.php');
$config = new PluginServicecatalogConfig();
$color  = $config->getGeneralColor();
$hover  = $config->getGeneralHoverColor();
$colortheme = $config->getTheme();
?>

a .far, a .fas, .btn-linkstyled .fa, .btn-linkstyled .far, .btn-linkstyled .fas {
    color: unset;
}

.events {
    padding-left: 0rem;
}

.grid-stack > .grid-stack-item > .grid-stack-item-content,
div[class^="mostsc"],
div[class^="menusc"],
div[class^="linksc"],
div[class^="favsc"],
.itemsdisplay {
    background-color: <?php echo $colortheme; ?>;
}

div[class^="menusc"]:hover,
li[class^="first-btnsc"]:hover,
div[class^="btnsc"]:hover,
div[class^="btnsc"]:active,
div[class^="favsc"]:hover,
div[class^="searchsc"]:hover,
div[class^="mostsc"]:active,
div[class^="mostsc"]:hover,
div[class^="linksc"]:hover,
visitedbg,
faqrow {
    background-color: #cccccc1f !important;
}

table.dataTable tbody tr {
    background-color: <?php echo $colortheme; ?>;
}


div[class^="menusc"] {
    float: left;
    list-style-type: none;
    padding: 4px 15px 15px 15px;
    overflow: auto;
    margin: 10px;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    border: solid #CCC 1px;
    background-color: <?php echo $colortheme; ?>;
}

i.thumbnail {
    float: left;
    margin: 20px 15px 60px 0;
}

.sc-buttons {
    margin: 30px 15px 0px 0;
}

@media only screen and (min-width: 768px) {
    .cd-faq-content {
        background-color: <?php echo $colortheme; ?>;
    }
}


/* Wrapper Style */

.wrapper {
    margin: 0 auto;
    /*padding-left:12%;*/
    /*padding-right:12%;*/
}

.wrap {
    /*width: 830px;*/
    height: auto;
    /*margin: 70px 0px;*/
    /*float: left;*/
}

@media (max-width: 380px) {
    .bt-container {
        width: 250px;
    }
}

@media (min-width: 380px) and (max-width: 380px) {
    .bt-container {
        width: 450px;
    }
}

div[class^="btnsc"],
div[class^="mostsc"] {
    box-sizing: unset !important;
    background-color: <?php echo $colortheme; ?>;
    float: left;
    margin: 0 10px 10px 0;
    height: 145px;
    position: relative;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    /*border: solid 1px double;*/
    text-align: center;
    /*line-height:100px;*/
    /*min-height: 250px !important;*/
    padding: 20px !important;
    border-radius: 10px !important;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px !important;
    margin: 2px;
    border-color: #CCC;
    border-style: double;
    /*min-width: 200px;*/
}

div[class^="btnsc"]:hover,
div[class^="mostsc"]:hover {
    opacity: 0.7;
}

div[class^="btnsc"]:active,
div[class^="mostsc"]:active {
    transform: scale(.98, .98);
}

.btnsc-big,
.mostsc-big {
    width: 300px;
}

.btnsc-normal,
.mostsc-normal {
    width: 200px;
}

.btnsc-small,
.mostsc-small {
    width: 120px;
}

div[class^="favsc"] {
    float: left;
    -webkit-border-radius: 10px !important;
    border-color: #CCC;
    border-style: double;
    max-width: 350px;
}

div[class^="favsc"]:hover {
    opacity: 0.7;
}

div[class^="favsc"]:active {
    transform: scale(.98, .98);
}

.favsc-big {
    width: 300px;
}


.favsc-small {
    width: 120px;
}

.favsc-link-normal {
    width: 20%;
    padding: 15px;
}

div[class^="menusc"]:hover {
    background: #cccccc1f !important;
}

.menusc-normal {
    width: 280px;
}

div[class^="linksc"] {
    float: left;
    list-style-type: none;
    padding: 4px 15px 15px 15px;
    overflow: auto;
    margin: 10px;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    border: solid #CCC 1px;
}

div[class^="linksc"]:hover {
    background: #cccccc1f !important;
}

.linksc-normal {
    width: 220px;
    min-height: 200px;
}


.menusc-entity-normal {
    width: 300px !important;
    min-height: 250px;
}

img.bt-img-link-responsive {
    /*width: inherit !important;*/
    padding: 6px;
}

.bt-img-responsive {
    /*background-color: */<?php //echo $colortheme; ?>/*;*/
    /*background-repeat: no-repeat;*/
    /*border: 1px solid #e6e6e6 !important;*/
    /*-webkit-border-radius: 8px;*/
    /*-moz-border-radius: 8px;*/
    border-radius: 8px;
    max-width: 60%;
}

img.bt-img-responsive {
    background-size: initial !important;
    width: initial;
    height: initial;
    border: none;
}

img.bt-img-fav {
    background-size: initial !important;
    width: 15%;
    border: none;
}

.bt-features .bt-feature img:hover {
    background-image: unset;
    background-repeat: unset;
    background-color: <?php echo $colortheme; ?>;
}

.space {
    margin-bottom: 110px;
}

.label_firsttitle {
    /*position: absolute;*/
    color: rgba(0, 79, 145, 1);
    font-size: 11px;
    /*left: 10px;*/
}

.label_favtitle {
    position: relative;
    color: rgba(0, 79, 145, 1);
    margin-right: 10px;
    margin-bottom: 10px;
    margin-left: 5px;
    margin-top: 10px;
    display: inline-block;
    font-size: 12px;
    font-family: inherit;
    font-weight: normal;
}

.label_title {
    /*position: absolute;*/
    color: rgba(0, 79, 145, 1);
    font-size: 11px;
    margin: 15px;
    /*left: 10px;*/
}

.label {
    position: absolute;
    color: rgba(0, 79, 145, 1);
    font-size: 10px;
    left: 10px;
    text-align: left;
}

/*.bottom_title{margin-top: 120px;}*/
.bottom {
    bottom: 5px;
}

.top {
    top: 5px;
}

.red-folder,
.blue-folder,
.orange-folder,
.green-folder,
.purple-folder,
.red-light-folder,
.marroon-folder,
.turquoise-folder,
.gray-folder,
.gray2-folder,
.green-bright-folder,
.blue-nav-folder,
.redish-folder,
.lagoon-folder {
    background: rgba(245, 245, 245, 1);
}

.red
.blue,
.orange,
.green,
.purple,
.red-light,
.marroon,
.turquoise,
.gray,
.gray2,
.green-bright,
.blue-nav,
.redish,
.lagoon {
    background: rgb(255, 255, 255);
}

.grayback {
    background: rgb(255, 255, 255);
}

.tooltip-details {
    font-size: 11px;
}

.details {
    background-color: <?php echo $colortheme; ?>;
}

@media screen and (max-width: 900px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 450px;
    }
}

@media (min-width: 900px) and (max-width: 1366px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 500px;
    }
}

@media only screen and (min-width: 1367px) and (max-width: 1600px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 550px;
        min-width: 450px;
    }
}

@media (min-width: 1601px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 550px;
    }
}

.keywords {
    font-size: 11px;
    font-family: inherit;
    font-style: italic;
    /*margin:0 0 0 1em;  indentation */
    font-weight: normal;
    padding: 0;
    list-style: none;
    /*color: #000 !important;*/
}

.keywords_founded {
    font-size: 11px;
    position: absolute;
    bottom: 5px;
    left: 5px;
    color: #CCC;
    font-weight: normal;
}

@keyframes fade {
    0% {
        opacity: 0;
    }
    10% {
        opacity: 1;
    }
    50% {
        opacity: 1;
    }
    60% {
        opacity: 0;
    }
}

.fa-white {
    color: #FFFFFF;
}

.fa-gray {
    color: rgba(61, 61, 61, 0.32) !important;
}

.sc-fa-color {
    color: #185791;
    vertical-align: middle;
}

.background_title {
    background-image: linear-gradient(to bottom, #fafafa 0px, #ebebeb 100%);
}

.fa-back {
    color: <?php echo $color; ?>;
}

.fas-sc {
    margin-top: 20px;
}

.fas-sc-small {
    margin-top: 5px;
}


.fas-sc-fav-small {
    margin-top: 15px;
}


.far-sc {
    margin-top: 20px !important;
}

.fa-menu-sc {
    margin-top: 20px;
    margin-bottom: 20px;
}

.launch_details {
    margin-top: 5px;
    width: 500px;
    padding-top: 10px;
    display: -webkit-inline-box;
}

.ul_comment {
    margin-bottom: 1px;
}


