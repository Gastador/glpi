<?php
header("Content-type: text/css; charset: UTF-8");
include('../../../../inc/includes.php');
$config = new PluginServicecatalogConfig();
$color  = $config->getGeneralColor();
$hover  = $config->getGeneralHoverColor();
$colortheme = $config->getTheme();
?>

.grid-stack > .grid-stack-item > .grid-stack-item-content,
.itemsdisplay {
    background-color: <?php echo $colortheme; ?>;
}

.events {
    padding-left: 0rem;
}

div[class^="menusc"] {
    float: left;
    list-style-type: none;
    padding: 4px 15px 15px 15px;
    overflow: auto;
    margin: 10px;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    border: solid #CCC 1px;
    background-color: <?php echo $colortheme; ?>;
}

table.dataTable tbody tr {
    background-color: <?php echo $colortheme; ?>;
}

i.thumbnail {
    float: left;
    margin: 20px 15px 60px 0;
}

.sc-buttons {
    margin: 30px 15px 0px 0;
}

@media only screen and (min-width: 768px) {
    .cd-faq-content {
        background-color: <?php echo $colortheme; ?>;
    }
}

a .far, a .fas, .btn-linkstyled .fa, .btn-linkstyled .far, .btn-linkstyled .fas {
    color: unset;
}

/* Wrapper Style */

.wrapper {
    margin: 0 auto;
    /*padding-left:12%;*/
    /*padding-right:12%;*/
}

.wrap {
    /*width: 830px;*/
    height: auto;
    margin: 70px 0px;
    /*float: left;*/
}

ul.ul_comment {
    margin-left: 20px !important;
    margin-bottom: 1rem !important;
}

li.li_comment {
    display: block !important;
}

.fa-white {
    color: #FFFFFF;
}

.tooltip-details {
    font-size: 11px;
}

@media screen and (max-width: 900px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 450px;
    }
}

.details {
    background-color: <?php echo $colortheme; ?>;
}

@media (min-width: 900px) and (max-width: 1366px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 500px;
    }
}

@media only screen and (min-width: 1367px) and (max-width: 1600px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 550px;
        min-width: 450px;
    }
}

@media (min-width: 1601px) {
    .details {
        font-size: 11px;
        border: solid #CCC 1px;
        padding: 15px;
        max-width: 550px;
    }
}

@media (max-width: 380px) {
    .bt-container {
        width: 250px;
    }
}

@media (min-width: 380px) and (max-width: 380px) {
    .bt-container {
        width: 450px;
    }
}

.keywords {
    font-size: 11px;
    font-family: inherit;
    /*font-style: italic;
    margin:0 0 0 1em;  indentation */
    font-weight: normal;
    padding: 0;
    list-style: none;
    color: #fff !important;
}

.keywords_founded {
    font-size: 11px;
    position: absolute;
    bottom: 5px;
    left: 5px;
    color: #CCC;
    font-weight: normal;
}

div[class^="btnsc"],
div[class^="mostsc"]{
    float: left;
    margin: 0 10px 10px 0;
    height: 195px;
    position: relative;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    /*border: solid 1px;*/
    text-align: center;
    /*line-height:100px;*/
}

div[class^="btnsc"]:hover,
div[class^="mostsc"]:hover {
    opacity: 0.7;
}

div[class^="btnsc"]:active,
div[class^="mostsc"]:active {
    transform: scale(.98, .98);
}

.btnsc-big,
.mostsc-big {
    width: 300px;
}

.btnsc-normal,
.mostsc-normal {
    width: 200px;
}

.btnsc-small,
.mostsc-small {
    width: 120px;
}

div[class^="favsc"] {
    float: left;
    max-width: 350px;
}

div[class^="favsc"]:hover {
    opacity: 0.7;
}

div[class^="favsc"]:active {
    transform: scale(.98, .98);
}

.favsc-big {
    width: 300px;
}


.favsc-small {
    width: 120px;
}

.favsc-link-normal {
    width: 20%;
    padding: 15px;
}

.headfavorite {
    margin-right: 5px;
    margin-top: 5px;
}

div[class^="menusc"]:hover {
    background: #cccccc1f !important;
}

.menusc-normal {
    width: 280px;
}

div[class^="linksc"] {
    float: left;
    list-style-type: none;
    padding: 4px 15px 15px 15px;
    overflow: auto;
    margin: 10px;
    cursor: pointer;
    transition: all .4s ease;
    user-drag: element;
    border: solid #CCC 1px;
}

div[class^="linksc"]:hover {
    background: #cccccc1f !important;
}


.linksc-normal {
    width: 220px;
    min-height: 200px;
}


.menusc-entity-normal {
    width: 300px !important;
    min-height: 250px;
}

img.bt-img-responsive {
    background-size: initial !important;
    width: initial;
    height: initial;
    border: none;
    max-width: 50%;
    margin-top: 10px;
}

img.bt-img-fav {
    background-size: initial !important;
    width: 15%;
    border: none;
}

img.bt-img-link-responsive {
    /*width: inherit !important;*/
    padding: 6px;
}


.bt-img-responsive {
    background-color: <?php echo $colortheme; ?>;
    background-repeat: no-repeat;
    border: 1px solid #e6e6e6 !important;
    -webkit-border-radius: 8px;
    -moz-border-radius: 8px;
    border-radius: 8px;
}

.bt-features .bt-feature img:hover {
    background-image: unset;
    background-repeat: unset;
    background-color: <?php echo $colortheme; ?>;
}

.stick {
    margin-right: 0 !important;
}

.space {
    margin-bottom: 110px;
}

.label_firsttitle {
    /*position: absolute;*/
    color: white;
    font-size: 13px;
    font-family: inherit;
    font-weight: normal;
    /*left: 10px;*/
}

.label_favtitle {
    position: relative;
    color: white;
    margin-right: 10px;
    margin-bottom: 10px;
    margin-left: 5px;
    margin-top: 10px;
    display: inline-block;
    font-size: 12px;
    font-family: inherit;
    font-weight: normal;
}

.label_title {
    position: relative;
    color: white;
    margin: 15px;
    display: block;
}

.label {
    position: absolute;
    color: white;
    font-size: 12px;
    font-family: inherit;
    font-weight: normal;
    left: 10px;
    text-align: left;
}

/*.bottom_title{margin-top: 120px;}*/
.bottom {
    bottom: 5px;
}

.top {
    top: 5px;
}

.red,
.red-folder {
    border: none !important;
}

.blue,
.blue-folder {
    background: #00a9ec;
    border: none !important;
}

.orange,
.orange-folder {
    background: #ff9000;
    border: none !important;
}

.green,
.green-folder {
    background: #4a9a4e;
    border: none !important;
}

.purple,
.purple-folder {
    background: rgba(139, 1, 137, 0.52);
    border: none !important;
}

.red-light,
.red-light-folder {
    background: #ce4e4e;
    border: none !important;
}

.marroon,
.marroon-folder {
    background: #53150b;
    border: none !important;
}

.turquoise,
.turquoise-folder {
    background: #007491;
    border: none !important;
}

.gray,
.gray-folder {
    background: rgba(61, 61, 61, 0.32);
    border: none !important;
    /*animation: flip 6s linear infinite;*/
    /*transform: rotateX(0deg);*/
}

.grayback {
    background: rgba(61, 61, 61, 0.32);
    border: none !important;
    /*animation: flip 6s linear infinite;*/
    /*transform: rotateX(0deg);*/
}

.gray2,
.gray2-folder {
    background: rgba(61, 61, 61, 0.49);
    border: none !important;
    /*animation: flip 6s linear infinite;*/
    /*transform: rotateX(0deg);*/
}

.green-bright,
.green-bright-folder {
    background: #78d204;
    border: none !important;
}

.blue-nav,
.blue-nav-folder {
    background: #004f91;
    border: none !important;
}

.redish,
.redish-folder {
    background: #fe677d;
    border: none !important;
}

.lagoon,
.lagoon-folder {
    background: rgba(74, 171, 255, 0.64);
    border: none !important;
}

@keyframes flip {
    0% {
        transform: rotateX(0deg);
    }
    15% {
        transform: rotateX(360deg);
    }
    100% {
        transform: rotateX(360deg);
    }
}

.fa-gray {
    color: #eeeeee !important;
}

.fas-sc {
    color: white;
    margin-top: 20px;
}

.fas-sc-small {
    color: white;
    margin-top: 10px;
}

.far-sc {
    color: white !important;
    margin-top: 20px !important;
}

.sc-fa-color {
    color: white !important;
    vertical-align: middle;
}

.sc-fa-color-details {
    color: black !important;
    vertical-align: middle;
}

.fa-menu-sc {
    margin-top: 20px;
    margin-bottom: 20px;
}

.launch_details {
    margin-top: 5px;
    width: 500px;
    display: -webkit-inline-box;
    padding-top: 10px;
}

.faq {
    /*border: solid #CCC 1px;*/
    /*padding: 15px;*/
}


