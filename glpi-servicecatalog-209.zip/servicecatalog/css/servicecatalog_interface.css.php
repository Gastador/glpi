<?php
header("Content-type: text/css; charset: UTF-8");
include('../../../inc/includes.php');
$config = new PluginServicecatalogConfig();
$color  = $config->getGeneralColor();
$hover  = $config->getGeneralHoverColor();
$colortheme = $config->getTheme();
?>

@media (max-width: 380px) {
div[class^="menusc"] {
width: 190px;
}
}

@media (min-width: 380px) and (max-width: 768px) {
div[class^="menusc"] {
width: 250px;
}
}

@media (min-width: 768px) {
div[class^="menusc"] {
width: 280px;
}
}

div[class^="menusc"]:hover {
background: #cccccc1f!important;
}

/*
*, *::before, *::after {
box-sizing: unset;
}*/

a .far, a .fas, .btn-linkstyled .fa, .btn-linkstyled .far, .btn-linkstyled .fas {
color: unset;
}

#plugin_servicecatalog_searchBar input:focus ~ label,
#plugin_servicecatalog_search_kb_Bar input:focus ~ label {
color: <?php echo $color; ?> !important;
top: 30px;
font-size: 1em;
}

/* Style the links inside the navigation bar */
.topnav a {
float: left;
display: block;
text-align: center;
padding: 10px 10px;
text-decoration: none;
font-size: 12px;
font-weight: normal;
cursor: pointer;
}

/* Change the color of links on hover */
.topnav a:hover {
border: 1px solid #d3d3d3;
border-radius: 3px;
padding: 5px;
margin-top: 5px;
margin-right: 5px;
box-sizing: border-box;
color: unset;
}

/* Style the "active" element to highlight the current page */
.topnav a.active {
border: 1px solid #d3d3d3;
border-radius: 3px;
padding: 5px;
margin-top: 5px;
box-sizing: border-box;
}

.topnav a.active:hover {
border: 1px solid #d3d3d3;
border-radius: 3px;
padding: 5px;
margin-top: 5px;
box-sizing: border-box;
cursor: default;
}

.sc-color {
color : <?php echo $color; ?>;
vertical-align: sub;
}

.sc-color:hover {
color: <?php echo $color; ?>;
}

.sc-hover {
color : <?php echo $hover; ?>;
vertical-align: sub;
}

.sc-hover:hover {
color : <?php echo $color; ?>;
}

.sc-search {
color : <?php echo $hover; ?>;
vertical-align: middle;
}

.sc-search:hover {
color: <?php echo $color; ?>;
vertical-align: middle;
}

.topnav .search-container button {
float: right;
padding: 4px 5px;
margin-right: 6px;
font-size: 17px;
border: none;
}

.topnav .search-container button:hover {
}

.sc-contact {
color: <?php echo $color; ?>;
font-size: 1.5em;
margin-bottom: 10px;
}

/*** buttons ***/

a.bt-interface {
color: <?php echo $color; ?>;
}

a.bt-interface:hover {
color: <?php echo $hover; ?>;
}

a.bt-buttons {
color: <?php echo $color; ?>;
}

a.bt-buttons:hover {
color: <?php echo $hover; ?>;
}

.comment_buttons {
color: <?php echo $hover; ?>;
}

.faq-folder {
color: <?php echo $color; ?>;
cursor: pointer;
user-select: none;
display: inline-block;
margin-right: 6px;
}
