<?php
header("Content-type: text/css; charset: UTF-8");
include('../../../inc/includes.php');
$config = new PluginServicecatalogConfig();
$language = ($config->getDropLanguagesButton()==1)?"display:none!important":"";
$help = ($config->getDropHelpButton()==1)?"display:none!important":"";
$preference = ($config->getDropPreferencesButton()==1)?"display:none!important":"";
$savedsearch = ($config->getDropSavedsearchsButton()==1)?"display:none!important":"";
$logout = ($config->getDropLogoutButton()==1)?"display:none!important":"";

?>

#language_link {
<?php echo $language; ?>;
}

#help_link {
<?php echo $help; ?>;
}

#preferences_link {
<?php echo $preference; ?>;
}

#bookmark_link {
<?php echo $savedsearch; ?>;
}

#deconnexion {
<?php echo $logout; ?>;
}
