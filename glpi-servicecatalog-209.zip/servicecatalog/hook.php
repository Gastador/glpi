<?php
/*
 -------------------------------------------------------------------------
 Servicecatalog plugin for GLPI
 Copyright (C) 2018-2022 by the Servicecatalog Development Team.

 https://github.com/InfotelGLPI/servicecatalog
 -------------------------------------------------------------------------

 LICENSE

 This file is part of Servicecatalog.

 Servicecatalog is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Servicecatalog is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Servicecatalog. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

/**
 * @return bool
 */
function plugin_servicecatalog_install()
{
    global $DB;

    include_once(PLUGIN_SERVICECATALOG_DIR . "/inc/profile.class.php");
    if (!$DB->tableExists("glpi_plugin_servicecatalog_configs")) {
        // table sql creation
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/empty-2.0.9.sql");

        $query = "INSERT INTO `glpi_plugin_servicecatalog_dashboards` (`id`, `entities_id`, `is_recursive`, `users_id`, `grid`)
                VALUES (1, 0, 1, 0, '[{\"id\":\"gs1\",\"x\":0,\"y\":0,\"w\":6,\"h\":6},
            {\"id\":\"gs20\",\"x\":0,\"y\":6,\"w\":6,\"h\":6},
            {\"id\":\"gs12\",\"x\":6,\"y\":6,\"w\":6,\"h\":6},
            {\"id\":\"gs13\",\"x\":6,\"y\":6,\"w\":6,\"h\":6}]');";
        $DB->query($query);

        include_once(PLUGIN_SERVICECATALOG_DIR . "/inc/widgetbuttonorder.class.php");
        $order = new PluginServicecatalogWidgetbuttonorder();
        $order->loadButtons();

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `title_watchers_dropdown`               = \"" . _n('Watcher', 'Watchers', 2) . "\",
                    `title_submit_message_button`           = \"" . __('Submit ticket', 'servicecatalog') . "\",
                    `title_your_open_tickets`               = \"" . __("Your opened tickets", "servicecatalog") . "\",
                    `title_your_resolved_tickets`           = \"" . __('Your tickets to close', 'servicecatalog') . "\",
                    `title_your_open_incidents`             = \"" . __('Your opened incidents', 'servicecatalog') . "\",
                    `title_your_open_requests`              = \"" . __('Your opened requests', 'servicecatalog') . "\",
                    `title_your_and_group_open_incidents`   = \"" . __('Your and your group opened incidents', 'servicecatalog') . "\",
                    `title_your_and_group_open_requests`    = \"" . __('Your and your group opened requests', 'servicecatalog') . "\",
                    `select_title_request_category`         = \"" . __('Select request category', 'servicecatalog') . "\",
                    `select_title_incident_category`        = \"" . __('Select incident category', 'servicecatalog') . "\",
                    `select_title_faq_article`              = \"" . __('Linked FAQ items', 'servicecatalog') . "\",
                    `title_favorites_category`              = \"" . __('Favorite categories', 'servicecatalog') . "\",
                    `title_ticket`                          = \"" . __('Title') . "\",
                    `title_description_ticket`              = \"" . __('Description') . "\",
                    `title`                                 = \"" . __('Choose what you want to do', 'servicecatalog') . "\",
                    `title_your_tickets_to_validate`        = \"" . __('Your tickets to validate', 'servicecatalog') . "\",
                    `title_myelements_menu`                 = \"" . __('Your materials', 'servicecatalog') . "\",
                    `title_myappliances_menu`               = \"" . __('Your appliances', 'servicecatalog') . "\",
                    `title_tickets_menu`                    = \"" . _n('Ticket', 'Tickets', 2) . "\",
                    `title_incidents_menu`                  = \"" . __('Incidents', 'servicecatalog') . "\",
                    `title_requests_menu`                   = \"" . __('Requests', 'servicecatalog') . "\",
                    `fa_myelements_menu`                    = 'fa-desktop',
                    `title_closedtickets_menu`              = \"" . __('Your closed tickets', 'servicecatalog') . "\",
                    `fa_closedtickets_menu`                 = 'fa-window-close',
                    `fa_back`                               = 'fa-chevron-circle-left',
                    `drop_helpdesk_menu`                    = 0,
                    `columns_for_table`                    = '[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"8\",\"9\"]'
                WHERE id = 1";
        $DB->query($query);

        $query = "UPDATE glpi_plugin_servicecatalog_widgets 
                SET `title_tickets_list`                    = \"" . __('See your', 'servicecatalog') . " " . __('tickets', 'servicecatalog') . "\",
                    `title_incidents_list`                  = \"" . __('See your', 'servicecatalog') . " " . __('incidents', 'servicecatalog') . "\",
                    `title_requests_list`                   = \"" . __('See your', 'servicecatalog') . " " . __('requests', 'servicecatalog') . "\",
                    `title_incident`                        = \"" . __('Create an', 'servicecatalog') . " " . __('Incident', 'servicecatalog') . "\",
                    `title_request`                         = \"" . __('Create a request', 'servicecatalog') . "\",
                    `title_reservation`                     = \"" . __('Do a', 'servicecatalog') . " " . __('material reservation', 'servicecatalog') . "\",
                    `title_faq`                             = \"" . __('Try to found', 'servicecatalog') . " " . __('a solution', 'servicecatalog') . "\",
                    `title_links`                           = \"" . __('Useful links list', 'servicecatalog') . "\",
                    `title_entity`                          = \"" . __('Change', 'servicecatalog') . " " . __('Context', 'servicecatalog') . "\",
                    `title_database`                        = \"" . __('Document', 'servicecatalog') . " " . __('database', 'servicecatalog') . "\",
                    `title_entity_list`                     = \"" . __('Choose context of your ticket', 'servicecatalog') . "\",
                    `title_personalinfo`                     = \"" . __('Your preferences', 'servicecatalog') . "\"
                WHERE id =1";
        $DB->query($query);

        plugin_servicecatalog_install_notifications();

        PluginServicecatalogProfile::createFirstAccess($_SESSION['glpiactiveprofile']['id']);
    }
    //no more used
//    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "linked_kbcategory")) {
//        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.1.0.sql");
//    }

    if (!$DB->fieldExists("glpi_plugin_servicecatalog_categories", "service_detail")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.2.0.sql");
    }

    //version 1.2.1
    if (!$DB->tableExists("glpi_plugin_servicecatalog_linktranslations")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.2.1.sql");
    }

    //version 1.2.2
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "drop_home_button")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.2.2.sql");
    }

    //version 1.3.1
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "palette")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.3.1.sql");
    }

    //version 1.3.2
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "layout")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.3.2.sql");
    }

    //version 1.3.3
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "title")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.3.3.sql");
    }

    //version 1.3.4
    if (!$DB->tableExists("glpi_plugin_servicecatalog_dashboards")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.3.4.sql");

        include_once(PLUGIN_SERVICECATALOG_DIR . "/inc/config.class.php");
        $widgets = [["id" => "gs1", "x" => 0, "y" => 0, "width" => 6, "height" => 18],
            ["id" => "gs10", "x" => 6, "y" => 6, "width" => 6, "height" => 6],
            ["id" => "gs11", "x" => 0, "y" => 18, "width" => 6, "height" => 6]];
        $config = new PluginServicecatalogConfig();
        $config->getConfig();
        if ($config->fields['see_title'] == 1) {
            $widgets[] = ["id" => "gs2", "x" => 0, "y" => 6, "width" => 6, "height" => 6];
        }
        if ($config->fields['see_stats'] == 1) {
            $widgets[] = ["id" => "gs3", "x" => 6, "y" => 6, "width" => 6, "height" => 6];
        }
        $grid = json_encode($widgets);

        $query = "INSERT INTO `glpi_plugin_servicecatalog_dashboards` (`id`, `users_id`, `grid`) VALUES (1, 0, '$grid');";
        $DB->query($query);

        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `see_stats`;";
        $DB->query($query);
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `see_title`;";
        $DB->query($query);
    }

    //version 1.3.5
    if (!$DB->tableExists("glpi_plugin_servicecatalog_tickettemplates")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.3.5.sql");
    }

    //version 1.3.6
    if (!$DB->tableExists("glpi_plugin_servicecatalog_entities")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.3.6.sql");
    }

    //version 1.4.2
    if (!$DB->tableExists("glpi_plugin_servicecatalog_formcreators")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.4.2.sql");
    }

    //version 1.4.5
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "title_watchers_dropdown")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.4.5.sql");
        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `title_watchers_dropdown`               = \"" . _n('Watcher', 'Watchers', 2) . "\",
                    `title_submit_message_button`           = \"" . __('Submit ticket', 'servicecatalog') . "\",
                    `title_incidents_list`                  = \"" . __('See your', 'servicecatalog') . " " . __('incidents', 'servicecatalog') . "\",
                    `title_requests_list`                   = \"" . __('See your', 'servicecatalog') . " " . __('requests', 'servicecatalog') . "\",
                    `title_your_open_incidents`             = \"" . __('Your opened incidents', 'servicecatalog') . "\",
                    `title_your_open_requests`              = \"" . __('Your opened requests', 'servicecatalog') . "\",
                    `title_your_and_group_open_incidents`   = \"" . __('Your and your group opened incidents', 'servicecatalog') . "\",
                    `title_your_and_group_open_requests`    = \"" . __('Your and your group opened requests', 'servicecatalog') . "\",
                    `title_incident`                        = \"" . __('Create an', 'servicecatalog') . " " . __('Incident', 'servicecatalog') . "\",
                    `title_request`                         = \"" . __('Create a request', 'servicecatalog') . "\",
                    `cat_size`                              = 'normal'
                WHERE id = 1";
        $DB->query($query);
    }
    //version 1.4.6
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "drop_helpdesk_footer")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.4.6.sql");
    }

    //version 1.4.7 - no more used
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "tablet_mode")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.4.7.sql");
    }

    //version 1.4.8 - no more used
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "title_validation")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.4.8.sql");
    }

    //version 1.5.2
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "title_searchbar_kb")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.5.2.sql");
    }

    //version 1.5.3
    if (!$DB->tableExists("glpi_plugin_servicecatalog_groups")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.5.3.sql");
    }

    //version 1.6.0
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_categories", "background_color")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.6.0.sql");
    }

    //version 1.6.1
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "general_color")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.6.1.sql");
    }

    if (is_dir(PLUGIN_SERVICECATALOG_DIR . "/css/palettes")) {
        migrateCssFolders();
    }

    //version 1.6.2
    if (!$DB->tableExists("glpi_plugin_servicecatalog_favorites")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.6.2.sql");

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `title_tickets_list`              = \"" . __('See your', 'servicecatalog') . " " . __('tickets', 'servicecatalog') . "\",
                    `select_title_request_category`   = \"" . __('Select request category', 'servicecatalog') . "\",
                    `select_title_incident_category`  = \"" . __('Select incident category', 'servicecatalog') . "\",
                    `title_favorites_category`        = \"" . __('Favorite categories', 'servicecatalog') . "\",
                    `title_reservation`               = \"" . __('Do a', 'servicecatalog') . " " . __('material reservation', 'servicecatalog') . "\",
                    `title_ticket`                    = \"" . __('Title') . "\",
                    `title_description_ticket`        = \"" . __('Description') . "\",
                    `title_links`                     = \"" . __('Useful links list', 'servicecatalog') . "\",
                    `title_faq`                       = \"" . __('Try to found', 'servicecatalog') . " " . __('a solution', 'servicecatalog') . "\",
                    `fa_back`                         = 'fas fa-chevron-circle-left'
                WHERE id = 1";
        $DB->query($query);
    }

    //version 1.6.3
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "add_requesters_from_tickets")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.6.3.sql");
    }

    //version 1.6.4
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_categories", "inherit_detail")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.6.4.sql");

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `select_title_faq_article`  = \"" . __('Linked FAQ items', 'servicecatalog') . "\",
                  `title_entity`                = \"" . __('Change', 'servicecatalog') . " " . __('Context', 'servicecatalog') . "\",
                  `title_database`              = \"" . __('Document', 'servicecatalog') . " " . __('database', 'servicecatalog') . "\",
                  `title`                       = \"" . __('Choose what you want to do', 'servicecatalog') . "\",
                  `title_entity_list`           = \"" . __('Choose context of your ticket', 'servicecatalog') . "\"
                WHERE id = '1';";
        $DB->query($query);
    }

    //version 1.6.5
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_categories", "inherit_alert")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.6.5.sql");
    }

    //version 1.7.2
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "default_icon")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.2.sql");

        include_once(PLUGIN_SERVICECATALOG_DIR . "/inc/widget.class.php");
        $widget = new PluginServicecatalogWidget();
        $widget->migrateFields();

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `title_your_open_tickets` = \"" . __("Your opened tickets", "servicecatalog") . "\",
                `title_your_resolved_tickets` = \"" . __('Your tickets to close', 'servicecatalog') . "\"
                WHERE id = 1";
        $DB->query($query);

        $query = "UPDATE glpi_plugin_servicecatalog_widgets 
                SET `title_personalinfo` = \"" . __('Update your personal informations', 'servicecatalog') . "\"
                WHERE id = 1";
        $DB->query($query);


        include_once(PLUGIN_SERVICECATALOG_DIR . "/inc/widgetbuttonorder.class.php");
        $order = new PluginServicecatalogWidgetbuttonorder();
        $order->loadButtons();
    }

    //version 1.7.3
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "title_your_tickets_to_validate")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.4.sql");

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `title_your_tickets_to_validate` = \"" . __('Your tickets to validate', 'servicecatalog') . "\"
                WHERE id = 1";
        $DB->query($query);
    }

    //version 1.7.5
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "display_myelements_menu")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.5.sql");

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `title_myelements_menu` = \"" . __('Your materials', 'servicecatalog') . "\",
                     `fa_myelements_menu`               = 'fa-desktop'
                WHERE id = 1";
        $DB->query($query);
    }

    //version 1.7.6
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "display_closedtickets_menu")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.6.sql");

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `title_closedtickets_menu` = \"" . __('Your closed tickets', 'servicecatalog') . "\",
                     `fa_closedtickets_menu`               = 'fa-window-close'
                WHERE id = 1";
        $DB->query($query);
    }

    //version 1.7.7 - No more used
//    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "new_page_to_create")) {
//        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.7.sql");
//    }

    //version 1.7.8 - No more used
//    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "leftbar_style")) {
//        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.8.sql");
//    }

    //version 1.7.9
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_categories", "simplified_name_incident")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.9.sql");
    }

    //version 1.7.10
    if (!$DB->tableExists("glpi_plugin_servicecatalog_ticketappointments")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.10.sql");
    }

    //version 1.7.11
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "see_widgets_border")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-1.7.11.sql");

        plugin_servicecatalog_install_notifications();
    }

    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "replace_ticket_update_form")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.0.sql");
        if (!$DB->fieldExists("glpi_plugin_servicecatalog_entities", "comment")) {
            $query = "ALTER TABLE `glpi_plugin_servicecatalog_entities` ADD `comment` varchar(255) DEFAULT NULL;";
            $DB->query($query);
        }
        if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "bypass_categories_selection")) {
            $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `bypass_categories_selection` tinyint(1) NOT NULL DEFAULT '0';";
            $DB->query($query);
        }
        if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "fields_more_informations")) {
            $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` ADD `fields_more_informations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL;";
            $DB->query($query);
            $query = "UPDATE `glpi_plugin_servicecatalog_configs` SET `fields_more_informations` = '[\"4\",\"6\",\"11\"]' WHERE `glpi_plugin_servicecatalog_configs`.`id` = 1;";
            $DB->query($query);
        }
    }

    //version 2.0.2
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "show_linked_tickets_simplifiedform")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.2.sql");


        $query = "SELECT `profiles_id` FROM `glpi_profilerights` WHERE `name` LIKE 'plugin_servicecatalog' AND `rights` = 1;";
        $result = $DB->query($query);
        while ($data = $DB->fetchArray($result)) {
            $profiles_id = $data['profiles_id'];
            $query = "INSERT INTO `glpi_profilerights` 
    (`id`, `profiles_id`, `name`, `rights`) VALUES (NULL, '" . $profiles_id . "', 'plugin_servicecatalog_incidents', '1');";
            $DB->query($query);
            $query = "INSERT INTO `glpi_profilerights` 
    (`id`, `profiles_id`, `name`, `rights`) VALUES (NULL, '" . $profiles_id . "', 'plugin_servicecatalog_requests', '1');";
            $DB->query($query);
        }

        $query = "SELECT `id`, `grid` FROM `glpi_plugin_servicecatalog_dashboards`";
        $result = $DB->query($query);

        while ($data = $DB->fetchArray($result)) {
            $id = $data['id'];
            $grids = json_decode($data['grid'], true);
            $newwidgets = [];
            $newwidget = [];
            foreach ($grids as $k => $widgets) {
                $newwidget['id'] = $widgets['id'];
                $newwidget['x'] = $widgets['x'];
                $newwidget['y'] = $widgets['y'];
                $newwidget['w'] = isset($widgets['width']) ? $widgets['width'] : $widgets['w'];
                $newwidget['h'] = isset($widgets['height']) ? $widgets['height'] : $widgets['h'];

                $newwidgets[] = $newwidget;
            }
            $newgrid = json_encode($newwidgets);
            $query = "UPDATE `glpi_plugin_servicecatalog_dashboards` SET `grid` = '" . $newgrid . "' WHERE `glpi_plugin_servicecatalog_dashboards`.`id` = " . $id . ";";
            $DB->query($query);
        }
    }

    //version 2.0.3
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "comment_impact")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.3.sql");
    }

    //version 2.0.5
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "use_strict_search")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.5.sql");

        $query = "UPDATE glpi_plugin_servicecatalog_configs 
                SET `columns_for_table` = '[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"8\",\"9\"]'
                WHERE id = 1";
        $DB->query($query);
    }

    //version 2.0.6
    if (!$DB->tableExists("glpi_plugin_servicecatalog_apiclients")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.6.sql");
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "tablet_mode")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `tablet_mode`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "leftbar_style")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `leftbar_style`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "palette")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `palette`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "comment_database")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `comment_database`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "title_validation")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `title_validation`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "img_validation")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `img_validation`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "linked_kbcategory")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `linked_kbcategory`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "new_page_to_create")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `new_page_to_create`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "see_stats")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `see_stats`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "see_title")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `see_title`;";
        $DB->query($query);
    }
    if ($DB->fieldExists("glpi_plugin_servicecatalog_configs", "display_topmenu")) {
        $query = "ALTER TABLE `glpi_plugin_servicecatalog_configs` DROP `display_topmenu`;";
        $DB->query($query);
    }

    //version 2.0.7
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "search_ticket_color")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.7.sql");
    }

    //version 2.0.8
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "use_detail_before_creation")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.8.sql");
    }

    //version 2.0.9
    if (!$DB->fieldExists("glpi_plugin_servicecatalog_configs", "force_background_title")) {
        $DB->runFile(PLUGIN_SERVICECATALOG_DIR . "/install/sql/update-2.0.9.sql");
    }


    $rep_files_servicecatalog = GLPI_PLUGIN_DOC_DIR . "/servicecatalog";
    if (!is_dir($rep_files_servicecatalog)) {
        mkdir($rep_files_servicecatalog);
    }

    return true;
}

/**
 *
 */
function migrateCssFolders()
{
    $default_css = PLUGIN_SERVICECATALOG_DIR . "/css";
    $normal_dir = PLUGIN_SERVICECATALOG_DIR . "/css/normal";

    rename($default_css . "/palettes/previews", $default_css . "/previews");

    $files = scandir($default_css . "/palettes");
    foreach ($files as $file) {
        if ($file != "." && $file != "..") {
            if ($file_contents = file_get_contents($default_css . "/palettes/" . $file)) {
                $file_contents = str_replace("../img", "../../img", $file_contents);
                $file_contents = str_replace("../pics", "../../pics", $file_contents);
                file_put_contents($default_css . "/palettes/" . $file, $file_contents);
            }
        }
    }

    rename($default_css . "/palettes", $normal_dir . "/palettes");
    rename($default_css . "/sly.css", $normal_dir . "/sly.scss");
}

/**
 * Uninstall process for plugin : need to return true if succeeded
 *
 * @return bool
 */
function plugin_servicecatalog_uninstall()
{
    global $DB;

    // Plugin tables deletion
    $tables = ["glpi_plugin_servicecatalog_categories",
        "glpi_plugin_servicecatalog_configs",
        "glpi_plugin_servicecatalog_categoryorders",
        "glpi_plugin_servicecatalog_configtranslations",
        "glpi_plugin_servicecatalog_categorytranslations",
        "glpi_plugin_servicecatalog_itilcategories_keywords",
        "glpi_plugin_servicecatalog_knowbaseitems_keywords",
        "glpi_plugin_servicecatalog_keywords",
        "glpi_plugin_servicecatalog_groups",
        "glpi_plugin_servicecatalog_groupconfigs",
        "glpi_plugin_servicecatalog_ticketchecks",
        "glpi_plugin_servicecatalog_linkgroups",
        "glpi_plugin_servicecatalog_links",
        "glpi_plugin_servicecatalog_linktranslations",
        "glpi_plugin_servicecatalog_dashboards",
        "glpi_plugin_servicecatalog_contacts",
        "glpi_plugin_servicecatalog_tickettemplates",
        "glpi_plugin_servicecatalog_formcreators",
        "glpi_plugin_servicecatalog_entities",
        "glpi_plugin_servicecatalog_fieldorders",
        "glpi_plugin_servicecatalog_favorites",
        "glpi_plugin_servicecatalog_favorites_users",
        "glpi_plugin_servicecatalog_favorites_groups",
        "glpi_plugin_servicecatalog_favorites_profiles",
        "glpi_plugin_servicecatalog_entities_favorites",
        "glpi_plugin_servicecatalog_widgetbuttonorders",
        "glpi_plugin_servicecatalog_widgets",
        "glpi_plugin_servicecatalog_ticketappointments",
        "glpi_plugin_servicecatalog_appliancelinks",
        "glpi_plugin_servicecatalog_apiclients"];

    foreach ($tables as $table) {
        $DB->query("DROP TABLE IF EXISTS `$table`;");
    }

    $rep_files_servicecatalog = GLPI_PLUGIN_DOC_DIR . "/servicecatalog";

    Toolbox::deleteDir($rep_files_servicecatalog);

    $notif = new Notification();
    $options = ['itemtype' => 'PluginServicecatalogTicketAppointment',
        'FIELDS' => 'id'];
    foreach ($DB->request('glpi_notifications', $options) as $data) {
        $notif->delete($data);
    }

    //templates
    $template = new NotificationTemplate();
    $translation = new NotificationTemplateTranslation();
    $notif_template = new Notification_NotificationTemplate();
    $options = ['itemtype' => 'PluginServicecatalogTicketAppointment',
        'FIELDS' => 'id'];
    foreach ($DB->request('glpi_notificationtemplates', $options) as $data) {
        $options_template = ['notificationtemplates_id' => $data['id'],
            'FIELDS' => 'id'];

        foreach ($DB->request('glpi_notificationtemplatetranslations', $options_template) as $data_template) {
            $translation->delete($data_template);
        }
        $template->delete($data);

        foreach ($DB->request('glpi_notifications_notificationtemplates', $options_template) as $data_template) {
            $notif_template->delete($data_template);
        }
    }

    //Delete rights associated with the plugin
    $profileRight = new ProfileRight();
    foreach (PluginServicecatalogProfile::getAllRights(true) as $right) {
        $profileRight->deleteByCriteria(['name' => $right['field']]);
    }

    return true;
}

/**
 * Define search option for types of the plugins
 *
 * @param $itemtype
 *
 * @return array
 */
function plugin_servicecatalog_getAddSearchOptions($itemtype)
{
    $sopt = [];

    if ($itemtype == "ITILCategory") {
        if (Session::haveRight("plugin_servicecatalog_setup", UPDATE)) {
            $sopt[1500]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1500]['field'] = 'comment';
            $sopt[1500]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Comments');
            $sopt[1500]['datatype'] = "text";
            $sopt[1500]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1500]['massiveaction'] = false;

            $sopt[1501]['table'] = 'glpi_plugin_servicecatalog_itilcategories_keywords';
            $sopt[1501]['field'] = 'name';
            $sopt[1501]['nosearch'] = true;
            $sopt[1501]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Keywords', 'servicecatalog');
            $sopt[1501]['forcegroupby'] = '1';
            $sopt[1501]['datatype'] = 'itemlink';
            $sopt[1501]['massiveaction'] = false;
            $sopt[1501]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'plugin_servicecatalog_categories_id'];

            $sopt[1502]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1502]['field'] = 'icon';
            $sopt[1502]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Icon');
            $sopt[1502]['datatype'] = "specific";
            $sopt[1502]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1502]['massiveaction'] = false;

            $sopt[1503]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1503]['field'] = 'background_color';
            $sopt[1503]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Background color', 'servicecatalog');
            $sopt[1503]['datatype'] = "color";
            $sopt[1503]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1503]['massiveaction'] = false;

            $sopt[1504]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1504]['field'] = 'size';
            $sopt[1504]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Size', 'servicecatalog');
            $sopt[1504]['datatype'] = "specific";
            $sopt[1504]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1504]['massiveaction'] = false;

            $sopt[1505]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1505]['field'] = 'glue';
            $sopt[1505]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Stick with the next', 'servicecatalog');
            $sopt[1505]['datatype'] = "bool";
            $sopt[1505]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1505]['massiveaction'] = false;

            $sopt[1506]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1506]['field'] = 'inherit_config';
            $sopt[1506]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Inherit of parent category', 'servicecatalog');
            $sopt[1506]['datatype'] = "bool";
            $sopt[1506]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1506]['massiveaction'] = false;

            $sopt[1507]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1507]['field'] = 'picture';
            $sopt[1507]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Picture');
            $sopt[1507]['datatype'] = "specific";
            $sopt[1507]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1507]['massiveaction'] = false;

            $sopt[1508]['table'] = 'glpi_plugin_servicecatalog_groups';
            $sopt[1508]['field'] = 'groups_id';
            $sopt[1508]['nosearch'] = true;
            $sopt[1508]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Limited to Groups', 'servicecatalog');
            $sopt[1508]['forcegroupby'] = '1';
            $sopt[1508]['datatype'] = 'itemlink';
            $sopt[1508]['massiveaction'] = false;
            $sopt[1508]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'plugin_servicecatalog_categories_id'];

            $sopt[1509]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1509]['field'] = 'force_validation';
            $sopt[1509]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('Force validation of user responsible in simplified interface', "servicecatalog");
            $sopt[1509]['datatype'] = "bool";
            $sopt[1509]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1509]['massiveaction'] = false;

            $sopt[1510]['table'] = 'glpi_plugin_servicecatalog_categories';
            $sopt[1510]['field'] = 'id';
            $sopt[1510]['name'] = PluginServicecatalogMain::getTypeName() . " - " . __('ID');
            $sopt[1510]['datatype'] = "id";
            $sopt[1510]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'itilcategories_id'];
            $sopt[1510]['massiveaction'] = false;
        }
    } elseif ($itemtype == "Appliance") {
        if (Session::haveRight("plugin_servicecatalog_setup", UPDATE)) {
            $sopt[1510]['table'] = 'glpi_plugin_servicecatalog_appliancelinks';
            $sopt[1510]['field'] = 'groups';
            $sopt[1510]['nosearch'] = true;
            $sopt[1510]['name'] = __('Appliance user groups', 'servicecatalog');
            $sopt[1510]['datatype'] = "itemlink";
            $sopt[1510]['joinparams'] = ['jointype' => 'child',
                'linkfield' => 'appliances_id'];
            $sopt[1510]['massiveaction'] = false;
        }
    }

    return $sopt;
}

/**
 * @param $type
 * @param $ID
 * @param $data
 * @param $num
 *
 * @return date|string|translated
 */
function plugin_servicecatalog_giveItem($type, $ID, $data, $num)
{
    global $DB;

    $searchopt = &Search::getOptions($type);
    $table = $searchopt[$ID]["table"];
    $field = $searchopt[$ID]["field"];

    switch ($table . '.' . $field) {
        case "glpi_plugin_servicecatalog_itilcategories_keywords.name":
            $out = '';
            $item = new PluginServicecatalogItilcategory_Keyword();

            if ($item->canUpdate()) {
                $query = "SELECT `glpi_plugin_servicecatalog_itilcategories_keywords`.`name`
                           FROM `glpi_plugin_servicecatalog_itilcategories_keywords`
                           LEFT JOIN `glpi_plugin_servicecatalog_categories` 
                             ON (`glpi_plugin_servicecatalog_categories`.`id` = `glpi_plugin_servicecatalog_itilcategories_keywords`.`plugin_servicecatalog_categories_id`) 
                           WHERE `glpi_plugin_servicecatalog_categories`.`itilcategories_id` = " . $data['raw']['id'];

                if ($result_linked = $DB->query($query)) {
                    if ($DB->numrows($result_linked)) {
                        while ($data_linked = $DB->fetchAssoc($result_linked)) {
                            $out .= $data_linked['name'] . "<br>";
                        }
                    } else {
                        $out .= ' ';
                    }
                }
            } else {
                $out .= ' ';
            }
            return $out;
            break;
        case "glpi_plugin_servicecatalog_groups.groups_id":
            $out = '';
            $item = new PluginServicecatalogGroup();

            if ($item->canUpdate()) {
                $query = "SELECT `glpi_groups`.`name`
                           FROM `glpi_plugin_servicecatalog_groups`
                            LEFT JOIN `glpi_groups` 
                             ON (`glpi_groups`.`id` = `glpi_plugin_servicecatalog_groups`.`groups_id`) 
                           LEFT JOIN `glpi_plugin_servicecatalog_categories` 
                             ON (`glpi_plugin_servicecatalog_categories`.`id` = `glpi_plugin_servicecatalog_groups`.`plugin_servicecatalog_categories_id`) 
                           WHERE `glpi_plugin_servicecatalog_categories`.`itilcategories_id` = " . $data['raw']['id'];

                if ($result_linked = $DB->query($query)) {
                    if ($DB->numrows($result_linked)) {
                        while ($data_linked = $DB->fetchAssoc($result_linked)) {
                            $out .= $data_linked['name'] . "<br>";
                        }
                    } else {
                        $out .= ' ';
                    }
                }
            } else {
                $out .= ' ';
            }
            return $out;
            break;
        case "glpi_plugin_servicecatalog_appliancelinks.groups":
            $out = ' ';
            $item = new PluginServicecatalogApplianceLink();
            if ($item->canUpdate()) {
                $query = "SELECT `groups`
                           FROM `glpi_plugin_servicecatalog_appliancelinks`
                           WHERE `appliances_id` = " . $data['raw']['id'];

                if ($result_linked = $DB->query($query)) {
                    if ($DB->numrows($result_linked)) {
                        while ($data_linked = $DB->fetchAssoc($result_linked)) {
                            $groups = json_decode($data_linked['groups'], true);
                            if (count($groups) > 0) {
                                foreach ($groups as $group) {
                                    $link = new Group();
                                    if ($link->getFromDB($group)) {
                                        $out .= $link->getName() . "<br>";
                                    }
                                }
                            }
                        }
                    } else {
                        $out .= ' ';
                    }
                }
            } else {
                $out .= ' ';
            }
            return $out;
            break;
    }
    return "";
}

//Define dropdown relations
function plugin_servicecatalog_getDatabaseRelations()
{
    if (Plugin::isPluginActive("servicecatalog")) {
        return [
//            "glpi_knowbaseitemcategories" => ["glpi_plugin_servicecatalog_widgets" => "linked_kbcategory"],
            "glpi_tickettemplates" => ["glpi_plugin_servicecatalog_tickettemplates" => "tickettemplates_id"],
            "glpi_itilcategories" => [
                'glpi_plugin_servicecatalog_categories' => "itilcategories_id",
                'glpi_plugin_servicecatalog_categoryorders' => "itilcategories_id",
                'glpi_plugin_servicecatalog_formcreators' => "itilcategories_id",
                'glpi_plugin_servicecatalog_favorites' => "itilcategories_id",
            ],
            "glpi_groups" => [
                'glpi_plugin_servicecatalog_groups' => "groups_id",
                'glpi_plugin_servicecatalog_linkgroups' => 'groups_id'
            ],
            "glpi_tickets" => ['glpi_plugin_servicecatalog_ticketchecks' => 'tickets_id'],
            "glpi_entities" => [
                'glpi_plugin_servicecatalog_links' => 'entities_id',
                'glpi_plugin_servicecatalog_contacts' => 'entities_id',
                'glpi_plugin_servicecatalog_entities' => 'entities_id'
            ],
            "glpi_users" => ['glpi_plugin_servicecatalog_dashboards' => 'users_id'],
            "glpi_appliances" => ['glpi_plugin_servicecatalog_appliancelinks' => 'appliances_id']
        ];
    }
    return [];
}

function plugin_servicecatalog_MassiveActions($type)
{
    $actions = [];
    switch ($type) {
        case 'ITILCategory':
            $myclass = PluginServicecatalogCategory::class;
            $action_key = 'UpdateInherit';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Inherit of parent category', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateInheritPicture';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Inherit of parent picture', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateInheritItemtypes';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Inherit of parent itemtypes', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateInheritDetail';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Mydashboard alerts', 'servicecatalog') . " " . __('Inherit of parent category', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateInheritAlert';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Service details', 'servicecatalog') . " " . __('Inherit of parent category', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateGlue';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Stick with the next', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateIcon';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Icon');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateBackground';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Background color', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            $action_key = 'UpdateSize';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __("Update") . " " . __('Size', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;

            break;
        case 'Appliance':
            $myclass = PluginServicecatalogApplianceLink::class;
            $action_key = 'UseWithSC';
            $action_label = PluginServicecatalogMain::getTypeName() . " - " . __('Display on navigation menu and use it on ticket creation', 'servicecatalog');
            $actions[$myclass . MassiveAction::CLASS_ACTION_SEPARATOR . $action_key]
                = $action_label;
            break;
    }
    return $actions;
}


function plugin_servicecatalog_install_notifications()
{
    global $DB;

    $template = new NotificationTemplate();
    $dbu = new DbUtils();

    $query_id = "SELECT `id` FROM `glpi_notificationtemplates` 
                  WHERE `itemtype`='PluginServicecatalogTicketAppointment' AND `name` = 'Ticket appointments'";
    $result = $DB->query($query_id) or die($DB->error());

    if ($DB->numrows($result) > 0) {
        $templates_id = $DB->result($result, 0, 'id');
    } else {
        $tmp = [
            'name' => 'Ticket appointments',
            'itemtype' => 'PluginServicecatalogTicketAppointment',
            'date_mod' => $_SESSION['glpi_currenttime'],
            'comment' => '',
            'css' => '',
        ];
        $templates_id = $template->add($tmp);
    }
    if ($templates_id) {
        $translation = new NotificationTemplateTranslation();
        if (!$dbu->countElementsInTable(
            $translation->getTable(),
            ["notificationtemplates_id" => $templates_id]
        )) {
            $tmp['notificationtemplates_id'] = $templates_id;
            $tmp['language'] = '';
            $tmp['subject'] = '##lang.ticketappointement.title## - ##ticketappointement.name##';
            $tmp['content_text'] = '##ticketappointement.content##
                                             ##lang.ticketappointement.content##
                                             ##lang.ticketappointement.url## : ##ticketappointement.url##
                                             ##lang.ticketappointement.begin## : ##ticketappointement.begin##
                                             ##lang.ticketappointement.end## : ##ticketappointement.end##
                                             ##lang.ticketappointement.writer## : ##ticketappointement.writer##
                                             ##lang.ticketappointement.requester## : ##ticketappointement.requester##
                                             ##lang.ticketappointement.technician## : ##ticketappointement.technician##';
            $tmp['content_html'] = "&lt;p&gt;##ticketappointement.content##&lt;/p&gt;&lt;p&gt;##lang.ticketappointement.content##&lt;/p&gt;&lt;p&gt;
                                             ##lang.ticketappointement.url## : ##ticketappointement.url##&lt;/p&gt;&lt;p&gt;
                                             ##lang.ticketappointement.begin## : ##ticketappointement.begin##&lt;/p&gt;&lt;p&gt;
                                             ##lang.ticketappointement.end## : ##ticketappointement.end##&lt;/p&gt;&lt;p&gt;
                                             ##lang.ticketappointement.writer## : ##ticketappointement.writer##&lt;/p&gt;&lt;p&gt;
                                             ##lang.ticketappointement.requester## : ##ticketappointement.requester##&lt;/p&gt;&lt;p&gt;
                                             ##lang.ticketappointement.technician## : ##ticketappointement.technician##&lt;/p&gt;";

            $translation->add($tmp);
        }

        $notifs = [
            'New ticket appointement' => 'newappointement',
            'Cancel ticket appointement' => 'cancelappointement',
        ];

        $notification = new Notification();
        $notificationtemplate = new Notification_NotificationTemplate();
        foreach ($notifs as $label => $name) {
            if (!$dbu->countElementsInTable(
                "glpi_notifications",
                ["itemtype" => 'PluginServicecatalogTicketAppointment',
                    "event" => $name]
            )) {
                $tmp = [
                    'name' => $label,
                    'entities_id' => 0,
                    'itemtype' => 'PluginServicecatalogTicketAppointment',
                    'event' => $name,
                    'comment' => '',
                    'is_recursive' => 1,
                    'is_active' => 1,
                    'date_mod' => $_SESSION['glpi_currenttime'],
                ];
                $notification_id = $notification->add($tmp);

                $notificationtemplate->add(['notificationtemplates_id' => $templates_id,
                    'mode' => 'mailing',
                    'notifications_id' => $notification_id]);
            }
        }
    }
}

function plugin_datainjection_populate_servicecatalog()
{
    global $INJECTABLE_TYPES;
    $INJECTABLE_TYPES['PluginServicecatalogCategoryInjection'] = 'servicecatalog';
    $INJECTABLE_TYPES['PluginServicecatalogItilcategory_KeywordInjection'] = 'servicecatalog';
    $INJECTABLE_TYPES['PluginServicecatalogGroupInjection'] = 'servicecatalog';
}

function plugin_servicecatalog_replace_faq()
{
    $root = PLUGIN_SERVICECATALOG_WEBDIR;
    $script = " var root_servicecatalog_doc = '$root';
    (function ($) {
    
            $.fn.servicecatalog_replace_faq_postonly = function () {
                init();
                var object = this;
                // Start the plugin
                function init() {
                    $(document).ready(function () {
                        var hrefs = $('a[href$=\"helpdesk.faq.php\"]');
                        hrefs.each(function (href, value) {
                            if (value['pathname'].indexOf('plugins') < 0) {
                                $('a[href$=\"helpdesk.faq.php\"]').attr('href', root_servicecatalog_doc + '/front/faq.php');
                            }
                        });
                    });
                }
                return this;
            };
    }(jQuery));
    $(document).servicecatalog_replace_faq_postonly();";
    echo Html::scriptBlock($script);
}
